"""Read retained source sections; this program never attests or classifies."""
from primary2a import *
from review_dossier import spans
def show(cik,kind):
    ds=[d for d in gzread('event-documents.json.gz') if d['issuer_cik']==cik]
    if kind=='index':
        for n,d in enumerate(ds):print(n,d['accession'],d['document_type'],len(d.get('text') or ''),d['document_url'])
        return
    if kind.isdigit():
        print(ds[int(kind)]['text']);return
    for n,d in enumerate(ds):
        t=d.get('text') or '';intervals=[]
        if kind=='current' and d['document_type'] in {'8-K','8-K/A','6-K','8-A12B','DEFA14A'}:
            m=re.search(r'Item\s+[1-9]',t,re.I);a=m.start() if m else 0
            end=re.search(r'SIGNATURES?',t[a:],re.I);b=a+end.start() if end else len(t)
            intervals=[(a,b)]
        if kind=='equity' and d['document_type'] in {'10-Q','10-K','20-F'}:
            for pat in [r'CONSOLIDATED STATEMENT.{0,45}(?:EQUITY|DEFICIT)',r'(?:Shareholders[’\x27]?|Stockholders[’\x27]?)\s+Equity',r'Common stock',r'Share [Cc]apital']:
                matches=[m for m in re.finditer(pat,t,re.I) if m.start()>4000]
                for m in matches[:3]:intervals.append((max(0,m.start()-120),min(len(t),m.end()+3300)))
        if kind=='events':
            groups=read('event-candidates.json')['candidates']
            for g in groups:
                if g['issuer_cik']!=cik:continue
                for o in g['occurrences']:
                    if o['document_url']==d['document_url'] and not o.get('duplicate_context'):intervals.append((o['offset']-180,o['offset']+len(o['term'])+350))
        if kind=='terms' and d['document_type'].startswith('EX-'):
            for m in re.finditer(r'split|conversion|convertible|merger|common stock|ordinary shares|share capital|dividend|separation',t,re.I):intervals.append((m.start()-120,m.end()+430))
        sections=spans(t,intervals)
        if sections:
            print('\nDOCUMENT',n,d['accession'],d['document_type'],d['document_url'])
            for s in sections:print(s['start'],s['text'])
if __name__=='__main__':show(int(sys.argv[1]),sys.argv[2])

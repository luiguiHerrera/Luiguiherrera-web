"""Record the explicitly inspected SEC registrant covers, not a name matcher."""
from primary2a import *
from issuer_identity import identity_scope,verify

# Each entry was inspected against its official 13F issue/class and primary
# registrant/registered-security cover during this Wave 2A review.
REVIEWED_CIKS={1577552,93751,63908,217410,73309,1534701,732712,1065280,731766,937966,1404912,1543151,1138118,1140536,1144967,1408198,1467373,1707925,885725,858877,354950,1335258,1613103,27904,1900304,1381197,87347,89800,1094285,5272,14272,1739940,21076,1932393,1467858,62996,1103982,1114448,1781335,713676,80661,1260221,2969,29905,40987,882095,1131399,1645590,202058,920148,1099219,906163,1041061,899051,1783180,821189,40704,702165,73124,1136869}
SPECIAL={
1577552:'Alibaba sponsored ADS are the registered American Depositary Shares representing eight ordinary shares; the ordinary-share Hong Kong counters are a different instrument. The 1:8 deposit ratio identifies the instrument and is not a Q2 normalization factor.',
93751:'State Street $1 par common is distinct from Series G depositary shares representing preferred interests.',
217410:'Unilever sponsored ADR identifies the American Depositary Shares evidenced by receipts, each representing one ordinary share of nominal 3 1/2 pence. No event clearance follows from this identity proof.',
937966:'ASML ordinary shares have a separate New York share register held by JPMorgan Chase. This explicitly corroborates the official New York registry shares, rather than treating the issue as an ADS.',
1144967:'HDFC sponsored ADS are expressly registered as each representing three Rs.1 equity shares. Underlying equity and ADS quantities are not interchangeable.',
1138118:'CBRE Class A common $0.01 matches the specific official Class A entry.',
1467373:'Accenture Class A ordinary shares $0.0000225 match SHS CLASS A; no clearance propagates to another class.',
1900304:'Haleon registered ADS each represent two ordinary shares; the underlying shares and debt are distinct.',
1381197:'The registered common cover explicitly enumerates Class A outstanding shares separately from 400 Class B shares. The official issue is Class A; Class B is not covered.',
1103982:'Mondelez registered Class A common, no par value, matches the official Class A issue; notes listed below are separate.',
1114448:'Novartis ADS each represent one CHF0.49 ordinary share. Ordinary shares are listed only in connection with ADS registration.',
1131399:'GSK ADS each represent two ordinary shares of 31 1/4 pence; the listed debt classes are not this issue.',
1404912:'KKR common stock is distinct from Series D mandatory convertible preferred and subsidiary subordinated notes.',
1645590:'HPE common $0.01 is distinct from Series C mandatory convertible preferred.',
14272:'Bristol-Myers common $0.10 is distinct from Celgene contingent value rights and notes.',
1099219:'MetLife common $0.01 is distinct from Series A preferred and E/F depositary interests.',
73124:'Northern Trust $1.66 2/3 common is distinct from depositary shares representing Series E preferred.',
899051:'Allstate $0.01 common is distinct from preferred depositary shares and subordinated debentures.'}

def attest():
    s=Store();ins=gzread('candidate-owned-inventories.json.gz');plan={p['issuer_cik']:p for p in read('identity-document-plan.json')};out={};ds=[]
    for p in read('cik-candidates.json'):
        if p['prior_pilot_binding'] or p['comparisons_affected']<5 or len(p['candidates'])!=1:continue
        cik=p['candidates'][0]['cik']
        if cik not in REVIEWED_CIKS:continue
        e=plan[cik]
        assert s.ref(e['primary_url']) or s.ref(e['complete_submission_url']),'REVIEW_CANNOT_FETCH_ITS_OWN_UNSEEN_EVIDENCE'
        d=primary(e,s,'PRIMARY_IDENTITY');t=d['text'];m=re.search(r'Securities registered|Title of each class',t,re.I);assert m
        excerpt=t[m.start():m.start()+950]
        class_reason=SPECIAL.get(cik,'The inspected registered '+p['official_13f_class'][0]+' issue matches the official Q1/Q2 class. Other listed debt or preferred securities are outside this issue scope.')
        proof={'source_accession':d['accession'],'source_url':d['source_ref']['source_url'],'source_hash':d['source_ref']['sha256'],'document_hash':d['document_hash'],'source_section':'Registrant and registered securities cover','class_excerpt':excerpt}
        r={'security_id':p['security_id'],'cusip':p['cusip'],'issuer_cik':cik,'identity_scope_sha256':identity_scope(p),'proof_type':'UNIQUE_SEC_LEGAL_ENTITY_WITH_CLASS_EVIDENCE','identity_reason':'Primary registrant '+ins[str(cik)]['entity_name']+' and registered class were inspected together with the exact official 13F issue. SEC directory abbreviation expansion only found the candidate; it is not identity authority.','class_reason':class_reason,'proofs':[proof],'candidate_dispositions':{str(cik):'SELECTED_WITH_PRIMARY_REGISTRANT_AND_CLASS_PROOF'},'reviewer':'Codex primary agent; textual primary review, not independent human sign-off','review_authority':'IDENTITY_ONLY; NO_EVENT_CLEARANCE'}
        if cik==937966:
            pos=t.index('New York share register, held by JP Morgan Chase Bank');r['proofs'].append({**proof,'source_section':'Ordinary share registers and shareholder rights','class_excerpt':t[pos-160:pos+500]})
        result=verify(p,r,[d],ins,{d['source_ref']['source_url']:d['source_ref']['sha256']});assert result['status']=='CIK_VERIFIED',(p['security_id'],result)
        out[p['security_id']]=r;ds.append(d)
    assert len(out)==len(REVIEWED_CIKS),(len(out),len(REVIEWED_CIKS))
    write('identity-primary-reviews.json',out);gzwrite('reviewed-identity-primary-documents.json.gz',ds)
    print('EXPLICITLY_REVIEWED_NEW_CIK_BINDINGS',len(out),flush=True)
if __name__=='__main__':
    if sys.argv[1:]!=['--attest-inspected-primary-covers']:raise SystemExit('EXPLICIT_PRIMARY_REVIEW_REQUIRED')
    attest()

"""Attack real global authorization and the unchanged pilot certificate gates."""
import unittest,copy
from global_engine import *
from test_coverage import fixture,event,refresh,REF

class Wave2ACertificateAttacks(unittest.TestCase):
    def unknown(self,x):self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_same_issuer_wrong_class(self):
        x=fixture();x[0]['security_pair_id']='B';self.unknown(x)
    def test_same_ticker_wrong_cusip(self):
        x=fixture();x[0]['q2_cusip']='222222222';self.unknown(refresh(x))
    def test_stale_quarter(self):
        x=fixture();x[2]['economic_window']=['2026-07-01','2026-09-30'];self.unknown(refresh(x))
    def test_event_outside_period(self):
        x=fixture();ev=event();ev['effective_date']='2026-07-01';x[5]['events']=[ev];self.unknown(x)
    def test_foreign_missing_6k_forms(self):
        x=fixture();x[1]['regime']='FOREIGN_PRIVATE_ISSUER';self.unknown(refresh(x))
    def test_new_amendment_ignored(self):
        x=fixture();x[2]['entries'].append({'accession':'NEW_AMENDMENT','form':'10-Q/A'});self.unknown(refresh(x))
    def test_same_cusip_split_candidate_cannot_disappear(self):
        x=fixture();x[3].append({'candidate_id':'SAME_CUSIP_SPLIT','event_family':'SPLIT_OR_STOCK_DIVIDEND'});self.unknown(refresh(x))
    def test_class_conversion_not_issuer_wide(self):
        x=fixture();ev=event();ev['security_before']=['B'];x[5]['events']=[ev];self.unknown(x)
    def test_metadata_only_not_clear(self):
        x=fixture();x[4].clear();x[5]['narrative_coverage_beyond_keywords_reviewed']=False;self.unknown(refresh(x))
    def test_search_candidate_not_cik_authority(self):
        x=fixture();x[1]['status']='CANDIDATES_ONLY';self.unknown(refresh(x))
    def test_stable_issued_stock_not_a_clearance(self):
        x=fixture();x[5]['quarter_equity_units_reviewed']=True;x[5]['quantity_changing_events_reviewed']=False;self.unknown(x)

class Wave2AGlobalIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.e=GlobalBothEngine()
    def test_all_frozen_cases_have_both_sides(self):
        self.assertEqual(len(checked_target()['comparison_ids']),4162)
    def test_target_cannot_silently_expand(self):
        t=copy.deepcopy(self.e.selection);t['comparison_ids'].append('EXTRA');self.assertRaises(ValueError,checked_target,t)
    def test_target_cannot_shrink(self):
        t=copy.deepcopy(self.e.selection);t['comparison_ids'].pop();self.assertRaises(ValueError,checked_target,t)
    def test_new_and_exited_forbidden(self):
        rows=[r for r in self.e.engine.rows.values() if (r['previous_quantity'] is None) != (r['current_quantity'] is None)]
        for r in [next(r for r in rows if r['previous_quantity'] is None),next(r for r in rows if r['current_quantity'] is None)]:self.assertRaises(ValueError,self.e.evaluate,r['comparison_id'])
    def test_other_both_present_buckets_are_not_admitted(self):
        r=next(r for r in self.e.engine.rows.values() if r['comparison_id'] not in self.e.ids and r['previous_quantity'] is not None and r['current_quantity'] is not None)
        self.assertRaises(ValueError,self.e.evaluate,r['comparison_id'])
    def test_opaque_pilot_clearance_cannot_leak_to_unrelated_security(self):
        e=self.e;sec=next(s for s,c in e.certificates.items() if c['state']=='UNKNOWN');cid=next(c for c in e.ids if e.engine.rows[c]['security_id']==sec)
        old=e.certificates[sec];e.certificates[sec]=next(c for c in e.pilot.certificates.values() if c['state']=='VERIFIED_CLEAR_FOR_COMPARABILITY')
        try:self.assertRaises(ValueError,e.evaluate,cid)
        finally:e.certificates[sec]=old
    def test_packet_fingerprint_checked_at_application(self):
        e=self.e;sec=next(iter(e.pilot.certificates));cid=next(c for c in e.ids if e.engine.rows[c]['security_id']==sec);old=e.certificates[sec]['evidence_fingerprint'];e.certificates[sec]['evidence_fingerprint']='0'*64
        try:self.assertRaises(ValueError,e.evaluate,cid)
        finally:e.certificates[sec]['evidence_fingerprint']=old
    def test_verified_blocks_remain_indeterminate(self):
        for sec,c in self.e.certificates.items():
            if c['state']=='VERIFIED_BLOCK':
                cid=next(cid for cid in self.e.ids if self.e.engine.rows[cid]['security_id']==sec);self.assertEqual(self.e.evaluate(cid)['reported_status'],'INDETERMINATE')
    def test_unknown_does_not_resolve(self):
        sec=next(s for s,c in self.e.certificates.items() if c['state']=='UNKNOWN');cid=next(cid for cid in self.e.ids if self.e.engine.rows[cid]['security_id']==sec);self.assertEqual(self.e.evaluate(cid)['reported_status'],'INDETERMINATE')
    def test_manager_perimeter_conflict_is_still_authoritative(self):
        e=self.e;cid=next(cid for cid in sorted(e.pilot.ids) if e.pilot.certificates[e.engine.rows[cid]['security_id']]['state']=='VERIFIED_CLEAR_FOR_COMPARABILITY')
        d=next(d for d in e.engine.comparisons[cid]['dependencies'] if d['evidence_type']=='MANAGER_PERIMETER');node=e.engine.byid[d['evidence_id']];old=copy.deepcopy(node);node['status']='UNKNOWN'
        try:self.assertEqual(e.evaluate(cid)['reported_status'],'INDETERMINATE')
        finally:node.clear();node.update(old)
    def test_pilot_comparison_is_exact(self):
        from closure import load
        r=load('pilot-results.json')['comparison_results'][0];self.assertEqual(self.e.evaluate(r['comparison_id']),r)

if __name__=='__main__':unittest.main()

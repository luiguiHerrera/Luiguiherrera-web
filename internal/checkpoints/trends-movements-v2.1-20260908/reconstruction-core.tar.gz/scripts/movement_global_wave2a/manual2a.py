"""Independent retained-XML reconstruction; expectations require a separate review."""
from context2a import *
from global_engine import GlobalBothEngine
from fractions import Fraction
from collections import Counter
import xml.etree.ElementTree as ET

def parse_rows(body,sec):
    cusip,put,unit=sec.split('|');found=[]
    for raw in re.findall(r'<(?:[\w.-]+:)?infoTable\b[^>]*>.*?</(?:[\w.-]+:)?infoTable\s*>',body,re.S|re.I):
        clean=re.sub(r'(<\/?)[\w.-]+:',r'\1',raw);root=ET.fromstring(clean)
        fields={n.tag.rsplit('}',1)[-1].lower():(n.text or '').strip() for n in root.iter()}
        if fields.get('cusip')!=cusip or fields.get('sshprnamttype')!=unit or fields.get('putcall','LONG').upper()!=put:continue
        q=Fraction(fields['sshprnamt']);found.append({'quantity':str(q),'security_class':fields.get('titleofclass'),'issuer_name':fields.get('nameofissuer'),'raw_xml':raw,'raw_xml_sha256':sha(raw.encode())})
    return found

def dossier():
    e=GlobalBothEngine();out=read('both-present-results.json');qualified={r['comparison_id']:r for r in out['comparison_results'] if r['reported_status']!='INDETERMINATE'}
    old=prior_read('pilot-results.json',ROOT/'internal/trends-movements/wave1d')['manual_expected_by_comparison_id'];chosen=list(sorted(set(old)&set(qualified)));pk=read('target-packets.json')
    # Every newly resolved packet, then every available manager, then a balanced
    # sample. No >=50-comparison or normalized family can evade selection.
    for p in pk:
        possible=[cid for cid in p['comparison_ids'] if cid in qualified]
        if possible and (p['security_id'] not in {e.engine.rows[c]['security_id'] for c in chosen}):chosen.append(possible[0])
    for manager in sorted({r['manager_id'] for r in e.engine.rows.values() if r['comparison_id'] in e.ids}):
        if manager not in {e.engine.rows[c]['manager_id'] for c in chosen}:
            possible=[c for c in sorted(qualified) if e.engine.rows[c]['manager_id']==manager]
            if possible:chosen.append(possible[0])
    while len(chosen)<110:
        counts=Counter(e.engine.rows[c]['manager_id'] for c in chosen)
        remaining=[c for c in qualified if c not in chosen]
        if not remaining:break
        chosen.append(min(remaining,key=lambda c:(counts[e.engine.rows[c]['manager_id']],c)))
    s=Store();cache={};checks=[]
    for cid in chosen:
        row=e.engine.rows[cid];r=qualified[cid];sec=row['security_id'];primary={}
        for side in ['previous','current']:
            records=[]
            for u in row[side+'_sources']:
                if u not in cache:cache[u]=s.bytes(u).decode('utf-8',errors='strict')
                hits=parse_rows(cache[u],sec);assert hits,('NO_PRIMARY_ROWS',cid,side)
                records.extend({**x,'source_ref':s.compact_ref(u)} for x in hits)
            total=sum((Fraction(x['quantity']) for x in records),Fraction(0));assert total==Fraction(str(row[side+'_quantity'])),('PRIMARY_AGGREGATION_CONFLICT',cid,side)
            assert len({x['security_class'] for x in records})==1,('CLASS_AGGREGATION_CONFLICT',cid)
            primary[side]={'quarter':row[side+'_quarter'],'quantity':str(total),'rows':records}
        c=e.scopes[sec][1]
        checks.append({'comparison_id':cid,'security_id':sec,'manager_id':row['manager_id'],'sic_group':'SEC_SIC_2_DIGIT:'+str(c['sic'])[:2] if c.get('sic') else 'UNKNOWN','regime':c.get('regime'),'primary_observations':primary,'packet_state':r['corporate_event_certificate']['state'],'certificate_sha256':sha(r['corporate_event_certificate']),'normalization_numerator':r['normalization_numerator'],'normalization_denominator':r['normalization_denominator'],'preserved_manual_expectation':old.get(cid),'review_status':'PRESERVED_PRIOR_EXPLICIT_REVIEW' if cid in old else 'NEW_EXPECTATION_REVIEW_REQUIRED'})
    write('manual-primary-dossier.json',{'target_sha256':sha(e.selection),'sample_rule':'All newly resolved packets, 73 preserved reviewed comparisons, all available resolved managers, then balance managers to at least 110. Exact primary XML independently parsed; no live holdings.','checks':checks,'available_target_managers':19,'requested_manager_minimum':20,'twenty_manager_requirement':'NOT_MET_IN_19_MANAGER_TARGET'})
    for n,c in enumerate(checks):
        if not c['preserved_manual_expectation']:print(n,c['comparison_id'],c['primary_observations']['previous']['quantity'],'->',c['primary_observations']['current']['quantity'],c['normalization_numerator'],c['normalization_denominator'],[x['security_class'] for x in c['primary_observations']['previous']['rows']],[x['security_class'] for x in c['primary_observations']['current']['rows']])

def audit():
    dossier=read('manual-primary-dossier.json');new=read('manual-new-expectations.json');out=read('both-present-results.json');by={r['comparison_id']:r for r in out['comparison_results']};s=Store();cache={};fp=[];checks=dossier['checks']
    assert set(new)=={c['comparison_id'] for c in checks if not c['preserved_manual_expectation']},'UNREVIEWED_SAMPLE'
    for c in checks:
        cid=c['comparison_id'];r=by[cid];expected=c['preserved_manual_expectation'] or new[cid]['expected_reported_status']
        assert sha(r['corporate_event_certificate'])==c['certificate_sha256'],'STALE_MANUAL_PACKET'
        if not c['preserved_manual_expectation']:
            assert new[cid]['primary_dossier_row_sha256']==sha(c) and new[cid]['primary_rows_textually_reviewed'] is True
        for side,p in c['primary_observations'].items():
            hits=[]
            for u in dict.fromkeys(row['source_ref']['source_url'] for row in p['rows']):
                if u not in cache:cache[u]=s.bytes(u).decode()
                hits.extend(parse_rows(cache[u],c['security_id']))
            assert sum((Fraction(x['quantity']) for x in hits),Fraction(0))==Fraction(p['quantity'])
            for row in p['rows']:
                u=row['source_ref']['source_url'];assert s.ref(u)['sha256']==row['source_ref']['sha256'];assert row['raw_xml'] in cache[u] and sha(row['raw_xml'].encode())==row['raw_xml_sha256']
        if expected!=r['reported_status']:fp.append(cid)
    secs={c['security_id'] for c in checks};managers={c['manager_id'] for c in checks};sics={c['sic_group'] for c in checks if c['sic_group']!='UNKNOWN'}
    factors={str(c['normalization_numerator'])+'/'+str(c['normalization_denominator']) for c in checks}
    allnorm={r['security_id'] for r in out['comparison_results'] if r['corporate_event_certificate']['state']=='VERIFIED_EVENT_NORMALIZATION_AVAILABLE'}
    high={s for s,n in Counter(r['security_id'] for r in out['comparison_results'] if r['reported_status']!='INDETERMINATE').items() if n>=50}
    assert allnorm<=secs and high<=secs
    result={'manual_checks':len(checks),'new_manual_checks':len(new),'preserved_manual_checks':len(checks)-len(new),'distinct_securities':len(secs),'distinct_managers':len(managers),'distinct_SIC_groups':len(sics),'normalization_families_checked':sorted(factors),'all_non_1_1_families_checked':allnorm<=secs,'event_normalized_families_checked':len(allnorm),'all_packets_resolving_50_plus_checked':high<=secs,'packets_resolving_50_plus':len(high),'false_positives_observed':len(fp),'false_positive_ids':fp,'confirmed_false_negatives':0,'confirmed_false_negatives_basis':'No independently established comparable unresolved case; pending evidence is unevaluable, not a confirmed negative.','statistical_zero_error_claim':False,'reviewer':'Codex primary agent textual review; not independent human sign-off','minimum_checks_pass':len(checks)>=100 and len(secs)>=50 and len(sics)>=10,'minimum_twenty_managers_pass':len(managers)>=20,'available_target_managers':19,'state':'PASS' if len(checks)>=100 and len(secs)>=50 and len(sics)>=10 and len(managers)>=20 and not fp else 'INCOMPLETE_TWENTY_MANAGER_REQUIREMENT' if not fp else 'FAIL_FALSE_POSITIVE'}
    write('manual-audit.json',result);print(canonical(result))
if __name__=='__main__':dossier() if sys.argv[1:]==['dossier'] else audit()

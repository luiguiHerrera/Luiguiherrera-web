"""Freeze the known lower-risk BOTH_PRESENT set; excluded cases stay visible."""
from context2a import *
from collections import Counter,defaultdict

def run():
    sys.path.insert(0,str(ROOT/'scripts/movement_evidence_wave1'));from build import baseline
    rows=corpus();bs={r['comparison_id']:r for r in baseline()}
    both=[r for r in rows if r['previous_quantity'] is not None and r['current_quantity'] is not None]
    target=[r for r in both if bs[r['comparison_id']]['resolution_bucket']=='EVIDENCE_RESOLVABLE']
    assert len(target)==4162
    ids=sorted(r['comparison_id'] for r in target)
    frozen={'scope':'FROZEN_4162_EVIDENCE_RESOLVABLE_BOTH_PRESENT','corpus_sha256':EXPECTED_CORPUS,'previous_quarter':'2026-03-31','current_quarter':'2026-06-30','comparison_ids':ids}
    if (OUT/'target.json').exists():assert read('target.json')==frozen,'TARGET_DRIFT'
    write('target.json',frozen)
    bindings={b['security_pair_id']:b for b in prior_read('security-bindings.json',ROOT/'internal/trends-movements/wave1b')}
    snapshot=json.loads(gzip.decompress((ROOT/'lib/trends/capital/generated/snapshot.json.gz').read_bytes()))
    public={x['id']:x for x in snapshot['companies']};allfreq=Counter(r['security_id'] for r in rows);groups=defaultdict(list)
    for r in target:groups[r['security_id']].append(r)
    packets=[]
    for sec,rs in groups.items():
        p=public.get(sec,{})
        n=len(rs);packets.append({'security_id':sec,'comparisons_affected':n,'manager_ids':sorted({r['manager_id'] for r in rs}),'managers_affected':len({r['manager_id'] for r in rs}),'comparison_ids':sorted(r['comparison_id'] for r in rs),'security_frequency':allfreq[sec],'public_overlap_presence':sec in public,'trend_links':p.get('trend_ids',[]),'binding':bindings[sec],'leverage_tier':'20_PLUS' if n>=20 else '10_19' if n>=10 else '5_9' if n>=5 else '2_4' if n>=2 else '1'})
    packets.sort(key=lambda p:(-p['comparisons_affected'],-p['managers_affected'],-p['security_frequency'],-int(p['public_overlap_presence']),-len(p['trend_links']),p['security_id']))
    write('target-packets.json',packets)
    write('target-census.json',{'corpus_count':len(rows),'all_both_present':len(both),'target_count':len(target),'target_sha256':sha(frozen),'security_pairs':len(packets),'manager_count':len({r['manager_id'] for r in target}),'all_both_present_manager_count':len({r['manager_id'] for r in both}),'excluded_both_present_by_baseline_bucket':dict(Counter(bs[r['comparison_id']]['resolution_bucket'] for r in both if r['comparison_id'] not in set(ids))),'presence_transitions_in_evidence_resolvable':sum(bs[r['comparison_id']]['resolution_bucket']=='EVIDENCE_RESOLVABLE' and r not in both for r in rows),'leverage_tiers':dict(Counter(p['leverage_tier'] for p in packets)),'minimum_20_manager_audit':'IMPOSSIBLE_IN_FROZEN_19_MANAGER_TARGET; USER_CLARIFICATION_PENDING','unknown_rate_pass_threshold':.05,'unknown_rate_threshold_basis':'Conservative predeclared operational threshold; not statistical confidence or a publication gate.'})
    print(canonical(read('target-census.json')))
if __name__=='__main__':run()

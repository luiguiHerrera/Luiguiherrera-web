"""All mappings here are candidates only until primary class evidence is reviewed."""
from context2a import *
from collections import Counter
from concurrent.futures import ThreadPoolExecutor,as_completed

def key(s):return ' '.join(re.sub(r'[^A-Z0-9 ]',' ',(s or '').upper()).split())
# Search expansion ONLY. These words never establish an issuer/class binding.
SEARCH_WORDS={'HLDG':'HOLDING','HLDGS':'HOLDINGS','HLDNGS':'HOLDINGS','SYS':'SYSTEMS','INTL':'INTERNATIONAL','MTRS':'MOTORS','FINL':'FINANCIAL','SVCS':'SERVICES','RES':'RESOURCES','SOUTHN':'SOUTHERN','STR':'STREET','TR':'TRUST','COS':'COMPANIES','NATL':'NATIONAL','CTZNS':'CITIZENS','BK':'BANK','ELEC':'ELECTRIC','PWR':'POWER','PETE':'PETROLEUM','RESH':'RESEARCH','LABS':'LABORATORIES','TECH':'TECHNOLOGIES'}
def search_key(s):
    words=[SEARCH_WORDS.get(w,w) for w in key(s).split()]
    return ' '.join(w for w in words if w not in {'THE','INC','INCORPORATED','CORP','CORPORATION','CO','COMPANY','LTD','LIMITED','PLC','NV','DEL','DE','NEW'})
SEARCH_NAMES={'78462F103|LONG|SH':'SPDR S&P 500 ETF TRUST','N07059210|LONG|SH':'ASML HOLDING NV','009158106|LONG|SH':'AIR PRODUCTS & CHEMICALS INC'}
def run():
    prior=prior_read('issuer-cik-bindings.json',ROOT/'internal/trends-movements/wave1b')
    ps=prior_read('issuer-security-packets.json',ROOT/'internal/trends-movements/wave1b')
    bypid={p['packet_id']:p for p in prior};bysec={b['security_pair_id']:bypid[p['packet_id']] for p in ps for b in p['securities']}
    pilot={c['security_id']:c for c in prior_read('pilot-cik-bindings.json')}
    s=Store();index=s.json('https://www.sec.gov/files/company_tickers_exchange.json');out=[]
    indexed=[(cik,name,key(name),search_key(name)) for cik,name,ticker,exchange in index['data']]
    for p in read('target-packets.json'):
        sec=p['security_id'];b=p['binding'];old=bysec.get(sec,{});candidates={r['cik']:{'cik':r['cik'],'name':r['name'],'basis':'EXACT_SEC_DIRECTORY_CANDIDATE_ONLY'} for r in old.get('directory_candidates',[])}
        if old.get('cik'):candidates[old['cik']]={'cik':old['cik'],'name':None,'basis':'PREVIOUS_CIK_CANDIDATE_REQUIRES_CLASS_PROOF'}
        if sec in pilot:
            pc=pilot[sec];candidates[pc['issuer_cik']]={'cik':pc['issuer_cik'],'name':pc.get('sec_entity_name'),'basis':'PRESERVED_PILOT_CLASS_VERIFIED'}
        official=key(b.get('issuer_name_q1'))
        searched=search_key(SEARCH_NAMES.get(sec,b.get('issuer_name_q1')))
        for cik,name,legal,search_legal in indexed:
            # Literal prefix/normalized index matches only widen discovery, never identity authority.
            if official and (legal==official or (len(official)>=15 and (legal.startswith(official) or official.startswith(legal)))):
                candidates.setdefault(cik,{'cik':cik,'name':name,'basis':'SEC_INDEX_LITERAL_NAME_CANDIDATE_ONLY'})
            if searched == search_legal:
                candidates.setdefault(cik,{'cik':cik,'name':name,'basis':'EXPANDED_SEARCH_WORDS_CANDIDATE_ONLY; NO_IDENTITY_AUTHORITY'})
        out.append({'security_id':sec,'cusip':b['q1_cusip'],'official_13f_name':[b['issuer_name_q1'],b['issuer_name_q2']],'official_13f_class':[b['class_q1'],b['class_q2']],'candidates':sorted(candidates.values(),key=lambda x:x['cik']),'prior_pilot_binding':pilot.get(sec),'status':'CANDIDATES_ONLY','priority_rank':len(out)+1,'comparisons_affected':p['comparisons_affected']})
    write('cik-candidates.json',out)
    print(canonical({'packets':len(out),'candidate_counts':dict(Counter(len(p['candidates']) for p in out)),'unique_ciks':len({c['cik'] for p in out for c in p['candidates']})}))

def retrieve():
    s=Store();fail=[];ciks=[]
    for p in read('cik-candidates.json'):
        for c in p['candidates']:
            if c['cik'] not in ciks:ciks.append(c['cik'])
    def task(cik):
        u=f'https://data.sec.gov/submissions/CIK{cik:010d}.json';s.get(u,'ISSUER_METADATA');d=s.json(u);assert int(d['cik'])==cik
        for f in d['filings'].get('files',[]):
            if f['filingFrom']<='2026-08-14' and f['filingTo']>='2026-03-01':s.get('https://data.sec.gov/submissions/'+f['name'],'ISSUER_HISTORY')
        return cik
    with ThreadPoolExecutor(max_workers=4) as ex:
        jobs={ex.submit(task,c):c for c in ciks}
        for i,f in enumerate(as_completed(jobs),1):
            try:f.result()
            except Exception as e:fail.append({'cik':jobs[f],'error':str(e)})
            if i%100==0:print('METADATA',i,'/',len(ciks),'failures',len(fail),flush=True)
    write('metadata-retrieval.json',{'candidate_ciks':ciks,'failures':fail,'completed':len(ciks)-len(fail)})
    print('METADATA_COMPLETE',len(ciks),'FAILURES',len(fail))
if __name__=='__main__':retrieve() if sys.argv[1:]==['retrieve'] else run()

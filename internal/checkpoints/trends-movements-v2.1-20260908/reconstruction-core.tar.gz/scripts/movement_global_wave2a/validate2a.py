"""Current-remote app checks and immutable earlier-wave tests; separate logs."""
from context2a import *
import subprocess,os,time

def run(names):
    specs={c['name']:c['command'] for c in prior_read('validation.json')['checks']}
    # The fetched remote adds tests beyond the previous pilot base.
    specs['app-tests']=specs['app-tests'][:7]+sorted(str(p.relative_to(ROOT)) for directory in ['lib','components'] for p in (ROOT/directory).rglob('*') if p.name.endswith(('.test.ts','.test.tsx','.test.mts','.test.mjs')))
    # Preserve the node runner flags; source test files begin after --test.
    original=next(c['command'] for c in prior_read('validation.json')['checks'] if c['name']=='app-tests')
    specs['app-tests']=original[:original.index('--test')+1]+sorted(str(p.relative_to(ROOT)) for directory in ['lib','components'] for p in (ROOT/directory).rglob('*') if p.name.endswith(('.test.ts','.test.tsx','.test.mts','.test.mjs')))
    specs['wave1d-python']=['python3','-B','-m','unittest','discover','-s','scripts/movement_pilot_wave1d','-p','test_*.py']
    specs['wave2a-python']=['python3','-B','-m','unittest','discover','-s','scripts/movement_global_wave2a','-p','test_*.py']
    specs['git-diff-check']=['git','diff','--check']
    env=dict(os.environ);env['PATH']='/private/tmp/npm-audit-remediation-20260907/node-v22.23.2-darwin-arm64/bin:'+env['PATH'];env['PYTHONDONTWRITEBYTECODE']='1'
    env['STAT_LEVELS_QUALIFICATION_DIR']='/private/tmp/september-2026-final-on-a933-evidence/final-statistical-qualification'
    (OUT/'validation-logs').mkdir(exist_ok=True)
    for name in names:
        if name in {'source-audit','offline-replay'}:raise ValueError('DO_NOT_MUTATE_PRIOR_WAVES')
        log=OUT/'validation-logs'/(name+'.log');start=time.monotonic()
        with log.open('wb') as f:p=subprocess.run(specs[name],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
        rec={'name':name,'command':specs[name],'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-start,2),'log':str(log.relative_to(OUT)),'log_sha256':sha(log.read_bytes())}
        write('validation-'+name+'.json',rec);print(canonical(rec),flush=True)
if __name__=='__main__':run(sys.argv[1:])

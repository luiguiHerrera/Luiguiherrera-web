"""Observed resolution disparity within the frozen BOTH_PRESENT denominator."""
from context2a import *
from global_engine import GlobalBothEngine
from collections import Counter,defaultdict
import math

def run():
    out=read('both-present-results.json');e=GlobalBothEngine();rs=out['comparison_results'];raw={r['comparison_id']:r for r in corpus()};pk={p['security_id']:p for p in read('target-packets.json')}
    mids={raw[r['comparison_id']]['manager_id'] for r in rs};breadth=Counter(r['manager_id'] for r in raw.values() if r['manager_id'] in mids)
    large=set(sorted(mids,key=lambda m:(breadth[m],m))[-math.ceil(len(mids)/4):]);frequency=Counter(r['security_id'] for r in rs)
    grouped={k:defaultdict(list) for k in ['manager','portfolio_breadth','security_frequency','trend_category','sector_SIC','filing_regime','event_complexity']}
    per=[]
    for r in rs:
        row=raw[r['comparison_id']];sec=r['security_id'];b,c,i,g,d=e.scopes[sec];n=frequency[sec];families={x['event_family'] for x in g};known_identity=c.get('status')=='CIK_VERIFIED'
        event='PRIMARY_COVERAGE_UNAVAILABLE' if not d else 'NO_CLUSTERED_CANDIDATE' if not families else 'ONE_FAMILY' if len(families)==1 else 'TWO_OR_THREE_FAMILIES' if len(families)<=3 else 'FOUR_PLUS_FAMILIES'
        keys={'manager':row['manager_id'],'portfolio_breadth':'LARGE_TOP_QUARTILE' if row['manager_id'] in large else 'OTHER','security_frequency':'ONE_MANAGER' if n==1 else 'TWO_TO_FOUR' if n<5 else 'FIVE_TO_NINE' if n<10 else 'TEN_OR_MORE','trend_category':'+'.join(sorted(pk[sec]['trend_links'])) or 'UNMAPPED','sector_SIC':'SEC_SIC_2_DIGIT:'+str(c['sic'])[:2] if known_identity and c.get('sic') else 'UNKNOWN_IDENTITY_OR_SIC','filing_regime':c.get('regime','UNSUPPORTED_OR_INDETERMINATE') if known_identity else 'UNVERIFIED_ISSUER_REGIME','event_complexity':event}
        for dim,key in keys.items():grouped[dim][key].append(r)
        per.append({'comparison_id':r['comparison_id'],**keys})
    dimensions={};failed=[]
    for dim,gs in grouped.items():
        st={k:{'comparisons':len(v),'resolved':sum(r['reported_status']!='INDETERMINATE' for r in v),'unresolved':sum(r['reported_status']=='INDETERMINATE' for r in v),'resolution_rate':round(sum(r['reported_status']!='INDETERMINATE' for r in v)/len(v),8)} for k,v in sorted(gs.items())}
        rates=[v['resolution_rate'] for v in st.values()];reasons=[]
        if max(rates)>0 and min(rates)==0:reasons.append('NONEMPTY_GROUP_HAS_ZERO_RESOLUTION')
        elif min(rates)>0 and max(rates)>2*min(rates):reasons.append('OBSERVED_RATE_DISPARITY_OVER_TWO_FOLD')
        state='FAIL' if reasons else 'INDETERMINATE' if not max(rates) else 'PASS'
        if state=='FAIL':failed.append(dim)
        dimensions[dim]={'state':state,'groups':st,'reasons':reasons}
    result={'BOTH_PRESENT_RESOLUTION_BIAS_CHECK':'FAIL' if failed else 'PASS','BOTH_PRESENT_BIAS_DIMENSIONS_FAILED':failed,'FULL_MOVEMENT_BIAS_CHECK':'FAIL_EXPECTED_PRESENCE_TRANSITIONS_UNRESOLVED','scope':'Exact frozen 4162 BOTH_PRESENT; presence transitions excluded from this phase-specific test.','target_sha256':out['target_sha256'],'dimensions':dimensions,'definitions':{'portfolio_breadth':'Full frozen-corpus security breadth among the 19 target managers; largest quartile, ties deterministic.','security_frequency':'Number of target manager comparisons for the issue; never a post-resolution count.','sector_SIC':'Verified SEC issuer SIC two-digit group. UNKNOWN is missing-data status, not a sector.','filing_regime':'Only primary-verified issuer bindings carry a filing regime; candidate metadata is not promoted.','event_complexity':'Distinct inherited clustering families in scoped retained event documents; not raw keyword occurrences and not verified event count. Missing primary coverage is explicit.','criterion':'Preserved operational disparity rule: nonempty zero-resolution group or >2x observed rate disparity. Descriptive, not a statistical test or causal estimate.'},'publication_locked':True}
    write('resolution-bias.json',result);write('comparison-strata.json',per);print(canonical({k:v for k,v in result.items() if k not in {'dimensions','definitions'}}))
if __name__=='__main__':run()

"""Report measured coverage without converting incomplete review into a pass."""
from context2a import *
from primary2a import gzread
from collections import Counter

def ledgers():
    out=read('both-present-results.json');certs={c['security_id']:c for c in read('corporate-event-coverage.json')};identities={i['security_id']:i for i in read('issuer-cik-bindings.json')};candidates={c['security_id']:c for c in read('cik-candidates.json')};results={r['comparison_id']:r for r in out['comparison_results']};ds=gzread('identity-primary-documents.json.gz');ed=gzread('event-documents.json.gz');available={d['issuer_cik'] for d in ds};queue=[];tiers={}
    for p in read('target-packets.json'):
        sec=p['security_id'];i=identities[sec];c=certs[sec];cs=candidates[sec]['candidates'];gaps=[];ciks={x['cik'] for x in cs};scoped=[d for d in ed if d['issuer_cik']==i.get('issuer_cik')]
        if c['state']=='UNKNOWN':
            if not p['binding']['authoritative_period_identity']:gaps.append('OFFICIAL_QUARTER_SECURITY_IDENTITY_NOT_AUTHORITATIVE')
            if i['status']=='CIK_AMBIGUOUS':gaps.append('MULTIPLE_CIKS_NEED_PRIMARY_DISAMBIGUATION')
            elif i['status']!='CIK_VERIFIED':
                gaps.append('NO_CIK_DISCOVERY_CANDIDATE' if not cs else 'RETAINED_IDENTITY_PRIMARY_AWAITS_CLASS_REVIEW' if available&ciks else 'APPROPRIATE_IDENTITY_PRIMARY_UNAVAILABLE')
            if i['status']=='CIK_VERIFIED':
                gaps.append('RETAINED_EVENT_PRIMARY_REVIEW_INCOMPLETE' if scoped else 'REGIME_INVENTORY_EVENT_PRIMARY_AND_EXHIBIT_REVIEW_PENDING')
            if any(d.get('mode')=='PDF_REVIEW_REQUIRED' for d in scoped):gaps.append('RETAINED_PDF_CLASS_NARRATIVE_NOT_CLOSED')
        resolved=sum(results[cid]['reported_status']!='INDETERMINATE' for cid in p['comparison_ids'])
        row={'rank':p.get('rank',len(queue)+1),'security_id':sec,'comparisons_affected':p['comparisons_affected'],'managers_affected':p['managers_affected'],'security_frequency':p['security_frequency'],'public_overlap_presence':p['public_overlap_presence'],'trend_links':p['trend_links'],'tier':p['leverage_tier'],'official_binding_status':p['binding']['binding_status'],'authoritative_period_identity':p['binding']['authoritative_period_identity'],'cik_discovery_attempted':True,'candidate_ciks':sorted(ciks),'cik_status':i['status'],'verified_cik':i.get('issuer_cik'),'regime':i.get('regime') if i['status']=='CIK_VERIFIED' else 'UNVERIFIED_ISSUER_REGIME','packet_state':c['state'],'resolved_comparisons':resolved,'gaps':gaps,'certificate_failed_checks':c['failed_checks'],'next_step':'NONE' if c['state']!='UNKNOWN' else 'Close these explicit evidence gaps in frozen rank order; use retained sources before new retrieval.'}
        queue.append(row);t=tiers.setdefault(p['leverage_tier'],Counter());t['packets']+=1;t['comparisons']+=p['comparisons_affected'];t['resolved']+=resolved;t[c['state']]+=1
    write('packet-review-ledger.json',queue);write('remaining-review-queue.json',[r for r in queue if r['packet_state']=='UNKNOWN'])
    write('tier-yield.json',{k:{**dict(v),'comparison_resolution_rate':v['resolved']/v['comparisons'] if v['comparisons'] else None} for k,v in tiers.items()})
    return queue

def run():
    q=ledgers();pre=read('preflight.json');census=read('target-census.json');out=read('both-present-results.json');manual=read('manual-audit.json');bias=read('resolution-bias.json');source=read('source-audit.json');isolation=read('isolation-audit.json');offline=read('offline-replay.json');ids=read('issuer-cik-bindings.json');packets=read('target-packets.json');counts=Counter(i['status'] for i in ids);states=out['packet_counts'];tiers=Counter(p['leverage_tier'] for p in packets)
    resolved=[r for r in out['comparison_results'] if r['reported_status']!='INDETERMINATE'];raw={r['comparison_id']:r for r in corpus()};managers={raw[r['comparison_id']]['manager_id'] for r in resolved};secs={r['security_id'] for r in resolved};unknown=states['UNKNOWN']/len(packets)
    validation=[read(p.name) for p in sorted(OUT.glob('validation-*.json'))];assert all(c['exit_code']==0 for c in validation);assert offline['state']==isolation['state']==source['state']=='PASS'
    assert read('metadata-clustering-replay.json')['state']=='PASS'
    anticipated={str(p.relative_to(ROOT)) for d in [OUT,ROOT/'scripts/movement_global_wave2a'] for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    anticipated.update(str((OUT/f).relative_to(ROOT)) for f in ['REPORT.md','RESULT.json','files-created.json'])
    testnames={'app-tests','baseline-python','wave1-python','wave1b-python','xml','wave1c-python','wave1d-python','wave2a-python'};testcount=0
    for c in validation:
        if c['name'] in testnames:
            t=(OUT/c['log']).read_text();m=re.search(r'(?:Ran |# tests )(\d+)',t);assert m;testcount+=int(m[1])
    result={
    'STATE':'WAVE_2A_INCOMPLETE_EVIDENCE_COVERAGE','BASE_COMMIT':pre['base_commit'],'REMOTE_HEAD':pre['remote_head'],
    'MOVEMENT_CORPUS_COUNT':8137,'MOVEMENT_CORPUS_SHA256':EXPECTED_CORPUS,'MOVEMENT_CORPUS_CHANGED':'NO',
    'BOTH_PRESENT_TARGET_COUNT':4162,'BOTH_PRESENT_TARGET_SHA256':out['target_sha256'],
    'PILOT_REPLAY':out['pilot_replay'],'PILOT_TOTAL_RESOLVED':487,'PILOT_PACKET_CLEAR':64,'PILOT_PACKET_VERIFIED_BLOCK':2,'PILOT_PACKET_UNKNOWN':0,
    'TARGET_SECURITY_PAIRS':len(packets),'TARGET_SECURITY_BINDINGS_ALREADY_VERIFIED':sum(p['binding']['authoritative_period_identity'] for p in packets),'TARGET_SECURITY_BINDINGS_NEWLY_VERIFIED':0,'TARGET_SECURITY_BINDINGS_UNKNOWN':sum(not p['binding']['authoritative_period_identity'] for p in packets),
    'CIK_VERIFIED_TOTAL':counts['CIK_VERIFIED'],'CIK_AMBIGUOUS_TOTAL':counts['CIK_AMBIGUOUS'],'CIK_UNRESOLVED_TOTAL':counts['CIK_NOT_FOUND'],
    'PACKETS_TOTAL':len(packets),'PACKETS_CLEAR':states.get('VERIFIED_CLEAR_FOR_COMPARABILITY',0),'PACKETS_EVENT_NORMALIZED':states.get('VERIFIED_EVENT_NORMALIZATION_AVAILABLE',0),'PACKETS_VERIFIED_BLOCK':states['VERIFIED_BLOCK'],'PACKETS_UNKNOWN':states['UNKNOWN'],
    'BOTH_PRESENT_RESOLVED':out['both_present_resolved'],'BOTH_PRESENT_BLOCKED':out['both_present_blocked'],'BOTH_PRESENT_UNKNOWN':out['both_present_unknown'],
    **{k:out['resolved_status_counts'].get(k,0) for k in ['REPORTED_INCREASED','REPORTED_REDUCED','REPORTED_UNCHANGED']},'NEW':0,'EXITED':0,
    'BOTH_PRESENT_COMPLETENESS':len(resolved)/4162,'BOTH_PRESENT_MANAGER_COVERAGE':{'resolved_managers':len(managers),'target_managers':19,'fraction':len(managers)/19},'BOTH_PRESENT_SECURITY_COVERAGE':{'resolved_securities':len(secs),'target_securities':len(packets),'fraction':len(secs)/len(packets)},
    'PACKETS_AFFECTING_20_PLUS':0,'PACKETS_10_19':10,'PACKETS_5_9':121,'PACKETS_2_4':849,'PACKETS_1':1155,
    'MANUAL_CHECKS':manual['manual_checks'],'DISTINCT_SECURITIES_MANUALLY_CHECKED':manual['distinct_securities'],'DISTINCT_MANAGERS_MANUALLY_CHECKED':manual['distinct_managers'],'NORMALIZATION_FAMILIES_CHECKED':manual['normalization_families_checked'],'FALSE_POSITIVES_OBSERVED':manual['false_positives_observed'],'CONFIRMED_FALSE_NEGATIVES':manual['confirmed_false_negatives'],
    **{k:bias[k] for k in ['BOTH_PRESENT_RESOLUTION_BIAS_CHECK','BOTH_PRESENT_BIAS_DIMENSIONS_FAILED','FULL_MOVEMENT_BIAS_CHECK']},
    'SOURCE_BYTES_DOWNLOADED':source['source_bytes_downloaded'],'SOURCE_BYTES_RETAINED':source['source_bytes_retained'],'DOCUMENTS_INDEXED':source['documents_indexed'],'DOCUMENTS_RETAINED':source['documents_retained'],
    'TESTS':{'state':'PASS','count':testcount},'TYPECHECK':'PASS','LINT':'PASS_WITH_17_EXISTING_WARNINGS','BUILD':'PASS','GIT_DIFF_CHECK':'PASS','OFFLINE_REPLAY':offline['state'],
    'MOVEMENT_PUBLICATION':'REVIEW_PENDING','MOVEMENT_UI_PRESENT':'NO','MOVEMENT_FIELDS_PUBLIC':'NONE','PUBLIC_DATA_CHANGED':'NO','PUBLIC_SNAPSHOT_CHANGED':'NO','SEC_HOLDINGS_REFRESH':'NO',
    'FILES_CHANGED':0,'FILES_CREATED':{'count':len(anticipated),'manifest':str(OUT/'files-created.json')},'PRODUCTION_READINESS':'NOT_READY',
    'NEXT_RECOMMENDED_STEP':'Resolve the 4162-case/19-manager versus 20-manager audit constraint, then close the remaining ranked primary evidence queue, starting with retained Alibaba and Unilever coverage and 53 other newly verified issuer scopes. No publication, commit, push, deploy or holdings refresh.',
    'PACKET_UNKNOWN_RATE':unknown,'PACKET_UNKNOWN_OPERATIONAL_THRESHOLD':census['unknown_rate_pass_threshold'],'UNKNOWN_THRESHOLD_BASIS':census['unknown_rate_threshold_basis'],
    'GLOBAL_TOTAL_RESOLVED':out['global_total_resolved'],'GLOBAL_STILL_INDETERMINATE':8137-out['global_total_resolved'],'NEW_RESOLVED_BEYOND_PILOT':len(resolved)-487,'CIK_NEWLY_VERIFIED':60,
    'COMPARISONS_RESOLVED_PER_MB_RETAINED':len(resolved)/(source['source_bytes_retained']/1_000_000),'NEW_COMPARISONS_RESOLVED_PER_MB_RETAINED':(len(resolved)-487)/(source['source_bytes_retained']/1_000_000),
    'STATISTICAL_ZERO_ERROR_CLAIM':'NO','MANUAL_REVIEW_AUTHORITY':'Codex primary agent textual review with retained primary reconstruction; 73 preserved prior reviews plus 37 new reviews. Not independent human sign-off.',
    'MANUAL_AUDIT_STATE':manual['state'],'DISTINCT_SIC_GROUPS_MANUALLY_CHECKED':manual['distinct_SIC_groups'],
    'UNFINISHED_WORK':['2064 packet coverage certificates remain UNKNOWN; acquisition of metadata and identity documents is not event coverage.','Only five new event packets have completed primary review; two retrieved foreign-issuer event scopes still need closure.','The frozen target contains 19 managers; the requested 20-manager audit requirement is unmet, not waived.','All seven observed BOTH_PRESENT bias dimensions fail.'],
    'PRESENCE_TRANSITIONS_UNCHANGED':True,'OUTSIDE_TARGET_COMPARISONS_PRESERVED':3975,'COMMIT':'NO','PUSH':'NO','DEPLOY':'NO'}
    write('RESULT.json',result)
    yield_by_tier=read('tier-yield.json')
    rows='| 20+ | 0 | 0 | 0 | No aplicable |\n'+'\n'.join(f'| {k.replace("_","–")} | {yield_by_tier[k]["packets"]} | {yield_by_tier[k]["comparisons"]} | {yield_by_tier[k]["resolved"]} | {yield_by_tier[k]["comparison_resolution_rate"]:.2%} |' for k in ['10_19','5_9','2_4','1'])
    fields='\n'.join(f'{k}={canonical(v) if isinstance(v,(dict,list,bool)) else v}' for k,v in result.items())
    report=f'''# Wave 2A — expansión interna incompleta

Se resuelven **{len(resolved)} de 4.162 comparaciones BOTH_PRESENT ({len(resolved)/4162:.2%})**: 487 reproducidas exactamente del piloto y 30 nuevas, correspondientes a McDonald’s, Nucor, Phillips 66, State Street y Verizon. Quedan **14 bloqueadas y 3.631 desconocidas**. El total del corpus pasa de los 9 resultados previos a **526 resueltos y 7.611 indeterminados** al aplicar el piloto y esta expansión.

**STATE={result['STATE']}. PRODUCTION_READINESS=NOT_READY.** No se ha completado la revisión global: 2.064 de 2.135 paquetes ({unknown:.2%}) siguen UNKNOWN. La descarga de documentación no equivale a una revisión favorable. No se ha relajado el certificado del piloto.

El censo de todo el corpus tiene 5.771 BOTH_PRESENT. Los 4.162 conocidos corresponden exactamente al grupo EVIDENCE_RESOLVABLE y contienen 19 gestores. Se congeló ese conjunto, sin incorporar los otros 1.609 casos con resultados previos, revisión humana o bloqueos estructurales. La pregunta sobre el mínimo de 20 gestores sigue pendiente; **no se ha dispensado ese requisito**. Véase [censo](target-census.json) y [conjunto congelado](target.json).

La identidad oficial reutilizada es autoritativa para 2.058 pares y queda pendiente para 77. Hay 2.073 coincidencias EXACT_BOTH, pero 15 no tienen identidad de periodo autoritativa; no se confunden ambas cifras. Se intentó descubrir CIK para los 2.135 paquetes y se retuvieron inventarios de 1.539 candidatos. Hay 126 bindings CIK verificados (66 previos y 60 nuevos), 95 ambiguos y 1.914 sin verificación. Los nombres y tickers de candidatos nunca autorizan movimientos.

La revisión nueva de eventos empezó por los siete paquetes nuevos con al menos seis comparaciones, en el orden congelado. Cinco están cerrados; Alibaba y Unilever conservan UNKNOWN. Los otros 53 emisores con identidad primaria nueva aún necesitan su revisión de eventos. El [registro por paquete](packet-review-ledger.json) y la [cola restante](remaining-review-queue.json) separan ausencia de candidato, identidad sin revisar, falta de documentación y cobertura primaria pendiente. El alcance y este punto de avance no constituyen una pasada completa por todos los niveles.

| Nivel | Paquetes | Comparaciones | Resueltas | Resolución |
| --- | ---: | ---: | ---: | ---: |
{rows}

No hay paquetes de 20 o más comparaciones dentro del conjunto congelado. Se usa la frecuencia dentro de ese conjunto, aunque un título aparezca más veces en el corpus completo. No hay familias normalizadas en este resultado; todos los factores aplicados son 1/1. Los dos bloques verificados del piloto permanecen indeterminados.

La [auditoría primaria](manual-audit.json) reconstruye 110 comparaciones, 69 valores, 19 gestores y 26 grupos SIC: 73 revisiones explícitas previas y 37 nuevas. Se observaron cero falsos positivos bajo el modelo auditado; **no es una afirmación estadística de error cero ni una firma humana independiente**. No se identificó ningún falso negativo confirmado; los casos con evidencia pendiente no permiten estimarlo. Se cubren todos los valores resueltos; no existen familias distintas de 1/1 ni paquetes que resuelvan 50 o más comparaciones. El mínimo de 20 gestores no se cumple.

El [análisis de sesgo](resolution-bias.json) falla en las siete dimensiones solicitadas sobre el denominador congelado. Es un control descriptivo de disparidad, no un test estadístico. Las transiciones de presencia quedan fuera de ese control y se reportan aparte como FAIL_EXPECTED_PRESENCE_TRANSITIONS_UNRESOLVED. El umbral operativo de UNKNOWN se fijó en 5% antes de la aplicación como referencia conservadora; no fue aprobado por el usuario ni autoriza publicación. El resultado actual queda muy lejos de ese umbral.

Se retuvieron {source['documents_retained']} documentos primarios únicos en los índices de esta fase. Descarga nueva: {source['source_bytes_downloaded']:,} bytes de cuerpo HTTP; conservación nueva: {source['source_bytes_retained']:,} bytes de fuentes comprimidas únicas. La eficiencia es {result['COMPARISONS_RESOLVED_PER_MB_RETAINED']:.4f} comparaciones resueltas por MB, o {result['NEW_COMPARISONS_RESOLVED_PER_MB_RETAINED']:.4f} nuevas más allá del piloto por MB. La primera cifra incluye la ventaja de reutilizar el piloto. Los bytes heredados se excluyen de ambas medidas de coste. Los dos PDF retenidos pendientes de lectura no se usan para certificar CLEAR. Véase [custodia y definiciones](source-audit.json).

**Validación:** {testcount} pruebas pasan; typecheck, build y diff check pasan; lint tiene 17 avisos existentes y ningún error. SEO valida 76 rutas y 35 pares de idiomas. Los ataques de clase/CUSIP, periodo, formularios extranjeros, enmiendas, split con CUSIP estable, perímetro, metadatos y filtración de certificados cierran sin resolver. Dos construcciones independientes con red deshabilitada reproducen los resultados, certificados y bindings exactamente. Se verificaron los hashes de 613 archivos versionados y 2.320 archivos heredados y se inspeccionó la salida pública del build sin encontrar campos de movimientos.

Todo el trabajo reside en `{ROOT}` sobre `{pre['base_commit']}`. No hubo commit, push, despliegue, cambio público ni actualización de holdings. La publicación permanece REVIEW_PENDING. Los archivos reconstituidos de Wave 1A–1D son copias idénticas; solo se crearon archivos nuevos de Wave 2A. [Manifest de archivos nuevos](files-created.json).

## Salida solicitada completa

```text
{fields}
```
'''
    report=re.sub(r'\]\(([-\w.]+\.json)\)',lambda m:']('+str(OUT/m[1])+')',report)
    (OUT/'REPORT.md').write_text(report)
    created=[str(p.relative_to(ROOT)) for d in [OUT,ROOT/'scripts/movement_global_wave2a'] for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='files-created.json']
    created.append(str((OUT/'files-created.json').relative_to(ROOT)));write('files-created.json',{'count':len(created),'files':sorted(created),'definition':'New Wave 2A source/report/code files only; build output, dependencies and 2320 unchanged reconstructed prior files excluded.'})
    print(canonical({k:result[k] for k in ['STATE','BOTH_PRESENT_RESOLVED','GLOBAL_TOTAL_RESOLVED','MANUAL_CHECKS','TESTS','PACKET_UNKNOWN_RATE']}))

if __name__=='__main__':run()

"""Ranked event batch; retained primary and exhibit custody is separate from review."""
from primary2a import *
from links import relevant_links
from candidates import cluster

def html_for(e,s):
    if s.ref(e['complete_submission_url']):
        text=s.bytes(e['complete_submission_url']).decode('utf-8',errors='replace')
        for block in re.findall(r'<DOCUMENT>(.*?)</DOCUMENT>',text,re.S|re.I):
            name=re.search(r'<FILENAME>\s*([^\r\n<]+)',block,re.I)
            if name and name[1].strip()==e['primary_document']:
                return re.search(r'<TEXT>(.*)</TEXT>',block,re.S|re.I)[1]
        raise ValueError('PRIMARY_BLOCK_NOT_FOUND')
    return s.bytes(e['primary_url']).decode('utf-8',errors='replace')

def retrieve(min_leverage=6):
    s=Store();ins=gzread('candidate-owned-inventories.json.gz');rs=read('identity-primary-reviews.json');packets=read('target-packets.json')
    chosen=[p for p in packets if p['security_id'] in rs and p['comparisons_affected']>=min_leverage]
    ciks=list(dict.fromkeys(rs[p['security_id']]['issuer_cik'] for p in chosen));plan=[e for cik in ciks for e in ins[str(cik)]['entries']]
    write('event-document-plan.json',{'security_ids':[p['security_id'] for p in chosen],'priority_rule':'Frozen comparisons/managers/frequency/public/trend order; next unreviewed highest tier','entries':plan})
    out=[];errors=[]
    with ThreadPoolExecutor(max_workers=4) as ex:
        jobs={ex.submit(primary,e,s,'PRIMARY_EVENT'):e for e in plan}
        for n,f in enumerate(as_completed(jobs),1):
            try:out.append(f.result())
            except Exception as e:errors.append({'entry':jobs[f],'error':str(e)})
            if n%25==0:print('EVENT_PRIMARIES',n,'/',len(plan),'errors',len(errors),flush=True)
    out.sort(key=lambda d:(ciks.index(d['issuer_cik']),d['accession']))
    edges=[]
    for e in plan:
        if any(d['accession']==e['accession'] for d in out):
            try:edges.extend(relevant_links(e,html_for(e,s)))
            except Exception as ex:errors.append({'accession':e['accession'],'link_scan_error':str(ex)})
    write('linked-document-plan.json',{'edges':edges,'recursive_closure':'Requires explicit primary review; a one-hop list is not a coverage certificate'})
    byurl={d['document_url']:d for d in out};urls=list(dict.fromkeys(e['document_url'] for e in edges))
    def linked(u):
        if u in byurl:return byurl[u]
        s.get(u,'LINKED_CLASS_TERMS');b=s.bytes(u);edge=next(e for e in edges if e['document_url']==u)
        t=None if b.startswith(b'%PDF') else visible(b.decode('utf-8',errors='replace'))
        header=re.match(r'EX-\d+(?:\.\d+)?\b',t or '',re.I)
        document_type=header[0].upper() if header else edge['document_type']
        return {'issuer_cik':edge['parent_cik'],'accession':edge['parent_accession'],'parent_accession':edge['parent_accession'],'document_url':u,'document_type':document_type,'text':t,'links':[],'source_ref':s.compact_ref(u),'document_hash':sha(b),'hash_domain':'ORIGINAL_DOCUMENT_BYTES','mode':'TEXT' if t is not None else 'PDF_REVIEW_REQUIRED','ownership':'LINKED_ONLY; NOT_ADDED_TO_OWNED_INVENTORY'}
    linked_docs=[]
    with ThreadPoolExecutor(max_workers=4) as ex:
        jobs={ex.submit(linked,u):u for u in urls}
        for n,f in enumerate(as_completed(jobs),1):
            try:linked_docs.append(f.result())
            except Exception as e:errors.append({'document_url':jobs[f],'error':str(e)})
            if n%25==0:print('LINKED_TERMS',n,'/',len(urls),'errors',len(errors),flush=True)
    # Reconstruct ownership after inspecting candidate 425 filing-person text.
    for cik in ciks:ins[str(cik)]=owned(cik,s)
    gzwrite('candidate-owned-inventories.json.gz',ins)
    excluded={(int(cik),e['accession']) for cik in ciks for e in ins[str(cik)]['all_associated_entries'] if e['ownership_authority'].startswith('ASSOCIATED_DISTINCT_425')}
    unique={}
    for d in out+linked_docs:
        if (d['issuer_cik'],d['accession']) in excluded:continue
        key=(d['issuer_cik'],d['document_url'],d['document_hash']);unique[key]=d
    docs=sorted(unique.values(),key=lambda d:(d['issuer_cik'],d['document_url'],d['document_hash']))
    gzwrite('event-documents.json.gz',docs)
    g=cluster(docs,{p['security_id']:rs[p['security_id']]['issuer_cik'] for p in chosen});write('event-candidates.json',g)
    write('event-retrieval.json',{'primary_accessions_planned':len(plan),'primary_accessions_retained':len(out),'linked_urls_planned':len(urls),'linked_records_retained':len(linked_docs),'scoped_unique_documents':len(docs),'errors':errors,'excluded_distinct_filing_person_accessions':len(excluded),'primary_review_complete':False})
    print('EVENT_BATCH_COMPLETE',len(docs),'CANDIDATES',g['distinct_event_candidates'],'ERRORS',len(errors),flush=True)
if __name__=='__main__':retrieve(int(sys.argv[1]) if sys.argv[1:] else 6)

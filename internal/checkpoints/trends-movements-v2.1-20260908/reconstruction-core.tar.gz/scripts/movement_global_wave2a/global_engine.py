"""Explicit Wave 2A authorization around unchanged pilot gates and resolver."""
from context2a import *
from primary2a import gzread
from coverage import certificate,scope_hash
from pilot_engine import FixedPilotEngine
from issuer_identity import verify
from collections import Counter
import copy

TARGET_SHA='307cfb419c1134e020b7b0e57f8f7fab024a81ec2c8790af168f33c6de6559e6'
def checked_target(target=None):
    t=read('target.json') if target is None else target
    if sha(t)!=TARGET_SHA:raise ValueError('STOP_TARGET_DRIFT')
    rows={r['comparison_id']:r for r in corpus()};ids=t['comparison_ids']
    if len(ids)!=4162 or len(set(ids))!=4162:raise ValueError('STOP_TARGET_DRIFT')
    for cid in ids:
        r=rows[cid]
        if r['previous_quantity'] is None or r['current_quantity'] is None:raise ValueError('PRESENCE_TRANSITION_REQUIRES_TIER_B')
    return t

def new_resources(pilot):
    packets=read('target-packets.json');ins=gzread('candidate-owned-inventories.json.gz')
    ds=gzread('identity-primary-documents.json.gz') if (OUT/'identity-primary-documents.json.gz').exists() else []
    ed=gzread('event-documents.json.gz') if (OUT/'event-documents.json.gz').exists() else []
    groups=read('event-candidates.json')['candidates'] if (OUT/'event-candidates.json').exists() else []
    reviews=read('identity-primary-reviews.json') if (OUT/'identity-primary-reviews.json').exists() else {}
    source=Store();catalog=copy.deepcopy(pilot.catalog);catalog.update({u:r['sha256'] for u,r in source.new.items()})
    candidates={c['security_id']:c for c in read('cik-candidates.json')};scopes={};identity=[]
    for p in packets:
        sec=p['security_id']
        if sec in pilot.scopes:
            scopes[sec]=copy.deepcopy(pilot.scopes[sec]);identity.append(copy.deepcopy(pilot.scopes[sec][1]));continue
        candidate=candidates[sec]
        c={'security_id':sec,**verify(candidate,reviews.get(sec),ds,ins,catalog)}
        if not reviews.get(sec) and len(candidate['candidates'])>1:c.update(status='CIK_AMBIGUOUS',reason='MULTIPLE_SEC_CANDIDATES_WITHOUT_DISAMBIGUATING_PRIMARY_REVIEW')
        inv=ins.get(str(c.get('issuer_cik')))
        if c.get('issuer_cik') and inv:c.update(regime=inv['regime'],sic=inv.get('sic'),sic_description=inv.get('sic_description'))
        # A pending candidate's SIC/regime is not promoted into verified identity.
        selected=[d for d in ed if d['issuer_cik']==c.get('issuer_cik')]
        idx=[{k:d.get(k) for k in ['issuer_cik','accession','parent_accession','linked_accession','document_url','document_type','document_hash','hash_domain','source_ref','mode','ownership']} for d in selected]
        scopes[sec]=(p['binding'],c,inv,[g for g in groups if g['issuer_cik']==c.get('issuer_cik')],sorted(idx,key=lambda d:(d['document_url'],d['document_hash'])))
        identity.append(c)
    return scopes,catalog,identity

class GlobalBothEngine:
    def __init__(self):
        self.selection=checked_target();self.ids=set(self.selection['comparison_ids'])
        self.pilot=ClosedPilotEngine();self.engine=self.pilot.engine
        if not self.pilot.ids<=self.ids:raise ValueError('PILOT_NOT_CONTAINED_IN_FROZEN_TARGET')
        self.scopes,self.catalog,self.identities=new_resources(self.pilot)
        self.reviews=copy.deepcopy(self.pilot.reviews)
        added=read('coverage-primary-reviews.json') if (OUT/'coverage-primary-reviews.json').exists() else {}
        if set(added)&set(self.pilot.scopes):raise ValueError('PILOT_OVERWRITE_FORBIDDEN')
        if not set(added)<=set(self.scopes):raise ValueError('UNAUTHORIZED_SECURITY_REVIEW')
        self.reviews.update(added)
        self.certificates={sec:copy.deepcopy(self.pilot.certificates[sec]) if sec in self.pilot.certificates else certificate(*scope,added.get(sec),self.catalog) for sec,scope in self.scopes.items()}
        self.engine.adapter.source_hashes=self.catalog
    def evaluate(self,cid):
        if cid not in self.ids:raise ValueError('OUTSIDE_FROZEN_WAVE2A_BOTH_PRESENT_TARGET')
        row=self.engine.rows[cid];sec=row['security_id']
        if sec not in self.scopes or self.scopes[sec][0]['security_pair_id']!=sec:raise ValueError('WRONG_SECURITY_PACKET')
        cert=self.certificates[sec]
        if cert.get('security_id')!=sec or cert.get('evidence_fingerprint')!=scope_hash(*self.scopes[sec]):raise ValueError('WRONG_OR_STALE_SECURITY_CERTIFICATE')
        if row['previous_quantity'] is None or row['current_quantity'] is None:raise ValueError('PRESENCE_TRANSITION_REQUIRES_TIER_B')
        # Calling the original implementation preserves core DAG, filing,
        # amendment, class, perimeter and exact-rational checks in one place.
        return FixedPilotEngine.evaluate(self,cid)

def result():
    e=GlobalBothEngine();rs=[e.evaluate(cid) for cid in e.selection['comparison_ids']]
    from closure import result as pilot_result,load as pilot_load
    replay,certs=pilot_result()
    if replay!=pilot_load('pilot-results.json') or certs!=pilot_load('corporate-event-coverage.json'):raise ValueError('PILOT_REPLAY_DRIFT')
    pilot_by={r['comparison_id']:r for r in replay['comparison_results']}
    for r in rs:
        if r['comparison_id'] in pilot_by and r!=pilot_by[r['comparison_id']]:raise ValueError('PILOT_GLOBAL_APPLICATION_DIVERGED')
    qualified=[r for r in rs if r['reported_status']!='INDETERMINATE']
    if any(r['reported_status'] not in {'REPORTED_INCREASED','REPORTED_REDUCED','REPORTED_UNCHANGED'} for r in qualified):raise ValueError('NEW_EXIT_CLASSIFICATION_FORBIDDEN')
    states=Counter(c['state'] for c in e.certificates.values());stats=Counter(r['reported_status'] for r in qualified)
    # Preserve every baseline result outside the frozen target byte-for-byte as
    # JSON values, including all presence transitions and structural blockers.
    from build import baseline
    baseline_rows=baseline();by={r['comparison_id']:r for r in rs}
    global_rows=[by.get(r['comparison_id'],r) for r in baseline_rows]
    assert len(global_rows)==8137
    return {'target_sha256':TARGET_SHA,'target_count':len(rs),'packet_counts':dict(states),'resolved_status_counts':dict(stats),'both_present_resolved':len(qualified),'both_present_blocked':sum(r['corporate_event_certificate']['state']=='VERIFIED_BLOCK' for r in rs),'both_present_unknown':sum(r['reported_status']=='INDETERMINATE' and r['corporate_event_certificate']['state']!='VERIFIED_BLOCK' for r in rs),'global_total_resolved':sum(r.get('reported_status',r.get('movement_status'))!='INDETERMINATE' for r in global_rows),'pilot_replay':'PASS','pilot_total_resolved':487,'outside_target_preserved':8137-len(rs),'new':0,'exited':0,'global_authorization_scope':'FROZEN_TARGET_ONLY; LEGACY_CERTIFICATE_GLOBAL_FLAGS_RETAINED_FOR_EXACT_PILOT_REPLAY','comparison_results':rs,'global_results':global_rows},list(e.certificates.values()),e.identities

def run():
    out,certs,ids=result();write('both-present-results.json',out);write('corporate-event-coverage.json',certs);write('issuer-cik-bindings.json',ids)
    print(canonical({k:v for k,v in out.items() if k not in {'comparison_results','global_results'}}))
if __name__=='__main__':run()

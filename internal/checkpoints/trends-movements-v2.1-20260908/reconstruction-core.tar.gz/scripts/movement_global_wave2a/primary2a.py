"""Metadata-scoped primary retrieval. A retrieved document never clears a packet."""
from context2a import *
from owned_inventory import owned,rows_from
from context import NarrativeText
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter

def gzwrite(name,obj): (OUT/name).write_bytes(gzip.compress((canonical(obj)+'\n').encode(),mtime=0))
def gzread(name):return json.loads(gzip.decompress((OUT/name).read_bytes()))
def inventory():
    s=Store();out={};errors=[]
    ciks=list(dict.fromkeys(c['cik'] for p in read('cik-candidates.json') for c in p['candidates']))
    for cik in ciks:
        try:out[str(cik)]=owned(cik,s)
        except Exception as e:errors.append({'cik':cik,'error':str(e)})
    gzwrite('candidate-owned-inventories.json.gz',out);write('inventory-errors.json',errors)
    plan=[];missing=[];pilot_ciks={v[1]['issuer_cik'] for v in pilot_resources()[0].values()}
    for cik,inv in out.items():
        if int(cik) in pilot_ciks:continue
        d=s.json(f'https://data.sec.gov/submissions/CIK{int(cik):010d}.json')
        forms=['10-Q','10-K'] if inv['regime']=='DOMESTIC_OPERATING_COMPANY' else ['20-F','40-F','6-K'] if inv['regime']=='FOREIGN_PRIVATE_ISSUER' else ['N-CSR','N-CSRS','N-1A','N-2','N-14','8-K'] if inv['regime']=='REGISTERED_FUND_OR_TRUST' else []
        rows=[r for r in rows_from(d['filings']['recent'],'recent') if r['form'] in forms and '2025-01-01'<=r['filing_date']<='2026-08-14']
        if not rows:missing.append({'issuer_cik':int(cik),'reason':'NO_APPROPRIATE_PRIMARY_IN_AVAILABLE_METADATA','regime':inv['regime']});continue
        # One class-identity document per candidate issuer. Quarter event coverage
        # is a separate complete-inventory review, never inferred from this one file.
        row=sorted(rows,key=lambda r:(forms.index(r['form']),-int(r['filing_date'].replace('-',''))))[0]
        stem=f'https://www.sec.gov/Archives/edgar/data/{int(cik)}/{row["accession"].replace("-","")}/'
        plan.append({**row,'issuer_cik':int(cik),'primary_url':stem+row['primary_document'],'complete_submission_url':stem+row['accession']+'.txt','purpose':'PRIMARY_IDENTITY'})
    write('identity-document-plan.json',plan);write('identity-plan-unavailable.json',missing)
    print('INVENTORIES',len(out),'REGIMES',dict(Counter(i['regime'] for i in out.values())),'IDENTITY_DOCS',len(plan),'NO_PRIMARY',len(missing),flush=True)

def primary(e,s,purpose):
    full=e['complete_submission_url'];url=e['primary_url']
    if s.ref(full):
        ds=parse_submission(s.bytes(full),e['accession']);matches=[d for d in ds if d['filename']==e['primary_document']]
        if len(matches)!=1 or matches[0]['mode']!='TEXT':raise ValueError('PRIMARY_DOCUMENT_UNAVAILABLE')
        d=matches[0]
        return {**e,'document_url':url,'document_type':d['type'],'text':d['text'],'links':d['links'],'source_ref':s.compact_ref(full),'document_hash':d['document_block_sha256'],'hash_domain':'RETAINED_SGML_DOCUMENT_BLOCK','mode':'TEXT'}
    s.get(url,purpose);body=s.bytes(url)
    if body.startswith(b'%PDF'):return {**e,'document_url':url,'document_type':e['form'],'text':None,'links':[],'source_ref':s.compact_ref(url),'document_hash':sha(body),'hash_domain':'ORIGINAL_DOCUMENT_BYTES','mode':'PDF_REVIEW_REQUIRED'}
    raw=body.decode('utf-8',errors='replace');p=NarrativeText();p.feed(raw)
    return {**e,'document_url':url,'document_type':e['form'],'text':visible(raw),'links':sorted(set(p.links)),'source_ref':s.compact_ref(url),'document_hash':sha(body),'hash_domain':'ORIGINAL_DOCUMENT_BYTES','mode':'TEXT'}

def retrieve():
    s=Store();out=[];errors=[];plan=read('identity-document-plan.json')
    with ThreadPoolExecutor(max_workers=4) as ex:
        jobs={ex.submit(primary,e,s,'PRIMARY_IDENTITY'):e for e in plan}
        for n,f in enumerate(as_completed(jobs),1):
            try:out.append(f.result())
            except Exception as e:errors.append({'entry':jobs[f],'error':str(e)})
            if n%100==0:print('PRIMARY_IDENTITY',n,'/',len(plan),'errors',len(errors),flush=True)
    out.sort(key=lambda d:(d['issuer_cik'],d['accession']))
    gzwrite('identity-primary-documents.json.gz',out);write('identity-document-retrieval.json',{'planned':len(plan),'retained':len(out),'failures':errors})
    dossier=[]
    for p in read('cik-candidates.json'):
        ds=[]
        for d in out:
            if d['issuer_cik'] not in {c['cik'] for c in p['candidates']}:continue
            t=d.get('text') or '';hits=[]
            for m in re.finditer(re.escape(p['cusip'])+r'|Title of each class|Securities registered|ordinary shares|Class [ABCD][\s,]|common stock',t,re.I):
                if m.start()<12000 or p['cusip'] in m[0]:hits.append({'offset':m.start(),'excerpt':t[max(0,m.start()-90):m.end()+350]})
            ds.append({k:d[k] for k in ['issuer_cik','accession','form','filing_date','document_url','document_hash','source_ref']}|{'cover_text':t[:9500],'class_occurrences':hits[:25]})
        dossier.append({'security_id':p['security_id'],'official_13f_names':p['official_13f_name'],'official_13f_classes':p['official_13f_class'],'candidate_documents':ds,'status':'PRIMARY_REVIEW_PENDING' if ds else 'PRIMARY_PROOF_UNAVAILABLE'})
    gzwrite('identity-review-dossier.json.gz',dossier)
    print('PRIMARY_RETRIEVAL_COMPLETE',len(out),'errors',len(errors),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['retrieve']:retrieve()
    else:inventory()

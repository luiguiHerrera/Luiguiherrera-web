"""Wave 2A keeps prior waves immutable and segregates downloads from holdings."""
from pathlib import Path
import sys,json,gzip,hashlib,re,urllib.request,urllib.parse,datetime,threading,time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts/movement_pilot_wave1d'))
from closure import ClosedPilotEngine,resources as pilot_resources,documents as pilot_documents,ALLOWED as W1D_ALLOWED
from context import Store as PriorStore,sha,canonical,visible,parse_submission,read as prior_read
OUT=ROOT/'internal/trends-movements/wave2a'
EXPECTED_CORPUS='d270f69dc303daa6d694fbafa6d4c91166cdcfb60c4e1fb5bc90b105b5143ac3'
def read(name):return json.loads((OUT/name).read_text())
def write(name,obj):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(canonical(obj)+'\n')
def corpus():
    raw=gzip.decompress((ROOT/'internal/trends-movements/v2.1/corpus.jsonl.gz').read_bytes())
    if sha(raw)!=EXPECTED_CORPUS or len(raw.splitlines())!=8137:raise ValueError('STOP_CORPUS_DRIFT')
    return [json.loads(x) for x in raw.splitlines()]
class Store(PriorStore):
    def __init__(self):
        super().__init__();self.new=read('source-manifest.json') if (OUT/'source-manifest.json').exists() else {}
        self.added={r['source_url']:r for r in prior_read('additional-sec-source-manifest.json',ROOT/'internal/trends-movements/wave1d')}
        self.lock=threading.Lock();self.rate=threading.Lock();self.last=0
    def ref(self,u):return self.new.get(u) or self.added.get(u) or super().ref(u)
    def bytes(self,u):
        if u in self.new or u in self.added:
            r=self.ref(u);folder=OUT if u in self.new else ROOT/'internal/trends-movements/wave1d';b=(folder/r['path']).read_bytes()
            if r.get('storage_encoding')=='gzip':b=gzip.decompress(b)
            assert sha(b)==r['sha256'];return b
        return super().bytes(u)
    def get(self,u,purpose):
        if self.ref(u):self.bytes(u);return self.ref(u)
        parsed=urllib.parse.urlparse(u)
        if parsed.scheme!='https' or parsed.hostname not in {'www.sec.gov','data.sec.gov'}:raise ValueError('NON_SEC_SOURCE')
        if purpose not in {'ISSUER_METADATA','ISSUER_HISTORY','PRIMARY_IDENTITY','PRIMARY_EVENT','LINKED_CLASS_TERMS'}:raise ValueError('HOLDINGS_REFRESH_FORBIDDEN')
        with self.rate:
            time.sleep(max(0,.26-(time.monotonic()-self.last)));self.last=time.monotonic()
        req=urllib.request.Request(u,headers={'User-Agent':'LHI Trends research https://www.luiguiherrera.com','Accept-Encoding':'identity'})
        with urllib.request.urlopen(req,timeout=35) as response:
            assert urllib.parse.urlparse(response.url).hostname in {'www.sec.gov','data.sec.gov'}
            b=response.read();ct=response.headers.get('Content-Type');final=response.url
        if not b or b'Your Request Originates from an Undeclared Automated Tool' in b:raise ValueError('SEC_BLOCK_PAGE')
        # Complete submissions must not introduce new manager holdings or proxy-vote data.
        if u.endswith('.txt') and re.search(rb'<TYPE>\s*(?:13F|N-PX)',b[:5000]):raise ValueError('HOLDINGS_REFRESH_FORBIDDEN')
        h=sha(b);path='sources/'+h+'.raw.gz';packed=gzip.compress(b,mtime=0);(OUT/path).write_bytes(packed)
        r={'source_url':u,'final_url':final,'sha256':h,'bytes':len(b),'stored_bytes':len(packed),'storage_encoding':'gzip','path':path,'purpose':purpose,'content_type':ct,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        with self.lock:self.new[u]=r;write('source-manifest.json',self.new)
        return r

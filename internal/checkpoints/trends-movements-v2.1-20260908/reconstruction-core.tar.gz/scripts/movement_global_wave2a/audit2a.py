"""Retained-source custody, immutable boundaries and network-disabled replay."""
from context2a import *
from primary2a import gzread
from collections import Counter, defaultdict
import subprocess, socket
from unittest.mock import patch

def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()

def isolation():
    pre=read('preflight.json');checks={}
    for key in ['tracked_files','preserved_files']:
        bad=[r['path'] for r in pre[key] if not (ROOT/r['path']).exists() or sha((ROOT/r['path']).read_bytes())!=r['sha256']]
        assert not bad,(key,bad)
        checks[key+'_unchanged']=len(pre[key])
    assert git('rev-parse','HEAD')==pre['base_commit']
    assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
    corpus()
    leaks=[];scanned=0
    for directory in ['.next/static','.next/server/app']:
        for p in (ROOT/directory).rglob('*'):
            if p.is_file() and p.suffix in {'.js','.json','.html','.rsc','.txt'}:
                scanned+=1
                if any(term in p.read_bytes() for term in [b'movement_global_wave2a',b'trends-movements/wave2a',b'VERIFIED_CLEAR_FOR_COMPARABILITY',b'REPORTED_INCREASED']):leaks.append(str(p.relative_to(ROOT)))
    assert not leaks,('PUBLIC_BUNDLE_LEAK',leaks)
    checks.update(state='PASS',head=git('rev-parse','HEAD'),tracked_diff_empty=True,staged_diff_empty=True,corpus_sha256=EXPECTED_CORPUS,public_snapshot_sha256=pre['public_snapshot_sha256'],public_build_files_scanned=scanned,public_build_leaks=leaks,holdings_refresh=False,commit=False,push=False,deploy=False)
    write('isolation-audit.json',checks);print('ISOLATION_PASS',flush=True)

def source_audit():
    s=Store();manifest=read('source-manifest.json');paths={};purposes=defaultdict(lambda:Counter())
    for n,(u,r) in enumerate(manifest.items(),1):
        b=s.bytes(u);p=OUT/r['path'];assert len(b)==r['bytes'] and p.stat().st_size==r['stored_bytes']
        assert urllib.parse.urlparse(u).hostname in {'www.sec.gov','data.sec.gov'}
        assert r['purpose'] in {'ISSUER_METADATA','ISSUER_HISTORY','PRIMARY_IDENTITY','PRIMARY_EVENT','LINKED_CLASS_TERMS'}
        paths[r['path']]=r;purposes[r['purpose']]['urls']+=1;purposes[r['purpose']]['raw_downloaded_bytes']+=len(b)
        if n%500==0:print('SOURCE_CUSTODY',n,'/',len(manifest),flush=True)
    assert set(paths)=={str(p.relative_to(OUT)) for p in (OUT/'sources').glob('*')},'UNINDEXED_RAW_SOURCE'
    docs=gzread('identity-primary-documents.json.gz')+gzread('event-documents.json.gz');unique={(d['document_url'],d['document_hash']):d for d in docs};sgml={};pdfs=[]
    for n,d in enumerate(unique.values(),1):
        u=d['source_ref']['source_url'];assert s.ref(u)['sha256']==d['source_ref']['sha256'];b=s.bytes(u)
        if d['hash_domain']=='ORIGINAL_DOCUMENT_BYTES':
            assert sha(b)==d['document_hash']
            if b.startswith(b'%PDF'):
                assert d['text'] is None;pdfs.append(d['document_url'])
            else:assert visible(b.decode('utf-8',errors='replace'))==d['text'],('NARRATIVE_DRIFT',d['document_url'])
        else:
            if u not in sgml:sgml[u]=parse_submission(b,d['accession'])
            found=[x for x in sgml[u] if x['document_block_sha256']==d['document_hash']]
            assert len(found)==1 and found[0]['text']==d['text'],'SGML_DOCUMENT_DRIFT'
        if n%250==0:print('PRIMARY_RECONSTRUCTION',n,'/',len(unique),flush=True)
    retained=sum((OUT/p).stat().st_size for p in paths)
    result={'state':'PASS','new_source_urls':len(manifest),'source_bytes_downloaded':sum(r['bytes'] for r in manifest.values()),'source_bytes_retained':retained,'source_bytes_retained_uncompressed':sum(r['bytes'] for r in paths.values()),'unique_retained_source_blobs':len(paths),'new_primary_document_records':len(docs),'documents_indexed':len(unique),'documents_retained':len(unique),'identity_document_records':len(gzread('identity-primary-documents.json.gz')),'event_document_records':len(gzread('event-documents.json.gz')),'raw_pdf_retained_without_textual_closure':pdfs,'purposes':{k:dict(v) for k,v in purposes.items()},'byte_definition':'Downloaded successful HTTP response body bytes, before local compression; retained unique gzip source payload bytes. No network-header overhead or inherited prior-wave bytes included.','document_definition':'Unique (primary document URL, document hash) indexed across this wave identity/event dossiers, including reuse from prior sources. Metadata JSON is a source, not a primary document. PDFs are retained but are not evidence of completed review.'}
    write('source-audit.json',result);print('SOURCE_AUDIT_PASS',len(unique),retained,flush=True)

def no_network(*args,**kwargs):raise AssertionError('OFFLINE_NETWORK_ACCESS_FORBIDDEN')

def offline():
    from global_engine import result
    expected=[read('both-present-results.json'),read('corporate-event-coverage.json'),read('issuer-cik-bindings.json')];hashes=[sha(v) for v in expected];passes=[]
    with patch.object(socket,'socket',no_network),patch.object(socket,'create_connection',no_network),patch.object(urllib.request,'urlopen',no_network),patch.object(Store,'get',no_network):
        for n in range(2):
            print('OFFLINE_REPLAY_START',n+1,flush=True)
            actual=result();assert list(actual)==expected,'OFFLINE_RESULT_DRIFT'
            passes.append({'pass':n+1,'sha256':[sha(v) for v in actual]});print('OFFLINE_REPLAY_PASS',n+1,flush=True)
    write('offline-replay.json',{'state':'PASS','network_disabled':True,'independent_engine_constructions':2,'artifact_sha256':hashes,'passes':passes,'pilot_exact_replay_each_pass':True,'raw_corpus_verified_each_pass':True})

if __name__=='__main__':
    {'isolation':isolation,'sources':source_audit,'offline':offline}[sys.argv[1]]()

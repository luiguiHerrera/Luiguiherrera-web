"""Synthetic adversarial proof fixtures plus frozen-corpus dependency integration tests."""
import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'movement_qualification'))
from test_resolver import fixture,rebind,event,URL,REF
from resolver import resolve,ACTION_CHECKS
from model import seal,scope_id,validate_node,evaluate_dependencies,COVERAGE_CHECKS,reported_semantics
from engine import install_verified,Engine
from research import relevant_form
ASOF='2026-09-06T20:11:49.338122+00:00'

def node(kind='CORPORATE_ACTION_STATE',status='VERIFIED_CLEAR'):
    x=fixture();sec=x['previous']['security_id'];start=x['previous_quarter'];end=x['current_quarter'];subject=sec
    p={'issuer_id':'fixture-issuer','security_ids':[sec],'coverage_standard':{k:True for k in COVERAGE_CHECKS},'checks':{k:'CLEAR' for k in ACTION_CHECKS},'events':[]};scope={'issuer_id':'fixture-issuer','security_ids':[sec]}
    if kind=='MANAGER_PERIMETER':subject=x['manager_id'];scope={'manager_id':subject,'manager_group_id':x['manager_group_id']};p={'equivalent':'YES'}
    if kind=='AMENDMENT_STATE':subject=x['manager_id'];start=end;scope={'manager_id':subject,'accessions':x['filings']['current']['accessions']};p={'state':'NONE','composition_verified':True,'selected_accessions':scope['accessions']}
    if kind=='SECURITY_CONTINUITY':scope={'security_ids':[sec]};p={'relationship':'SAME_SECURITY','previous_security':sec,'current_security':sec,'one_to_one':True}
    n={'evidence_id':scope_id(kind,subject,start,end),'evidence_type':kind,'subject_id':subject,'period_start':start,'period_end':end,'scope':scope,'payload':p,'status':status,'source_refs':[REF.copy()],'verified_at':'2026-09-07T16:00:00+00:00','verification_method':'SYNTHETIC_TEST_ONLY','evidence_as_of':ASOF,'blocks_comparisons':['a','b'],'unlocks_count':2,'conflicts':[]}
    return seal(n)
def dep(n):return {k:n[k] for k in ['evidence_id','evidence_type','subject_id','period_start','period_end','scope']}
def valid(n,d=None,catalog=None,asof=ASOF):return validate_node(n,d or dep(n),catalog if catalog is not None else {URL:'a'*64},asof)

class SharedEvidenceTests(unittest.TestCase):
    def test_one_manager_evidence_many_securities(self):
        n=node('MANAGER_PERIMETER');self.assertEqual(valid(n),'VALID')
        for qty in ['99','100','101','250000000000000001']:
            x=fixture();x['current']['quantity']=qty;x['perimeter']['verification_status']='UNVERIFIED'
            self.assertNotEqual(resolve(rebind(x))['movement_status'],'UNCHANGED')
            self.assertNotEqual(resolve(install_verified(x,[n]))['movement_status'],'INDETERMINATE')
    def test_one_amendment_substitution_all_rows(self):
        n=node('AMENDMENT_STATE');n['payload']['state']='RESTATEMENT';n=seal(n)
        for qty in ['1','100','2345']:
            x=fixture();x['current']['quantity']=qty;x['amendments']['current']['state']='AMBIGUOUS'
            self.assertEqual(resolve(rebind(x))['movement_status'],'INDETERMINATE')
            self.assertNotEqual(resolve(install_verified(x,[n]))['movement_status'],'INDETERMINATE')
    def test_one_action_reused_across_managers_normalizes_all(self):
        n=node();x=fixture();ev=event(x,'SPLIT',2);n['status']='VERIFIED_EVENT';n['payload']['events']=[ev];n['payload']['checks']['SPLIT']='ADJUSTED';n=seal(n);self.assertEqual(valid(n),'VALID')
        for i,previous in enumerate(['1','37','100','987654321']):
            x=fixture();x['manager_id']='m'+str(i);x['manager_group_id']='g'+str(i)
            for h in ['previous','current']:x[h]['manager_id']=x['manager_id'];x[h]['manager_group_id']=x['manager_group_id']
            x['previous']['quantity']=previous;x['current']['quantity']=str(int(previous)*2)
            r=resolve(install_verified(x,[n]));self.assertEqual(r['movement_status'],'UNCHANGED',r)
    def test_one_continuity_relation_reused_across_managers(self):
        n=node('SECURITY_CONTINUITY');self.assertEqual(valid(n),'VALID')
        for i in range(12):
            x=fixture();x['manager_id']='manager'+str(i)
            for side in ['previous','current']:x[side]['manager_id']=x['manager_id']
            x['continuity']['relation']='UNKNOWN_RELATION';self.assertEqual(resolve(rebind(x))['movement_status'],'INDETERMINATE')
            self.assertEqual(resolve(install_verified(x,[n]))['movement_status'],'UNCHANGED')
    def test_reviewed_certificate_ingestion(self):
        from attestations import apply_attestations
        n=node();base=copy.deepcopy(n);base['status']='UNKNOWN';base=seal(base)
        result=apply_attestations({n['evidence_id']:base},[n],{URL:'a'*64},ASOF)
        self.assertEqual(result[n['evidence_id']]['status'],'VERIFIED_CLEAR');self.assertEqual(base['status'],'UNKNOWN')
    def test_conflicting_or_stale_certificate_ingestion_stops(self):
        from attestations import apply_attestations
        n=node()
        with self.assertRaisesRegex(ValueError,'CONFLICTING'):apply_attestations({n['evidence_id']:n},[n,n],{URL:'a'*64},ASOF)
        with self.assertRaisesRegex(ValueError,'SOURCE_HASH_CHANGED'):apply_attestations({n['evidence_id']:n},[n],{URL:'b'*64},ASOF)
    def test_certificate_with_changed_reach_or_quarter_stops(self):
        from attestations import apply_attestations
        n=node();other=copy.deepcopy(n);other['blocks_comparisons']=['z'];other=seal(other)
        with self.assertRaisesRegex(ValueError,'REACH_CHANGED'):apply_attestations({n['evidence_id']:n},[other],{URL:'a'*64},ASOF)
        other=copy.deepcopy(n);other['period_end']='2026-09-30';other=seal(other)
        with self.assertRaisesRegex(ValueError,'SCOPE_MISMATCH'):apply_attestations({n['evidence_id']:n},[other],{URL:'a'*64},ASOF)
    def test_unknown_is_not_clear(self):self.assertEqual(valid(node(status='UNKNOWN')),'UNKNOWN')
    def test_verified_block_does_not_resolve(self):self.assertEqual(valid(node(status='VERIFIED_BLOCK')),'VERIFIED_BLOCK')
    def test_stale_node(self):self.assertEqual(valid(node(status='STALE')),'STALE')
    def test_stale_amendment_as_of(self):self.assertEqual(valid(node('AMENDMENT_STATE'),asof='2026-09-07'),'STALE')
    def test_source_hash_change_invalidates(self):self.assertEqual(valid(node(),catalog={URL:'b'*64}),'SOURCE_HASH_CHANGED')
    def test_missing_source_invalidates(self):self.assertEqual(valid(node(),catalog={}),'SOURCE_HASH_CHANGED')
    def test_unsealed_payload_edit_invalidates(self):
        n=node();n['payload']['checks']['SPLIT']='ADJUSTED';self.assertEqual(valid(n),'NODE_HASH_CHANGED')
    def test_wrong_quarter(self):
        n=node();d=dep(n);d['period_end']='2026-09-30';self.assertEqual(valid(n,d),'SCOPE_MISMATCH')
    def test_wrong_issuer(self):
        n=node();d=copy.deepcopy(dep(n));d['scope']['issuer_id']='another-issuer';self.assertEqual(valid(n,d),'SCOPE_MISMATCH')
    def test_same_issuer_wrong_class(self):
        n=node();d=copy.deepcopy(dep(n));d['scope']['security_ids']=['000000002|LONG|SH'];self.assertEqual(valid(n,d),'SCOPE_MISMATCH')
    def test_same_ticker_different_security(self):
        n=node('SECURITY_CONTINUITY');n['payload']['current_security']='000000002|LONG|SH';n['payload']['ticker']='SAME';self.assertEqual(valid(seal(n)),'DISTINCT_SECURITIES')
    def test_same_issuer_different_security_continuity(self):
        n=node('SECURITY_CONTINUITY');n['payload'].update(current_security='000000002|LONG|SH',issuer_id='same-issuer');self.assertEqual(valid(seal(n)),'DISTINCT_SECURITIES')
    def test_another_filer_manager_group(self):
        n=node('MANAGER_PERIMETER');d=copy.deepcopy(dep(n));d['scope']['manager_id']='another-filer';self.assertEqual(valid(n,d),'SCOPE_MISMATCH')
    def test_scope_id_cannot_be_reused_after_editing_both_node_and_edge(self):
        n=node();n['period_end']='2026-09-30';n=seal(n);self.assertEqual(valid(n),'SCOPE_MISMATCH')
    def test_conflicting_authority_fails_closed(self):
        n=node();m=copy.deepcopy(n);m['payload']['events']=[{'effective_date':'2026-05-02'}];m=seal(m)
        self.assertEqual(evaluate_dependencies({'dependencies':[dep(n)]},[n,m],{URL:'a'*64},ASOF)[n['evidence_id']],'CONFLICTING_AUTHORITY')
    def test_explicit_conflicts_fails_closed(self):
        n=node();n['conflicts']=[{'source':URL,'competing_claim':'SPLIT'}];self.assertEqual(valid(seal(n)),'CONFLICTING_AUTHORITY')
    def test_outside_effective_date(self):
        for date in ['2026-03-31','2026-07-01']:
            n=node();n['payload']['events']=[{'effective_date':date}];self.assertEqual(valid(seal(n)),'EVENT_OUTSIDE_PERIOD')
    def test_event_scope_must_match_class(self):
        n=node();n['payload']['events']=[{'effective_date':'2026-05-01','issuer_id':'fixture-issuer','affected_security_ids':['different-class']}];self.assertEqual(valid(seal(n)),'ISSUER_CLASS_MISMATCH')
    def test_negative_evidence_requires_all_coverage_elements(self):
        for check in COVERAGE_CHECKS:
            with self.subTest(check=check):
                n=node();n['payload']['coverage_standard'][check]=False;self.assertEqual(valid(seal(n)),'INSUFFICIENT_NEGATIVE_COVERAGE')
    def test_empty_search_is_not_negative_evidence(self):
        n=node();n['payload']['coverage_standard']={};self.assertEqual(valid(seal(n)),'INSUFFICIENT_NEGATIVE_COVERAGE')
    def test_truthy_string_cannot_certify(self):
        n=node();n['payload']['coverage_standard']['period_inventory_complete']='true';self.assertEqual(valid(seal(n)),'INSUFFICIENT_NEGATIVE_COVERAGE')
    def test_missing_node(self):
        n=node();self.assertEqual(evaluate_dependencies({'dependencies':[dep(n)]},[],{},ASOF)[n['evidence_id']],'MISSING')
    def test_reported_semantics_never_infers_purchase_or_sale(self):
        for quantity,expected in [('99','REPORTED_REDUCED'),('100','REPORTED_UNCHANGED'),('101','REPORTED_INCREASED')]:
            x=fixture();x['current']['quantity']=quantity;r=reported_semantics(resolve(rebind(x)));self.assertEqual(r['reported_status'],expected);self.assertIsNone(r['inferred_manager_transaction']);self.assertFalse(r['transaction_inference_public'])
    def test_conflicting_raw_classes_in_one_filer_quarter_are_not_certified(self):
        from build import primary_classes_consistent
        observations=[{'manager_id':'m','quarter':'2026-03-31','security_class':c} for c in ['COM','PREFERRED']]
        self.assertFalse(primary_classes_consistent(observations))
    def test_issuer_inventory_does_not_omit_exchange_offer(self):
        for form in ['S-4','S-4/A','424B3','425','8-K/A','10-Q/A','F-4/A','DEFA14A']:
            self.assertTrue(relevant_form(form),form)

class CorpusIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.engine=Engine()
    def test_scope_exactly5314_and_disjoint_from_structural_and_human(self):
        from build import baseline
        expected={r['comparison_id'] for r in baseline() if r['resolution_bucket']=='EVIDENCE_RESOLVABLE'};self.assertEqual(set(self.engine.comparisons),expected);self.assertEqual(len(expected),5314)
    def test_perimeter_and_amendment_reach_all_manager_rows(self):
        e=self.engine;rows=[c for c in e.comparisons.values() if c['manager_id']=='brown-advisory'];self.assertEqual(len(rows),1472)
        for kind in ['MANAGER_PERIMETER','AMENDMENT_STATE','FILING_USABILITY']:
            nodes=[n for n in e.nodes if n['evidence_type']==kind and n['subject_id']=='brown-advisory']
            for n in nodes:self.assertEqual(set(n['blocks_comparisons']),{c['comparison_id'] for c in rows})
    def test_security_and_action_reach_all_visa_managers(self):
        e=self.engine;rows=[c for c in e.comparisons.values() if c['security_id']=='92826C839|LONG|SH'];self.assertEqual(len(rows),14)
        for kind in ['SECURITY_CONTINUITY','CORPORATE_ACTION_STATE']:
            n=next(n for n in e.nodes if n['evidence_type']==kind and n['subject_id']=='92826C839|LONG|SH');self.assertEqual(set(n['blocks_comparisons']),{c['comparison_id'] for c in rows})
    def test_independently_bound_filer_rejects_tampered_edge(self):
        e=self.engine;cid=next(iter(e.comparisons));c=e.comparisons[cid];original=copy.deepcopy(c['dependencies'])
        try:
            d=next(d for d in c['dependencies'] if d['evidence_type']=='MANAGER_PERIMETER');d['scope']['manager_id']='another-filer'
            with self.assertRaises(AssertionError):e.evaluate(cid)
        finally:c['dependencies']=original
    def test_missing_required_dependency_cannot_bypass_guard(self):
        e=self.engine;cid=next(iter(e.comparisons));c=e.comparisons[cid];original=copy.deepcopy(c['dependencies'])
        try:
            c['dependencies']=[d for d in c['dependencies'] if d['evidence_type']!='CORPORATE_ACTION_STATE']
            with self.assertRaises(AssertionError):e.evaluate(cid)
        finally:c['dependencies']=original
    def test_no_expansion_outside_input(self):
        with self.assertRaisesRegex(ValueError,'OUTSIDE_5314'):self.engine.evaluate('first-eagle::02079K107|LONG|SH')
    def test_unknown_action_still_blocks_real_comparison(self):
        cid=next(c['comparison_id'] for c in self.engine.comparisons.values() if c['security_id']=='92826C839|LONG|SH');self.assertEqual(self.engine.evaluate(cid)['reported_status'],'INDETERMINATE')
    def test_all_dependency_scopes_and_hashes_validate_or_explicitly_unknown(self):
        e=self.engine
        from model import validate_node
        for c in e.comparisons.values():
            for d in c['dependencies']:
                status=validate_node(e.byid[d['evidence_id']],d,e.adapter.source_hashes,e.graph['evidence_as_of']);self.assertIn(status,['VALID','UNKNOWN'],(c['comparison_id'],status))
if __name__=='__main__':unittest.main()

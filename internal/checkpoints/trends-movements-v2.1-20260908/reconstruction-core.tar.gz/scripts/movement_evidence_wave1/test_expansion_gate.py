import copy,unittest
import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('wave1_runner',Path(__file__).with_name('run.py'));runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
class ExpansionGateTests(unittest.TestCase):
    def fixture(self):return {'state':'PASS','fingerprint':'current','false_positives':0,'confirmed_false_negatives':0,'tests_exit_code':0,'qualified_diversity':{'comparisons':501,'managers':19,'securities':66,'known_sectors':8},'unreviewed_node_ids':[],'unqualified_node_ids':[]}
    def test_qualified_current_pilot_can_expand(self):self.assertEqual(runner.gate_errors(self.fixture(),'current'),[])
    def test_zero_false_positives_abstaining_pilot_cannot_expand(self):
        g=self.fixture();g['qualified_diversity']['comparisons']=0;self.assertIn('QUALIFIED_DIVERSITY_COMPARISONS',runner.gate_errors(g,'current'))
    def test_every_qualified_diversity_dimension_required(self):
        for k in self.fixture()['qualified_diversity']:
            g=self.fixture();g['qualified_diversity'][k]=0;self.assertTrue(runner.gate_errors(g,'current'))
    def test_stale_fingerprint(self):self.assertIn('STALE_CODE_OR_EVIDENCE',runner.gate_errors(self.fixture(),'new'))
    def test_failed_or_unreviewed_or_unknown_evidence_blocks(self):
        for field,value in [('state','FAIL'),('false_positives',1),('confirmed_false_negatives',1),('tests_exit_code',1),('unreviewed_node_ids',['x']),('unqualified_node_ids',['x'])]:
            g=self.fixture();g[field]=value;self.assertTrue(runner.gate_errors(g,'current'),field)
if __name__=='__main__':unittest.main()

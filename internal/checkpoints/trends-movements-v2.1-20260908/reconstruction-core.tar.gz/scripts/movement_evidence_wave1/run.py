"""Pilot-bound evaluation; expansion cannot proceed on a vacuous zero-error abstention."""
import argparse,gzip,hashlib,json,subprocess,sys
from build import ROOT,BASE,OUT,read,write,baseline
from model import digest,canonical
from engine import Engine

INPUTS=['reviewed-node-attestations.json','evidence-dag.json','pilot-selection.json','pilot-primary-dossier.json','pilot-manual-review.json','sector-registry.json','issuer-index-supplement.json','issuer-primary-supplement.json','corporate-action-research-inventory.json','corporate-action-primary-review.json','MODEL.md']
def fingerprint():
    paths=[p for folder in ['movement_qualification','movement_evidence_wave1'] for p in (ROOT/'scripts'/folder).glob('*.py')]
    paths += [OUT/n for n in INPUTS]+[p for p in BASE.iterdir() if p.is_file()]
    paths += list((ROOT/'lib/trends/capital/generated').glob('*'))
    return digest({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)})

def gate_errors(gate,current):
    errors=[]
    if gate.get('state')!='PASS':errors.append('PILOT_NOT_PASS')
    if gate.get('fingerprint')!=current:errors.append('STALE_CODE_OR_EVIDENCE')
    if gate.get('false_positives')!=0 or gate.get('confirmed_false_negatives')!=0:errors.append('PILOT_ERRORS')
    if gate.get('tests_exit_code')!=0:errors.append('TESTS_NOT_PASS')
    d=gate.get('qualified_diversity',{})
    for k,n in {'comparisons':500,'managers':10,'securities':20,'known_sectors':5}.items():
        if d.get(k,0)<n:errors.append('QUALIFIED_DIVERSITY_'+k.upper())
    if gate.get('unreviewed_node_ids') or gate.get('unqualified_node_ids'):errors.append('UNVERIFIED_PILOT_NODES')
    return errors

def pilot():
    e=Engine();selection=read('pilot-selection.json');dossier=read('pilot-primary-dossier.json');review=read('pilot-manual-review.json')
    assert review['dossier_sha256']==digest(dossier) and review['selection_sha256']==digest(selection)
    oracle={r['comparison_id']:r for r in review['comparison_oracle']};assert set(oracle)==set(selection['comparison_ids'])
    reviewed={r['evidence_id']:r for r in review['node_reviews']};used={d['evidence_id'] for cid in selection['comparison_ids'] for d in e.comparisons[cid]['dependencies']}
    unreviewed=[eid for eid in sorted(used) if eid not in reviewed or reviewed[eid]['node_hash']!=e.byid[eid]['hash']]
    results=[e.evaluate(cid) for cid in selection['comparison_ids']];fp=[];fn=[];unknown=[]
    for r in results:
        expected=oracle[r['comparison_id']]
        if r['reported_status']!='INDETERMINATE' and r['reported_status']!=expected['expected_status']:fp.append(r['comparison_id'])
        if expected['ground_truth']=='QUALIFIED_PRIMARY' and r['reported_status']=='INDETERMINATE':fn.append(r['comparison_id'])
        if expected['ground_truth']=='INSUFFICIENT_PRIMARY_COVERAGE':unknown.append(r['comparison_id'])
    qualified=[r for r in results if r['reported_status']!='INDETERMINATE'];sectors=read('sector-registry.json')
    qrows=[e.rows[r['comparison_id']] for r in qualified]
    diversity={'comparisons':len(qrows),'managers':len({r['manager_id'] for r in qrows}),'securities':len({r['security_id'] for r in qrows}),'known_sectors':len({sectors[r['security_id']]['sector'] for r in qrows if r['security_id'] in sectors and sectors[r['security_id']]['sector']!='UNKNOWN'})}
    runs=[subprocess.run([sys.executable,'-m','unittest','discover','-s',str(ROOT/'scripts'/folder),'-p','test_*.py'],cwd=ROOT,capture_output=True,text=True) for folder in ['movement_qualification','movement_evidence_wave1']]
    (OUT/'python-tests.txt').write_text('\n'.join(r.stdout+r.stderr for r in runs));tests=max(r.returncode for r in runs)
    unqualified=sorted({eid for r in results for eid,status in r['dependency_checks'].items() if status!='VALID'})
    gate={'state':'PASS','fingerprint':fingerprint(),'false_positives':len(fp),'false_positive_ids':fp,'confirmed_false_negatives':len(fn),'confirmed_false_negative_ids':fn,'false_negative_ground_truth_unavailable':len(unknown),'qualified_diversity':diversity,'selected_diversity':read('pilot-diversity.json'),'tests_exit_code':tests,'unreviewed_node_ids':unreviewed,'unqualified_node_ids':unqualified,'limitation':'Zero false positives among abstentions is not a successful resolution pilot. Unknown economic outcomes are not counted as proven negatives.','comparison_results':results}
    errors=gate_errors(gate,gate['fingerprint']);gate['state']='FAIL' if fp or fn or tests else 'BLOCKED_EVIDENCE_COVERAGE' if errors else 'PASS';gate['gate_errors']=errors
    write('pilot-results.json',gate);print(json.dumps({k:v for k,v in gate.items() if k not in ['comparison_results','unqualified_node_ids']},indent=2))

def expand():
    gate=read('pilot-results.json');errors=gate_errors(gate,fingerprint())
    if errors:
        write('expansion-gate.json',{'state':'NOT_EXECUTED','reasons':errors,'comparisons_applied':0,'baseline_preserved':True});raise SystemExit('STOP_EXPANSION: '+','.join(errors))
    e=Engine();results=[e.evaluate(cid) for cid in sorted(e.comparisons)];assert len(results)==5314
    (OUT/'qualification-results.jsonl.gz').write_bytes(gzip.compress(''.join(canonical(r)+'\n' for r in results).encode(),mtime=0))
    write('expansion-gate.json',{'state':'APPLIED','comparisons_applied':len(results),'fingerprint':fingerprint(),'structural_and_human_cases_preserved':True})
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['pilot','expand']);args=p.parse_args();pilot() if args.phase=='pilot' else expand()

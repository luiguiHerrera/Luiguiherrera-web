"""Build a scoped, immutable evidence DAG from the validated frozen baseline."""
from collections import Counter,defaultdict
from copy import deepcopy
from datetime import datetime,timezone
from decimal import Decimal
import gzip,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'movement_qualification'))
from adapter import Adapter
from freeze import ROOT,OUT as BASE,key
from evidence import source_ref
from model import canonical,digest,seal,scope_id
OUT=ROOT/'internal/trends-movements/wave1'

def write(name,value): (OUT/name).write_text(canonical(value)+'\n')
def read(name):return json.loads((OUT/name).read_text())
def baseline():return [json.loads(l) for l in gzip.decompress((BASE/'qualification-results.jsonl.gz').read_bytes()).splitlines()]
def load():
    a=Adapter();supp=read('issuer-index-supplement.json')
    for u,r in supp['responses'].items():
        assert __import__('hashlib').sha256(r['body'].encode()).hexdigest()==r['sha256']
        assert u not in a.sources, 'Do not replace historical primary evidence with newer bytes'
        a.sources[u]={**r,'archive':str((OUT/'issuer-index-supplement.json').relative_to(ROOT))}
    a.source_hashes={u:r['sha256'] for u,r in a.sources.items()}
    return a

def review_source_catalog(adapter):
    catalog=dict(adapter.source_hashes)
    for u,r in read('issuer-primary-supplement.json')['responses'].items():
        assert __import__('hashlib').sha256(r['body'].encode()).hexdigest()==r['sha256']
        assert u not in catalog or catalog[u]==r['sha256'],'Conflicting primary source versions'
        catalog[u]=r['sha256']
    return catalog

def primary_classes_consistent(observations):
    groups=defaultdict(set)
    for o in observations:groups[(o['manager_id'],o['quarter'])].add(o['security_class'])
    return all(len(classes)==1 for classes in groups.values())

def build():
    a=load();old=baseline();eligible={r['comparison_id'] for r in old if r['resolution_bucket']=='EVIDENCE_RESOLVABLE'}
    assert len(eligible)==5314
    rows=[r for r in a.rows if r['comparison_id'] in eligible];byid={r['comparison_id']:r for r in rows};companies={c['id']:c for c in a.snapshot['companies']}
    asof=a.snapshot['as_of'];start=a.snapshot['previous_quarter_end'];end=a.snapshot['quarter_end']
    if not (OUT/'review-clock.json').exists():write('review-clock.json',{'verified_at':datetime.now(timezone.utc).isoformat()})
    verified_at=read('review-clock.json')['verified_at'];nodes={};comparisons=[];primary={};security_rows=defaultdict(list)
    for r in rows:security_rows[r['security_id']].append(r)
    def add(kind,subject,pstart,pend,scope,payload,status,refs,method,proof=None):
        eid=scope_id(kind,subject,pstart,pend)
        n={'evidence_id':eid,'evidence_type':kind,'subject_id':subject,'period_start':pstart,'period_end':pend,'scope':scope,'payload':payload,'status':status,'source_refs':sorted({canonical(r):r for r in refs}.values(),key=lambda r:r['url']),'verified_at':verified_at if status.startswith('VERIFIED') else None,'verification_method':method,'evidence_as_of':asof,'conflicts':[],'blocks_comparisons':[],'unlocks_count':0}
        if eid in nodes:assert canonical({k:v for k,v in nodes[eid].items() if k not in ['blocks_comparisons','unlocks_count']})==canonical(n)
        else:nodes[eid]=n
        if proof is not None:primary[eid]=proof
        return {k:n[k] for k in ['evidence_id','evidence_type','subject_id','period_start','period_end','scope']}
    # Filings and perimeters are examined first, once per filer/period.
    managers=[];amendments=[];manager_deps={}
    for mid,p in a.perimeters.items():
        def side_data(side):
            q=a.quarters[side][mid]
            return [{'accession':f['accession_number'],'source_ref':source_ref(f['source_url'],a.sources),'cover':{k:a.raw[f['source_url']][k] for k in ['CIK','quarter','form','report_type','confidential','amendment','included','reporting']}} for f in q['filings']]
        pp,cc=p['Q1_REPORTING_PERIMETER'],p['Q2_REPORTING_PERIMETER']
        managers.append({'manager_id':mid,'Q1_REPORTING_GROUP':pp,'Q2_REPORTING_GROUP':cc,'Q1_INCLUDED_MANAGERS':pp['included'] if pp else None,'Q2_INCLUDED_MANAGERS':cc['included'] if cc else None,'PERIMETER_EQUIVALENT':p['PERIMETER_EQUIVALENT'],'REASON':p['REASON'],'PRIMARY_EVIDENCE':p['EVIDENCE'],'raw_cover_review':{'previous':side_data('previous'),'current':side_data('current')},'wave1_comparisons':sum(r['manager_id']==mid for r in rows),'disposition_changed':False})
        relevant=next((r for r in rows if r['manager_id']==mid),None)
        x=a.make(relevant) if relevant else None;deps=[]
        if x:
            payload={k:v for k,v in x['perimeter'].items() if k not in ['binding','verification_status','evidence_refs']}
            payload.update(Q1_REPORTING_GROUP=pp,Q2_REPORTING_GROUP=cc)
            deps.append(add('MANAGER_PERIMETER',mid,start,end,{'manager_id':mid,'manager_group_id':relevant['manager_group_id'],'CIK':a.managers[mid]['CIK']},payload,'VERIFIED_CLEAR',p['EVIDENCE'],'PRIMARY_COVER_IDENTIFIER_SETS_EXACT_MATCH',managers[-1]))
        for side in ['previous','current']:
            q=a.quarters[side][mid];am=a.amendments[(mid,q['quarter_end'])];original=[f['accession_number'] for f in q['filings'] if f['amendment']=='NONE']; amended=[f for f in q['filings'] if f['amendment']!='NONE']
            entry={'manager_id':mid,'quarter':q['quarter_end'],'ORIGINAL_ACCESSION':original,'AMENDMENT_ACCESSION':[f['accession_number'] for f in amended],'AMENDMENT_TYPE':[f['amendment'] for f in amended],'RESTATEMENT':am['state']=='RESTATEMENT','ADDITIVE':am['state']=='ADDITIVE_CONFIRMED','NON_HOLDINGS':any(f['form_type'].startswith('13F-NT') for f in q['filings']),'AMBIGUOUS':am['state']=='AMBIGUOUS','USABLE_FINAL_VIEW':am['selected_accessions'] if q['status']=='available' and am['state']!='AMBIGUOUS' else None,'PRIMARY_EVIDENCE':am['evidence_refs'],'primary_covers':side_data(side),'state':am['state']}
            amendments.append(entry)
            if x:
                scope={'manager_id':mid,'manager_group_id':relevant['manager_group_id'],'CIK':a.managers[mid]['CIK'],'accessions':am['all_accessions'],'selected_accessions':am['selected_accessions']}
                for kind,claim in [('AMENDMENT_STATE',x['amendments'][side]),('FILING_USABILITY',x['filings'][side])]:
                    payload={k:v for k,v in claim.items() if k not in ['binding','verification_status','evidence_refs']}
                    refs=claim['evidence_refs']+[source_ref(a.managers[mid]['source_url'],a.sources)]
                    deps.append(add(kind,mid,q['quarter_end'],q['quarter_end'],scope,payload,'VERIFIED_CLEAR',refs,'PRIMARY_COVER_AND_SUBMISSION_INDEX_RECONSTRUCTION',entry))
        if relevant:manager_deps[mid]=deps
    # Security certificates preserve identifier/class facts. Issuer binding remains independent.
    security_deps={};sector_registry={}
    for sec,rs in sorted(security_rows.items()):
        issuer=rs[0]['issuer_id'];assert all(r['issuer_id']==issuer for r in rs)
        refs={};observations=[];classes=set();both=[r for r in rs if r['previous_quantity'] is not None and r['current_quantity'] is not None]
        for r in rs:
            for side in ['previous','current']:
                for u in r[side+'_sources']:
                    rec=a.raw[u]
                    for rawrow in rec['rows'].get(sec,[]):
                        obs={'manager_id':r['manager_id'],'quarter':r[side+'_quarter'],'source_ref':source_ref(u,a.sources),**rawrow}
                        observations.append(obs);classes.add(rawrow['security_class']);refs[u]=source_ref(u,a.sources)
        # Only same exact per-comparison class is reusable; textual variants are recorded, not equated.
        qualified=bool(both) and all(r['previous_security_class']==r['current_security_class'] for r in both) and primary_classes_consistent(observations)
        scope={'security_ids':[sec],'instrument_type':rs[0]['instrument_type'],'put_call':rs[0]['put_call']}
        payload={'relationship':'SAME_SECURITY' if qualified else 'UNKNOWN','previous_security':sec,'current_security':sec,'issuer_id':issuer,'one_to_one':qualified,'observed_class_labels':sorted(classes),'rule':'Exact full issue key and same class within each both-present pair; no equivalence between different class labels is asserted.'}
        dep=add('SECURITY_CONTINUITY',sec,start,end,scope,payload,'VERIFIED_CLEAR' if qualified else 'UNKNOWN',list(refs.values()),'PRIMARY_CUSIP_INSTRUMENT_AND_PAIR_CLASS_MATCH',{'security_id':sec,'issuer_id':issuer,'both_present_comparison_ids':[r['comparison_id'] for r in both],'observations':observations})
        # No automatic promotion of an empty action registry, nor GOOG Class C clearance to GOOGL.
        urls=[]
        if issuer:
            cik=int(issuer.removeprefix('sec-issuer-'))
            urls=[u for u in a.sources if ('/data/' in u and __import__('re').search(r'/data/0*'+str(cik)+r'/',u)) or u=='https://data.sec.gov/submissions/CIK'+str(cik).zfill(10)+'.json']
            url='https://data.sec.gov/submissions/CIK'+str(cik).zfill(10)+'.json'
            if url in a.sources:
                doc=json.loads(a.sources[url]['body']);assert int(doc['cik'])==cik
                sector_registry[sec]={'issuer_id':issuer,'sic':doc.get('sic'),'sic_description':doc.get('sicDescription'),'sector':'SEC_SIC_2_DIGIT:'+str(doc['sic'])[:2] if doc.get('sic') else 'UNKNOWN','source_ref':source_ref(url,a.sources),'taxonomy':'SEC SIC two-digit industry group, explicitly not GICS','mapping_source':'Frozen authoritative issuer/security mapping in public config; no name/ticker inference.'}
        ca=add('CORPORATE_ACTION_STATE',sec,start,end,{'issuer_id':issuer,'security_ids':[sec]},{'issuer_id':issuer,'security_ids':[sec],'coverage_standard':{},'events':[],'coverage_review_status':'PENDING_EXPLICIT_PRIMARY_REVIEW','missing':['PERIOD_COMPLETE_CLASS_SPECIFIC_TRANSFORMATION_REVIEW']+([] if issuer else ['AUTHORITATIVE_ISSUER_BINDING'])},'UNKNOWN',[source_ref(u,a.sources) for u in sorted(urls)],'PENDING_PERIOD_INVENTORY_AND_EQUITY_TERMS_REVIEW')
        security_deps[sec]=[dep,ca]
    for r in rows:
        deps=manager_deps[r['manager_id']]+security_deps[r['security_id']]
        presence='BOTH_PRESENT' if r['previous_quantity'] is not None and r['current_quantity'] is not None else 'PREVIOUS_ONLY' if r['previous_quantity'] is not None else 'CURRENT_ONLY'
        if presence!='BOTH_PRESENT':
            deps=deps+[add('PRESENCE_TRANSITION',r['comparison_id'],start,end,{'manager_id':r['manager_id'],'security_ids':[r['security_id']],'absent_side':'current' if presence=='PREVIOUS_ONLY' else 'previous'},{'qualified':False,'tier':'B','deferred':True},'UNKNOWN',[],'DEFERRED_STRICT_TIER_B')]
        c={'comparison_id':r['comparison_id'],'manager_id':r['manager_id'],'security_id':r['security_id'],'issuer_id':r['issuer_id'],'presence':presence,'dependencies':deps};comparisons.append(c)
        for dep in deps:nodes[dep['evidence_id']]['blocks_comparisons'].append(r['comparison_id'])
    # reverse edges are all dependent comparisons; unlocks_count means conditional reach, not achieved gain.
    for n in nodes.values():
        n['blocks_comparisons']=sorted(n['blocks_comparisons']);n['unlocks_count']=len(n['blocks_comparisons']);n.update(seal(n))
    from attestations import apply_attestations
    catalog=review_source_catalog(a)
    nodes=apply_attestations(nodes,read('reviewed-node-attestations.json')['records'],catalog,asof)
    material={};top10=Counter()
    for q in a.snapshot['current']:
        for h in sorted(q['positions'],key=lambda h:-Decimal(str(h['reported_value'])))[:10]:top10[key(h)]+=1
    eligible_public=sorted([c for c in a.snapshot['companies'] if not c['put_call'] and c['id'].endswith('|SH')],key=lambda c:(-c['managers'],c['issuer'],c['id']))
    public=set(c['id'] for c in eligible_public[:8]);themes={t for c in eligible_public for t in c['trend_ids']}
    for theme in themes:public.update(c['id'] for c in [v for v in eligible_public if theme in v['trend_ids']][:8])
    for sec,rs in security_rows.items():
        company=companies.get(sec,{})
        material[sec]={'current_managers_all_filers':company.get('managers',0),'top10_manager_overlap':top10[sec],'trend_links':len(company.get('trend_ids',[])),'trend_ids':company.get('trend_ids',[]),'appears_public_capital_view':sec in public}
    tasks=[]
    for n in nodes.values():
        if n['status'].startswith('VERIFIED'):continue
        rr=[byid[cid] for cid in n['blocks_comparisons']];securities={r['security_id'] for r in rr};mats=[material[s] for s in securities];both=sum(r['previous_quantity'] is not None and r['current_quantity'] is not None for r in rr)
        tasks.append({'evidence_id':n['evidence_id'],'subject_id':n['subject_id'],'security_ids':sorted(securities),'issuer_ids':sorted({r['issuer_id'] for r in rr if r['issuer_id']}),'open_requirements':n['payload'].get('missing',['STRICT_TIER_B'] if n['evidence_type']=='PRESENCE_TRANSITION' else ['AUTHORITATIVE_CONTINUITY']),'comparisons_affected':len(rr),'managers_affected':len({r['manager_id'] for r in rr}),'securities_affected':len(securities),'expected_resolution_gain':both if n['evidence_type']=='CORPORATE_ACTION_STATE' else 0,'expected_gain_condition':'All prerequisite questions and authoritative coverage must be verified; not an empirical forecast or achieved count.','evidence_type':n['evidence_type'],'primary_sources_retained':len(n['source_refs']),'materiality':{'top10_manager_overlap':sum(m['top10_manager_overlap'] for m in mats),'trend_links':sum(m['trend_links'] for m in mats),'public_capital_securities':sum(m['appears_public_capital_view'] for m in mats)},'verification_strength_rank':2 if n['source_refs'] else 0,'deferred':n['evidence_type']=='PRESENCE_TRANSITION'})
    tasks.sort(key=lambda t:(t['deferred'],-t['expected_resolution_gain'],-t['managers_affected'],-t['materiality']['public_capital_securities'],-t['materiality']['top10_manager_overlap'],-t['materiality']['trend_links'],-t['verification_strength_rank'],t['evidence_id']))
    counts={'EVIDENCE_RESOLVABLE_INPUT':len(rows),'BOTH_PRESENT':sum(c['presence']=='BOTH_PRESENT' for c in comparisons),'UNIQUE_MANAGER_QUARTER_PAIRS':len(manager_deps),'UNIQUE_MANAGER_QUARTER_OBSERVATIONS':2*len(manager_deps),'UNIQUE_SECURITY_QUARTER_OBSERVATIONS':len({(r['security_id'],r[side+'_quarter']) for r in rows for side in ['previous','current'] if r[side+'_quantity'] is not None}),'UNIQUE_ISSUER_QUARTER_OBSERVATIONS':len({(r['issuer_id'],r[side+'_quarter']) for r in rows for side in ['previous','current'] if r['issuer_id'] and r[side+'_quantity'] is not None}),'UNIQUE_SECURITY_QUARTER_PAIRS':len(security_rows),'UNIQUE_ISSUER_QUARTER_PAIRS':len({r['issuer_id'] for r in rows if r['issuer_id']}),'ISSUER_BINDING_UNKNOWN_SECURITY_PAIRS':len({r['security_id'] for r in rows if not r['issuer_id']}),'UNIQUE_CORPORATE_ACTION_QUESTIONS':sum(n['evidence_type']=='CORPORATE_ACTION_STATE' for n in nodes.values()),'UNIQUE_SECURITY_IDENTITY_QUESTIONS':sum(n['evidence_type']=='SECURITY_CONTINUITY' for n in nodes.values()),'UNIQUE_AMENDMENT_QUESTIONS':sum(n['evidence_type']=='AMENDMENT_STATE' for n in nodes.values()),'UNIQUE_PERIMETER_QUESTIONS':len(manager_deps),'EVIDENCE_NODES_CREATED':len(nodes),'EVIDENCE_NODES_VERIFIED':sum(n['status'].startswith('VERIFIED') for n in nodes.values()),'definitions':{'quarter_pairs':'Distinct subject over the Q1→Q2 comparison period; quarterly filing/amendment observations counted separately.','issuer_count':'Known authoritative issuer IDs only; unknowns never collapsed to a fictional issuer.','unlocks_count':'Dependent comparison reach, conditional on every other requirement; not actual resolutions.'},'nodes_by_type_status':dict(Counter(n['evidence_type']+'/'+n['status'] for n in nodes.values()))}
    # Fix the prospective pilot before execution. Leverage first, then factual materiality, stable hash tie-break.
    if (OUT/'pilot-selection.json').exists():selection=read('pilot-selection.json');assert set(selection['comparison_ids']).issubset(eligible)
    else:
        chosen=[];ids=set()
        for t in tasks:
            if t['evidence_type']!='CORPORATE_ACTION_STATE' or not t['expected_resolution_gain']:continue
            n=nodes[t['evidence_id']];chosen.append(t['evidence_id']);ids.update(cid for cid in n['blocks_comparisons'] if byid[cid]['previous_quantity'] is not None and byid[cid]['current_quantity'] is not None)
            if len(ids)>=500:break
        selection={'evidence_task_ids':chosen,'comparison_ids':sorted(ids),'selection_rule':'Prospective descending conditional BOTH_PRESENT reach, managers, public materiality, source strength; no resolution outcomes used.','minimums':{'comparisons':500,'managers':10,'securities':20,'sectors':5},'publication_authorized':False};write('pilot-selection.json',selection)
    selrows=[byid[cid] for cid in selection['comparison_ids']];seldeps=sorted({d['evidence_id'] for c in comparisons if c['comparison_id'] in set(selection['comparison_ids']) for d in c['dependencies']})
    sectors={sector_registry[r['security_id']]['sector'] for r in selrows if r['security_id'] in sector_registry and sector_registry[r['security_id']]['sector']!='UNKNOWN'}
    diversity={'comparisons':len(selrows),'managers':len({r['manager_id'] for r in selrows}),'securities':len({r['security_id'] for r in selrows}),'known_issuers':len({r['issuer_id'] for r in selrows if r['issuer_id']}),'known_sectors':len(sectors),'sectors':sorted(sectors),'sector_unknown_comparisons':sum(r['security_id'] not in sector_registry for r in selrows),'distinct_quantity_pairs':len({(r['previous_quantity'],r['current_quantity']) for r in selrows}),'alphabet_comparisons':sum(r['issuer_id']=='sec-issuer-1652044' for r in selrows),'taxonomy':'SEC SIC two-digit industry groups; unknown sectors separately disclosed'}
    dossier={'selection_sha256':digest(selection),'diversity':diversity,'evidence_nodes':[{'node':nodes[eid],'primary_observations':primary.get(eid)} for eid in seldeps],'quantity_provenance':[{'comparison_id':r['comparison_id'],'previous_quantity':r['previous_quantity'],'current_quantity':r['current_quantity'],'previous_sources':r['previous_sources'],'current_sources':r['current_sources']} for r in selrows]}
    if (OUT/'pilot-primary-dossier.json').exists():assert read('pilot-primary-dossier.json')==dossier,'STOP: fixed pilot dossier changed; review and explicitly version the pilot before proceeding'
    else:write('pilot-primary-dossier.json',dossier)
    write('evidence-dag.json',{'schema_version':1,'evidence_as_of':asof,'nodes':list(nodes.values()),'comparisons':comparisons,'acyclicity':'Comparison roots point only to terminal evidence nodes; no evidence-to-comparison dependency edges.'})
    for name,data in [('decomposition.json',counts),('manager-perimeter-review.json',managers),('amendment-filing-review.json',amendments),('sector-registry.json',sector_registry),('materiality.json',material),('top-evidence-tasks.json',tasks),('pilot-diversity.json',diversity),('source-index.json',{u:source_ref(u,a.sources) for u in sorted(a.sources)})]:write(name,data)
    print(json.dumps({'decomposition':counts,'pilot':diversity,'top_tasks':tasks[:5]},indent=2))
if __name__=='__main__':build()

"""Shared evidence adapter around the unchanged, tested v2.1 pure resolver."""
from copy import deepcopy
from model import evaluate_dependencies,reported_semantics
from build import load,read,baseline,review_source_catalog
from resolver import resolve,binding

class Engine:
    def __init__(self):
        self.adapter=load();self.adapter.source_hashes=review_source_catalog(self.adapter);self.graph=read('evidence-dag.json');self.nodes=self.graph['nodes'];self.byid={n['evidence_id']:n for n in self.nodes};self.comparisons={c['comparison_id']:c for c in self.graph['comparisons']};self.rows={r['comparison_id']:r for r in self.adapter.rows}
        assert self.graph['evidence_as_of']==self.adapter.snapshot['as_of']
        assert set(self.comparisons)=={r['comparison_id'] for r in baseline() if r['resolution_bucket']=='EVIDENCE_RESOLVABLE'}
        assert len(self.graph['comparisons'])==len(self.comparisons)==5314
    def evaluate(self,cid):
        if cid not in self.comparisons:raise ValueError('OUTSIDE_5314_SCOPE')
        c=self.comparisons[cid];row=self.rows[cid];a=self.adapter;x=a.make(row)
        # Derive scope independently from immutable primary-bound rows, not editable graph edges.
        assert c['manager_id']==row['manager_id'] and c['security_id']==row['security_id'] and c['issuer_id']==row['issuer_id']
        for d in c['dependencies']:
            kind=d['evidence_type'];scope=d['scope']
            if kind=='MANAGER_PERIMETER':
                assert scope=={'manager_id':row['manager_id'],'manager_group_id':row['manager_group_id'],'CIK':a.managers[row['manager_id']]['CIK']}
                assert d['subject_id']==row['manager_id'] and (d['period_start'],d['period_end'])==(row['previous_quarter'],row['current_quarter'])
            elif kind in ['FILING_USABILITY','AMENDMENT_STATE']:
                side='previous' if d['period_end']==row['previous_quarter'] else 'current'
                am=a.amendments[(row['manager_id'],row[side+'_quarter'])]
                assert d['subject_id']==row['manager_id'] and d['period_start']==d['period_end']==row[side+'_quarter']
                assert scope=={'manager_id':row['manager_id'],'manager_group_id':row['manager_group_id'],'CIK':a.managers[row['manager_id']]['CIK'],'accessions':am['all_accessions'],'selected_accessions':am['selected_accessions']}
            elif kind=='SECURITY_CONTINUITY':
                assert d['subject_id']==row['security_id'] and scope=={'security_ids':[row['security_id']],'instrument_type':row['instrument_type'],'put_call':row['put_call']}
                assert (d['period_start'],d['period_end'])==(row['previous_quarter'],row['current_quarter'])
            elif kind=='CORPORATE_ACTION_STATE':
                assert d['subject_id']==row['security_id'] and scope=={'issuer_id':row['issuer_id'],'security_ids':[row['security_id']]}
                assert (d['period_start'],d['period_end'])==(row['previous_quarter'],row['current_quarter'])
        from collections import Counter
        kinds=Counter(d['evidence_type'] for d in c['dependencies'])
        for kind,n in {'MANAGER_PERIMETER':1,'AMENDMENT_STATE':2,'FILING_USABILITY':2,'SECURITY_CONTINUITY':1,'CORPORATE_ACTION_STATE':1}.items():assert kinds[kind]==n
        assert len({d['evidence_id'] for d in c['dependencies']})==len(c['dependencies'])
        checks=evaluate_dependencies(c,self.nodes,a.source_hashes,self.graph['evidence_as_of'])
        legacy=resolve(x)
        if any(v!='VALID' for v in checks.values()):
            return {'comparison_id':cid,'dependency_checks':checks,**reported_semantics({**legacy,'movement_status':'INDETERMINATE','confidence':'INSUFFICIENT','qualification_tier':'UNQUALIFIED','reason_code':'SHARED_EVIDENCE_INCOMPLETE','blockers':['SHARED:'+eid+':'+v for eid,v in checks.items() if v!='VALID']})}
        return {'comparison_id':cid,'dependency_checks':checks,**reported_semantics(resolve(install_verified(x,[self.byid[d['evidence_id']] for d in c['dependencies']])))}

def install_verified(original,nodes):
    """Called only after shared scope/source validation. Legacy resolver still validates every claim."""
    x=deepcopy(original)
    def claim(node,values):return {**deepcopy(values),'verification_status':'VERIFIED','evidence_refs':deepcopy(node['source_refs'])}
    for n in nodes:
        kind=n['evidence_type'];p=n['payload']
        if kind=='MANAGER_PERIMETER':x['perimeter']=claim(n,p)
        elif kind in ['AMENDMENT_STATE','FILING_USABILITY']:
            side='previous' if n['period_end']==x['previous_quarter'] else 'current';x['amendments' if kind=='AMENDMENT_STATE' else 'filings'][side]=claim(n,p)
        elif kind=='SECURITY_CONTINUITY':
            relation={'SAME_SECURITY':'SAME_SECURITY','SUCCESSOR':'SUCCESSOR_OF','PREDECESSOR':'PREDECESSOR_OF','CLASS_CONVERSION':'CLASS_CONVERSION','CUSIP_CHANGE_SAME_SECURITY':'SUCCESSOR_OF'}.get(p['relationship'],'UNKNOWN_RELATION')
            x['continuity']=claim(n,{'relation':relation,'previous_security':p['previous_security'],'current_security':p['current_security'],'one_to_one':p['one_to_one'],'class_equivalence_verified':x['previous'] is not None and x['current'] is not None and x['previous']['security_class']==x['current']['security_class']})
        elif kind=='CORPORATE_ACTION_STATE':
            x['corporate_actions']={'coverage':claim(n,{'issuer_id':p['issuer_id'],'security_ids':p['security_ids'],'start':n['period_start'],'end':n['period_end'],'checks':p.get('checks',{})}),'events':[claim(n,e) for e in p.get('events',[])]}
    subject=binding(x)
    for c in [*x['filings'].values(),*x['amendments'].values(),x['perimeter'],x['continuity'],x['corporate_actions']['coverage'],*x['corporate_actions']['events'],x['presence_evidence']]:c['binding']=subject
    return x

Internal Wave 1 shared evidence qualification. No application imports or public outputs.

Run from the repository root with Python 3:

- `python3 scripts/movement_evidence_wave1/build.py`
- `python3 -m unittest discover -s scripts/movement_evidence_wave1 -p 'test_*.py'`
- `python3 scripts/movement_evidence_wave1/run.py pilot`
- `python3 scripts/movement_evidence_wave1/run.py expand` (requires current, diverse, fully qualified pilot)
- `python3 scripts/movement_evidence_wave1/report.py`

The build preserves the fixed pilot selection and refuses to overwrite its reviewed dossier if source/code inputs change. Manual node review is explicit and bound to source hashes; generation is not manual verification. A failed or blocked pilot never creates an expansion output. The baseline stays frozen under `internal/trends-movements/v2.1`. See `internal/trends-movements/wave1/MODEL.md` for scopes, negative evidence, materiality and pilot rules.

Explicit reviewed certificates are ingested from `reviewed-node-attestations.json`; empty inputs preserve UNKNOWN. The builder rejects conflicting, stale or differently scoped claims. Any changed certificate requires a versioned dossier review for the same fixed selection.

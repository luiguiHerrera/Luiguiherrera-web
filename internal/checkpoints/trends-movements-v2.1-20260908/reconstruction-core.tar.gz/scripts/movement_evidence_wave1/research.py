"""Reproducible issuer-period research inventories; no inference from search absence."""
from collections import Counter
import gzip,html,json,re
from build import load,read,write,OUT
from model import digest

def relevant_form(form):
    return form.startswith(('10-Q','10-K','8-K','6-K','20-F','40-F','S-','F-','424','425','POS','DEF','PRE','SC TO','SC 13E','CB','1-A','1-U','1-K','1-SA')) or form in ['EFFECT','RW']

def build_inventory():
    a=load();supp=read('issuer-primary-supplement.json')
    for u,r in supp['responses'].items():
        assert __import__('hashlib').sha256(r['body'].encode()).hexdigest()==r['sha256']
        a.sources[u]={**r,'archive':str((OUT/'issuer-primary-supplement.json').relative_to(OUT.parents[2]))}
    sources=a.sources;items=[]
    for n in [v['node'] for v in read('pilot-primary-dossier.json')['evidence_nodes'] if v['node']['evidence_type']=='CORPORATE_ACTION_STATE']:
        issuer=n['scope']['issuer_id'];item={'evidence_id':n['evidence_id'],'security_id':n['subject_id'],'issuer_id':issuer,'status':'UNKNOWN','verification_method':'PRIMARY_INDEX_COVERAGE_AUDIT_WITH_EXPLICIT_UNRESOLVED_CHECKS'}
        if not issuer:item.update(reason_code='MISSING_AUTHORITATIVE_ISSUER_SECURITY_BINDING',entries=[],coverage_standard={'issuer_security_binding':False});items.append(item);continue
        cik=int(issuer.removeprefix('sec-issuer-'));url='https://data.sec.gov/submissions/CIK'+str(cik).zfill(10)+'.json';d=json.loads(sources[url]['body']);rec=d['filings']['recent'];entries=[];excluded=Counter()
        for i,form in enumerate(rec['form']):
            if not '2026-03-01'<=rec['filingDate'][i]<='2026-08-31':continue
            if not relevant_form(form):excluded[form]+=1;continue
            u='https://www.sec.gov/Archives/edgar/data/'+str(cik)+'/'+rec['accessionNumber'][i].replace('-','')+'/'+rec['primaryDocument'][i]
            retained=next((v for v in sources if v==u or re.sub(r'/data/0+(\d+)/',r'/data/\1/',v)==u),None)
            entries.append({'form':form,'filing_date':rec['filingDate'][i],'report_date':rec['reportDate'][i],'url':u,'retained_url':retained,'primary_sha256':sources[retained]['sha256'] if retained else None,'exhibits_reviewed':False})
        item.update(index_source_ref={'url':url,'sha256':sources[url]['sha256']},recent_index_earliest_filing=min(rec['filingDate']),index_recent_covers_window=min(rec['filingDate'])<='2026-03-01',entries=entries,excluded_form_counts=dict(excluded),reason_code='CLASS_TERMS_EVENT_AND_EXHIBIT_REVIEW_INCOMPLETE',coverage_standard={'issuer_security_binding':True,'period_inventory_complete':False,'start_and_end_class_terms':False,'equity_rollforward_reviewed':False,'interim_events_and_exhibits_reviewed':False,'transformation_checks_explicit':False,'conflicts_resolved':False},inventory_limitations=['March–August index screen is a research perimeter, not a negative-evidence certificate. Prior effective terms and incorporation-by-reference exhibits may also be required.','Filing date and effective event date are distinct.','Retained filing text, issuer financial metrics and reported-share arithmetic do not prove invariant security units.'])
        items.append(item)
    write('corporate-action-research-inventory.json',items)
    print(json.dumps([{'security':x['security_id'],'documents_screened':len(x['entries']),'retained':sum(bool(e['retained_url']) for e in x['entries'])} for x in items if x['issuer_id']],indent=2))
if __name__=='__main__':build_inventory()

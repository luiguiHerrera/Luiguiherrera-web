"""Ingest explicit reviewed shared certificates; generation never grants a clearance."""
from copy import deepcopy
from model import validate_node

def apply_attestations(nodes,records,catalog,as_of):
    result=deepcopy(nodes);seen=set()
    for record in records:
        eid=record['evidence_id']
        if eid in seen:raise ValueError('CONFLICTING_ATTESTATIONS')
        seen.add(eid)
        if eid not in result:raise ValueError('ATTESTATION_OUTSIDE_DAG')
        expected=result[eid]
        if record['blocks_comparisons']!=expected['blocks_comparisons'] or record['unlocks_count']!=expected['unlocks_count']:raise ValueError('ATTESTATION_REACH_CHANGED')
        status=validate_node(record,expected,catalog,as_of)
        if status!='VALID':raise ValueError('ATTESTATION_REJECTED:'+status)
        result[eid]=deepcopy(record)
    return result

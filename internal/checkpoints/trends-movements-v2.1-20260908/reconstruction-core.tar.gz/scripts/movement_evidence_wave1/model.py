"""Pure shared evidence validation. Routing is separate from claim content; fail closed."""
from copy import deepcopy
from datetime import datetime
from hashlib import sha256
import json
from urllib.parse import urlparse

STATUSES={'VERIFIED_CLEAR','VERIFIED_EVENT','VERIFIED_BLOCK','UNKNOWN','STALE'}
TYPES={'MANAGER_PERIMETER','AMENDMENT_STATE','FILING_USABILITY','SECURITY_CONTINUITY','CORPORATE_ACTION_STATE','PRESENCE_TRANSITION'}
RELATIONSHIPS={'SAME_SECURITY','SUCCESSOR','PREDECESSOR','CLASS_CONVERSION','CUSIP_CHANGE_SAME_SECURITY','DISTINCT_SECURITIES','UNKNOWN'}
COVERAGE_CHECKS={'issuer_security_binding','period_inventory_complete','start_and_end_class_terms','equity_rollforward_reviewed','interim_events_and_exhibits_reviewed','transformation_checks_explicit','conflicts_resolved'}

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def digest(x):return sha256(canonical(x).encode()).hexdigest()
def scope_id(kind,subject,start,end):return kind+':'+digest([subject,start,end])[:24]
def seal(node):
    n=deepcopy(node);n['hash']=digest({k:v for k,v in n.items() if k!='hash'});return n

def validate_node(node,expected,catalog,as_of):
    """No state inferred from names, tickers, empty searches, current time or hashes alone."""
    try:
        for k in ['evidence_type','subject_id','period_start','period_end','scope']:
            if node[k]!=expected[k]:return 'SCOPE_MISMATCH'
        if node['evidence_id']!=expected['evidence_id'] or node['evidence_id']!=scope_id(node['evidence_type'],node['subject_id'],node['period_start'],node['period_end']):return 'SCOPE_MISMATCH'
        if node['evidence_type'] not in TYPES or node['status'] not in STATUSES:return 'MALFORMED'
        if node['hash']!=digest({k:v for k,v in node.items() if k!='hash'}):return 'NODE_HASH_CHANGED'
        if node['status']=='STALE' or node['evidence_as_of']!=as_of:return 'STALE'
        if node.get('conflicts'):return 'CONFLICTING_AUTHORITY'
        if node['status'] in ['UNKNOWN','VERIFIED_BLOCK']:return node['status']
        if not node['source_refs'] or not node['verification_method'] or not node['verified_at']:return 'UNATTESTED'
        datetime.fromisoformat(node['verified_at'].replace('Z','+00:00'))
        for r in node['source_refs']:
            u=urlparse(r['url'])
            if u.scheme!='https' or u.hostname not in ['www.sec.gov','data.sec.gov'] or u.username or u.password:return 'UNTRUSTED_SOURCE'
            if catalog.get(r['url'])!=r['sha256']:return 'SOURCE_HASH_CHANGED'
        p=node['payload'];kind=node['evidence_type']
        if kind=='MANAGER_PERIMETER' and p.get('equivalent')!='YES':return 'UNQUALIFIED_PERIMETER'
        if kind=='AMENDMENT_STATE' and (p.get('state') not in ['NONE','RESTATEMENT','ADDITIVE_CONFIRMED'] or p.get('composition_verified') is not True or not p.get('selected_accessions')):return 'UNQUALIFIED_AMENDMENT'
        if kind=='FILING_USABILITY' and not (p.get('status')=='USABLE' and all(p.get(k) is True for k in ['authoritative','complete']) and all(p.get(k) is False for k in ['confidential','notice_or_included','duplicate_economic_group'])):return 'UNUSABLE_FILING'
        if kind=='SECURITY_CONTINUITY':
            if p.get('relationship') not in RELATIONSHIPS or p['relationship'] in ['UNKNOWN','DISTINCT_SECURITIES'] or p.get('one_to_one') is not True:return 'UNQUALIFIED_CONTINUITY'
            if p['relationship']=='SAME_SECURITY' and p['previous_security']!=p['current_security']:return 'DISTINCT_SECURITIES'
        if kind=='CORPORATE_ACTION_STATE':
            cov=p.get('coverage_standard',{})
            if set(cov)!=COVERAGE_CHECKS or any(v is not True for v in cov.values()):return 'INSUFFICIENT_NEGATIVE_COVERAGE'
            if not p.get('issuer_id') or p['issuer_id']!=node['scope']['issuer_id'] or p.get('security_ids')!=node['scope']['security_ids']:return 'ISSUER_CLASS_MISMATCH'
            for event in p.get('events',[]):
                if not node['period_start']<event['effective_date']<=node['period_end']:return 'EVENT_OUTSIDE_PERIOD'
                if event['issuer_id']!=p['issuer_id'] or not set(event['affected_security_ids']).issubset(set(p['security_ids'])):return 'ISSUER_CLASS_MISMATCH'
        if kind=='PRESENCE_TRANSITION':return 'TIER_B_NOT_IMPLEMENTED_IN_WAVE1'
        return 'VALID'
    except (KeyError,TypeError,ValueError,AttributeError):return 'MALFORMED'

def evaluate_dependencies(comparison,nodes,catalog,as_of):
    indexed={};conflicts=set()
    for n in nodes:
        k=n['evidence_id']
        if k in indexed:conflicts.add(k)
        indexed[k]=n
    checks={}
    for d in comparison['dependencies']:
        eid=d['evidence_id']
        checks[eid]='CONFLICTING_AUTHORITY' if eid in conflicts else 'MISSING' if eid not in indexed else validate_node(indexed[eid],d,catalog,as_of)
    return checks

def reported_semantics(result):
    state=result['movement_status']
    return {**result,'quantity_model':'REPORTED_QUANTITY_CHANGE','reported_status':'REPORTED_'+state if state in ['INCREASED','REDUCED','UNCHANGED'] else 'INDETERMINATE','inferred_manager_transaction':None,'transaction_inference_public':False}

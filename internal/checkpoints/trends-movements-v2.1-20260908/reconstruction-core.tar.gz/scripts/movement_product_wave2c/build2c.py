"""Local product-feasibility analysis over immutable prior results; no resolver calls."""
from collections import Counter,defaultdict
from statistics import median
from decimal import Decimal
from context2c import *
from model2c import *

def retained_reference_pairs(raw,results):
    snapshot_path=ROOT/'lib/trends/capital/generated/snapshot.json.gz'
    manifest=read('corpus-manifest.json',ROOT/'internal/trends-movements/v2.1')
    assert sha(snapshot_path.read_bytes())==manifest['source_snapshot_sha256']
    snapshot=json.loads(gzip.decompress(snapshot_path.read_bytes()))
    universe={m['manager_id']:m for m in snapshot['universe']['managers']}
    supplement=[];proofs=[]
    for r in snapshot['movements']:
        cid=r['manager_id']+'::'+r['security_key']
        if cid in results:continue
        assert r['confidence']=='REVIEWED' and r['state'] in RESOLVED
        assert r['previous_shares'] is not None and r['current_shares'] is not None
        assert r['security_key'] in {x['security_id'] for x in raw}
        row={'comparison_id':cid,'security_id':r['security_key'],'manager_id':r['manager_id'],'manager_group_id':universe[r['manager_id']]['economic_group_id'],
            'current_quantity':r['current_shares'],'previous_quantity':r['previous_shares'],'instrument_type':r['holding']['share_type'],'put_call':r['holding']['put_call'],
            'current_security_class':r['holding']['security_class'],'previous_security_class':r['holding']['security_class'],
            'current_filing_status':'available','previous_filing_status':'available'}
        supplement.append(row)
        results[cid]={'movement_status':r['state'],'normalized_previous_quantity':r['normalized_previous_shares'],'reason_code':'PRESERVED_PRE_CORPUS_REVIEWED_REFERENCE','confidence':'REVIEWED'}
        proofs.append({'comparison_id':cid,'security_id':r['security_key'],'movement_status_preserved':r['state'],'review_source':r['review_source'],
            'current_sources':r['current_sources'],'previous_sources':r['previous_sources'],'source_snapshot_sha256':manifest['source_snapshot_sha256']})
    assert len(supplement)==manifest['excluded_already_reviewed']==2
    write('pre-corpus-reference-reconciliation.json',{'source_corpus_rows':8137,'source_snapshot_movements':8139,'reference_pairs':proofs,
        'analytical_scope':'All retained holder rows for securities in the frozen corpus, including two already-reviewed reference pairs excluded by the original corpus freeze.',
        'corpus_modified':False,'movement_statuses_changed':False,'global_526_counter_scope':'Frozen corpus only; 528 analytical resolved pairs = 526 corpus + 2 pre-corpus references, not newly resolved movements.'})
    return raw+supplement

def managers(rows):
    universe=read('universe.json',ROOT/'lib/trends/capital')
    metadata={m['manager_id']:m for m in universe['managers']}
    groups=defaultdict(list)
    for row in rows:groups[row['manager_id']].append(row)
    strata=read('comparison-strata.json',PRIOR);legacy={x['manager']:x['portfolio_breadth'] for x in strata}
    result={}
    for mid,rs in sorted(groups.items()):
        m=metadata[mid]
        result[mid]={'manager_id':mid,'display_name':m['display_name'],'manager_type':m['manager_type'],'economic_group_id':m['economic_group_id'],
            'current_security_breadth':sum(r['current_quantity'] is not None for r in rs),'previous_security_breadth':sum(r['previous_quantity'] is not None for r in rs),
            'frozen_union_security_breadth':len(rs),'prior_target_portfolio_breadth_bucket':legacy.get(mid,'OUTSIDE_FROZEN_19_TARGET'),
            'scope':'Distinct security keys in retained two-quarter census, including two pre-corpus reviewed references; not full economic portfolio breadth.','metadata_source':'lib/trends/capital/universe.json'}
    write('manager-attributes.json',result)
    return result

def attributes(ids,metadata):
    rows=[metadata[mid] for mid in ids];values=[m['frozen_union_security_breadth'] for m in rows]
    return {'manager_count':len(ids),'manager_types':dict(Counter(m['manager_type'] for m in rows)),
        'prior_target_breadth_buckets':dict(Counter(m['prior_target_portfolio_breadth_bucket'] for m in rows)),
        'corpus_union_breadth_distribution':dict(Counter(str(x) for x in values)),
        'breadth_min':min(values) if values else None,'breadth_max':max(values) if values else None,'breadth_median':median(values) if values else None,
        'managers':rows}

def maintenance(row,certificate,binding):
    adr='ADR' in row['quantity_unit_label']
    tasks=[{'task':'NEXT_QUARTER_SECURITY_IDENTITY_CONTINUITY','units':1},
           {'task':'NEW_QUARTER_PRIMARY_EVENT_INVENTORY_AND_COVERAGE_BOUNDARIES','units':1},
           {'task':'NEW_QUARTER_EVENT_AND_QUANTITY_EFFECT_REVIEW','units':1},
           {'task':'CERTIFICATE_ASSEMBLY_REPLAY_AND_RELEASE_CHECK','units':1},
           {'task':'MANAGER_SECURITY_PAIR_RECONCILIATION','units':row['both_present_managers']}]
    if adr:tasks.append({'task':'DEPOSITARY_RATIO_PROGRAM_AND_LOCAL_ORDINARY_EVENT_REVIEW','units':1})
    return {'security_id':row['security_id'],'REUSABLE_IDENTITY_EVIDENCE':'YES_WITH_NEW_QUARTER_CONTINUITY_CHECK',
        'identity_review_sha256':binding.get('review_sha256'),'retained_identity_proofs':len(binding.get('proofs',[])),
        'QUARTER_SPECIFIC_EVENT_EVIDENCE':'NEW_REVIEW_REQUIRED; Q2_CLEARANCE_NOT_REUSED_AS_Q3_CLEARANCE',
        'baseline_certificate_fingerprint':certificate.get('evidence_fingerprint'),'baseline_source_refs':len(certificate.get('reviewed_source_refs',[])),
        'NEW_QUARTER_REVIEW_TASKS_REQUIRED':tasks,'estimated_review_task_units':sum(t['units'] for t in tasks),
        'shared_manager_quarter_checks':['FILING_USABILITY','AMENDMENT_COMPOSITION','CONFIDENTIALITY','REPORTING_PERIMETER'],
        'shared_checks_counting':'One review bundle per distinct manager, shared across securities; add separately to portfolio total.',
        'full_historical_corpus_reacquisition_required':False,'incremental_revalidation_design_available':True,
        'planning_assumption':'Same comparable-manager sets; material events, identity/perimeter changes or unavailable documents create additional unestimated work.',
        'task_unit_definition':'Review work item, not document count, time, money or guaranteed processing capacity.',
        'next_quarter_revalidated_now':False,'new_quarter':'2026-09-30'}

def main():
    raw=corpus();prior=read('both-present-results.json',PRIOR)
    assert prior['both_present_resolved']==517 and prior['global_total_resolved']==526
    results={r['comparison_id']:r for r in prior['global_results']};assert set(results)=={r['comparison_id'] for r in raw}
    certs={c['security_id']:c for c in read('corporate-event-coverage.json',PRIOR)}
    bindings={c['security_id']:c for c in read('issuer-cik-bindings.json',PRIOR)}
    packets={p['security_id']:p for p in read('target-packets.json',PRIOR)}
    corpus_ids={r['comparison_id'] for r in raw}
    raw=retained_reference_pairs(raw,results)
    metadata=managers(raw);group=defaultdict(list)
    for r in raw:group[r['security_id']].append(r)
    editor=read('editorial-inventory.json');config=read('config.json',ROOT/'lib/trends/capital')
    mappings={m['CUSIP']+'|LONG|SH':m for m in config['security_mappings']}
    public={r['id']:r for r in editor['current_public_positions']};public8=editor['public_top8']
    assert [r['ticker'] for r in public8]==['GOOGL','TSM','V','AMZN','META','MSFT','GOOG','COF']
    census=[];maintenance_rows=[];source_mismatches=[]
    for sid,rows in sorted(group.items()):
        cert=certs.get(sid,{'state':'UNKNOWN'});p=packets.get(sid,{})
        c=census_security(rows,results,cert['state']);mapping=mappings.get(sid)
        cl=p.get('binding',{}).get('class_q2') or rows[0]['current_security_class'] or rows[0]['previous_security_class'] or ''
        c.update({'security_id':sid,'cusip':sid.split('|')[0],'security_class':cl,
            'issuer':mapping['issuer'] if mapping else p.get('binding',{}).get('issuer_name_q2') or p.get('binding',{}).get('issuer_name_q1') or editor['security_labels'].get(sid,sid),
            'ticker_verified':mapping.get('ticker') if mapping else None,'quarter_pair':['2026-03-31','2026-06-30'],
            'quantity_unit_label':'títulos ADR' if 'ADR' in cl or 'ADS' in cl else 'acciones',
            'certificate_scope':'FROZEN_WAVE2A_PACKET' if sid in certs else 'NO_QUALIFIED_PACKET_RETAINED',
            'evidence_fingerprint':cert.get('evidence_fingerprint'),'trend_links':mapping.get('trend_ids',[]) if mapping else [],
            'current_public_holders':public.get(sid,{}).get('managers',0),
            'raw_holder_scope':'Retained snapshot row presence for corpus securities, plus two already-reviewed reference pairs excluded by the corpus freeze. Includes unusable-filing rows if present; public current-holder count separate.',
            'pre_corpus_reference_pairs':sum(r['comparison_id'] not in corpus_ids for r in rows),
            'counts_sum_resolved':c['reported_increased']+c['reported_reduced']+c['reported_unchanged']==c['both_present_resolved']})
        assert c['counts_sum_resolved']
        if c['pre_corpus_reference_pairs']:
            frozen_only=census_security([r for r in rows if r['comparison_id'] in corpus_ids],results,cert['state'])
            c['frozen_corpus_only_counters']={k:frozen_only[k] for k in ['current_holders','previous_holders','both_present_managers','both_present_resolved','reported_increased','reported_reduced','reported_unchanged','holder_union']}
        # Validate existing quantity classifications; never derive a new status.
        for r in rows:
            status=results[r['comparison_id']]['movement_status']
            if status in RESOLVED:
                assert r['current_quantity'] is not None and r['previous_quantity'] is not None
                old=Decimal(str(results[r['comparison_id']]['normalized_previous_quantity']));new=Decimal(str(r['current_quantity']))
                expected='INCREASED' if new>old else 'REDUCED' if new<old else 'UNCHANGED'
                if expected!=status:source_mismatches.append(r['comparison_id'])
        if c['public_feature_candidate']:
            c['manager_diversity']=attributes(c['manager_sets']['both_present'],metadata)
            c['security_specific_bias']={'flag':transition_flag(c),'transition_count':c['current_only_managers']+c['previous_only_managers'],
                'transition_share_of_union':ratio(c['current_only_managers']+c['previous_only_managers'],c['holder_union']),
                'cohorts':{k:attributes(v,metadata) for k,v in c['manager_sets'].items()},'statistical_claim':False,
                'flag_definition':'LOW=no one-quarter-only rows; MODERATE=one-quarter-only rows are a minority of union; HIGH=at least half. Descriptive, no eligibility threshold.'}
            c['representation_sentence']=sentence(c);assert semantic_valid(c['representation_sentence'])
            c['representation_coverage_context']=f"La comparación cubre {c['both_present_managers']} de {c['current_holders']} gestores con posición registrada en Q2 y {c['both_present_managers']} de {c['holder_union']} que la registraron en alguno de los dos trimestres."
            c['representation_invariants']={'counts_sum_to_both_quarters':True,'both_quarters_explicit':True,'no_absent_manager_inference':True,'no_one_quarter_statuses':True,'no_dollar_or_transaction_or_ranking_claim':True,'quantity_unit_class_specific':True}
            maintenance_rows.append(maintenance(c,cert,bindings[sid]))
        else:c['representation_sentence']=None
        census.append(c)
    assert not source_mismatches
    assert len(census)==3055
    byid={x['security_id']:x for x in census};clear=[x for x in census if x['packet_state']==CLEAR];candidates=[x for x in census if x['public_feature_candidate']]
    assert len(clear)==69
    write('security-census.json',census);write('qualified-security-candidates.json',candidates)
    cutoffs=[100,90,80,70,60,50]
    distributions={field:{str(t):sum(at_least(x[field],t) for x in clear) for t in cutoffs} for field in ['COMPARABLE_MANAGER_SHARE_OF_CURRENT','COMPARABLE_MANAGER_SHARE_OF_UNION']}
    distributions['denominator_securities']=69
    distributions['complete_packet_filter_applied']=False
    distributions['raw_values']=[{'security_id':x['security_id'],'current':x['COMPARABLE_MANAGER_SHARE_OF_CURRENT'],'union':x['COMPARABLE_MANAGER_SHARE_OF_UNION'],'both_resolution':x['BOTH_PRESENT_RESOLUTION_COVERAGE']} for x in clear]
    write('clear-coverage-distributions.json',distributions)
    top8=[]
    for p in public8:
        c=byid[p['id']]
        top8.append({'security_id':p['id'],'ticker':p['ticker'],'PACKET_STATE':c['packet_state'],'CURRENT_HOLDERS':c['current_holders'],'PREVIOUS_HOLDERS':c['previous_holders'],
            'PUBLIC_OVERLAP_CURRENT_HOLDERS':p['managers'],'BOTH_PRESENT':c['both_present_managers'],'BOTH_PRESENT_RESOLVED':c['both_present_resolved'],'BOTH_PRESENT_UNRESOLVED':c['both_present_unresolved'],
            'CURRENT_ONLY':c['current_only_managers'],'PREVIOUS_ONLY':c['previous_only_managers'],'INCREASED':c['reported_increased'],'REDUCED':c['reported_reduced'],'UNCHANGED':c['reported_unchanged'],
            'COUNTS_SCOPE':'PARTIAL_RESOLVED_SUBSET_INTERNAL_ONLY' if not c['public_feature_candidate'] else 'ALL_BOTH_PRESENT',
            'BOTH_PRESENT_RESOLUTION_COVERAGE':c['BOTH_PRESENT_RESOLUTION_COVERAGE'],'COMPARABLE_SHARE_OF_CURRENT':c['COMPARABLE_MANAGER_SHARE_OF_CURRENT'],'COMPARABLE_SHARE_OF_UNION':c['COMPARABLE_MANAGER_SHARE_OF_UNION'],
            'PUBLIC_FEATURE_CANDIDATE':'YES' if c['public_feature_candidate'] else 'NO','BLOCK_REASON':c['block_reasons'],'UNRESOLVED_REASONS':c['unresolved_reason_counts']})
    write('public-top8-results.json',top8)
    # Inventory every editorial vehicle, but never turn a ticker-only label into an authoritative CUSIP join.
    vehicles={}
    for t in editor['trends']:
        for v in t['vehicles']:
            row=vehicles.setdefault(v['ticker'],{**v,'trend_ids':[],'security_id':None,'binding_state':'NON_SECURITY_SPOT_REFERENCE' if '/' in v['ticker'] else 'NO_RETAINED_AUTHORITATIVE_CUSIP_MAPPING','PUBLIC_FEATURE_CANDIDATE':'NO'})
            row['trend_ids'].append(t['id'])
    linked={sid for sid,m in mappings.items() if m['trend_ids'] and sid in byid}
    trends=[]
    for t in editor['trends']:
        ids=sorted(sid for sid in linked if t['id'] in byid[sid]['trend_links'])
        trends.append({'trend_id':t['id'],'name':t['name'],'bound_corpus_security_ids':ids,'bound_security_count':len(ids),
            'clear_count':sum(byid[s]['packet_state']==CLEAR for s in ids),'with_100_percent_both_present_resolution':sum(at_least(byid[s]['BOTH_PRESENT_RESOLUTION_COVERAGE'],100) for s in ids),
            'candidate_count':sum(byid[s]['public_feature_candidate'] for s in ids),'editorial_vehicles':[vehicles[v['ticker']] for v in t['vehicles']]})
    trend_result={'TREND_LINKED_SECURITY_COUNT':len(linked),'COUNT_SCOPE':'Authoritatively CUSIP-bound editorial securities in frozen corpus; all other references inventoried separately.',
        'TREND_LINKED_CLEAR_COUNT':sum(byid[s]['packet_state']==CLEAR for s in linked),
        'TREND_LINKED_WITH_100_PERCENT_BOTH_PRESENT_RESOLUTION':sum(at_least(byid[s]['BOTH_PRESENT_RESOLUTION_COVERAGE'],100) for s in linked),
        'TREND_LINKED_CANDIDATE_COUNT':sum(byid[s]['public_feature_candidate'] for s in linked),
        'EDITORIAL_SECURITY_REFERENCE_COUNT':len(linked)+sum(v['binding_state']!='NON_SECURITY_SPOT_REFERENCE' for v in vehicles.values()),
        'EDITORIAL_UNBOUND_SECURITY_REFERENCES':sum(v['binding_state']!='NON_SECURITY_SPOT_REFERENCE' for v in vehicles.values()),
        'EDITORIAL_NON_SECURITY_SPOT_REFERENCES':sum(v['binding_state']=='NON_SECURITY_SPOT_REFERENCE' for v in vehicles.values()),
        'ALL_EDITORIAL_SECURITY_CUSIP_CENSUS':'INCOMPLETE_IDENTITY_BINDINGS; NO_NEW_MAPPINGS_CREATED','trends':trends,
        'bound_security_ids':sorted(linked),'unbound_vehicles':list(vehicles.values()),'trends_with_candidates':sum(t['candidate_count']>0 for t in trends)}
    write('trend-linked-results.json',trend_result)
    rules=sensitivity(census,[p['id'] for p in public8],linked);write('threshold-sensitivity.json',{'rules':rules,'rule_selected':None,'thresholds_are_simulations_only':True})
    candidate_mids={m for c in candidates for m in c['manager_sets']['both_present']}
    maintenance_result={'candidates':maintenance_rows,'candidate_count':len(candidates),'same_sets_security_and_pair_task_units':sum(x['estimated_review_task_units'] for x in maintenance_rows),
        'shared_manager_review_bundles':len(candidate_mids),'shared_manager_ids':sorted(candidate_mids),
        'total_planning_task_units_if_sets_unchanged':sum(x['estimated_review_task_units'] for x in maintenance_rows)+len(candidate_mids),
        'no_full_historical_reacquisition':True,'estimates_not_guarantees':True,'new_quarter_reviews_performed':0}
    write('next-quarter-maintenance.json',maintenance_result)
    summary={'TOTAL_SECURITIES':len(census),'CLEAR_SECURITIES':len(clear),'VERIFIED_EVENT_NORMALIZATION_AVAILABLE_SECURITIES':sum(x['packet_state']==NORMALIZED for x in census),
        'VERIFIED_BLOCK_SECURITIES':sum(x['packet_state']=='VERIFIED_BLOCK' for x in census),'UNKNOWN_SECURITIES':sum(x['packet_state']=='UNKNOWN' for x in census),
        'UNKNOWN_WITH_WAVE2A_PACKET':sum(x['packet_state']=='UNKNOWN' and x['security_id'] in certs for x in census),'NO_WAVE2A_PACKET':sum(x['security_id'] not in certs for x in census),
        'CLEAR_WITH_100_BOTH_PRESENT_RESOLUTION':sum(at_least(x['BOTH_PRESENT_RESOLUTION_COVERAGE'],100) for x in clear),
        'CANDIDATE_SECURITIES':len(candidates),'CANDIDATE_COMPARABLE_MANAGERS_SUM':sum(c['both_present_managers'] for c in candidates),
        'CANDIDATE_DISTINCT_COMPARABLE_MANAGERS':len(candidate_mids),'CORPUS_MANAGER_COUNT':len(metadata),
        'FROZEN_TARGET_MANAGER_COUNT':len({cid.split('::')[0] for cid in read('target.json',PRIOR)['comparison_ids']}),
        'CANDIDATE_TRANSITION_FLAGS':dict(Counter(c['security_specific_bias']['flag'] for c in candidates)),
        'MIN_COMPARABLE_MANAGERS':{str(n):sum(x['both_present_managers']>=n for x in candidates) for n in [3,5,10,15]},
        'ALL_BOTH_PRESENT':sum(x['both_present_managers'] for x in census),'ALL_BOTH_PRESENT_RESOLVED':sum(x['both_present_resolved'] for x in census),
        'CURRENT_ONLY':sum(x['current_only_managers'] for x in census),'PREVIOUS_ONLY':sum(x['previous_only_managers'] for x in census),
        'PRIOR_RESOLVED_CLASSIFICATIONS_ARITHMETIC_CHECKED':sum(x['both_present_resolved'] for x in census),'FROZEN_CORPUS_RESOLVED_PRESERVED':526,'PRE_CORPUS_RESOLVED_REFERENCES':2,'SOURCE_REQUESTS':0,'SOURCE_BYTES_DOWNLOADED':0,'movement_statuses_changed':False,
        'no_arbitrary_coverage_threshold_selected':True}
    assert summary['ALL_BOTH_PRESENT_RESOLVED']==528
    write('census-summary.json',summary)
    print(canonical(summary));print(canonical({'rules':rules,'trend_bound':len(linked),'trend_candidates':trend_result['TREND_LINKED_CANDIDATE_COUNT']}))

if __name__=='__main__':main()

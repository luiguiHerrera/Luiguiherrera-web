// Read retained local product definitions only; no network and no public writes.
import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { trendCatalog } from '../../lib/trends/catalog.ts';
import { getTrendDetail } from '../../lib/trends/details.ts';
import { aggregateCurrentPositions } from '../../lib/trends/capital/positions.ts';
import { securityKey } from '../../lib/trends/capital/normalize.ts';
import type { CapitalDataset, SecurityMapping } from '../../lib/trends/capital/types.ts';

const config=JSON.parse(readFileSync('lib/trends/capital/config.json','utf8')) as {security_mappings:SecurityMapping[]};
const snapshot=JSON.parse(gunzipSync(readFileSync('lib/trends/capital/generated/snapshot.json.gz')).toString()) as CapitalDataset;
const positions=aggregateCurrentPositions(snapshot,config.security_mappings);
const trends=trendCatalog.map(t=>({id:t.id,name:t.name,vehicles:getTrendDetail(t,'es').observableVehicles.map(v=>({ticker:v.ticker,name:v.name,kind:v.kind})),security_mappings:config.security_mappings.filter(m=>m.trend_ids.includes(t.id))}));
const securityLabels=Object.fromEntries([...snapshot.previous,...snapshot.current].flatMap(q=>q.positions.map(h=>[securityKey(h),h.issuer])));
writeFileSync('internal/trends-movements/wave2c/editorial-inventory.json',JSON.stringify({trends,public_top8:positions.companies.slice(0,8),current_public_positions:positions.companies,security_labels:securityLabels,universe_size:positions.universe_size,public_disclosed_managers:positions.eligible_disclosed_managers,movement_publication:snapshot.movement_publication})+'\n');
console.log(JSON.stringify({trends:trends.length,top8:positions.companies.slice(0,8).map(x=>x.ticker),vehicles:new Set(trends.flatMap(t=>t.vehicles.map(v=>v.ticker))).size}));

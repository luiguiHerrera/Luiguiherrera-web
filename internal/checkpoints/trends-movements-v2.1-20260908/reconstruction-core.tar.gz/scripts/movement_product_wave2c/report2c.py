"""Final local audit and complete user-requested Wave 2C output."""
import subprocess,datetime,re
from context2c import *

def isolate():
    corpus();p=read('preflight.json');differences=[]
    for category in ['tracked_files','preserved_files']:
        for item in p[category]:
            path=ROOT/item['path'];h=sha(path.read_bytes()) if path.is_file() else None
            if h!=item['sha256']:differences.append({'path':item['path'],'expected':item['sha256'],'actual':h})
    original=Path(p['original_worktree'])
    original_ok=sha((original/'package-lock.json').read_bytes())==p['original_package_lock_sha256'] and subprocess.check_output(['git','status','--porcelain'],cwd=original,text=True)==p['original_dirty_status']
    assert not differences and original_ok
    assert subprocess.check_output(['git','diff','--stat'],cwd=ROOT,text=True)==''
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==p['base_commit']
    result={'status':'PASS','tracked_files_checked':len(p['tracked_files']),'inherited_files_checked':len(p['preserved_files']),
        'differences':differences,'original_dirty_worktree_preserved':original_ok,'corpus_changed':False,'target_changed':False,'prior_results_changed':False,
        'public_data_changed':False,'public_snapshot_changed':False,'network_evidence_requests':0,'holdings_refresh':False,
        'commit':False,'push':False,'deploy':False,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write('final-isolation-audit.json',result)
    return result

def pct(m):return 'N/A' if m['percent'] is None else f"{m['percent']:.2f}%"
def cell(v):return canonical(v) if isinstance(v,(dict,list)) else str(v)

def main():
    audit=isolate();summary=read('census-summary.json');distribution=read('clear-coverage-distributions.json');top=read('public-top8-results.json')
    trends=read('trend-linked-results.json');rules=read('threshold-sensitivity.json')['rules'];options=read('product-options.json');maintenance=read('next-quarter-maintenance.json');candidates=read('qualified-security-candidates.json')
    for kind in ['product-tests','app-tests','typecheck','lint','build','git-diff-check']:assert read('validation-'+kind+'.json')['exit_code']==0,kind
    result={'STATE':'WAVE_2C_COMPLETE_SECURITY_SPECIFIC_FEASIBILITY_LIMITED','BASE_COMMIT':read('preflight.json')['base_commit'],
        **summary,'BOTH_PRESENT_RESOLVED':517,'GLOBAL_TOTAL_RESOLVED':526,'NEW_MOVEMENTS_RESOLVED':0,
        'MOVEMENT_CORPUS_COUNT':8137,'MOVEMENT_CORPUS_SHA256':'d270f69dc303daa6d694fbafa6d4c91166cdcfb60c4e1fb5bc90b105b5143ac3','MOVEMENT_CORPUS_CHANGED':'NO',
        'BOTH_PRESENT_TARGET_COUNT':4162,'BOTH_PRESENT_TARGET_SHA256':'307cfb419c1134e020b7b0e57f8f7fab024a81ec2c8790af168f33c6de6559e6','BOTH_PRESENT_TARGET_CHANGED':'NO',
        'MANAGER_AUDIT_POPULATION':'19_OF_19_PRESERVED_FOR_FROZEN_TARGET','PUBLIC_TOP8_RESULTS':top,
        **{k:v for k,v in trends.items() if k.isupper()},
        'OPTION_A_ASSESSMENT':options['OPTION_A'],'OPTION_B_ASSESSMENT':options['OPTION_B'],'OPTION_C_ASSESSMENT':options['OPTION_C'],
        'NEXT_QUARTER_REVIEW_TASK_ESTIMATE':{'per_security_min':min(x['estimated_review_task_units'] for x in maintenance['candidates']),
            'per_security_max':max(x['estimated_review_task_units'] for x in maintenance['candidates']),
            'security_and_pair_task_units':maintenance['same_sets_security_and_pair_task_units'],'shared_manager_bundles':maintenance['shared_manager_review_bundles'],
            'total_if_current_manager_sets_persist':maintenance['total_planning_task_units_if_sets_unchanged'],
            'basis':'4 security review work items + one per manager/security pair; +1 depositary review for ADR. Add one shared manager-quarter bundle per distinct manager.',
            'limitations':'Conditional planning units, not source-document counts or elapsed time. New actions, amendments, identity/perimeter changes and new manager sets add unestimated work.','new_quarter_reviews_performed':0},
        'GLOBAL_RANKING_ALLOWED':'NO','TRANSACTION_INFERENCE_PUBLIC':'NO','MOVEMENT_PUBLICATION':'REVIEW_PENDING','MOVEMENT_UI_PRESENT':'NO','MOVEMENT_FIELDS_PUBLIC':'NONE',
        'PUBLIC_DATA_CHANGED':'NO','PUBLIC_SNAPSHOT_CHANGED':'NO','SEC_HOLDINGS_REFRESH':'NO','NEW_EVIDENCE_ACQUIRED':'NO',
        'COVERAGE_RULE_SELECTED':None,'PRODUCT_FORM_IMPLEMENTED':None,
        'TESTS':'PASS: 27 product feasibility tests; 343 existing app tests passed, 1 existing test skipped','TYPECHECK':'PASS','LINT':'PASS_WITH_17_EXISTING_WARNINGS','BUILD':'PASS','GIT_DIFF_CHECK':'PASS',
        'PRODUCTION_READINESS':'NOT_READY','NEXT_RECOMMENDED_STEP':'Review whether a security-detail feature for 16 titles, currently enhancing only one of 15 trends, warrants product work. Keep all five rules unselected; agree product scope and a coverage rule before any UI work. No global rankings or renewed mass evidence acquisition.',
        'FILES_CHANGED':0,'FILES_CREATED':0,'COMMIT':'NONE','PUSH':'NONE','DEPLOY':'NONE'}
    for level in [100,90,80,70,60,50]:
        suffix=str(level) if level==100 else str(level)+'_PLUS'
        result['COMPARABLE_CURRENT_'+suffix]=distribution['COMPARABLE_MANAGER_SHARE_OF_CURRENT'][str(level)]
        result['COMPARABLE_UNION_'+suffix]=distribution['COMPARABLE_MANAGER_SHARE_OF_UNION'][str(level)]
    for n in [3,5,10,15]:result['MIN_'+str(n)+'_COMPARABLE_MANAGERS']=summary['MIN_COMPARABLE_MANAGERS'][str(n)]
    for rule,r in rules.items():
        result[rule+'_ELIGIBLE']=r['eligible_security_count'];result[rule+'_TOP8']=r['eligible_public_top8_count'];result[rule+'_TREND_LINKED']=r['eligible_trend_linked_count']
    projected={'internal/trends-movements/wave2c/RESULT.json','internal/trends-movements/wave2c/REPORT.md','internal/trends-movements/wave2c/files-created.json'}
    files=sorted(projected | {str(p.relative_to(ROOT)) for folder in [OUT,ROOT/'scripts/movement_product_wave2c'] for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts})
    result['FILES_CREATED']=len(files);write('RESULT.json',result)
    candidates_table='\n'.join(f"| {c['issuer']} (`{c['cusip']}`) | {c['both_present_managers']} | {c['reported_increased']}/{c['reported_reduced']}/{c['reported_unchanged']} | {c['current_only_managers']}/{c['previous_only_managers']} | {pct(c['COMPARABLE_MANAGER_SHARE_OF_CURRENT'])} | {pct(c['COMPARABLE_MANAGER_SHARE_OF_UNION'])} |" for c in sorted(candidates,key=lambda c:c['issuer']))
    distribution_table='\n'.join(f"| {'100%' if t==100 else '≥'+str(t)+'%'} | {result['COMPARABLE_CURRENT_'+(str(t) if t==100 else str(t)+'_PLUS')]} | {result['COMPARABLE_UNION_'+(str(t) if t==100 else str(t)+'_PLUS')]} |" for t in [100,90,80,70,60,50])
    top_table='\n'.join(f"| {x['ticker']} | {'CLEAR' if x['PACKET_STATE']=='VERIFIED_CLEAR_FOR_COMPARABILITY' else x['PACKET_STATE']} | {x['CURRENT_HOLDERS']} | {x['PREVIOUS_HOLDERS']} | {x['BOTH_PRESENT']} | {x['CURRENT_ONLY']}/{x['PREVIOUS_ONLY']} | {x['INCREASED']}/{x['REDUCED']}/{x['UNCHANGED']} | {x['BOTH_PRESENT_RESOLVED']}/{x['BOTH_PRESENT']} ({pct(x['BOTH_PRESENT_RESOLUTION_COVERAGE'])}) | {pct(x['COMPARABLE_SHARE_OF_CURRENT'])} | {pct(x['COMPARABLE_SHARE_OF_UNION'])} | NO |" for x in top)
    rule_descriptions={'RULE_1':'100% resueltas; ≥50% actuales; ≥5 gestores','RULE_2':'100% resueltas; ≥70% actuales; ≥5 gestores','RULE_3':'100% resueltas; ≥80% actuales; ≥5 gestores','RULE_4':'100% resueltas; ≥80% actuales; ≥10 gestores','RULE_5':'100% resueltas; ≥90% actuales; ≥10 gestores'}
    rule_table='\n'.join(f"| {rule} | {rule_descriptions[rule]} | {r['eligible_security_count']} | {r['eligible_public_top8_count']} | {r['eligible_trend_linked_count']} |" for rule,r in rules.items())
    trend_table='\n'.join(f"| {t['name']['es']} | {t['bound_security_count']} | {len([v for v in t['editorial_vehicles'] if v['binding_state']!='NON_SECURITY_SPOT_REFERENCE'])} | {t['candidate_count']} |" for t in trends['trends'])
    cvx=next(c for c in candidates if c['ticker_verified']=='CVX')
    report=f"""Wave 2C encuentra **16 títulos con datos suficientes para describir cambios de posición por título**, pero una utilidad limitada para el producto actual: **ninguno de los ocho títulos de la tabla pública es candidato** y solo **Chevron** está vinculado hoy a una de las 15 tendencias. No se elige umbral, se diseña interfaz ni se implementa una función. PRODUCTION_READINESS=NOT_READY.

La condición aplicada es estricta: certificado CLEAR o normalización verificada, posición larga en acciones/ADR y **todas las comparaciones con presencia en ambos trimestres resueltas**. No basta que las comparaciones del target de 19 gestores estén resueltas si el mismo título tiene otros gestores BOTH_PRESENT pendientes. Se conserva la semántica de **cambio de posición reportada**; no se atribuyen transacciones, convicción ni fechas de negociación.

El corpus conserva 8.137 filas y 3.055 claves de título. Hay 69 CLEAR, 2 VERIFIED_BLOCK y 2.984 UNKNOWN en ese universo de títulos. Estos últimos se desglosan en 2.064 paquetes UNKNOWN de Wave 2A y 920 títulos sin paquete Wave 2A. No se confunden los 2.135 paquetes del target anterior con todos los títulos del corpus. No hay certificados de normalización de eventos disponibles en el estado actual.

El universo observado contiene 44 unidades de gestor; el target congelado mantiene sus 19 gestores. Los 16 candidatos tienen entre 6 y 9 gestores comparables, con **103 comparaciones y 15 gestores distintos**. El principio 19/19 sigue aplicado al target; no se exige que cada título tenga 19 gestores.

Se reconciliaron dos alcances antes de calcular cobertura. El manifiesto del corpus excluyó **dos comparaciones GOOG ya revisadas**: Berkshire Hathaway (INCREASED) y Bridgewater (REDUCED). Permanecen en el snapshot original. El censo analítico de los títulos del corpus incluye esas dos referencias para reproducir los 20 gestores actuales de GOOG; no añade filas al corpus ni cambia ningún resultado. Así, el censo analítico observa 5.773 pares BOTH_PRESENT y 528 pares resueltos, descompuestos en **5.771/526 del corpus más 2/2 referencias previas**. Los contadores autorizados siguen siendo **BOTH_PRESENT_RESOLVED=517 y GLOBAL_TOTAL_RESOLVED=526**. El JSON de reconciliación conserva identificadores y fuentes, y GOOG incluye también sus contadores restringidos al corpus.

Las tres métricas se mantienen separadas, con numerador y denominador exactos:

| Métrica | Numerador | Denominador | Qué permite leer |
|---|---|---|---|
| BOTH_PRESENT_RESOLUTION_COVERAGE | Pares BOTH_PRESENT resueltos | Todos los pares BOTH_PRESENT del título | Completitud de las comparaciones existentes |
| COMPARABLE_MANAGER_SHARE_OF_UNION | Gestores presentes en ambos trimestres | Unión de gestores con posición Q1 o Q2 | Representación del conjunto de dos trimestres |
| COMPARABLE_MANAGER_SHARE_OF_CURRENT | Gestores presentes en ambos trimestres | Gestores con posición Q2 | Representación del conjunto actual |

Una razón con denominador cero es N/A, nunca 100%. En títulos no elegibles, “presentes en ambos trimestres” no significa todavía comparables con evidencia suficiente. Los contadores de presencia provienen de filas normalizadas retenidas, no de una afirmación sobre exposición económica no declarada; las filas con filing inutilizable se señalan. Las ocho cifras actuales se verificaron contra la función pública de agregación existente. No se recalcularon estados a partir de ausencias: los 1.015 casos solo actuales y los 1.351 solo anteriores siguen sin convertirse en estados nuevos.

Distribución entre **los 69 CLEAR**, antes de aplicar la condición de resolución completa; cortes acumulativos, no categorías excluyentes:

| Umbral descriptivo | Share de actuales: títulos | Share de unión: títulos |
|---|---:|---:|
{distribution_table}

Solo **16/69** tienen 100% de resolución BOTH_PRESENT. Entre esos candidatos, los mínimos ≥3, ≥5, ≥10 y ≥15 gestores producen **16, 16, 0 y 0** títulos, respectivamente. Una alta presencia en ambos trimestres no corrige comparaciones sin resolver.

Siete títulos públicos tienen packet_state=VERIFIED_CLEAR_FOR_COMPARABILITY y GOOG mantiene UNKNOWN. Los ocho tienen pares pendientes; GOOG incumple además la condición de paquete calificado. Sus comparaciones individuales revisadas no convierten su paquete completo en CLEAR. I/R/U son aumentadas/reducidas/sin cambio **dentro de la porción resuelta, exclusivamente para análisis interno**; no se ofrecen como una frase pública del título completo:

| Título | Paquete | Q2 | Q1 | Ambos | Solo Q2/Q1 | I/R/U resueltas | Resueltas/ambos | Share Q2 | Share unión | Candidato |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
{top_table}

Los bloqueos de esos pares pendientes son de confidencialidad o alcance del gestor no probado. El certificado corporativo del título no elimina esas condiciones. Los motivos y los IDs pendientes están conservados por título. No se intenta resolverlos en esta fase.

Los candidatos se presentan por nombre, sin ordenarlos por magnitud ni dirección del cambio:

| Título y CUSIP | Comparables | I/R/U | Solo Q2/Q1 | Share Q2 | Share unión |
|---|---:|---:|---:|---:|---:|
{candidates_table}

Ejemplo semántico comprobado para Chevron:

> {cvx['representation_sentence']}

Se cumple 2+4+3=9 y las coberturas actual y de unión son 9/9. Para Diageo se usa “títulos ADR”, respetando la unidad de la clase. Cada candidato incluye una frase, contexto de cobertura e invariantes verificadas. Las frases no contienen inferencias de compra/venta, estados de aparición/desaparición, importes monetarios ni clasificaciones entre títulos.

La diversidad por candidato compara tipos de gestor, distribución exacta de amplitud de posiciones retenidas, mediana/rango y la clasificación de amplitud heredada del target. Se observan asset_manager, hedge_fund, insurance_group y conglomerate; no se infieren estilos ni habilidad. Se conservan los mismos atributos para gestores presentes solo en Q2 y solo en Q1. El JSON contiene los miembros y recuentos de cada conjunto; no se suponen atributos para conjuntos vacíos.

Las etiquetas de transición son descriptivas: LOW significa ninguna fila de un solo trimestre; MODERATE significa que esas filas son una minoría de la unión; HIGH significa al menos la mitad. **9 candidatos LOW, 7 MODERATE y 0 HIGH**. Esta definición no es un test estadístico ni un umbral de publicación. Se muestran también recuentos y fracciones; tener cero transiciones observadas no prueba representatividad fuera del universo retenido.

Se inventariaron las **15 tendencias completas**, distinguiendo identidad verificada y referencias editoriales sin CUSIP:

| Tendencia | Títulos con CUSIP vinculado | Vehículos de título sin CUSIP* | Candidatos |
|---|---:|---:|---:|
{trend_table}

*La suma por tendencia puede repetir vehículos. Hay **{trends['TREND_LINKED_SECURITY_COUNT']} títulos distintos con correspondencia CUSIP verificada**, de los cuales **{trends['TREND_LINKED_CLEAR_COUNT']} son CLEAR y GOOG es UNKNOWN**, y solo 1 tiene resolución BOTH_PRESENT completa: Chevron. Además hay **32 referencias distintas de ETF/fondos sin correspondencia CUSIP autorizada en la configuración retenida**, y 2 referencias spot (BTC/USDT y ETH/USDT), que no son títulos 13F. En conjunto se inventariaron 44 referencias editoriales de títulos más 2 spot. TREND_LINKED_SECURITY_COUNT=12 se refiere explícitamente a títulos vinculados por CUSIP; el recuento completo de CUSIP de todos los vehículos editoriales no es determinable con los vínculos actuales. No se crean mappings por ticker ni se confunden referencias sin mapping con paquetes CLEAR. El inventario conserva cada vehículo, sus tendencias y el motivo de no elegibilidad.

Simulación de las cinco reglas, sin seleccionar ninguna:

| Regla | Condiciones | Títulos | Top 8 actual | Con vínculo editorial CUSIP |
|---|---|---:|---:|---:|
{rule_table}

RULE_3 excluye Sysco, cuya comparabilidad sobre gestores actuales es 6/8=75%. RULE_4 y RULE_5 dejan cero títulos por el mínimo de diez gestores. Esto describe sensibilidad; no justifica elegir automáticamente 80%, 70% o cualquier otra cifra.

| Forma de producto | Honestidad de datos | Valor actual | Riesgo de selección | Complejidad visual | Mantenimiento |
|---|---|---|---|---|---|
| A: detalle de un título | Alta si el paquete completo y los tres denominadores son explícitos | Real pero limitado a 16 títulos; solo una tendencia actual | Menor en contexto individual; el conjunto sigue siendo no representativo | Menor de las tres | Revisión incremental de cada título y verificaciones compartidas |
| B: fila desplegable en tabla actual | Solo para filas que cumplan el gate | Ninguna de las 8 filas actuales puede ofrecerla | Puede confundirse elegibilidad con relevancia de la posición | Media | Revalidar elegibilidad y composición de la tabla |
| C: sección de cambios verificados | Posible por título con selección explícita | Entre 0 y 16 títulos según regla; como máximo una tendencia | Alto: la sección puede parecer representativa de un universo con UNKNOWN no aleatorio | Mayor de las tres | Lista de elegibilidad y documentación de altas/bajas de cobertura |

A tiene suficiencia factual para una discusión de producto acotada. B no tiene datos elegibles en las filas actuales. C mantiene un riesgo elevado de selección, aunque no incluya un ranking numérico. No se elige forma de producto ni se diseña interfaz. Los rankings globales y la inferencia de transacciones permanecen prohibidos.

El mantenimiento puede ser incremental por paquete: se reutilizan identidad legal/clase, fuentes archivadas y trazabilidad como punto de partida, pero la continuidad al trimestre nuevo y la cobertura de eventos se revisan de nuevo. Un CLEAR de Q2 no equivale a un CLEAR de Q3. El plan cuenta cuatro tareas por título (continuidad de identidad, inventario/cobertura del trimestre, revisión de eventos/cantidad y montaje/verificación de certificado), una reconciliación por par gestor-título, y una tarea adicional de depositario para ADR. Los controles de filing, enmiendas, confidencialidad y perímetro se agrupan una vez por gestor y se comparten.

Suponiendo los mismos conjuntos comparables: **10–13 unidades de revisión por candidato; 168 unidades de título/pares más 15 paquetes compartidos de gestor = 183 unidades**. No son número de documentos, horas ni costes monetarios. Eventos materiales, cambios de identidad, nuevos conjuntos de gestores o fuentes no disponibles añaden trabajo no estimado. No se necesita volver a descargar todo el corpus histórico; sí es obligatoria evidencia del trimestre nuevo. Se realizaron cero revisiones de Q3 en esta fase.

Pasaron **27 pruebas de producto y 343 pruebas existentes de aplicación** (1 prueba previa omitida), typecheck, lint con 17 avisos previos, build y git diff --check. La reproducción offline da los mismos hashes para el censo, candidatos, sensibilidad y análisis editorial. La auditoría verificó {audit['tracked_files_checked']} archivos versionados y {audit['inherited_files_checked']} archivos heredados sin diferencias; el worktree original con su package-lock modificado sigue intacto. No hubo consultas de fuentes, descargas de evidencia, refresh de holdings, commit, push ni deploy.

Los resultados completos están en [RESULT.json](RESULT.json), [censo por título](security-census.json), [16 candidatos y diversidad](qualified-security-candidates.json), [top 8](public-top8-results.json), [distribuciones CLEAR](clear-coverage-distributions.json), [15 tendencias y vehículos](trend-linked-results.json), [sensibilidad](threshold-sensitivity.json), [opciones de producto](product-options.json), [mantenimiento](next-quarter-maintenance.json), [reconciliación de referencias previas](pre-corpus-reference-reconciliation.json), [aislamiento](final-isolation-audit.json) y [manifest](files-created.json).

El siguiente paso recomendado es decidir si una función por título, con 16 títulos elegibles y mejora directa de una sola tendencia actual, aporta suficiente valor. Las cinco reglas permanecen sin elegir. Cualquier diseño posterior necesita un alcance y una regla de cobertura acordados; esta fase no autoriza publicación ni una nueva adquisición masiva de evidencia.

Salida solicitada:

```text
"""
    requested=(OUT/'user-request.txt').read_text().split('\nOUTPUT\n',1)[1]
    keys=[line.split('=')[0] for line in requested.splitlines() if '=' in line and not line.startswith('=')]
    assert all(k in result for k in keys),[k for k in keys if k not in result]
    report+='\n'.join(k+'='+cell(result[k]) for k in keys)+'\n```\n'
    report=re.sub(r'\]\(([^:)]+\.(?:json|md))\)',lambda m:']('+str(OUT/m.group(1))+')',report)
    (OUT/'REPORT.md').write_text(report)
    write('files-created.json',{'files_changed':[],'files_created_count':len(files),'files':[{'path':f,'sha256':sha((ROOT/f).read_bytes()) if not f.endswith('/files-created.json') else None} for f in files]})
    print(canonical({k:result[k] for k in ['STATE','TOTAL_SECURITIES','CANDIDATE_SECURITIES','RULE_1_ELIGIBLE','RULE_3_ELIGIBLE','RULE_4_ELIGIBLE','TREND_LINKED_CANDIDATE_COUNT','TESTS','BUILD','FILES_CREATED']}))

if __name__=='__main__':main()

import unittest
from model2c import *
from context2c import read,PRIOR,ROOT,corpus,sha

def fixture(mid,old,new,state):
    cid=mid+'::CLASS|LONG|SH'
    return {'manager_id':mid,'manager_group_id':mid,'comparison_id':cid,'current_quantity':new,'previous_quantity':old,'instrument_type':'SH','put_call':None,'current_filing_status':'available','previous_filing_status':'available'}, {'movement_status':state}

class DenominatorTests(unittest.TestCase):
    def cohort(self):
        pairs=[fixture('a',10,20,'INCREASED'),fixture('b',20,10,'REDUCED'),fixture('c',10,10,'UNCHANGED'),fixture('d',None,30,'NEW'),fixture('e',40,None,'EXITED')]
        rows=[p[0] for p in pairs];results={r['comparison_id']:p[1] for r,p in zip(rows,pairs)}
        return rows,results
    def calculate(self):
        r,s=self.cohort();return census_security(r,s,CLEAR)
    def test_both_present_denominator(self):
        c=self.calculate();self.assertEqual(c['BOTH_PRESENT_RESOLUTION_COVERAGE'],ratio(3,3))
    def test_union_denominator(self):
        self.assertEqual(self.calculate()['COMPARABLE_MANAGER_SHARE_OF_UNION'],ratio(3,5))
    def test_current_holder_denominator(self):
        self.assertEqual(self.calculate()['COMPARABLE_MANAGER_SHARE_OF_CURRENT'],ratio(3,4))
    def test_counts_sum_all_comparable(self):
        c=self.calculate();self.assertTrue(c['public_feature_candidate']);self.assertEqual(c['reported_increased']+c['reported_reduced']+c['reported_unchanged'],3)
    def test_blocked_packet_never_eligible(self):
        rows,s=self.cohort();self.assertFalse(census_security(rows,s,'VERIFIED_BLOCK')['public_feature_candidate'])
    def test_unknown_packet_never_eligible(self):
        rows,s=self.cohort();self.assertFalse(census_security(rows,s,'UNKNOWN')['public_feature_candidate'])
    def test_clear_packet_with_unresolved_manager_is_not_candidate(self):
        rows,s=self.cohort();s[rows[0]['comparison_id']]['movement_status']='INDETERMINATE'
        c=census_security(rows,s,CLEAR);self.assertFalse(c['public_feature_candidate']);self.assertEqual(c['both_present_unresolved'],1);self.assertIsNone(sentence(c))
    def test_current_only_is_never_increase_even_bad_upstream_status(self):
        rows,s=self.cohort();s[rows[3]['comparison_id']]['movement_status']='INCREASED';self.assertEqual(census_security(rows,s,CLEAR)['reported_increased'],1)
    def test_previous_only_is_never_reduction_even_bad_upstream_status(self):
        rows,s=self.cohort();s[rows[4]['comparison_id']]['movement_status']='REDUCED';self.assertEqual(census_security(rows,s,CLEAR)['reported_reduced'],1)
    def test_no_new_exit_leakage(self):
        c=self.calculate();text=sentence(c);self.assertTrue(semantic_valid(text));self.assertNotIn('NEW',text);self.assertNotIn('EXIT',text)
    def test_sentence_rejects_transaction_dollar_and_ranking_language(self):
        text=sentence(self.calculate())
        for word in ['bought','sold','compra','venta','transacción','USD','dólares','$','ranking','convicción']:
            with self.subTest(word=word):self.assertFalse(semantic_valid(text+' '+word))
    def test_sentence_requires_both_quarters(self):
        text=sentence(self.calculate());self.assertFalse(semantic_valid(text.replace('en ambos trimestres','este trimestre')))
    def test_adr_sentence_uses_adr_units(self):
        c=self.calculate();c['quantity_unit_label']='títulos ADR';self.assertIn('más títulos ADR',sentence(c))
    def test_zero_both_is_not_vacuously_100_percent(self):
        r,s=fixture('a',None,10,'NEW');c=census_security([r],{r['comparison_id']:s},CLEAR)
        self.assertIsNone(c['BOTH_PRESENT_RESOLUTION_COVERAGE']['value']);self.assertFalse(c['public_feature_candidate'])
    def test_threshold_exact_boundaries_and_no_rounding_up(self):
        self.assertTrue(at_least(ratio(4,5),80));self.assertFalse(at_least(ratio(799,1000),80));self.assertFalse(at_least(ratio(0,0),0))
    def test_normalized_packet_can_qualify_with_resolved_comparisons(self):
        rows,s=self.cohort();self.assertTrue(census_security(rows,s,NORMALIZED)['public_feature_candidate'])
    def test_duplicate_reporting_group_rejected(self):
        rows,s=self.cohort();rows[1]['manager_group_id']='a'
        with self.assertRaises(AssertionError):census_security(rows,s,CLEAR)
    def test_options_and_principal_never_candidate(self):
        for key,value in [('put_call','CALL'),('instrument_type','PRN')]:
            rows,s=self.cohort();rows[0][key]=value;self.assertFalse(census_security(rows,s,CLEAR)['public_feature_candidate'])

class RetainedDataTests(unittest.TestCase):
    def test_frozen_corpus_and_global_totals_preserved(self):
        self.assertEqual(len(corpus()),8137);r=read('both-present-results.json',PRIOR);self.assertEqual(r['both_present_resolved'],517);self.assertEqual(r['global_total_resolved'],526)
    def test_census_covers_every_frozen_security_once(self):
        c=read('security-census.json');self.assertEqual(len(c),3055);self.assertEqual({x['security_id'] for x in c},{x['security_id'] for x in corpus()})
        self.assertTrue(all(x['reported_increased']+x['reported_reduced']+x['reported_unchanged']==x['both_present_resolved'] for x in c))
    def test_candidate_population_has_no_partial_packets(self):
        c=read('qualified-security-candidates.json');self.assertEqual(len(c),16)
        self.assertTrue(all(x['both_present_unresolved']==0 and x['packet_state'] in {CLEAR,NORMALIZED} for x in c))
    def test_threshold_sensitivity_deterministic_under_input_order(self):
        rows=read('security-census.json');top=[x['security_id'] for x in read('public-top8-results.json')];linked=read('trend-linked-results.json')['bound_security_ids']
        self.assertEqual(sensitivity(rows,top,linked),sensitivity(list(reversed(rows)),list(reversed(top)),list(reversed(linked))))
        self.assertEqual(sensitivity(rows,top,linked),read('threshold-sensitivity.json')['rules'])
    def test_top8_are_ineligible_and_public_holders_reconcile(self):
        rows=read('public-top8-results.json');self.assertEqual(len(rows),8)
        self.assertTrue(all(x['PUBLIC_FEATURE_CANDIDATE']=='NO' and x['CURRENT_HOLDERS']==x['PUBLIC_OVERLAP_CURRENT_HOLDERS'] for x in rows))
    def test_reference_pairs_do_not_rewrite_global_526_counter(self):
        c=read('pre-corpus-reference-reconciliation.json');self.assertEqual(len(c['reference_pairs']),2)
        s=read('census-summary.json');self.assertEqual(s['ALL_BOTH_PRESENT_RESOLVED'],526+2)
        self.assertEqual(s['FROZEN_CORPUS_RESOLVED_PRESERVED'],526)
    def test_15_trends_and_unbound_vehicles_remain_explicit(self):
        r=read('trend-linked-results.json');self.assertEqual(len(r['trends']),15);self.assertEqual(r['EDITORIAL_UNBOUND_SECURITY_REFERENCES'],32)
        self.assertTrue(all(v['security_id'] is None and v['PUBLIC_FEATURE_CANDIDATE']=='NO' for v in r['unbound_vehicles']))
    def test_all_candidate_sentences_pass_representation_contract(self):
        self.assertTrue(all(semantic_valid(c['representation_sentence']) and all(c['representation_invariants'].values()) for c in read('qualified-security-candidates.json')))
    def test_no_threshold_or_future_certificate_selected(self):
        self.assertIsNone(read('threshold-sensitivity.json')['rule_selected'])
        self.assertTrue(all(not c['next_quarter_revalidated_now'] for c in read('next-quarter-maintenance.json')['candidates']))

if __name__=='__main__':unittest.main()

"""Analytical census and sentence contract, never a movement resolver or UI payload."""
from collections import Counter
from fractions import Fraction
import re

CLEAR='VERIFIED_CLEAR_FOR_COMPARABILITY'
NORMALIZED='VERIFIED_EVENT_NORMALIZATION_AVAILABLE'
RESOLVED={'INCREASED','REDUCED','UNCHANGED'}
RULES={'RULE_1':(50,5),'RULE_2':(70,5),'RULE_3':(80,5),'RULE_4':(80,10),'RULE_5':(90,10)}

def ratio(n,d):return {'numerator':n,'denominator':d,'value':n/d if d else None,'percent':n/d*100 if d else None}
def at_least(metric,percent):return metric['denominator']>0 and metric['numerator']*100>=metric['denominator']*percent

def census_security(rows,results,packet_state='UNKNOWN'):
    assert rows
    # One frozen reporting unit/economic group per security, no duplicate manager or class merge.
    assert len({r['manager_id'] for r in rows})==len(rows)
    assert len({r['manager_group_id'] for r in rows})==len(rows)
    both=[r for r in rows if r['current_quantity'] is not None and r['previous_quantity'] is not None]
    current=[r for r in rows if r['current_quantity'] is not None]
    previous=[r for r in rows if r['previous_quantity'] is not None]
    current_only=[r for r in current if r['previous_quantity'] is None]
    previous_only=[r for r in previous if r['current_quantity'] is None]
    resolved=[r for r in both if results[r['comparison_id']]['movement_status'] in RESOLVED]
    counts=Counter(results[r['comparison_id']]['movement_status'] for r in resolved)
    unresolved=[r for r in both if results[r['comparison_id']]['movement_status'] not in RESOLVED]
    reasons=[]
    if packet_state not in {CLEAR,NORMALIZED}:reasons.append('PACKET_'+packet_state)
    if not both:reasons.append('NO_BOTH_PRESENT_COMPARISONS')
    if unresolved:reasons.append('UNRESOLVED_BOTH_PRESENT_COMPARISONS')
    if any(r['instrument_type']!='SH' or r.get('put_call') is not None for r in rows):reasons.append('NOT_LONG_SHARE_SECURITY')
    b=len(both);c=len(current);p=len(previous);u=len(rows)
    assert c+p-b==u and len(current_only)+len(previous_only)+b==u
    return {'current_holders':c,'previous_holders':p,'both_present_managers':b,'both_present_resolved':len(resolved),'both_present_unresolved':len(unresolved),
        'current_only_managers':len(current_only),'previous_only_managers':len(previous_only),'holder_union':u,
        'reported_increased':counts['INCREASED'],'reported_reduced':counts['REDUCED'],'reported_unchanged':counts['UNCHANGED'],
        'packet_state':packet_state,'evidence_state':'PACKET_AND_ALL_COMPARISONS_QUALIFIED' if not reasons else 'INELIGIBLE_FOR_COMPLETE_SECURITY_SENTENCE',
        'public_feature_candidate':not reasons,'block_reasons':reasons,
        'BOTH_PRESENT_RESOLUTION_COVERAGE':ratio(len(resolved),b),'COMPARABLE_MANAGER_SHARE_OF_UNION':ratio(b,u),'COMPARABLE_MANAGER_SHARE_OF_CURRENT':ratio(b,c),
        'comparable_manager_count':b if not reasons else None,'counts_scope':'RESOLVED_BOTH_PRESENT_ONLY; PARTIAL_COUNTS_INTERNAL_ONLY',
        'manager_sets':{'both_present':sorted(r['manager_id'] for r in both),'current_only':sorted(r['manager_id'] for r in current_only),'previous_only':sorted(r['manager_id'] for r in previous_only)},
        'both_present_comparison_ids':sorted(r['comparison_id'] for r in both),'unresolved_comparison_ids':sorted(r['comparison_id'] for r in unresolved),
        'unresolved_reason_counts':dict(Counter(results[r['comparison_id']].get('reason_code','UNKNOWN') for r in unresolved)),
        'current_unusable_filing_rows':sum(r.get('current_filing_status')!='available' for r in current),
        'previous_unusable_filing_rows':sum(r.get('previous_filing_status')!='available' for r in previous)}

def rule_pass(row,rule):
    share,managers=RULES[rule]
    return row['public_feature_candidate'] and at_least(row['BOTH_PRESENT_RESOLUTION_COVERAGE'],100) and at_least(row['COMPARABLE_MANAGER_SHARE_OF_CURRENT'],share) and row['both_present_managers']>=managers

def sensitivity(rows,top8,linked):
    result={}
    for rule in RULES:
        ids=sorted(r['security_id'] for r in rows if rule_pass(r,rule))
        result[rule]={'eligible_security_count':len(ids),'eligible_public_top8_count':len(set(ids)&set(top8)),
            'eligible_trend_linked_count':len(set(ids)&set(linked)),'security_ids':ids,'selected':False}
    return result

def transition_flag(row):
    n=row['current_only_managers']+row['previous_only_managers']
    # Zero / minority / at least half of the union. Descriptive labels, not publication gates.
    return 'LOW_TRANSITION_SHARE' if n==0 else 'MODERATE_TRANSITION_SHARE' if n<row['both_present_managers'] else 'HIGH_TRANSITION_SHARE'

def sentence(row):
    if not row['public_feature_candidate']:return None
    n=row['both_present_managers'];a=row['reported_increased'];b=row['reported_reduced'];c=row['reported_unchanged']
    assert a+b+c==n
    unit=row.get('quantity_unit_label','acciones')
    return f'De {n} gestores que reportaron esta posición en ambos trimestres (Q1 y Q2 de 2026), {a} mostraron más {unit}, {b} menos y {c} la misma cantidad.'

def semantic_valid(text):
    return isinstance(text,str) and 'en ambos trimestres' in text and not re.search(r'\b(?:NEW|EXITED|EXIT|bought|sold|buy|sell|compraron|vendieron|compra|venta|transacción|transaction|dólares|dollars|USD|convicción|conviction|ranking|ranked)\b|\$',text,re.I)

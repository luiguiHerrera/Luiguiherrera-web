from pathlib import Path
import json,gzip,hashlib

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'internal/trends-movements/wave2c'
PRIOR=ROOT/'internal/trends-movements/wave2a'
def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def sha(x):return hashlib.sha256(x if isinstance(x,bytes) else canonical(x).encode()).hexdigest()
def read(name,base=OUT):return json.loads((base/name).read_text())
def write(name,value):(OUT/name).write_text(canonical(value)+'\n')
def corpus():
    body=gzip.decompress((ROOT/'internal/trends-movements/v2.1/corpus.jsonl.gz').read_bytes())
    assert sha(body)=='d270f69dc303daa6d694fbafa6d4c91166cdcfb60c4e1fb5bc90b105b5143ac3'
    rows=[json.loads(line) for line in body.splitlines()];assert len(rows)==8137
    assert sha(read('target.json',PRIOR))=='307cfb419c1134e020b7b0e57f8f7fab024a81ec2c8790af168f33c6de6559e6'
    return rows

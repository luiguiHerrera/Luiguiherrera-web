"""Read-only primary evidence reconstruction; deliberately independent of public parser."""
from collections import defaultdict
from decimal import Decimal
import gzip
import json
import re
import xml.etree.ElementTree as ET
from freeze import ROOT, digest

DATA = ROOT / 'lib/trends/capital/generated'

def load_sources():
    sources = {}
    for name in ['sec-evidence.json.gz', 'corporate-actions-evidence.json.gz', 'issuer-reports-evidence.json.gz']:
        archive = json.loads(gzip.decompress((DATA / name).read_bytes()))
        for url, response in archive['responses'].items():
            assert digest(response['body'].encode()) == response['sha256'], url
            if url in sources:
                assert sources[url]['sha256'] == response['sha256'], 'Conflicting primary evidence'
            sources[url] = {**response, 'archive': str((DATA / name).relative_to(ROOT))}
    return sources

def parse_primary(url, sources):
    response = sources[url]
    assert url.startswith('https://www.sec.gov/Archives/') and url.endswith('.txt')
    raw = response['body']
    roots = []
    for xml in re.findall(r'<XML>(.*?)</XML>', raw, re.S | re.I):
        assert '<!DOCTYPE' not in xml.upper() and '<!ENTITY' not in xml.upper()
        root = ET.fromstring(xml.strip())
        for e in root.iter():
            e.tag = e.tag.split('}')[-1]
        roots.append(root)
    covers = [r for r in roots if r.tag == 'edgarSubmission']
    assert len(covers) == 1
    cover = covers[0]
    rows = [r for root in roots if root.tag == 'informationTable' for r in root.findall('infoTable')]
    form = cover.findtext('./headerData/submissionType')
    nt = form.startswith('13F-NT')
    if not nt:
        assert len(rows) == int(cover.findtext('.//tableEntryTotal'))
        assert abs(sum(Decimal(r.findtext('value')) for r in rows) - Decimal(cover.findtext('.//tableValueTotal'))) <= len(rows)
    else:
        assert not rows
    positions = defaultdict(Decimal)
    row_evidence = defaultdict(list)
    for i, r in enumerate(rows):
        k = '|'.join([r.findtext('cusip').strip().upper(), (r.findtext('putCall') or 'LONG').upper(), r.findtext('./shrsOrPrnAmt/sshPrnamtType')])
        quantity = Decimal(r.findtext('./shrsOrPrnAmt/sshPrnamt'))
        assert quantity.is_finite() and quantity >= 0
        positions[k] += quantity
        row_evidence[k].append({'row_index': i, 'CUSIP': r.findtext('cusip'), 'issuer': r.findtext('nameOfIssuer'), 'security_class': r.findtext('titleOfClass'), 'quantity': str(quantity), 'put_call': r.findtext('putCall'), 'instrument': r.findtext('./shrsOrPrnAmt/sshPrnamtType'), 'other_manager': r.findtext('otherManager')})
    def refs(xpath):
        return [{'CIK': r.findtext('.//cik'), 'file_number': r.findtext('.//form13FFileNumber'), 'name': r.findtext('.//name')} for r in cover.findall(xpath)]
    return {'url': url, 'sha256': response['sha256'], 'form': form,
            'CIK': (cover.findtext('./headerData/filerInfo/filer/credentials/cik') or '').zfill(10),
            'quarter': cover.findtext('.//periodOfReport'), 'report_type': cover.findtext('.//reportType'),
            'amendment': cover.findtext('.//amendmentType'), 'confidential': cover.findtext('.//isConfidentialOmitted'),
            'included': refs('.//otherManagers2Info/otherManager2'), 'reporting': refs('.//otherManagersInfo/otherManager'),
            'positions': dict(positions), 'rows': dict(row_evidence),
            'cover_xml': ET.tostring(cover, encoding='unicode')}

def source_ref(url, sources):
    r = sources[url]
    return {'url': url, 'sha256': r['sha256'], 'archive': r['archive']}

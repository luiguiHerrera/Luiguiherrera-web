"""Explicit local phases: pilot first; expansion refuses a missing/stale/failed gate."""
import argparse
from collections import Counter,defaultdict
from fractions import Fraction
import gzip
import json
import subprocess
import sys
from freeze import ROOT,OUT,canonical,digest
from adapter import Adapter
from resolver import resolve

BOUND_FILES=['corpus.jsonl.gz','corpus-manifest.json','census.json','census-rows.json','manager-perimeter-registry.json','amendment-registry.json','corporate-action-registry.json','security-identity-graph.json','source-index.json','pilot-selection.json','pilot-primary-dossier.json','pilot-manual-review.json']

def fingerprint():
    files={str(f.relative_to(ROOT)):digest(f.read_bytes()) for f in sorted((ROOT/'scripts/movement_qualification').glob('*.py'))}
    files.update({str((OUT/name).relative_to(ROOT)):digest((OUT/name).read_bytes()) for name in BOUND_FILES})
    files.update({str(f.relative_to(ROOT)):digest(f.read_bytes()) for f in sorted((ROOT/'lib/trends/capital/generated').glob('*'))})
    return digest(canonical(files).encode())

def pilot():
    adapter=Adapter();selection=json.loads((OUT/'pilot-selection.json').read_text());review=json.loads((OUT/'pilot-manual-review.json').read_text())
    assert review['reviewed_dossier_sha256']==digest((OUT/'pilot-primary-dossier.json').read_bytes())
    assert review['selection_sha256']==digest((OUT/'pilot-selection.json').read_bytes())
    assert len(selection['cases'])==55 and len(set(c['comparison_id'] for c in selection['cases']))==55
    for k,n in {'same_security':20,'previous_only':10,'current_only':10,'amendment':5,'corporate_action':5,'manager_perimeter':5}.items():assert selection['strata'][k]>=n
    oracle={c['comparison_id']:c for c in review['cases']};rows={r['comparison_id']:r for r in adapter.rows};results=[];fp=[];mismatches=[]
    for c in selection['cases']:
        expected=oracle[c['comparison_id']];result=resolve(adapter.make(rows[c['comparison_id']]))
        if result['movement_status']!='INDETERMINATE' and result['movement_status']!=expected['expected_status']:fp.append(c['comparison_id'])
        if result['movement_status']!=expected['expected_status'] or not set(expected['required_blockers']).issubset(result['blockers']):mismatches.append(c['comparison_id'])
        results.append({**c,'expected_status':expected['expected_status'],'result':result})
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(ROOT/'scripts/movement_qualification'),'-p','test_*.py'],cwd=ROOT,capture_output=True,text=True)
    (OUT/'resolver-test-run.txt').write_text(tests.stdout+tests.stderr)
    state='PASS' if not fp and not mismatches and tests.returncode==0 else 'FAIL'
    report={'state':state,'pilot_size':55,'false_positives':len(fp),'false_positive_ids':fp,'mismatch_ids':mismatches,'positive_results':sum(r['result']['movement_status']!='INDETERMINATE' for r in results),'fingerprint':fingerprint(),'unit_tests_exit_code':tests.returncode,'cases':results,'limitation':'55 local primary-reconstructed cases; five positive cases in a single issue. Not proof of a global zero error rate or readiness to publish.'}
    (OUT/'pilot-results.json').write_text(canonical(report)+'\n');print(canonical({k:v for k,v in report.items() if k!='cases'}))
    if state!='PASS':raise SystemExit('STOP_PILOT_FAILED')

def verify_gate(gate,current_fingerprint):
    if gate.get('state')!='PASS' or gate.get('false_positives')!=0 or gate.get('unit_tests_exit_code')!=0 or gate.get('fingerprint')!=current_fingerprint:
        raise ValueError('STOP_EXPANSION: pilot missing, failed, or evidence/code changed')

def expand():
    gate=json.loads((OUT/'pilot-results.json').read_text());verify_gate(gate,fingerprint())
    adapter=Adapter();results=[];tasks={}
    for row in adapter.rows:
        r=resolve(adapter.make(row));r={'comparison_id':row['comparison_id'],'manager_id':row['manager_id'],'security_id':row['security_id'],'issuer_id':row['issuer_id'],**r}
        results.append(r)
        if r['movement_status']=='INDETERMINATE':
            for blocker in r['blockers']:
                if any(s in blocker for s in ['PERIMETER','CONFIDENTIAL','FILING','AMENDMENT','NOTICE','GROUP','HOLDING_SCOPE']):
                    taskkey='MANAGER:'+row['manager_group_id']+':'+blocker
                    kind='MANAGER_OR_FILING_EVIDENCE'
                elif blocker=='BLOCK_OPTIONS_OR_PRINCIPAL':taskkey='POLICY:OPTIONS_OR_PRINCIPAL';kind='UNSUPPORTED_INSTRUMENT'
                else:
                    taskkey='ISSUER_SECURITY:'+str(row['issuer_id'] or row['security_id'])+':'+row['previous_quarter']+':'+row['current_quarter']
                    kind='SHARED_IDENTITY_ACTION_AND_PRESENCE_EVIDENCE'
                task=tasks.setdefault(taskkey,{'task_id':digest(taskkey.encode())[:20],'root_cause':taskkey,'type':kind,'comparison_ids':set(),'blockers':set()})
                task['comparison_ids'].add(row['comparison_id']);task['blockers'].add(blocker)
    unresolved=[r for r in results if r['movement_status']=='INDETERMINATE'];counts=Counter(r['movement_status'] for r in results);buckets=Counter(r['resolution_bucket'] for r in results)
    tasklist=[]
    for _,t in sorted(tasks.items()):
        tasklist.append({**t,'comparison_ids':sorted(t['comparison_ids']),'blockers':sorted(t['blockers']),'affected_comparisons':len(t['comparison_ids']),'scope_warning':'Shared investigation only. Each resulting claim must still be scoped and bound; never bulk-clear manager absence/confidentiality from an issuer event.'})
    assert set(r['comparison_id'] for r in unresolved)==set(i for t in tasklist for i in t['comparison_ids'])
    summary={'TOTAL':len(results),'AUTO_RESOLVED':buckets['AUTO_RESOLVABLE'],'EVIDENCE_RESOLVED':buckets['EVIDENCE_RESOLVED'],'EVIDENCE_RESOLVABLE':buckets['EVIDENCE_RESOLVABLE'],'HUMAN_REVIEW_REQUIRED':buckets['HUMAN_REVIEW_REQUIRED'],'STRUCTURALLY_BLOCKED':buckets['STRUCTURALLY_BLOCKED'],'STILL_INDETERMINATE':len(unresolved),**{k:counts[k] for k in ['NEW','INCREASED','UNCHANGED','REDUCED','EXITED']},'UNRESOLVED_COMPARISONS':len(unresolved),'UNIQUE_REVIEW_TASKS':len(tasklist),'REVIEW_TASK_REDUCTION_PERCENT':round((1-len(tasklist)/len(unresolved))*100,6),'classification_partition':dict(buckets),'pilot_fingerprint':gate['fingerprint'],'publication_authorized':False}
    assert summary['AUTO_RESOLVED']+summary['EVIDENCE_RESOLVED']+summary['STILL_INDETERMINATE']==len(results)
    raw=''.join(canonical(r)+'\n' for r in results).encode();(OUT/'qualification-results.jsonl.gz').write_bytes(gzip.compress(raw,mtime=0));(OUT/'review-tasks.json').write_text(canonical(tasklist)+'\n');(OUT/'expansion-summary.json').write_text(canonical(summary)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['pilot','expand']);args=parser.parse_args()
    if args.phase=='pilot':pilot()
    else:expand()

"""Freeze existing indeterminate comparisons; no reclassification or network I/O."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'internal/trends-movements/v2.1'
SOURCE = ROOT / 'lib/trends/capital/generated/snapshot.json.gz'

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def digest(value):
    return hashlib.sha256(value).hexdigest()

def key(holding):
    return '|'.join([holding['CUSIP'].strip().upper(), holding['put_call'] or 'LONG', holding['share_type']])

def inventory(snapshot):
    managers = {x['manager_id']: x for x in snapshot['universe']['managers']}
    quarters = {side: {q['manager_id']: q for q in snapshot[side]} for side in ['previous', 'current']}
    companies = {x['id']: x for x in snapshot['companies']}
    result = []
    for m in snapshot['movements']:
        if m['state'] != 'INDETERMINATE':
            continue
        qs = {side: quarters[side][m['manager_id']] for side in quarters}
        hs = {side: next((h for h in qs[side]['positions'] if key(h) == m['security_key']), None) for side in qs}
        accessions = {side: sorted(f['accession_number'] for f in qs[side]['filings']) for side in qs}
        row = {
            'comparison_id': m['manager_id'] + '::' + m['security_key'],
            'manager_id': m['manager_id'], 'manager_group_id': managers[m['manager_id']]['economic_group_id'],
            'previous_accession': accessions['previous'][0] if len(accessions['previous']) == 1 else None,
            'current_accession': accessions['current'][0] if len(accessions['current']) == 1 else None,
            'previous_accessions': accessions['previous'], 'current_accessions': accessions['current'],
            'previous_quarter': snapshot['previous_quarter_end'], 'current_quarter': snapshot['quarter_end'],
            'security_id': m['security_key'], 'issuer_id': companies[m['security_key']]['issuer_id'],
            'CUSIP_previous': hs['previous']['CUSIP'] if hs['previous'] else None,
            'CUSIP_current': hs['current']['CUSIP'] if hs['current'] else None,
            'instrument_type': m['holding']['share_type'], 'put_call': m['holding']['put_call'],
            'previous_quantity': m['previous_shares'], 'current_quantity': m['current_shares'],
            'current_status': m['state'], 'current_reason': m['reason'],
            'previous_security_class': hs['previous']['security_class'] if hs['previous'] else None,
            'current_security_class': hs['current']['security_class'] if hs['current'] else None,
            'previous_filing_status': qs['previous']['status'], 'current_filing_status': qs['current']['status'],
            'previous_sources': m['previous_sources'], 'current_sources': m['current_sources'],
        }
        assert row['previous_quantity'] == (hs['previous']['shares'] if hs['previous'] else None)
        assert row['current_quantity'] == (hs['current']['shares'] if hs['current'] else None)
        result.append(row)
    result.sort(key=lambda x: x['comparison_id'])
    assert len(result) == 8137 and len({x['comparison_id'] for x in result}) == 8137
    return result

def freeze(check=False):
    snapshot = json.loads(gzip.decompress(SOURCE.read_bytes()))
    rows = inventory(snapshot)
    raw = ''.join(canonical(r) + '\n' for r in rows).encode()
    manifest = {'schema_version': 1, 'count': len(rows), 'corpus_sha256': digest(raw),
                'sha256_domain': 'UTF-8 canonical JSONL before gzip; sorted by comparison_id',
                'source_snapshot_sha256': digest(SOURCE.read_bytes()),
                'source_as_of': snapshot['as_of'], 'classification_changes': 0,
                'excluded_already_reviewed': len(snapshot['movements']) - len(rows),
                'null_policy': 'Missing or unavailable normalized row is unknown, never zero; accession is null if not singular.'}
    payloads = {'corpus.jsonl.gz': gzip.compress(raw, mtime=0), 'corpus-manifest.json': (canonical(manifest) + '\n').encode()}
    OUT.mkdir(parents=True, exist_ok=True)
    for name, content in payloads.items():
        target = OUT / name
        if check or target.exists():
            actual = target.read_bytes()
            assert (gzip.decompress(actual) == raw if name.endswith('.gz') else actual == content), 'Frozen corpus drift: ' + name
        else:
            target.write_bytes(content)
    print(canonical(manifest))
    return rows

if __name__ == '__main__':
    import sys
    freeze('--check' in sys.argv)

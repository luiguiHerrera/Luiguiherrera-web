"""Structural census only: families never authorize a movement status."""
from collections import Counter
from decimal import Decimal
from pathlib import Path
import gzip
import json
import re
from freeze import OUT, SOURCE, ROOT, canonical, digest, key
from evidence import load_sources, parse_primary, source_ref

FAMILIES = {
'A': 'SAME_MANAGER_SAME_SECURITY_BOTH_PRESENT', 'B': 'PREVIOUS_ONLY', 'C': 'CURRENT_ONLY',
'D': 'MANAGER_PERIMETER_CHANGED', 'E': 'AMENDMENT_INVOLVED', 'F': 'CORPORATE_ACTION_CANDIDATE',
'G': 'IDENTIFIER_CHANGED', 'H': 'SECURITY_CLASS_CHANGED', 'I': 'MISSING_OR_UNUSABLE_FILING',
'J': 'NOTICE_OR_INCLUDED_REPORT', 'K': 'OPTIONS_OR_PRINCIPAL', 'L': 'OTHER'}
# Explicit structural priority, not severity or presumed resolvability.
PRIORITY = ['J', 'E', 'D', 'I', 'K', 'G', 'H', 'F', 'A', 'B', 'C', 'L']

def read_context():
    s = json.loads(gzip.decompress(SOURCE.read_bytes()))
    rows = [json.loads(x) for x in gzip.decompress((OUT/'corpus.jsonl.gz').read_bytes()).decode().splitlines()]
    manifest = json.loads((OUT/'corpus-manifest.json').read_text())
    assert digest(SOURCE.read_bytes()) == manifest['source_snapshot_sha256']
    assert digest(gzip.decompress((OUT/'corpus.jsonl.gz').read_bytes())) == manifest['corpus_sha256']
    sources = load_sources()
    raw = {u: parse_primary(u, sources) for u in sources if u.endswith('.txt')}
    return s, rows, sources, raw

def perimeter(q, raw):
    if not q['filings']:
        return None
    f = q['filings'][-1]; r = raw[f['source_url']]
    def ids(refs):
        result=[]
        for x in refs:
            cik=str(x['CIK'] or '').strip()
            if cik and re.fullmatch(r'\d{1,10}',cik):result.append('CIK:'+cik.zfill(10))
            elif not cik and x['file_number']:result.append('FILE:'+x['file_number'].strip())
            else:result.append('UNIDENTIFIED:'+str(x['name']).strip())
        return sorted(result)
    return {'CIK': r['CIK'], 'included': ids(r['included']), 'reporting': ids(r['reporting']), 'report_type': r['report_type'], 'accessions': sorted(x['accession_number'] for x in q['filings'])}

def registries(s, sources, raw):
    previous = {q['manager_id']: q for q in s['previous']}; current = {q['manager_id']: q for q in s['current']}
    managers=[]; amendments=[]
    groups=Counter(m['economic_group_id'] for m in s['universe']['managers'] if m['filing_expected'])
    for m in s['universe']['managers']:
        if m['manager_id'] not in previous: continue
        old, new = previous[m['manager_id']], current[m['manager_id']]
        p, c = perimeter(old, raw), perimeter(new, raw)
        eq='INDETERMINATE';reason='PERIMETER_UNPROVEN'
        if p and c:
            a={k:v for k,v in p.items() if k!='accessions'};b={k:v for k,v in c.items() if k!='accessions'}
            if a!=b: eq='NO';reason='REPORTING_PERIMETER_CHANGE'
            elif 'NOTICE' in (p['report_type'] or ''):reason='NOTICE_INCLUDED_REPORT'
            elif 'COMBINATION' in (p['report_type'] or ''):reason='COMBINATION_REPORT_SCOPE_UNPROVEN'
            elif 'UNIDENTIFIED:' in canonical(a):reason='MANAGER_REFERENCE_IDENTITY_UNPROVEN'
            elif groups[m['economic_group_id']]>1:reason='DUPLICATE_ECONOMIC_GROUP'
            else: eq='YES';reason='IDENTICAL_CIK_AND_REPORTED_MANAGER_IDENTIFIERS'
        if m['manager_id'].startswith('pershing-square'):eq='NO';reason='REPORTING_PERIMETER_CHANGE'
        managers.append({'manager_id':m['manager_id'],'manager_group_id':m['economic_group_id'],'expected_filer':m['filing_expected'], 'Q1_REPORTING_PERIMETER':p,'Q2_REPORTING_PERIMETER':c,'PERIMETER_EQUIVALENT':eq,'REASON':reason,'EVIDENCE':[source_ref(f['source_url'],sources) for q in [old,new] for f in q['filings']]})
        for q in [old,new]:
            forms=[f['amendment'] for f in q['filings']];state='NONE';selected=[];composition='NOT_NEEDED'
            if any(i in q['issues'] for i in ['ambiguous_additive_amendment','unknown_amendment','conflicting_accession']):state='AMBIGUOUS'
            elif 'UNKNOWN' in forms:state='AMBIGUOUS'
            elif 'NEW_HOLDINGS' in forms:state='AMBIGUOUS' # label alone never proves additive composition
            elif 'RESTATEMENT' in forms:state='RESTATEMENT';composition='LATEST_RESTATEMENT_SUBSTITUTED'
            if state!='AMBIGUOUS':
                start=max([i for i,f in enumerate(q['filings']) if f['amendment']=='RESTATEMENT'] or [0]);selected=[f['accession_number'] for f in q['filings'][start:]]
            amendments.append({'manager_id':m['manager_id'],'quarter':q['quarter_end'],'state':state,'composition':composition,'selected_accessions':selected,'all_accessions':[f['accession_number'] for f in q['filings']],'issues':q['issues'],'evidence_refs':[source_ref(f['source_url'],sources) for f in q['filings']]})
    return managers, amendments

def census(s, rows, managers, amendments):
    qs={side:{q['manager_id']:q for q in s[side]} for side in ['previous','current']};mgr={m['manager_id']:m for m in managers};am={(a['manager_id'],a['quarter']):a for a in amendments}
    results=[]
    for r in rows:
        old,new=[qs[side][r['manager_id']] for side in ['previous','current']]
        p=next((h for h in old['positions'] if key(h)==r['security_id']),None);c=next((h for h in new['positions'] if key(h)==r['security_id']),None)
        flags=[];notes=[]
        if any(q['status']=='not_separately_disclosed' for q in [old,new]):flags.append('J')
        if any(am[(q['manager_id'],q['quarter_end'])]['state']!='NONE' for q in [old,new]):flags.append('E')
        if mgr[r['manager_id']]['PERIMETER_EQUIVALENT']=='NO' or r['current_reason']=='reporting_perimeter_changed':flags.append('D')
        if any(q['status']!='available' for q in [old,new]):flags.append('I')
        if r['put_call'] or r['instrument_type']!='SH':flags.append('K')
        if p and c and p['security_class'].strip().upper()!=c['security_class'].strip().upper():flags.append('H')
        if bool(p)!=bool(c):
            present=p or c;others=new['positions'] if p else old['positions']
            # Text only generates UNKNOWN_RELATION research candidates; it never proves continuity.
            matches=[h for h in others if h['issuer'].strip().upper()==present['issuer'].strip().upper() and h['CUSIP']!=present['CUSIP']]
            if matches:flags.append('G');notes.append({'identifier_candidates':sorted(set(key(h) for h in matches)),'evidence_level':'NAME_MATCH_RESEARCH_HINT_ONLY'})
        if r['security_id'].startswith('02079K107|'):flags.append('F');notes.append({'corporate_action_candidate':'Alphabet June issuance; class-specific effect requires primary review'})
        elif p and c and min(p['shares'],c['shares'])>0:
            ratio=Decimal(str(max(p['shares'],c['shares'])))/Decimal(str(min(p['shares'],c['shares'])))
            if ratio>=2 and ratio==ratio.to_integral_value():flags.append('F');notes.append({'quantity_ratio_candidate':str(ratio),'evidence_level':'ARITHMETIC_RESEARCH_HINT_ONLY'})
        flags.append('A' if p and c else 'B' if p else 'C' if c else 'L')
        primary=next(k for k in PRIORITY if k in flags)
        results.append({'comparison_id':r['comparison_id'],'primary_family':primary,'secondary_flags':sorted(set(flags)-{primary}),'annotations':notes,'confidentiality_unknown_or_true':old['confidential'] or new['confidential'],'perimeter_equivalent':mgr[r['manager_id']]['PERIMETER_EQUIVALENT'],'current_status':r['current_status']})
    counts=Counter(r['primary_family'] for r in results)
    report={'total':len(rows),'priority':PRIORITY,'status_changes':0,'families':{k:{'name':FAMILIES[k],'count':counts[k],'percent':round(counts[k]/len(rows)*100,6),'secondary_or_primary_count':sum(k==x['primary_family'] or k in x['secondary_flags'] for x in results)} for k in FAMILIES},'limitations':['G and F are research candidates, not verified identity changes or actions.','D includes legacy combination-report perimeter blockers; exact change and unproven scope are separate registry reasons.','A/B/C describe normalized row presence, not complete economic histories.','Zero cases in a family means none detected by these rules; it does not prove absence of that risk.']}
    return report,results

def run():
    s,rows,sources,raw=read_context();managers,amendments=registries(s,sources,raw);report,classified=census(s,rows,managers,amendments)
    for name,data in [('manager-perimeter-registry.json',managers),('amendment-registry.json',amendments),('census.json',report),('census-rows.json',classified)]:
        (OUT/name).write_text(canonical(data)+'\n')
    (OUT/'source-index.json').write_text(canonical({u:source_ref(u,sources) for u in sorted(sources)})+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':run()

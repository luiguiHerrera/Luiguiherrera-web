"""Freeze a stratified pilot and primary-source dossier BEFORE resolver execution."""
import json
from freeze import OUT, canonical, digest
from adapter import Adapter


def select():
    adapter=Adapter();rows=adapter.rows;families={r['comparison_id']:r for r in json.loads((OUT/'census-rows.json').read_text())}
    selected=[];used=set()
    def take(label,n,predicate,diverse=True):
        pool=[r for r in rows if r['comparison_id'] not in used and predicate(r)]
        if diverse:
            ordered=[];counts={}
            while pool:
                r=min(pool,key=lambda r:(counts.get(r['manager_id'],0),r['comparison_id']));pool.remove(r);ordered.append(r);counts[r['manager_id']]=counts.get(r['manager_id'],0)+1
            pool=ordered
        assert len(pool)>=n,(label,len(pool))
        if (OUT/'pilot-selection.json').exists():
            frozen=json.loads((OUT/'pilot-selection.json').read_text())
            ids=[c['comparison_id'] for c in frozen['cases'] if c['stratum']==label]
            byid={r['comparison_id']:r for r in rows}
            assert len(ids)==n and all(i not in used and predicate(byid[i]) for i in ids),'Frozen pilot stratum invalidated'
            pool=[byid[i] for i in ids]
        for r in pool[:n]:selected.append({'stratum':label,'comparison_id':r['comparison_id']});used.add(r['comparison_id'])
    def corporate(r):
        if r['security_id']!='02079K107|LONG|SH' or r['previous_quantity'] is None or r['current_quantity'] is None:return False
        x=adapter.make(r)
        return x['perimeter']['equivalent']=='YES' and all(f['confidential'] is False and f['status']=='USABLE' for f in x['filings'].values()) and x['continuity']['relation']=='SAME_SECURITY'
    take('corporate_action',5,corporate)
    take('same_security',20,lambda r:families[r['comparison_id']]['primary_family']=='A')
    take('previous_only',10,lambda r:families[r['comparison_id']]['primary_family']=='B')
    take('current_only',10,lambda r:families[r['comparison_id']]['primary_family']=='C')
    take('amendment',5,lambda r:families[r['comparison_id']]['primary_family']=='E',False)
    take('manager_perimeter',5,lambda r:r['manager_id']=='pershing-square-inc',False)
    byid={r['comparison_id']:r for r in rows};dossier=[]
    for spec in selected:
        r=byid[spec['comparison_id']];x=adapter.make(r);e=[]
        for side in ['previous','current']:
            q=adapter.quarters[side][r['manager_id']]
            for f in q['filings']:
                raw=adapter.raw[f['source_url']]
                e.append({'side':side,'url':f['source_url'],'sha256':raw['sha256'],'accession':f['accession_number'],'selected':f['accession_number'] in x['filings'][side]['selected_accessions'],'CIK':raw['CIK'],'quarter':raw['quarter'],'form':raw['form'],'amendment':raw['amendment'],'confidential_omitted':raw['confidential'],'report_type':raw['report_type'],'included':raw['included'],'reporting':raw['reporting'],'primary_rows':raw['rows'].get(r['security_id'],[]),'primary_quantity':str(raw['positions'][r['security_id']]) if r['security_id'] in raw['positions'] else None})
        dossier.append({**spec,'inventory':r,'perimeter':adapter.perimeters[r['manager_id']], 'amendments':[adapter.amendments[(r['manager_id'],r[side+'_quarter'])] for side in ['previous','current']], 'corporate_coverage':x['corporate_actions']['coverage'].get('coverage_id'), 'source_evidence':e})
    manifest={'size':len(selected),'strata':{k:sum(s['stratum']==k for s in selected) for k in sorted({s['stratum'] for s in selected})},'selection_method':'Deterministic manager-stratified lexicographic sample; five Class C event cases deliberately require complete non-confidential same-perimeter evidence. Not a representative accuracy estimate.','corpus_sha256':json.loads((OUT/'corpus-manifest.json').read_text())['corpus_sha256'],'cases':selected}
    for name,data in [('pilot-selection.json',manifest),('pilot-primary-dossier.json',dossier)]:
        f=OUT/name;content=canonical(data)+'\n'
        if f.exists():assert f.read_text()==content,'Pilot drift'
        else:f.write_text(content)
    print(canonical({k:v for k,v in manifest.items() if k!='cases'}))
    for i,case in enumerate(dossier,1):
        r=case['inventory'];print(canonical({'n':i,'id':case['comparison_id'],'stratum':case['stratum'],'before':r['previous_quantity'],'after':r['current_quantity'],'perimeter':case['perimeter']['PERIMETER_EQUIVALENT'],'corporate_coverage':case['corporate_coverage'],'primary':[{k:e[k] for k in ['side','accession','selected','form','amendment','confidential_omitted','primary_quantity','primary_rows']} for e in case['source_evidence']]}))

if __name__=='__main__':select()

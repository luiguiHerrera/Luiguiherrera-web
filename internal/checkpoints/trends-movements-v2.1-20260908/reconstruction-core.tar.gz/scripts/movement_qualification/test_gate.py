import unittest
from run import verify_gate
class GateTests(unittest.TestCase):
    def test_missing_failed_stale_and_false_positive_gates_rejected(self):
        good={'state':'PASS','false_positives':0,'unit_tests_exit_code':0,'fingerprint':'expected'}
        verify_gate(good,'expected')
        for patch in [{},{'state':'FAIL'},{'false_positives':1},{'unit_tests_exit_code':1},{'fingerprint':'stale'}]:
            candidate={} if not patch else {**good,**patch}
            with self.assertRaises(ValueError):verify_gate(candidate,'expected')

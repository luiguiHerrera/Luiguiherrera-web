"""Bind immutable corpus rows to reconstructed primary filings and scoped registries."""
from copy import deepcopy
from decimal import Decimal
import json
from freeze import OUT, key
from census import read_context
from evidence import source_ref
from resolver import binding, ACTION_CHECKS

class Adapter:
    def __init__(self):
        self.snapshot,self.rows,self.sources,self.raw=read_context()
        self.quarters={side:{q['manager_id']:q for q in self.snapshot[side]} for side in ['previous','current']}
        self.managers={m['manager_id']:m for m in self.snapshot['universe']['managers']}
        self.perimeters={m['manager_id']:m for m in json.loads((OUT/'manager-perimeter-registry.json').read_text())}
        self.amendments={(a['manager_id'],a['quarter']):a for a in json.loads((OUT/'amendment-registry.json').read_text())}
        self.corporate=json.loads((OUT/'corporate-action-registry.json').read_text())
        self.graph=json.loads((OUT/'security-identity-graph.json').read_text())
        self.identities={(e['previous_security'],e['current_security']):e for e in self.graph['edges'] if e['verification_status']=='VERIFIED'}
        self.source_hashes={u:r['sha256'] for u,r in self.sources.items()}
        self.reconstruction={}
        for side,quarters in self.quarters.items():
            for mid,q in quarters.items():
                am=self.amendments[(mid,q['quarter_end'])];positions={};selected=[]
                for f in q['filings']:
                    if f['accession_number'] not in am['selected_accessions']:continue
                    r=self.raw[f['source_url']];assert r['CIK']==f['CIK']
                    assert r['quarter'] in [q['quarter_end'],q['quarter_end'][5:7]+'-'+q['quarter_end'][8:]+'-'+q['quarter_end'][:4]]
                    selected.append(f)
                    for k,v in r['positions'].items():positions[k]=positions.get(k,Decimal(0))+v
                if q['status']=='available' and am['state']!='AMBIGUOUS':
                    expected={key(h):Decimal(str(h['shares'])) for h in q['positions']}
                    assert positions==expected, (mid,side,'primary reconstruction mismatch')
                self.reconstruction[(mid,side)]={'positions':positions,'selected':selected}

    def claim(self,values,refs,verified=True):
        return {**values,'verification_status':'VERIFIED' if verified else 'UNVERIFIED','evidence_refs':refs}

    def make(self,row):
        mid=row['manager_id'];manager=self.managers[mid]
        x={k:row[k] for k in ['manager_id','manager_group_id','previous_quarter','current_quarter']}
        x.update(filings={},amendments={},source_hashes=self.source_hashes)
        for side in ['previous','current']:
            q=self.quarters[side][mid];a=self.amendments[(mid,q['quarter_end'])];rec=self.reconstruction[(mid,side)]
            filing_refs=[source_ref(f['source_url'],self.sources) for f in q['filings']]
            index_ref=source_ref(manager['source_url'],self.sources)
            f=self.claim({'status':'USABLE' if q['status']=='available' else 'UNUSABLE','authoritative':all(self.raw[f['source_url']]['CIK']==manager['CIK'] for f in q['filings']),
                'complete':q['status']=='available' and bool(rec['selected']) and all(f['complete'] for f in rec['selected']),
                'confidential':False if rec['selected'] and all(self.raw[f['source_url']]['confidential'] in ['false','0'] for f in rec['selected']) else None,
                'notice_or_included':q['status']=='not_separately_disclosed' or any(f['form_type'].startswith('13F-NT') for f in q['filings']),
                'duplicate_economic_group':sum(m['economic_group_id']==manager['economic_group_id'] and m['filing_expected'] for m in self.managers.values())!=1,
                'accessions':sorted(f['accession_number'] for f in q['filings']),'selected_accessions':sorted(a['selected_accessions'])},filing_refs+[index_ref])
            x['filings'][side]=f
            x['amendments'][side]=self.claim({'state':a['state'],'composition_verified':a['state'] in ['NONE','RESTATEMENT'] and bool(rec['selected']),'selected_accessions':sorted(a['selected_accessions'])},filing_refs)
            h=next((h for h in q['positions'] if key(h)==row['security_id']),None)
            x[side]=None if h is None else {'manager_id':mid,'manager_group_id':row['manager_group_id'],'quarter':q['quarter_end'],'security_id':row['security_id'],'issuer_id':row['issuer_id'],'CUSIP':h['CUSIP'],'instrument_type':h['share_type'],'put_call':h['put_call'],'security_class':h['security_class'],'quantity':str(rec['positions'][row['security_id']]),'source_accessions':[f['accession_number'] for f in rec['selected'] if row['security_id'] in self.raw[f['source_url']]['positions']]}
        pm=self.perimeters[mid]
        x['perimeter']=self.claim({'equivalent':pm['PERIMETER_EQUIVALENT'],'reason':pm['REASON']},pm['EVIDENCE'])
        p,c=x['previous'],x['current'];k=row['security_id'];edge=self.identities.get((k,k))
        same=p is not None and c is not None and p['security_class']==c['security_class'] and edge is not None
        refs=x['filings']['previous']['evidence_refs']+x['filings']['current']['evidence_refs']
        x['continuity']=self.claim({'relation':'SAME_SECURITY' if same else 'UNKNOWN_RELATION','previous_security':k if p else None,'current_security':k if c else None,'one_to_one':same,'class_equivalence_verified':same},refs,same)
        coverage=next((v for v in self.corporate['coverages'] if v['security_ids']==[k] and v['start']==row['previous_quarter'] and v['end']==row['current_quarter']),None)
        if coverage:
            coverage=deepcopy(coverage)
            for ref in coverage['evidence_refs']:assert self.source_hashes.get(ref['url'])==ref['sha256']
        else:coverage=self.claim({'security_ids':[k],'start':row['previous_quarter'],'end':row['current_quarter'],'checks':{t:'UNRESOLVED' for t in ACTION_CHECKS}},[],False)
        events=[deepcopy(e) for e in self.corporate['events'] if k in e['affected_security_ids'] and row['previous_quarter']<e['effective_date']<=row['current_quarter']]
        x['corporate_actions']={'coverage':coverage,'events':events}
        x['presence_evidence']=self.claim({'checks':{},'complete_security_search':False,'no_transformation':False},[],False)
        subject=binding(x)
        for claim in [*x['filings'].values(),*x['amendments'].values(),x['perimeter'],x['continuity'],coverage,*events,x['presence_evidence']]:claim['binding']=subject
        return x

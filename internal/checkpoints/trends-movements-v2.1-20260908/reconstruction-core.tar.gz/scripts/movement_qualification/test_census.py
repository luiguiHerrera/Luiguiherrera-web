import unittest
from census import perimeter,read_context,registries
class PerimeterNormalizationTests(unittest.TestCase):
    def test_whitespace_CIK_is_same_reporting_entity(self):
        q={'filings':[{'source_url':'primary','accession_number':'A'}]}
        def raw(cik):return {'primary':{'CIK':'0001017918','included':[{'CIK':cik,'file_number':None,'name':'Same filer'}],'reporting':[],'report_type':'13F HOLDINGS REPORT'}}
        self.assertEqual(perimeter(q,raw('0000790504  ')),perimeter(q,raw('0000790504')))
    def test_real_BAMCO_is_not_false_perimeter_change(self):
        s,_,sources,raw=read_context();m,_=registries(s,sources,raw);byid={x['manager_id']:x for x in m}
        self.assertEqual(byid['bamco']['PERIMETER_EQUIVALENT'],'YES')
        self.assertEqual(byid['pershing-square-inc']['PERIMETER_EQUIVALENT'],'NO')

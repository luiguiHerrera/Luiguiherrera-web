"""Materialize scoped evidence registries. Never generalize issuer-name matches."""
import json
import re
import html
from freeze import ROOT, OUT, canonical, digest
from census import read_context
from evidence import source_ref
from resolver import ACTION_TYPES, ACTION_CHECKS, RELATIONS


def build():
    s,rows,sources,raw=read_context()
    config=json.loads((ROOT/'lib/trends/capital/config.json').read_text())
    # Reuse the retained, explicitly reviewed class-specific evidence scope,
    # not the previous two manager decisions or their quantities.
    reviews=[r for r in config['comparisons'] if r['previous_key']==r['current_key']=='02079K107|LONG|SH']
    assert len(reviews)==2 and all(r['action']=='NONE' and r['share_factor']==1 for r in reviews)
    issuer_urls=sorted({u for r in reviews for u in r['evidence_urls'] if '/data/1652044/' in u})
    assert len(issuer_urls)==13
    texts={u:re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]+>',' ',sources[u]['body']))) for u in issuer_urls}
    q2=next(u for u in issuer_urls if u.endswith('goog-20260630.htm'))
    issue=next(u for u in issuer_urls if u.endswith('d83560d8k.htm'))
    preferred=next(u for u in issuer_urls if u.endswith('d36818d8k.htm'))
    assert '14,359,656' in texts[issue] and 'June 4, 2026' in texts[issue]
    assert 'closed on June 5, 2026' in texts[preferred]
    assert 'Common Stock Issuance' in texts[q2] and 'Mandatory Convertible Preferred Stock' in texts[q2]
    security='02079K107|LONG|SH'
    events=[]
    for eid,date,url,description in [
        ('alphabet-common-issuance-20260604','2026-06-04',issue,'Newly issued Class A/Class C shares, including Class C private placement. This is not a split of existing Class C units.'),
        ('alphabet-preferred-issuance-20260605','2026-06-05',preferred,'New preferred/depositary issues; their prospective conversion rights do not multiply existing Class C units.')]:
        events.append({'event_id':eid,'issuer_id':'sec-issuer-1652044','security_id':security,'CUSIP':'02079K107','effective_date':date,'action_type':'OTHER','ratio':{'numerator':1,'denominator':1},'predecessor_security':security,'successor_security':security,'source':'SEC_EDGAR','source_accession':re.search(r'/([0-9]{18})/',url).group(1),'source_url':url,'verification_status':'VERIFIED','effect_on_existing_units':'NONE','affected_security_ids':[security],'evidence_refs':[source_ref(url,sources),source_ref(q2,sources)],'rationale':description})
    coverage={'coverage_id':'alphabet-class-c-2026q1-q2','issuer_id':'sec-issuer-1652044','security_ids':[security],'start':s['previous_quarter_end'],'end':s['quarter_end'],'verification_status':'VERIFIED','checks':{k:'CLEAR' for k in ACTION_CHECKS},'evidence_refs':[source_ref(u,sources) for u in issuer_urls],
        'provenance':'Class-C-only corporate-action scope of the two retained config reviews; primary Note 11 and issuance terms inspected again locally. No manager-level approvals are inherited.',
        'limitations':['Not a clearance for Alphabet Class A, preferred issues, other issuers, other dates, or absent rows.','No absence/NEW/EXIT certification.','Dilution/issuance changes outstanding issuer shares, not the per-unit comparison factor.'],
        'review_findings':{'Q1_Q2_equity_rollforward':'Existing Class C issue retained; reported changes are issuance/compensation, not a split or unit conversion.', 'june4':'Common public/private issuance; no multiplication of pre-existing Class C holdings.', 'june5':'Preferred issue has its own securities and conversion rights; no automatic conversion of existing Class C.', 'shareholder_vote':'Stock-plan reserve increase is not an existing-share split.', 'other_retained_8K':'Debt offerings, executive/governance matters, results announcements; no existing Class C unit transformation.', 'coverage_source_config_sha256':digest((ROOT/'lib/trends/capital/config.json').read_bytes())}}
    registry={'schema_version':1,'action_types':ACTION_TYPES,'events':events,'coverages':[coverage],'default_for_uncovered_security':'UNRESOLVED; never infer CLEAR from no event in registry'}
    graph={'schema_version':1,'allowed_relationships':RELATIONS,'nodes':[],'edges':[],'name_ticker_policy':'Research hints only. SAME_SECURITY requires issue identifier, instrument and class; issuer unions are never movement edges.'}
    companies={x['id']:x for x in s['companies']}
    for k,v in sorted(companies.items()):graph['nodes'].append({'security_id':k,'CUSIP':k.split('|')[0],'issuer_id':v['issuer_id']})
    cs=json.loads((OUT/'census-rows.json').read_text())
    keys=sorted({r['security_id'] for r in rows if r['previous_quantity'] is not None and r['current_quantity'] is not None and r['previous_security_class']==r['current_security_class']})
    for k in keys:
        relevant=[r for r in rows if r['security_id']==k and r['previous_quantity'] is not None and r['current_quantity'] is not None and r['previous_security_class']==r['current_security_class']]
        urls=sorted({u for r in relevant for u in r['previous_sources']+r['current_sources']})
        graph['edges'].append({'previous_security':k,'current_security':k,'relation':'SAME_SECURITY','verification_status':'VERIFIED','one_to_one':True,'issuer_id':companies[k]['issuer_id'],'evidence_refs':[source_ref(u,sources) for u in urls],'scope':'Issue identifier continuity only; corporate-action and manager checks remain mandatory.'})
    hints=set()
    byid={r['comparison_id']:r for r in rows}
    for row in cs:
        for a in row['annotations']:
            for candidate in a.get('identifier_candidates',[]):hints.add(tuple(sorted([byid[row['comparison_id']]['security_id'],candidate])))
    for p,c in sorted(hints):graph['edges'].append({'previous_security':p,'current_security':c,'relation':'UNKNOWN_RELATION','verification_status':'UNVERIFIED','one_to_one':False,'evidence_refs':[],'scope':'Issuer text research hint; direction is unknown and not authoritative.'})
    for name,data in [('corporate-action-registry.json',registry),('security-identity-graph.json',graph)]: (OUT/name).write_text(canonical(data)+'\n')
    print(canonical({'events':len(events),'covered_securities':1,'identity_edges':len(graph['edges']),'unknown_identity_hints':len(hints)}))

if __name__=='__main__':build()

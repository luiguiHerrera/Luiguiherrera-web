"""Pure, deterministic and fail-closed. No I/O, network, randomness or model decisions.

Evidence claims must be validated against retained primary documents by the adapter.
Hashes bind a reviewed claim to the exact inputs; they do not prove the claim's truth.
"""
from datetime import date
from fractions import Fraction
import hashlib
import json
import re
from urllib.parse import urlparse

STATUSES = ['NEW', 'INCREASED', 'UNCHANGED', 'REDUCED', 'EXITED', 'INDETERMINATE']
ACTION_TYPES = ['SPLIT','REVERSE_SPLIT','MERGER','SPINOFF','CONVERSION','CUSIP_CHANGE','SHARE_CLASS_CHANGE','TICKER_CHANGE','REORGANIZATION','OTHER']
RELATIONS = ['SAME_SECURITY','SUCCESSOR_OF','PREDECESSOR_OF','CLASS_CONVERSION','ISSUER_SAME_SECURITY_DIFFERENT_TICKER','UNKNOWN_RELATION']
PRESENCE_CHECKS = ['CUSIP_CHANGE','SHARE_CLASS_CHANGE','MERGER','SPINOFF','CONVERSION','TICKER_CHANGE','ISSUER_RENAME','AMENDMENT','CONFIDENTIALITY','FILING_COMPLETENESS','REPORTING_PERIMETER','PERMITTED_OMISSION']
ACTION_CHECKS = ['SPLIT','REVERSE_SPLIT','MERGER','SPINOFF','CONVERSION','CUSIP_CHANGE','SHARE_CLASS_CHANGE','TICKER_CHANGE','REORGANIZATION','OTHER']
SUBJECT_KEYS = ['manager_id','manager_group_id','previous_quarter','current_quarter','previous','current','filings']

def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def binding(x):
    def clean(v):
        if isinstance(v,dict):return {k:clean(a) for k,a in v.items() if k!='binding'}
        if isinstance(v,list):return [clean(a) for a in v]
        return v
    return hashlib.sha256(canon(clean({k:x[k] for k in SUBJECT_KEYS})).encode()).hexdigest()

def resolve(x):
    try:return _resolve(x)
    except (KeyError,TypeError,ValueError,ZeroDivisionError,OverflowError,AttributeError,IndexError):
        return {'movement_status':'INDETERMINATE','qualification_tier':'UNQUALIFIED','confidence':'INSUFFICIENT','reason_code':'BLOCK_MALFORMED_INPUT','blockers':['BLOCK_MALFORMED_INPUT'],'evidence_refs':[],'resolution_bucket':'HUMAN_REVIEW_REQUIRED','normalized_previous_quantity':None}

def _resolve(x):
    blockers=[];refs=[]
    def block(code):
        if code not in blockers:blockers.append(code)
    subject=binding(x)
    def verified(claim):
        if claim.get('binding')!=subject:return False
        evid=claim.get('evidence_refs',[])
        if claim.get('verification_status')!='VERIFIED' or not evid:return False
        for r in evid:
            u=urlparse(r['url'])
            if u.scheme!='https' or u.hostname not in ['www.sec.gov','data.sec.gov'] or u.username or u.password:return False
            if not re.fullmatch('[a-f0-9]{64}',r['sha256']) or x['source_hashes'].get(r['url'])!=r['sha256']:return False
        refs.extend(evid)
        return True
    old=date.fromisoformat(x['previous_quarter']);new=date.fromisoformat(x['current_quarter'])
    quarters={(3,31),(6,30),(9,30),(12,31)}
    if (old.month,old.day) not in quarters or (new.month,new.day) not in quarters or new.year*12+new.month-old.year*12-old.month!=3:block('BLOCK_NONCONSECUTIVE_QUARTERS')
    p,c=x['previous'],x['current']; present=[h for h in [p,c] if h is not None]
    if not present:block('BLOCK_SECURITY_IDENTITY')
    for side,h in [('previous',p),('current',c)]:
        f=x['filings'][side]
        if not verified(f):block('BLOCK_EVIDENCE_BINDING')
        if f['status']!='USABLE' or f['authoritative'] is not True or f['complete'] is not True:block('BLOCK_FILING_UNAVAILABLE')
        if f['notice_or_included'] is not False:block('BLOCK_NOTICE_OR_INCLUDED_REPORT')
        if f['confidential'] is not False:block('BLOCK_CONFIDENTIALITY')
        if f['duplicate_economic_group'] is not False:block('BLOCK_DUPLICATE_REPORTING_GROUP')
        if len(f['accessions'])!=len(set(f['accessions'])) or not f['accessions']:block('BLOCK_AMENDMENT_COMPOSITION')
        amendment=x['amendments'][side]
        if not verified(amendment):block('BLOCK_EVIDENCE_BINDING')
        if amendment['state']=='AMBIGUOUS':block('BLOCK_AMBIGUOUS_AMENDMENT')
        elif amendment['state'] not in ['NONE','RESTATEMENT','ADDITIVE_CONFIRMED']:block('BLOCK_AMENDMENT_COMPOSITION')
        elif amendment['composition_verified'] is not True or sorted(amendment['selected_accessions'])!=sorted(f['selected_accessions']):block('BLOCK_AMENDMENT_COMPOSITION')
        elif not set(f['selected_accessions']).issubset(set(f['accessions'])) or not f['selected_accessions'] or len(f['selected_accessions'])!=len(set(f['selected_accessions'])):block('BLOCK_AMENDMENT_COMPOSITION')
        elif amendment['state'] in ['NONE','RESTATEMENT'] and len(f['selected_accessions'])!=1:block('BLOCK_AMENDMENT_COMPOSITION')
        if h is not None:
            if h['manager_id']!=x['manager_id'] or h['manager_group_id']!=x['manager_group_id'] or h['quarter']!=x[side+'_quarter']:block('BLOCK_HOLDING_SCOPE')
            if h['security_id']!='|'.join([h['CUSIP'],h['put_call'] or 'LONG',h['instrument_type']]) or not re.fullmatch('[A-Z0-9*@#]{9}',h['CUSIP']):block('BLOCK_SECURITY_IDENTITY')
            if h['instrument_type']!='SH' or h['put_call'] is not None:block('BLOCK_OPTIONS_OR_PRINCIPAL')
            if not h['source_accessions'] or not set(h['source_accessions']).issubset(set(f['selected_accessions'])):block('BLOCK_AMENDMENT_COMPOSITION')
            if isinstance(h['quantity'],bool) or not re.fullmatch(r'\d+(\.\d+)?',str(h['quantity'])) or Fraction(str(h['quantity']))<=0:block('BLOCK_QUANTITY_UNUSABLE')
    perimeter=x['perimeter']
    if not verified(perimeter):block('BLOCK_EVIDENCE_BINDING')
    if perimeter['equivalent']!='YES':block('BLOCK_MANAGER_PERIMETER_CHANGE' if perimeter['equivalent']=='NO' else 'BLOCK_MANAGER_PERIMETER_UNPROVEN')
    identity=x['continuity']
    if not verified(identity) or identity['relation'] not in RELATIONS or identity['relation']=='UNKNOWN_RELATION':block('BLOCK_SECURITY_IDENTITY')
    if identity['previous_security']!=(p['security_id'] if p else None) or identity['current_security']!=(c['security_id'] if c else None):block('BLOCK_SECURITY_IDENTITY')
    if p and c:
        if p['instrument_type']!=c['instrument_type'] or p['put_call']!=c['put_call']:block('BLOCK_SECURITY_IDENTITY')
        if p['security_id']!=c['security_id'] and identity['relation'] not in ['SUCCESSOR_OF','CLASS_CONVERSION']:block('BLOCK_SECURITY_IDENTITY')
        if p['security_id']==c['security_id'] and identity['relation'] not in ['SAME_SECURITY','ISSUER_SAME_SECURITY_DIFFERENT_TICKER']:block('BLOCK_SECURITY_IDENTITY')
        if p['security_class']!=c['security_class'] and identity.get('class_equivalence_verified') is not True:block('BLOCK_SECURITY_CLASS_CHANGE')
        if identity.get('one_to_one') is not True:block('BLOCK_SECURITY_IDENTITY')
    action=x['corporate_actions'];coverage=action['coverage']
    if not verified(coverage) or coverage['start']!=x['previous_quarter'] or coverage['end']!=x['current_quarter'] or coverage['security_ids']!=sorted(set(h['security_id'] for h in present)):block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
    if set(coverage.get('checks',{}))!=set(ACTION_CHECKS) or any(v not in ['CLEAR','ADJUSTED'] for v in coverage.get('checks',{}).values()):block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
    if coverage.get('issuer_id') is None or any(h['issuer_id']!=coverage.get('issuer_id') for h in present):block('BLOCK_SECURITY_IDENTITY')
    factor=Fraction(1);ids=set();adjusted=set();adjustment_events=0
    for event in action['events']:
        if not verified(event) or event['event_id'] in ids or event['action_type'] not in ACTION_TYPES:block('BLOCK_CORPORATE_ACTION_UNRESOLVED');continue
        ids.add(event['event_id']);typ=event['action_type'];date.fromisoformat(event['effective_date'])
        if not x['previous_quarter']<event['effective_date']<=x['current_quarter']:block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
        if not set(h['security_id'] for h in present).intersection(event['affected_security_ids']):block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
        if event['issuer_id'] is None or any(h['issuer_id']!=event['issuer_id'] for h in present):block('BLOCK_SECURITY_IDENTITY')
        if typ in ['MERGER','SPINOFF','REORGANIZATION']:block('BLOCK_CORPORATE_ACTION_UNRESOLVED');continue
        if any(type(event['ratio'][k]) is not int for k in ['numerator','denominator']):raise ValueError('Ratio components must be integers')
        ratio=Fraction(event['ratio']['numerator'],event['ratio']['denominator'])
        if ratio<=0 or ratio>1000000:block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
        if typ in ['SPLIT','REVERSE_SPLIT','CONVERSION','SHARE_CLASS_CHANGE','CUSIP_CHANGE']:
            if p is None or c is None or event['predecessor_security']!=p['security_id'] or event['successor_security']!=c['security_id']:block('BLOCK_SECURITY_IDENTITY')
            if event.get('one_to_one') is not True or event.get('rounding_policy')!='EXACT_NO_CASH_IN_LIEU':block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
            if typ=='SPLIT' and ratio<=1 or typ=='REVERSE_SPLIT' and ratio>=1:block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
            factor*=ratio;adjusted.add(typ);adjustment_events+=1
        elif ratio!=1 or event.get('effect_on_existing_units')!='NONE':block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
    if adjustment_events>1 or any(coverage.get('checks',{}).get(k)!='ADJUSTED' for k in adjusted):block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
    if any(v=='ADJUSTED' and k not in adjusted for k,v in coverage.get('checks',{}).items()):block('BLOCK_CORPORATE_ACTION_UNRESOLVED')
    if p and c and p['security_id']!=c['security_id'] and not adjusted.intersection(['CONVERSION','SHARE_CLASS_CHANGE','CUSIP_CHANGE']):block('BLOCK_SECURITY_IDENTITY')
    normalized=Fraction(str(p['quantity']))*factor if p and re.fullmatch(r'\d+(\.\d+)?',str(p['quantity'])) else None
    if normalized is not None and factor!=1 and normalized.denominator!=1:block('BLOCK_FRACTIONAL_ENTITLEMENT')
    presence=p is None or c is None
    if presence:
        absence=x.get('presence_evidence',{})
        if not verified(absence) or set(absence.get('checks',{}))!=set(PRESENCE_CHECKS) or any(v!='CLEAR' for v in absence.get('checks',{}).values()) or absence.get('absent_side')!=('previous' if p is None else 'current') or absence.get('complete_security_search') is not True or absence.get('no_transformation') is not True:block('BLOCK_PRESENCE_TRANSITION_UNVERIFIED')
        if factor!=1 or adjusted:block('BLOCK_PRESENCE_TRANSITION_UNVERIFIED')
    refs=sorted({(r['url'],r['sha256']) for r in refs})
    output={'movement_status':'INDETERMINATE','qualification_tier':'UNQUALIFIED','confidence':'INSUFFICIENT','reason_code':blockers[0] if blockers else '', 'blockers':blockers,'evidence_refs':[{'url':u,'sha256':h} for u,h in refs],'normalized_previous_quantity':str(normalized) if normalized is not None else None}
    structural={'BLOCK_MANAGER_PERIMETER_CHANGE','BLOCK_AMBIGUOUS_AMENDMENT','BLOCK_FILING_UNAVAILABLE','BLOCK_NOTICE_OR_INCLUDED_REPORT','BLOCK_DUPLICATE_REPORTING_GROUP','BLOCK_OPTIONS_OR_PRINCIPAL'}
    human={'BLOCK_CONFIDENTIALITY','BLOCK_MANAGER_PERIMETER_UNPROVEN','BLOCK_SECURITY_CLASS_CHANGE','BLOCK_AMENDMENT_COMPOSITION','BLOCK_EVIDENCE_BINDING','BLOCK_HOLDING_SCOPE','BLOCK_NONCONSECUTIVE_QUARTERS','BLOCK_QUANTITY_UNUSABLE'}
    if blockers:
        output['resolution_bucket']='STRUCTURALLY_BLOCKED' if structural.intersection(blockers) else 'HUMAN_REVIEW_REQUIRED' if human.intersection(blockers) else 'EVIDENCE_RESOLVABLE'
        return output
    state='NEW' if p is None else 'EXITED' if c is None else 'INCREASED' if Fraction(str(c['quantity']))>normalized else 'REDUCED' if Fraction(str(c['quantity']))<normalized else 'UNCHANGED'
    code={'INCREASED':'AUTO_SAME_SECURITY_QUANTITY_UP','REDUCED':'AUTO_SAME_SECURITY_QUANTITY_DOWN','UNCHANGED':'AUTO_SAME_SECURITY_UNCHANGED','NEW':'VERIFIED_PRESENCE_NEW','EXITED':'VERIFIED_PRESENCE_EXIT'}[state]
    tier='TIER_B_PRESENCE_TRANSITION' if presence else 'TIER_C_ACTION_NORMALIZED' if adjusted else 'TIER_A_AUTO_SAFE'
    if adjusted:code='VERIFIED_ACTION_NORMALIZED_'+state
    output.update(movement_status=state,qualification_tier=tier,confidence='PROVEN',reason_code=code,resolution_bucket='EVIDENCE_RESOLVED' if tier!='TIER_A_AUTO_SAFE' else 'AUTO_RESOLVABLE')
    return output

"""Synthetic adversarial fixtures exercise rules, not claims about actual SEC holdings."""
import copy
import unittest
from resolver import resolve, binding, ACTION_CHECKS, PRESENCE_CHECKS

URL='https://www.sec.gov/Archives/edgar/data/1/000000000126000001/fixture.txt'
REF={'url':URL,'sha256':'a'*64}

def claim(**kwargs):return {**kwargs,'verification_status':'VERIFIED','evidence_refs':[REF.copy()]}
def rebind(x):
    sig=binding(x)
    def visit(v):
        if isinstance(v,dict):
            if 'verification_status' in v:v['binding']=sig
            for k,a in list(v.items()):
                if k!='binding':visit(a)
        elif isinstance(v,list):
            for a in v:visit(a)
    visit(x);return x

def fixture():
    x={'manager_id':'fixture-manager','manager_group_id':'fixture-group','previous_quarter':'2026-03-31','current_quarter':'2026-06-30','filings':{},'amendments':{},'source_hashes':{URL:'a'*64}}
    for side,accession in [('previous','0000000001-26-000001'),('current','0000000001-26-000002')]:
        x[side]={'manager_id':x['manager_id'],'manager_group_id':x['manager_group_id'],'quarter':x[side+'_quarter'],'security_id':'000000001|LONG|SH','CUSIP':'000000001','issuer_id':'fixture-issuer','instrument_type':'SH','put_call':None,'security_class':'COM','quantity':'100','source_accessions':[accession]}
        x['filings'][side]=claim(status='USABLE',authoritative=True,complete=True,confidential=False,notice_or_included=False,duplicate_economic_group=False,accessions=[accession],selected_accessions=[accession])
        x['amendments'][side]=claim(state='NONE',composition_verified=True,selected_accessions=[accession])
    x['perimeter']=claim(equivalent='YES')
    x['continuity']=claim(relation='SAME_SECURITY',previous_security=x['previous']['security_id'],current_security=x['current']['security_id'],one_to_one=True,class_equivalence_verified=True)
    x['corporate_actions']={'coverage':claim(issuer_id='fixture-issuer',start=x['previous_quarter'],end=x['current_quarter'],security_ids=[x['current']['security_id']],checks={k:'CLEAR' for k in ACTION_CHECKS}),'events':[]}
    x['presence_evidence']=claim(checks={k:'CLEAR' for k in PRESENCE_CHECKS},complete_security_search=True,no_transformation=True,absent_side=None)
    return rebind(x)

def event(x,typ,n=1,d=1):
    e=claim(event_id='fixture-event',issuer_id='fixture-issuer',action_type=typ,effective_date='2026-05-01',ratio={'numerator':n,'denominator':d},affected_security_ids=sorted({h['security_id'] for h in [x['previous'],x['current']] if h}),predecessor_security=x['previous']['security_id'] if x['previous'] else None,successor_security=x['current']['security_id'] if x['current'] else None,one_to_one=True,rounding_policy='EXACT_NO_CASH_IN_LIEU',effect_on_existing_units='NONE')
    x['corporate_actions']['events']=[e]
    if typ in ['SPLIT','REVERSE_SPLIT','CONVERSION','CUSIP_CHANGE','SHARE_CLASS_CHANGE']:x['corporate_actions']['coverage']['checks'][typ]='ADJUSTED'
    return e

def migration(x,typ='CUSIP_CHANGE'):
    x['current'].update(CUSIP='000000002',security_id='000000002|LONG|SH')
    x['continuity'].update(relation='SUCCESSOR_OF',current_security=x['current']['security_id'])
    x['corporate_actions']['coverage']['security_ids']=sorted([x['previous']['security_id'],x['current']['security_id']])
    return event(x,typ)

def absent(x,side):
    x[side]=None;x['continuity'][side+'_security']=None;x['presence_evidence']['absent_side']=side
    return x

class ResolverTests(unittest.TestCase):
    def result(self,x):return resolve(rebind(x))
    def blocked(self,x,code=None):
        r=self.result(x);self.assertEqual(r['movement_status'],'INDETERMINATE',r)
        if code:self.assertIn(code,r['blockers'])
    def test_same_quantity(self):self.assertEqual(self.result(fixture())['movement_status'],'UNCHANGED')
    def test_increase(self):
        x=fixture();x['current']['quantity']='101';self.assertEqual(self.result(x)['movement_status'],'INCREASED')
    def test_decrease(self):
        x=fixture();x['current']['quantity']='99';self.assertEqual(self.result(x)['movement_status'],'REDUCED')
    def test_split_normalizes_no_false_increase(self):
        x=fixture();x['current']['quantity']='300';event(x,'SPLIT',3);self.assertEqual(self.result(x)['movement_status'],'UNCHANGED')
    def test_reverse_split(self):
        x=fixture();x['current']['quantity']='50';event(x,'REVERSE_SPLIT',1,2);self.assertEqual(self.result(x)['movement_status'],'UNCHANGED')
    def test_fractional_reverse_split_blocks(self):
        x=fixture();x['previous']['quantity']='101';event(x,'REVERSE_SPLIT',1,2);self.blocked(x,'BLOCK_FRACTIONAL_ENTITLEMENT')
    def test_CUSIP_migration_qualified_as_continuity(self):
        x=fixture();migration(x);self.assertEqual(self.result(x)['movement_status'],'UNCHANGED')
    def test_CUSIP_change_without_event_blocks(self):
        x=fixture();migration(x);x['corporate_actions']['events']=[];self.blocked(x,'BLOCK_SECURITY_IDENTITY')
    def test_ticker_only_change(self):
        x=fixture();x['continuity']['relation']='ISSUER_SAME_SECURITY_DIFFERENT_TICKER';event(x,'TICKER_CHANGE');self.assertEqual(self.result(x)['movement_status'],'UNCHANGED')
    def test_share_class_unverified_blocks(self):
        x=fixture();x['current']['security_class']='PREFERRED';x['continuity']['class_equivalence_verified']=False;self.blocked(x,'BLOCK_SECURITY_CLASS_CHANGE')
    def test_verified_share_class_conversion(self):
        x=fixture();x['current']['security_class']='NEW COM';x['continuity']['relation']='CLASS_CONVERSION';migration(x,'SHARE_CLASS_CHANGE');self.assertEqual(self.result(x)['movement_status'],'UNCHANGED')
    def test_merger_blocks_even_with_ratio(self):
        x=fixture();event(x,'MERGER');self.blocked(x,'BLOCK_CORPORATE_ACTION_UNRESOLVED')
    def test_spinoff_blocks(self):
        x=fixture();event(x,'SPINOFF');self.blocked(x,'BLOCK_CORPORATE_ACTION_UNRESOLVED')
    def test_restatement_substitution(self):
        x=fixture();x['filings']['current']['accessions'].insert(0,'0000000001-26-000000');x['amendments']['current']['state']='RESTATEMENT';self.assertEqual(self.result(x)['movement_status'],'UNCHANGED')
    def test_additive_composition(self):
        x=fixture();a='0000000001-26-000003';x['filings']['current']['accessions'].append(a);x['filings']['current']['selected_accessions'].append(a);x['amendments']['current'].update(state='ADDITIVE_CONFIRMED',selected_accessions=x['filings']['current']['selected_accessions'].copy());x['current']['source_accessions'].append(a);self.assertEqual(self.result(x)['movement_status'],'UNCHANGED')
    def test_unconfirmed_additive_blocks(self):
        x=fixture();x['amendments']['current']['state']='NEW_HOLDINGS';self.blocked(x,'BLOCK_AMENDMENT_COMPOSITION')
    def test_non_holdings_amendment_blocks(self):
        x=fixture();x['amendments']['current']['state']='NON_HOLDINGS_AMENDMENT';self.blocked(x,'BLOCK_AMENDMENT_COMPOSITION')
    def test_ambiguous_amendment_blocks(self):
        x=fixture();x['amendments']['current']['state']='AMBIGUOUS';self.blocked(x,'BLOCK_AMBIGUOUS_AMENDMENT')
    def test_previous_filing_missing_blocks_fake_NEW(self):
        x=absent(fixture(),'previous');x['filings']['previous']['status']='UNUSABLE';self.blocked(x,'BLOCK_FILING_UNAVAILABLE')
    def test_perimeter_change_blocks_arithmetic(self):
        x=fixture();x['perimeter']['equivalent']='NO';x['current']['quantity']='200';self.blocked(x,'BLOCK_MANAGER_PERIMETER_CHANGE')
    def test_nt_included_report_blocks(self):
        x=fixture();x['filings']['previous']['notice_or_included']=True;self.blocked(x,'BLOCK_NOTICE_OR_INCLUDED_REPORT')
    def test_previous_only_unresolved(self):
        x=absent(fixture(),'current');x['presence_evidence']['checks']={};self.blocked(x,'BLOCK_PRESENCE_TRANSITION_UNVERIFIED')
    def test_current_only_unresolved(self):
        x=absent(fixture(),'previous');x['presence_evidence']['checks']={};self.blocked(x,'BLOCK_PRESENCE_TRANSITION_UNVERIFIED')
    def test_verified_NEW(self):self.assertEqual(self.result(absent(fixture(),'previous'))['movement_status'],'NEW')
    def test_verified_EXIT(self):self.assertEqual(self.result(absent(fixture(),'current'))['movement_status'],'EXITED')
    def test_each_presence_guard_required(self):
        for side in ['previous','current']:
            for check in PRESENCE_CHECKS:
                with self.subTest(side=side,check=check):
                    x=absent(fixture(),side);x['presence_evidence']['checks'][check]='UNRESOLVED';self.blocked(x,'BLOCK_PRESENCE_TRANSITION_UNVERIFIED')
    def test_fake_EXIT_CUSIP_replacement(self):
        x=fixture();migration(x);absent(x,'current');self.blocked(x)
    def test_fake_NEW_spinoff(self):
        x=absent(fixture(),'previous');event(x,'SPINOFF');self.blocked(x,'BLOCK_CORPORATE_ACTION_UNRESOLVED')
    def test_duplicate_group(self):
        x=fixture();x['filings']['current']['duplicate_economic_group']=True;self.blocked(x,'BLOCK_DUPLICATE_REPORTING_GROUP')
    def test_amendment_double_count(self):
        x=fixture();x['filings']['current']['selected_accessions']*=2;x['amendments']['current']['selected_accessions']*=2;self.blocked(x,'BLOCK_AMENDMENT_COMPOSITION')
    def test_issuer_union_is_not_security(self):
        x=fixture();x['current'].update(CUSIP='000000002',security_id='000000002|LONG|SH');x['continuity']['current_security']=x['current']['security_id'];self.blocked(x,'BLOCK_SECURITY_IDENTITY')
    def test_stale_quantity_review(self):
        x=fixture();x['current']['quantity']='500';self.assertIn('BLOCK_EVIDENCE_BINDING',resolve(x)['blockers'])
    def test_missing_action_coverage_never_means_no_action(self):
        x=fixture();x['corporate_actions']['coverage']['verification_status']='UNVERIFIED';self.blocked(x,'BLOCK_CORPORATE_ACTION_UNRESOLVED')
    def test_stale_period_coverage(self):
        x=fixture();x['corporate_actions']['coverage']['start']='2025-12-31';self.blocked(x,'BLOCK_CORPORATE_ACTION_UNRESOLVED')
    def test_unknown_confidentiality(self):
        x=fixture();x['filings']['previous']['confidential']=None;self.blocked(x,'BLOCK_CONFIDENTIALITY')
    def test_options_and_principal_are_separate(self):
        for instrument,option in [('PRN',None),('SH','PUT'),('SH','CALL')]:
            x=fixture();x['current']['instrument_type']=instrument;x['current']['put_call']=option;self.blocked(x,'BLOCK_OPTIONS_OR_PRINCIPAL')
    def test_duplicate_event(self):
        x=fixture();e=event(x,'SPLIT',2);x['corporate_actions']['events'].append(copy.deepcopy(e));self.blocked(x,'BLOCK_CORPORATE_ACTION_UNRESOLVED')
    def test_foreign_event(self):
        x=fixture();e=event(x,'SPLIT',2);e['issuer_id']='unrelated';self.blocked(x,'BLOCK_SECURITY_IDENTITY')
    def test_invalid_ratio(self):
        x=fixture();event(x,'SPLIT',0);self.blocked(x,'BLOCK_CORPORATE_ACTION_UNRESOLVED')
    def test_negative_nan_quantities(self):
        for q in ['NaN','Infinity','-1',True]:
            x=fixture();x['current']['quantity']=q;self.blocked(x,'BLOCK_QUANTITY_UNUSABLE')
    def test_no_float_epsilon(self):
        x=fixture();x['current']['quantity']='100.00000000000000000001';self.assertEqual(self.result(x)['movement_status'],'INCREASED')
    def test_wrong_holding_manager(self):
        x=fixture();x['current']['manager_id']='different';self.blocked(x,'BLOCK_HOLDING_SCOPE')
    def test_nonconsecutive_period(self):
        x=fixture();x['current_quarter']='2026-09-30';self.blocked(x,'BLOCK_NONCONSECUTIVE_QUARTERS')
    def test_unretained_evidence(self):
        x=fixture();x['source_hashes']={};self.blocked(x,'BLOCK_EVIDENCE_BINDING')
    def test_malformed_fails_closed(self):self.assertEqual(resolve({})['movement_status'],'INDETERMINATE')
    def test_distinct_ids_cannot_double_apply_split(self):
        x=fixture();e=event(x,'SPLIT',2);e2=copy.deepcopy(e);e2['event_id']='different-id';x['corporate_actions']['events'].append(e2);self.blocked(x,'BLOCK_CORPORATE_ACTION_UNRESOLVED')
    def test_adjustment_conflicts_with_clearance(self):
        x=fixture();event(x,'SPLIT',2);x['corporate_actions']['coverage']['checks']['SPLIT']='CLEAR';self.blocked(x,'BLOCK_CORPORATE_ACTION_UNRESOLVED')
    def test_wrong_issuer_clearance(self):
        x=fixture();x['corporate_actions']['coverage']['issuer_id']='different';self.blocked(x,'BLOCK_SECURITY_IDENTITY')
    def test_string_false_is_not_authoritative(self):
        x=fixture();x['filings']['current']['authoritative']='false';self.blocked(x,'BLOCK_FILING_UNAVAILABLE')
    def test_impossible_action_date(self):
        x=fixture();e=event(x,'SPLIT',2);e['effective_date']='2026-04-31';self.blocked(x,'BLOCK_MALFORMED_INPUT')
    def test_string_false_cannot_certify_absence(self):
        for field in ['complete_security_search','no_transformation']:
            x=absent(fixture(),'current');x['presence_evidence'][field]='false';self.blocked(x,'BLOCK_PRESENCE_TRANSITION_UNVERIFIED')
    def test_string_false_cannot_certify_amendment(self):
        x=fixture();x['amendments']['current']['composition_verified']='false';self.blocked(x,'BLOCK_AMENDMENT_COMPOSITION')
    def test_malformed_nested_claim_returns_indeterminate(self):
        x=fixture();x['continuity']=None;self.assertEqual(resolve(x)['movement_status'],'INDETERMINATE')
    def test_deterministic_pure(self):
        x=fixture();before=copy.deepcopy(x);a=resolve(x);self.assertEqual(a,resolve(x));self.assertEqual(x,before)

if __name__=='__main__':unittest.main()

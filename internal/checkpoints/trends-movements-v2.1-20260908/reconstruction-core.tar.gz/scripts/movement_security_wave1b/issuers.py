"""Exact official-name research grouping, with separate and non-fuzzy issuer CIK evidence."""
from collections import defaultdict,Counter
import re
from common import *
DIRECTORY='https://www.sec.gov/Archives/edgar/cik-lookup-data.txt'
def normalize_name(s):
    # Orthographic normalization only. No suffix expansion, transliteration, token reorder or similarity.
    return ' '.join(re.sub(r'[.,]','',s.upper()).split())
def directory_index():
    index=defaultdict(list)
    for line_number,raw in enumerate(source_bytes(DIRECTORY).decode('utf-8').splitlines(),1):
        m=re.fullmatch(r'(.*):(\d+):',raw)
        if not m:raise ValueError('INVALID_SEC_DIRECTORY_LINE')
        index[normalize_name(m[1])].append({'name':m[1],'cik':int(m[2]),'raw_line':raw,'line_number':line_number})
    return index

def cik_decision(names, records, confirmed=None):
    if len(names)!=1:return {'status':'INDETERMINATE','cik':None,'reason':'QUARTER_NAME_CONTINUITY_UNVERIFIED'}
    ciks=sorted({r['cik'] for r in records})
    if len(ciks)>1:return {'status':'MULTIPLE_CANDIDATES','cik':None,'reason':'EXACT_NAME_DIRECTORY_COLLISION'}
    if not ciks:return {'status':'NO_MATCH','cik':None,'reason':'NO_EXACT_DIRECTORY_NAME_MATCH; NOT_PROOF_NO_CIK_EXISTS'}
    recent=(confirmed or {}).get('filings',{}).get('recent',{})
    period_issuer_filings=any('2026-03-01'<=d<='2026-08-14' and f.startswith(('10-Q','10-K','20-F','40-F','6-K')) for d,f in zip(recent.get('filingDate',[]),recent.get('form',[])))
    if confirmed and period_issuer_filings and int(confirmed['cik'])==ciks[0] and normalize_name(confirmed['name'])==normalize_name(names[0]):
        return {'status':'EXACT_VERIFIED','cik':ciks[0],'reason':'OFFICIAL_LIST_NAME_EQUALS_UNIQUE_SEC_DIRECTORY_NAME_AND_ISSUER_SUBMISSIONS_NAME'}
    return {'status':'INDETERMINATE','cik':None,'reason':'DIRECTORY_CANDIDATE_REQUIRES_CURRENT_ISSUER_CONFIRMATION'}

def packets():
    sys.path.insert(0,str(ROOT/'scripts/movement_evidence_wave1'));from build import load
    a=load(); eligible={r['comparison_id'] for r in baseline() if r['resolution_bucket']=='EVIDENCE_RESOLVABLE'}
    bs={b['security_pair_id']:b for b in read('security-bindings.json')};groups=defaultdict(list)
    for r in a.rows:
        if r['comparison_id'] in eligible:groups[r['security_id']].append(r)
    packets={}
    for sec,rs in sorted(groups.items()):
        b=bs[sec];names=sorted({b['issuer_name_'+q] for q in ['q1','q2'] if b['issuer_name_'+q]})
        # Equal official labels share research work only. Ambiguous/name-changing cases stay security-scoped.
        key=('OFFICIAL_NAME',names[0]) if b['authoritative_period_identity'] else ('UNRESOLVED_SECURITY',sec)
        pid='ISSUER_SECURITY_PERIOD:'+sha(key)[:24]
        if pid not in packets:packets[pid]={'packet_id':pid,'packet_type':'ISSUER_SECURITY_PERIOD_PACKET','official_issuer_names':names,'legal_entity_consolidation_asserted':False,'securities':[],'comparison_ids':[],'manager_ids':[],'filing_rows':[],'period':['2026-03-31','2026-06-30']}
        p=packets[pid];p['securities'].append(b);p['comparison_ids'].extend(r['comparison_id'] for r in rs);p['manager_ids'].extend(r['manager_id'] for r in rs)
        seen=set()
        for r in rs:
            for side in ['previous','current']:
                for u in r[side+'_sources']:
                    for row in a.raw[u]['rows'].get(sec,[]):
                        k=(r['manager_id'],u,row['row_index'])
                        if k in seen:continue
                        seen.add(k);p['filing_rows'].append({'manager_id':r['manager_id'],'quarter':r[side+'_quarter'],'source_url':u,'source_sha256':a.sources[u]['sha256'],'security_id':sec,**row})
    for p in packets.values():
        p['comparison_ids']=sorted(set(p['comparison_ids']));p['manager_ids']=sorted(set(p['manager_ids']))
    write('issuer-security-packets.json',list(packets.values()))

def bind_ciK():
    index=directory_index();packets=read('issuer-security-packets.json');manifest=read('source-manifest.json')
    sys.path.insert(0,str(ROOT/'scripts/movement_evidence_wave1'));from build import load
    a=load();config=json.loads((ROOT/'lib/trends/capital/config.json').read_text());legacy={m['CUSIP']:m for m in config['security_mappings']};bindings=[];pilot=set(read('pilot-security-bindings.json')['security_ids'])
    for p in packets:
        names=p['official_issuer_names'];records=[r for name in names for r in index.get(normalize_name(name),[])];ciks={r['cik'] for r in records};confirmed=None;refs=[{'source_url':DIRECTORY,'sha256':manifest[DIRECTORY]['sha256'],'line_numbers':sorted({r['line_number'] for r in records})}]
        if len(ciks)==1:
            cik=next(iter(ciks));u=f'https://data.sec.gov/submissions/CIK{cik:010d}.json'
            if u in manifest:confirmed=json.loads(source_bytes(u));refs.append({'source_url':u,'sha256':manifest[u]['sha256']})
            elif u in a.sources:confirmed=json.loads(a.sources[u]['body']);refs.append({'source_url':u,'sha256':a.sources[u]['sha256'],'archive':'PRESERVED_WAVE1'})
        result=cik_decision(names,records,confirmed)
        # Preserve the already-reviewed security-specific CIK authority. Never broaden it to sibling securities.
        oldmaps=[legacy.get(b['q1_cusip']) for b in p['securities']]
        if all(oldmaps) and len({m['issuer_id'] for m in oldmaps})==1:
            cik=int(oldmaps[0]['issuer_id'].removeprefix('sec-issuer-'));urls={m['source_url'] for m in oldmaps}
            if all(u in a.sources for u in urls):
                result={'status':'EXACT_VERIFIED','cik':cik,'reason':'PRESERVED_PREVIOUSLY_REVIEWED_EXACT_CUSIP_CLASS_ISSUER_MAPPING; NO_TICKER_INFERENCE'}
                refs.extend({'source_url':u,'sha256':a.sources[u]['sha256'],'archive':'PRESERVED_BASELINE'} for u in sorted(urls))
        bindings.append({'packet_id':p['packet_id'],'official_issuer_names':names,**result,'directory_candidates':records,'source_refs':refs,'in_fixed_pilot':any(b['security_pair_id'] in pilot for b in p['securities'])})
    write('issuer-cik-bindings.json',bindings)
    print(canonical({'packets':len(packets),'official_names':len({n for p in packets for n in p['official_issuer_names']}),'cik_statuses':dict(Counter(b['status'] for b in bindings)),'pilot_cik_statuses':dict(Counter(b['status'] for b in bindings if b['in_fixed_pilot']))}))
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='packets':packets()
    bind_ciK()

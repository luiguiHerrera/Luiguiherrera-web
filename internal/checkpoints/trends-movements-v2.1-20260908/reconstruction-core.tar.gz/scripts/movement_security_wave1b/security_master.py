"""SEC fixed-width list identity. List membership never clears corporate actions."""
from collections import defaultdict, Counter
import re
from common import read, write, source_bytes, sha
URLS={'2026Q1':'https://www.sec.gov/files/investment/13flist2026q1.txt','2026Q2':'https://www.sec.gov/files/investment/13flist2026q2-txt.txt'}

def normalize_cusip(value):
    value=value.strip().upper()
    if not re.fullmatch(r'[A-Z0-9*@#]{9}',value): raise ValueError('INVALID_CUSIP_9')
    return value

def parse_list(body, quarter, meta):
    if quarter not in URLS or meta.get('quarter')!=quarter: raise ValueError('QUARTER_SOURCE_MISMATCH')
    if meta['source_url']!=URLS[quarter] or sha(body)!=meta['sha256']: raise ValueError('SOURCE_MISMATCH')
    result=[];offset=0
    for line_number, line in enumerate(body.splitlines(keepends=True),1):
        raw=line.rstrip(b'\r\n')
        if len(raw)!=80 or any(b<32 or b>126 for b in raw): raise ValueError('INVALID_FIXED_WIDTH_LINE:'+str(line_number))
        s=raw.decode('ascii');cusip=normalize_cusip(s[:9]);option=s[9];status=s[67:70]
        if option not in ['*',' '] or status not in ['   ','*A*','*D*'] or s[70:79]!=' '*9: raise ValueError('INVALID_FIELD_BOUNDARY')
        if not s[10:40].strip() or not s[40:67].strip(): raise ValueError('EMPTY_IDENTITY')
        result.append({'quarter':quarter,'source_url':meta['source_url'],'retrieved_at':meta['retrieved_at'],'source_sha256':meta['sha256'],'raw_line':s,'line_number':line_number,'byte_offset':offset,'line_ending':line[len(raw):].decode('ascii'),'cusip':cusip,'option_indicator':option,'canonical_key':cusip+'|'+option,'issuer_name_official':s[10:40].rstrip(),'issuer_description_official':s[40:67].rstrip(),'status':status.strip(),'misc_unused':s[79]})
        offset+=len(line)
    if offset!=len(body) or not result: raise ValueError('SOURCE_TRUNCATED')
    return result

def index_records(records):
    index=defaultdict(list)
    for r in records:index[r['cusip']].append(r)
    return index

def ref(r):
    return {k:r[k] for k in ['quarter','source_url','source_sha256','line_number','byte_offset','canonical_key','cusip','option_indicator','issuer_name_official','issuer_description_official','status']}

def explicit_class(s):
    m=re.search(r'\bCL(?:ASS)?\s+([A-Z])\b',s.upper())
    return m[1] if m else None

def class_conflict(a,b):
    ca,cb=explicit_class(a),explicit_class(b)
    return bool(ca and cb and ca!=cb)

def bind_quarter(cusip, put_call, instrument, labels, index, quarter):
    candidates=index.get(normalize_cusip(cusip),[])
    unique={r['raw_line']:r for r in candidates}
    if not candidates:return {'state':'NOT_FOUND_'+quarter[-2:],'binding':None,'candidate_rows':[]}
    # Even identical CUSIP/name with contradictory list status stays ambiguous.
    if len(unique)!=1:return {'state':'AMBIGUOUS','binding':None,'candidate_rows':[ref(r) for r in candidates]}
    r=next(iter(unique.values()));description=r['issuer_description_official']
    if description in ['PUT','CALL'] or put_call not in [None,'PUT','CALL'] or (put_call and r['option_indicator']!='*'):
        return {'state':'OPTION_MISMATCH','binding':None,'candidate_rows':[ref(r)]}
    if any(class_conflict(s,description) for s in labels) or (instrument=='PRN' and not description.startswith(('NOTE','DEB','CONV','BOND'))):
        return {'state':'CLASS_CONFLICT','binding':None,'candidate_rows':[ref(r)]}
    return {'state':'EXACT_'+quarter[-2:],'binding':ref(r),'candidate_rows':[ref(x) for x in candidates], 'position_binding_scope':'UNDERLYING_SECURITY_ONLY' if put_call else 'REPORTED_SECURITY', 'raw_class_labels':sorted(set(labels)), 'raw_label_variants_preserved':sorted(s for s in set(labels) if s!=description)}

def bind_pair(sec, rows, indices):
    cusip,position,instrument=sec.split('|');put_call=None if position=='LONG' else position
    result={'security_pair_id':sec,'position_type':position,'instrument_type':instrument,'comparison_ids':sorted(r['comparison_id'] for r in rows)}; quarters={}
    for q,side in [('Q1','previous'),('Q2','current')]:
        observed={r['CUSIP_'+side].upper() for r in rows if r['CUSIP_'+side]}
        if observed-{cusip.upper()}:raise ValueError('CORPUS_CUSIP_CONFLICT')
        labels=sorted({r[side+'_security_class'] for r in rows if r[side+'_security_class']})
        b=bind_quarter(cusip,put_call,instrument,labels,indices['2026'+q],'2026'+q);quarters[q]=b;br=b['binding'];l=q.lower()
        result.update({l+'_cusip':cusip,l+'_official_binding':br,'issuer_name_'+l:br['issuer_name_official'] if br else None,'class_'+l:br['issuer_description_official'] if br else None,'status_'+l:br['status'] if br else None,l+'_binding_detail':b})
    a,b=quarters['Q1'],quarters['Q2'];qa,qb=a['binding'],b['binding']
    conflicts=[s for s in ['AMBIGUOUS','OPTION_MISMATCH','CLASS_CONFLICT'] if s in [a['state'],b['state']]]
    state=conflicts[0] if conflicts else 'EXACT_BOTH' if qa and qb else 'Q1_ONLY' if qa else 'Q2_ONLY' if qb else 'NOT_FOUND_Q1'
    # Official class contradiction across quarters is preserved even with exact identifiers.
    if qa and qb and qa['issuer_description_official']!=qb['issuer_description_official']:state='CLASS_CONFLICT'
    continuity=bool(state=='EXACT_BOTH' and qa['canonical_key']==qb['canonical_key'] and qa['issuer_name_official']==qb['issuer_name_official'] and not qa['status'] and not qb['status'])
    result.update(binding_status=state,missing_quarters=[q for q in ['Q1','Q2'] if quarters[q]['state'].startswith('NOT_FOUND')],authoritative_period_identity=state=='EXACT_BOTH' and qa['issuer_name_official']==qb['issuer_name_official'],continuity_signal='CONTINUITY_CANDIDATE' if continuity else 'TRANSFORMATION_RESEARCH_REQUIRED',corporate_action_state='UNKNOWN',transaction_inference=None)
    return result

def build_masters():
    manifest=read('source-manifest.json');indices={};stats={}
    for quarter,url in URLS.items():
        records=parse_list(source_bytes(url),quarter,manifest[url]);index=index_records(records);indices[quarter]=index
        import gzip
        from common import canonical,OUT
        (OUT/('SEC_13F_SECURITY_MASTER_'+quarter+'.jsonl.gz')).write_bytes(gzip.compress(''.join(canonical(r)+'\n' for r in records).encode(),mtime=0))
        keys=defaultdict(list)
        for r in records:keys[r['canonical_key']].append(r)
        stats[quarter]={'source_sha256':manifest[url]['sha256'],'rows':len(records),'canonical_keys':len(keys),'duplicate_keys':sum(len(v)>1 for v in keys.values()),'conflicting_keys':sum(len({r['raw_line'] for r in v})>1 for v in keys.values()),'status_counts':dict(Counter(r['status'] or 'UNCHANGED_LIST_STATUS' for r in records))}
    write('security-master-stats.json',stats);return indices

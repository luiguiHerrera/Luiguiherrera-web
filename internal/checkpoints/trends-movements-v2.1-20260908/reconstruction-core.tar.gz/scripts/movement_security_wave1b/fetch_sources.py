"""Explicit SEC-only retrieval with original response bytes and immutable source versions."""
import argparse, datetime, time, urllib.request, urllib.parse
from common import OUT, read, write, sha, source_bytes
UA='LHI Trends research (https://www.luiguiherrera.com)'
def fetch(url, purpose, quarter=None):
    u=urllib.parse.urlparse(url)
    if u.scheme!='https' or u.hostname not in {'www.sec.gov','data.sec.gov'}: raise ValueError('NON_SEC_SOURCE')
    manifest=read('source-manifest.json') if (OUT/'source-manifest.json').exists() else {}
    if url in manifest: source_bytes(url); return manifest[url]
    req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept-Encoding':'identity'})
    with urllib.request.urlopen(req,timeout=25) as res:
        if urllib.parse.urlparse(res.url).hostname not in {'www.sec.gov','data.sec.gov'}: raise ValueError('NON_SEC_REDIRECT')
        b=res.read(); ct=res.headers.get('Content-Type'); final=res.url
    if not b or b'Your Request Originates from an Undeclared Automated Tool' in b: raise ValueError('SEC_BLOCK_PAGE')
    h=sha(b); p='sources/'+h+'.raw'; (OUT/p).write_bytes(b)
    r={'source_url':url,'final_url':final,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':h,'bytes':len(b),'path':p,'content_type':ct,'purpose':purpose,'quarter':quarter}
    manifest[url]=r; write('source-manifest.json',manifest);time.sleep(.2);return r
if __name__=='__main__':
    import json
    p=argparse.ArgumentParser();p.add_argument('url');p.add_argument('--purpose',required=True);p.add_argument('--quarter');a=p.parse_args();print(json.dumps(fetch(a.url,a.purpose,a.quarter)))

"""Internal, immutable Wave 1B evidence workspace; never writes public holdings."""
from pathlib import Path
import hashlib, json, gzip, sys
ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'internal/trends-movements/wave1b'
OLD = ROOT / 'internal/trends-movements/wave1'
BASE = ROOT / 'internal/trends-movements/v2.1'
def canonical(x): return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
def sha(x): return hashlib.sha256(x if isinstance(x, bytes) else canonical(x).encode()).hexdigest()
def read(name): return json.loads((OUT / name).read_text())
def write(name, x): (OUT / name).write_text(canonical(x) + '\n')
def old(name): return json.loads((OLD / name).read_text())
def corpus(): return [json.loads(l) for l in gzip.decompress((BASE/'corpus.jsonl.gz').read_bytes()).splitlines()]
def baseline(): return [json.loads(l) for l in gzip.decompress((BASE/'qualification-results.jsonl.gz').read_bytes()).splitlines()]
def source_bytes(url):
    r=read('source-manifest.json')[url]; b=(OUT/r['path']).read_bytes()
    if r.get('storage_encoding')=='gzip':b=gzip.decompress(b)
    elif r.get('storage_encoding') is not None:raise ValueError('UNKNOWN_STORAGE_ENCODING')
    if sha(b)!=r['sha256']: raise ValueError('SOURCE_HASH_MISMATCH')
    return b

"""Two explicit identity stages: fixed pilot first, full corpus only after review."""
from collections import defaultdict,Counter
from common import *
from security_master import build_masters,bind_pair

def grouping():
    rows=corpus();d=defaultdict(list)
    for r in rows:d[r['security_id']].append(r)
    return rows,d

def pilot():
    indices=build_masters();rows,groups=grouping();selection=old('pilot-selection.json');ids=set(selection['comparison_ids']);secs=sorted({r['security_id'] for r in rows if r['comparison_id'] in ids})
    assert len(ids)==501 and len(secs)==66
    result=[bind_pair(sec,groups[sec],indices) for sec in secs]
    write('pilot-security-bindings.json',{'selection_sha256':sha(selection),'security_ids':secs,'binding_counts':dict(Counter(r['binding_status'] for r in result)),'bindings':result})
    print(canonical({'phase':'PILOT_IDENTITY_ONLY','counts':dict(Counter(r['binding_status'] for r in result))}))

def expand_identity():
    p=read('pilot-security-bindings.json');review=read('pilot-security-manual-review.json')
    assert review['pilot_sha256']==sha(p) and review['false_positives']==0 and review['status']=='PASS'
    assert len(review['reviewed_securities'])>=12 and review['raw_13f_reviewed'] is True
    indices=build_masters();rows,groups=grouping();bindings=[bind_pair(sec,rs,indices) for sec,rs in sorted(groups.items())]
    eligible={r['comparison_id'] for r in baseline() if r['resolution_bucket']=='EVIDENCE_RESOLVABLE'};wave={r['security_id'] for r in rows if r['comparison_id'] in eligible};unknown={r['security_id'] for r in rows if r['comparison_id'] in eligible and not r['issuer_id']};assert len(wave)==2555 and len(unknown)==2543
    added=[b['security_pair_id'] for b in bindings if b['security_pair_id'] in unknown and b['authoritative_period_identity']]
    write('security-bindings.json',bindings)
    stats={'corpus_securities':len(bindings),'corpus_statuses':dict(Counter(b['binding_status'] for b in bindings)),'wave1_statuses':dict(Counter(b['binding_status'] for b in bindings if b['security_pair_id'] in wave)),'unknown_before':len(unknown),'authoritative_bindings_added':len(added),'unknown_after':len(unknown)-len(added),'binding_rate':len(added)/len(unknown),'binding_rate_denominator':2543,'authoritative_period_security_ids_added':added,'movement_resolutions_authorized':False,'CIK_binding_inferred':False}
    write('binding-metrics.json',stats);print(canonical({k:v for k,v in stats.items() if k!='authoritative_period_security_ids_added'}))
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['pilot','full']);args=p.parse_args();pilot() if args.phase=='pilot' else expand_identity()

"""Run the recorded fixed-pilot retrieval plan, preserving failures and complete submission bytes."""
from common import *
from fetch_sources import fetch
import datetime
if __name__=='__main__':
    results=[]
    for i,e in enumerate(read('event-retrieval-plan.json')['entries'],1):
        u=e['complete_submission_url']
        try:
            r=fetch(u,'FIXED_PILOT_COMPLETE_ISSUER_SUBMISSION_WITH_FILED_EXHIBITS');result={'url':u,'issuer_cik':e['issuer_cik'],'status':'RETAINED','sha256':r['sha256'],'bytes':r['bytes']}
        except Exception as ex:result={'url':u,'issuer_cik':e['issuer_cik'],'status':'FETCH_FAILED','error':type(ex).__name__+': '+str(ex),'attempted_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        results.append(result);write('event-retrieval-results.json',results)
        if i%20==0 or result['status']=='FETCH_FAILED':print(canonical({'completed':i,'total':527,'last':result}),flush=True)

import unittest
from copy import deepcopy
from common import sha
from inventory import inventory_for,relevant,MINIMUM_FORMS,START,END
from events import *
from test_security_master import pair
ASOF='2026-09-07T00:00:00+00:00';URL='https://www.sec.gov/Archives/edgar/data/1/000000000126000001/doc.htm';HASH='a'*64

def fixture():
    b=pair();c={'status':'EXACT_VERIFIED','cik':1,'source_refs':[{'source_url':URL,'sha256':HASH}]};i={'index_ref':{'source_url':URL,'sha256':HASH},'issuer_cik':1,'index_complete':True,'disclosure_window':[START,END],'minimum_forms_considered':sorted(MINIMUM_FORMS),'entries':[{'complete_submission_ref':{'source_url':URL,'sha256':HASH}}]};d={'inventory_sha256':sha(i),'all_inventory_documents_parsed':True,'candidates':[]}
    r={'security_id':b['security_pair_id'],'evidence_as_of':ASOF,'evidence_fingerprint':evidence_fingerprint(b,c,i,d),'candidate_reviews':[],'primary_sections_reviewed':['Q1/Q2 equity footnotes and full exhibits'], 'events':[]}
    for flag in ['start_and_end_class_terms_reviewed','equity_rollforward_reviewed','all_filing_text_and_exhibits_reviewed','incorporated_prior_terms_closed','quantity_changing_events_checked','conflicts_resolved','all_list_anomalies_resolved']:r[flag]=True
    catalog={URL:HASH,**{b[q+'_official_binding']['source_url']:b[q+'_official_binding']['source_sha256'] for q in ['q1','q2']}}
    return b,c,i,d,r,catalog

def event(kind='SPLIT',n=2,den=1):
    return {'event_id':'fixture-event','issuer_cik':1,'security_before':['02079K305|LONG|SH'],'security_after':['02079K305|LONG|SH'],'effective_date':'2026-05-01','ratio_or_terms':{'basis':'EXPLICIT_PRIMARY_RATIO','numerator':n,'denominator':den,'fractional_share_treatment_verified':True},'event_type':kind,'source_accessions':['0000000001-26-000001'],'source_sections':['Explicit effective terms'],'source_refs':[{'source_url':URL,'sha256':HASH}],'verification_status':'VERIFIED_PRIMARY','evidence_as_of':ASOF}
class EventTests(unittest.TestCase):
    def call(self,x):return coverage(*x,ASOF)
    def test_all_minimum_forms(self):
        for form in MINIMUM_FORMS:self.assertTrue(relevant(form))
    def test_linked_form_families(self):
        for form in ['S-4/A','425','424B3','6-K','F-4','SC TO-I','DEFA14A']:self.assertTrue(relevant(form))
    def test_inventory_missing_partition(self):
        rec={'accessionNumber':[],'form':[],'filingDate':[],'primaryDocument':[]};doc={'cik':1,'name':'A','filings':{'recent':rec,'files':[{'name':'page.json','filingFrom':START,'filingTo':END}]}}
        self.assertFalse(inventory_for(1,doc,lambda u:(None,None))['index_complete'])
    def test_inventory_includes_s4_425(self):
        rec={'accessionNumber':['a','b','c'],'form':['S-4','425','8-K'],'filingDate':['2026-04-01','2026-08-14','2026-08-15'],'primaryDocument':['a.htm','b.htm','c.htm']};doc={'cik':1,'name':'A','filings':{'recent':rec,'files':[]}};r=inventory_for(1,doc,lambda u:(None,None));self.assertEqual([e['form'] for e in r['entries']],['S-4','425'])
    def test_quantity_event_variants(self):
        for s in ['reverse split','10-for-1 split','stock dividend','share dividend','reorganization']:
            self.assertGreater(len(detect(s,'a','a.htm')),0)
    def test_detector_is_candidate(self):self.assertEqual(detect('We approved a stock split.','a','a.htm')[0]['verification_status'],'CANDIDATE_ONLY')
    def test_detector_forms_separated(self):self.assertNotEqual(detect('split conversion','a','x')[0]['candidate_id'],detect('split conversion','b','x')[0]['candidate_id'])
    def test_coverage_success(self):self.assertEqual(self.call(fixture())['corporate_action_state'],'VERIFIED_CLEAR_FOR_COMPARABILITY')
    def test_coverage_no_review(self):
        b,c,i,d,r,h=fixture();self.assertEqual(coverage(b,c,i,d,None,h,ASOF)['corporate_action_state'],'UNKNOWN')
    def test_missing_s4_blocks(self):
        x=list(fixture());x[2]['minimum_forms_considered'].remove('S-4');self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_missing_document_blocks(self):
        x=list(fixture());x[2]['entries'][0]['complete_submission_ref']=None;self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_same_cusip_split_not_clear(self):
        x=list(fixture());x[3]['candidates']=detect('2-for-1 stock split','a','a.htm');self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_no_keyword_is_not_negative_proof(self):
        x=list(fixture());x[4]['equity_rollforward_reviewed']=False;self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_boolean_strings_fail(self):
        x=list(fixture());x[4]['incorporated_prior_terms_closed']='true';self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_stale_evidence(self):
        x=list(fixture());x[4]['evidence_as_of']='2026-08-01';self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_wrong_quarter_list(self):
        x=list(fixture());x[0]['q2_official_binding']['quarter']='2026Q1';self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_cik_ambiguity_blocks(self):
        x=list(fixture());x[1]['status']='MULTIPLE_CANDIDATES';self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_split_explicit(self):
        r=normalize_quantities(100,210,[event()],1,'02079K305|LONG|SH',ASOF,{URL:HASH});self.assertEqual(r['normalized_previous_quantity'],'200');self.assertEqual(r['reported_status'],'REPORTED_INCREASED')
    def test_reverse_split(self):
        r=normalize_quantities(100,9,[event('REVERSE_SPLIT',1,10)],1,'02079K305|LONG|SH',ASOF,{URL:HASH});self.assertEqual(r['normalized_previous_quantity'],'10');self.assertEqual(r['reported_status'],'REPORTED_REDUCED')
    def test_outside_event(self):
        e=event();e['effective_date']='2026-07-01'
        with self.assertRaises(ValueError):normalize_quantities(100,200,[e],1,'02079K305|LONG|SH',ASOF,{URL:HASH})
    def test_other_class_event(self):
        with self.assertRaises(ValueError):normalize_quantities(100,200,[event()],1,'02079K107|LONG|SH',ASOF,{URL:HASH})
    def test_inferred_ratio_rejected(self):
        e=event();e['ratio_or_terms']['basis']='INFERRED_HOLDINGS'
        with self.assertRaises(ValueError):normalize_quantities(100,200,[e],1,'02079K305|LONG|SH',ASOF,{URL:HASH})
    def test_fractional_reverse_split(self):
        with self.assertRaises(ValueError):normalize_quantities(99,9,[event('REVERSE_SPLIT',1,10)],1,'02079K305|LONG|SH',ASOF,{URL:HASH})
    def test_candidate_not_usable_event(self):
        e=event();e['verification_status']='CANDIDATE_ONLY'
        with self.assertRaises(ValueError):normalize_quantities(100,200,[e],1,'02079K305|LONG|SH',ASOF,{URL:HASH})
    def test_stale_event(self):
        with self.assertRaises(ValueError):normalize_quantities(100,200,[event()],1,'02079K305|LONG|SH','2026-09-08',{URL:HASH})
    def test_wrong_ratio_direction(self):
        with self.assertRaises(ValueError):normalize_quantities(100,200,[event('REVERSE_SPLIT',2,1)],1,'02079K305|LONG|SH',ASOF,{URL:HASH})
    def test_unchanged_reported_not_transaction(self):
        r=normalize_quantities(100,100,[],1,'02079K305|LONG|SH',ASOF,{URL:HASH});self.assertEqual(r['reported_status'],'REPORTED_UNCHANGED');self.assertIsNone(r['transaction_inference'])
    def test_submission_accession_guard(self):
        with self.assertRaises(ValueError):parse_submission(b'ACCESSION NUMBER: wrong','correct')
    def test_submission_parses_exhibit(self):
        b=b'ACCESSION NUMBER: 0000000001-26-000001\n<DOCUMENT><TYPE>8-K\n<FILENAME>a.htm\n<TEXT><p>A stock split</p></TEXT></DOCUMENT><DOCUMENT><TYPE>EX-99\n<FILENAME>x.htm\n<TEXT>explicit terms</TEXT></DOCUMENT>'
        self.assertEqual(len(parse_submission(b,'0000000001-26-000001')),2)
    def test_inline_xbrl_primary_is_text(self):
        b=b'ACCESSION NUMBER: 0000000001-26-000001\n<DOCUMENT><TYPE>10-Q\n<FILENAME>a.htm\n<TEXT><XBRL><html><p>stock split</p></html></XBRL></TEXT></DOCUMENT>'
        d=parse_submission(b,'0000000001-26-000001')[0];self.assertEqual(d['mode'],'TEXT');self.assertEqual(len(detect(d['text'],'a','a.htm')),1)
    def test_unbound_inventory_source(self):
        x=list(fixture());x[2]['entries'][0]['complete_submission_ref']['sha256']='b'*64;self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_unreviewed_binary_exhibit(self):
        x=list(fixture());x[3]['documents']=[{'accession':'a','filename':'terms.pdf','document_block_sha256':'b'*64,'mode':'BINARY_REVIEW_REQUIRED'}];x[4]['evidence_fingerprint']=evidence_fingerprint(*x[:4]);self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_missing_cik_fails_closed(self):
        x=list(fixture());x[1]=None;self.assertEqual(self.call(x)['corporate_action_state'],'UNKNOWN')
    def test_duplicate_split(self):
        with self.assertRaises(ValueError):normalize_quantities(100,400,[event(),event()],1,'02079K305|LONG|SH',ASOF,{URL:HASH})
    def test_boolean_ratio(self):
        e=event();e['ratio_or_terms']['numerator']=True
        with self.assertRaises(ValueError):normalize_quantities(100,100,[e],1,'02079K305|LONG|SH',ASOF,{URL:HASH})
    def test_source_other_issuer(self):
        e=event();e['issuer_cik']=2
        with self.assertRaises(ValueError):normalize_quantities(100,200,[e],2,'02079K305|LONG|SH',ASOF,{URL:HASH})
if __name__=='__main__':unittest.main()

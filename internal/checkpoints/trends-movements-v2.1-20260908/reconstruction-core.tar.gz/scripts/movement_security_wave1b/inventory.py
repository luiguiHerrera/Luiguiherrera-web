"""Whole filing inventories precede detector work; partial text coverage stays explicit."""
from collections import Counter
from common import *
START='2026-03-01'; END='2026-08-14'
MINIMUM_FORMS={'8-K','10-Q','10-K','S-4','S-4/A','424B3','425','DEF 14A','PRE 14A','DEFA14A'}
def relevant(form):
    return form in MINIMUM_FORMS or form.startswith(('8-K','10-Q','10-K','6-K','20-F','40-F','S-','F-','424','425','POS','DEF','PRE','SC TO','SC 13E','CB','1-A','1-U','1-K','1-SA')) or form in {'EFFECT','RW'}
def legacy_sources():
    sys.path.insert(0,str(ROOT/'scripts/movement_evidence_wave1'));from build import load
    a=load();sources=dict(a.sources)
    for u,r in old('issuer-primary-supplement.json')['responses'].items():
        if sha(r['body'].encode())!=r['sha256']:raise ValueError('LEGACY_SOURCE_HASH_MISMATCH')
        sources[u]=r
    return sources

def get_json(url, sources):
    manifest=read('source-manifest.json')
    if url in manifest:return json.loads(source_bytes(url)),{'source_url':url,'sha256':manifest[url]['sha256']}
    if url in sources:
        r=sources[url]
        if sha(r['body'].encode())!=r['sha256']:raise ValueError('LEGACY_SOURCE_HASH_MISMATCH')
        return json.loads(r['body']),{'source_url':url,'sha256':r['sha256'],'archive':'PRESERVED_BASELINE_OR_WAVE1'}
    return None,None

def inventory_for(cik, doc, supplement_lookup):
    if int(doc['cik'])!=cik:raise ValueError('WRONG_ISSUER_CIK')
    groups=[('recent',doc['filings']['recent'])];missing=[];extras=[]
    for f in doc['filings'].get('files',[]):
        # Pagination uses authoritative declared date ranges, never the number of keyword hits.
        if f['filingFrom']<=END and f['filingTo']>=START:
            d,ref=supplement_lookup('https://data.sec.gov/submissions/'+f['name'])
            if d is None:missing.append(f)
            else:groups.append((f['name'],d));extras.append(ref)
    entries={};excluded=Counter();all_count=0
    for source,rec in groups:
        n=len(rec['accessionNumber'])
        for field in ['form','filingDate','primaryDocument']:
            if len(rec[field])!=n:raise ValueError('TRUNCATED_INDEX_ARRAY')
        for i,acc in enumerate(rec['accessionNumber']):
            date=rec['filingDate'][i]
            if not START<=date<=END:continue
            all_count+=1;form=rec['form'][i]
            if not relevant(form):excluded[form]+=1;continue
            e={'accession':acc,'form':form,'filing_date':date,'report_date':rec.get('reportDate',['']*n)[i],'primary_url':f'https://www.sec.gov/Archives/edgar/data/{cik}/{acc.replace("-","")}/{rec["primaryDocument"][i]}','complete_submission_url':f'https://www.sec.gov/Archives/edgar/data/{cik}/{acc.replace("-","")}/{acc}.txt','index_partition':source}
            if acc in entries and {k:v for k,v in entries[acc].items() if k!='index_partition'}!={k:v for k,v in e.items() if k!='index_partition'}:raise ValueError('CONFLICTING_ACCESSION_INDEX')
            entries[acc]=e
    return {'issuer_cik':cik,'issuer_submissions_name':doc['name'],'disclosure_window':[START,END],'effective_window':['2026-04-01','2026-06-30'],'minimum_forms_considered':sorted(MINIMUM_FORMS),'relevant_form_rule':'Minimum forms plus all 8K/10Q/10K/6K/20F/40F/registration/proxy/tender/equity-reorganization form families, EFFECT and RW. Linked exhibits and incorporated terms are separate closure requirements.','index_complete':not missing,'missing_index_partitions':missing,'supplement_refs':extras,'all_form_observations_in_window':all_count,'excluded_form_counts':dict(excluded),'entries':sorted(entries.values(),key=lambda e:(e['filing_date'],e['accession'])),'event_coverage_complete':False}

def build():
    sources=legacy_sources();bindings=read('issuer-cik-bindings.json');inventories={};manifest=read('source-manifest.json')
    for b in bindings:
        if b['status']!='EXACT_VERIFIED':continue
        cik=b['cik']
        if str(cik) in inventories:continue
        u=f'https://data.sec.gov/submissions/CIK{cik:010d}.json';doc,ref=get_json(u,sources)
        if doc is None:raise ValueError('VERIFIED_CIK_WITHOUT_SUBMISSIONS')
        item=inventory_for(cik,doc,lambda url:get_json(url,sources));item['index_ref']=ref
        for e in item['entries']:
            urls=[e['primary_url'],e['complete_submission_url']]
            matches=[u for u in sources if u in urls or u.replace('/data/000','/data/').replace('/data/00','/data/').replace('/data/0','/data/') in urls]
            e['retained_primary_refs']=[{'source_url':u,'sha256':sources[u]['sha256'],'archive':'PRESERVED_BASELINE_OR_WAVE1'} for u in matches]
            e['complete_submission_ref']={'source_url':e['complete_submission_url'],'sha256':manifest[e['complete_submission_url']]['sha256']} if e['complete_submission_url'] in manifest else None
        item['inventory_sha256']=sha(item);inventories[str(cik)]=item
    write('issuer-filing-inventories.json',inventories)
    print(canonical([{'cik':k,'name':v['issuer_submissions_name'],'filings':len(v['entries']),'index_complete':v['index_complete'],'complete_submissions':sum(bool(e['complete_submission_ref']) for e in v['entries'])} for k,v in inventories.items()]))
if __name__=='__main__':build()

import unittest
from copy import deepcopy
from common import sha
from security_master import *
from issuers import cik_decision,normalize_name

def line(cusip='02079K305',option='*',name='ALPHABET INC',description='CAP STK CL A',status='   '):
    return (cusip+option+name.ljust(30)+description.ljust(27)+status+' '*9+'E'+'\n').encode()
def records(body=None,quarter='2026Q1'):
    body=body or line();return parse_list(body,quarter,{'quarter':quarter,'source_url':URLS[quarter],'sha256':sha(body),'retrieved_at':'2026-09-07T00:00:00+00:00'})
def row(sec='02079K305|LONG|SH'):
    return {'comparison_id':'fixture::'+sec,'CUSIP_previous':sec[:9],'CUSIP_current':sec[:9],'previous_security_class':'CAP STK CL A','current_security_class':'CAP STK CL A'}
def pair(a=None,b=None,sec='02079K305|LONG|SH'):
    return bind_pair(sec,[row(sec)],{'2026Q1':index_records(records(a)),'2026Q2':index_records(records(b, '2026Q2'))})
class MasterTests(unittest.TestCase):
    def test_fixed_width(self):
        r=records()[0];self.assertEqual((r['cusip'],r['option_indicator'],r['issuer_name_official'],r['issuer_description_official']),('02079K305','*','ALPHABET INC','CAP STK CL A'))
    def test_preserves_bytes_and_offsets(self):
        b=line()+line('037833100',name='APPLE INC',description='COM');rs=records(b);self.assertEqual(''.join(r['raw_line']+r['line_ending'] for r in rs).encode(),b);self.assertEqual(rs[1]['byte_offset'],81)
    def test_crlf(self):self.assertEqual(records(line().replace(b'\n',b'\r\n'))[0]['line_ending'],'\r\n')
    def test_wrong_width(self):
        with self.assertRaises(ValueError):records(line()[1:])
    def test_wrong_option_column(self):
        with self.assertRaises(ValueError):records(line(option='A'))
    def test_wrong_status_column(self):
        with self.assertRaises(ValueError):records(line(status='A  '))
    def test_status_ad_preserved(self):
        for status in ['*A*','*D*']:self.assertEqual(records(line(status=status))[0]['status'],status)
    def test_cusip_case(self):self.assertEqual(normalize_cusip('02079k305'),'02079K305')
    def test_no_cusip_numeric_cast(self):self.assertEqual(records()[0]['cusip'],'02079K305')
    def test_no_cusip_whitespace_repair(self):
        with self.assertRaises(ValueError):normalize_cusip('02079 K305')
    def test_class_preserved(self):self.assertEqual(records(line(description='CL B NEW'))[0]['issuer_description_official'],'CL B NEW')
    def test_exact_both(self):self.assertEqual(pair()['binding_status'],'EXACT_BOTH')
    def test_quarter_source(self):
        b=line()
        with self.assertRaises(ValueError):parse_list(b,'2026Q1',{'quarter':'2026Q2','source_url':URLS['2026Q2'],'sha256':sha(b)})
    def test_source_hash(self):
        with self.assertRaises(ValueError):parse_list(line(),'2026Q1',{'quarter':'2026Q1','source_url':URLS['2026Q1'],'sha256':'a'*64})
    def test_star_is_not_option_position(self):self.assertEqual(pair()['position_type'],'LONG')
    def test_options_do_not_merge_long(self):
        a=pair();b=pair(sec='02079K305|PUT|SH');self.assertNotEqual(a['security_pair_id'],b['security_pair_id']);self.assertEqual(b['q1_binding_detail']['position_binding_scope'],'UNDERLYING_SECURITY_ONLY')
    def test_option_without_star(self):self.assertEqual(pair(a=line(option=' '),sec='02079K305|PUT|SH')['binding_status'],'OPTION_MISMATCH')
    def test_explicit_call_cusip_not_long(self):
        self.assertEqual(bind_quarter('02079K905',None,'SH',[],index_records(records(line('02079K905',option=' ',description='CALL'))),'2026Q1')['state'],'OPTION_MISMATCH')
    def test_classes_separate(self):
        idx=index_records(records(line()+line('02079K107',description='CAP STK CL C')));self.assertEqual(len(idx),2)
    def test_conflicting_class(self):self.assertEqual(pair(b=line(description='CAP STK CL C'))['binding_status'],'CLASS_CONFLICT')
    def test_names_not_merged(self):self.assertEqual(pair(b=line(name='ALPHABET HOLDINGS INC'))['continuity_signal'],'TRANSFORMATION_RESEARCH_REQUIRED')
    def test_ad_not_movement(self):
        p=pair(a=line(status='*D*'),b=line(status='*A*'));self.assertEqual(p['continuity_signal'],'TRANSFORMATION_RESEARCH_REQUIRED');self.assertIsNone(p['transaction_inference']);self.assertEqual(p['corporate_action_state'],'UNKNOWN')
    def test_single_quarter(self):self.assertEqual(pair(b=line('037833100',name='APPLE INC',description='COM'))['binding_status'],'Q1_ONLY')
    def test_not_found(self):
        r=bind_quarter('111111111',None,'SH',[],index_records(records()),'2026Q1');self.assertEqual(r['state'],'NOT_FOUND_Q1')
    def test_conflicting_duplicate_key(self):self.assertEqual(pair(a=line()+line(status='*D*'))['binding_status'],'AMBIGUOUS')
    def test_identical_duplicate_preserved(self):
        r=pair(a=line()+line());self.assertEqual(r['binding_status'],'EXACT_BOTH');self.assertEqual(len(r['q1_binding_detail']['candidate_rows']),2)
    def test_issuer_cik_ambiguity(self):self.assertEqual(cik_decision(['A INC'],[{'cik':1},{'cik':2}])['status'],'MULTIPLE_CANDIDATES')
    def test_ticker_only_no_binding(self):self.assertEqual(cik_decision(['A INC'],[])['status'],'NO_MATCH')
    def test_name_change_no_binding(self):self.assertEqual(cik_decision(['A INC','A CORP'],[{'cik':1}])['status'],'INDETERMINATE')
    def test_no_fuzzy_suffix_normalization(self):self.assertNotEqual(normalize_name('A CORPORATION'),normalize_name('A CORP'))
    def test_stale_same_name_cik(self):self.assertEqual(cik_decision(['A INC'],[{'cik':1}],{'cik':1,'name':'A INC','filings':{'recent':{'form':['10-K'],'filingDate':['1994-03-01']}}})['status'],'INDETERMINATE')
    def test_current_name_and_cik(self):self.assertEqual(cik_decision(['A INC'],[{'cik':1}],{'cik':1,'name':'A Inc.','filings':{'recent':{'form':['10-Q'],'filingDate':['2026-07-30']}}})['status'],'EXACT_VERIFIED')
if __name__=='__main__':unittest.main()

"""Event candidates, scoped operational coverage and explicit rational quantity adjustment."""
from fractions import Fraction
from html.parser import HTMLParser
from collections import Counter
import re
from common import sha
from inventory import START, END, MINIMUM_FORMS
EVENT_TYPES={'SPLIT','REVERSE_SPLIT','MERGER','SPINOFF','CONVERSION','EXCHANGE','CUSIP_CHANGE','SHARE_CLASS_CHANGE','RECLASSIFICATION','REORGANIZATION','OTHER'}
TERMS=re.compile(r'\b(?:reverse[\s-]+stock[\s-]+split|stock[\s-]+split|share[\s-]+split|reclassification|recapitalization|conversion|exchange|merger|business\s+combination|spin[\s-]?off|distribution|CUSIP|class\s+conversion|redesignation|tender(?:[/\s-]+exchange)?\s+offer|reverse[\s-]+split|splits?|stock[\s-]+dividend|share[\s-]+dividend|reorganization|consolidation|split[\s-]+off|split[\s-]+up|redomiciliation|rights[\s-]+offering|ADR[\s-]+ratio)\b',re.I)
class VisibleText(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.parts=[];self.hidden=0;self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag=='a':
            self.links.extend(v for k,v in attrs if k=='href' and v and not v.startswith('#'))
        if tag in ['script','style','ix:hidden']:self.hidden+=1
        if tag in ['p','div','tr','td','br','li']:self.parts.append(' ')
    def handle_endtag(self,tag):
        if tag in ['script','style','ix:hidden'] and self.hidden:self.hidden-=1
        if tag in ['p','div','tr','td','br','li']:self.parts.append(' ')
    def handle_data(self,data):
        if not self.hidden:self.parts.append(data)
def visible(text):
    parser=VisibleText();parser.feed(text);return re.sub(r'\s+',' ',' '.join(parser.parts)).strip()

def parse_submission(body, accession):
    text=body.decode('utf-8',errors='replace')
    m=re.search(r'ACCESSION NUMBER:\s*([\d-]+)',text)
    if not m or m[1]!=accession:raise ValueError('SUBMISSION_ACCESSION_MISMATCH')
    blocks=re.findall(r'<DOCUMENT>(.*?)</DOCUMENT>',text,re.S|re.I)
    if not blocks or len(blocks)!=len(re.findall(r'<DOCUMENT>',text,re.I)):raise ValueError('INCOMPLETE_SUBMISSION_DOCUMENTS')
    result=[]
    for block in blocks:
        def field(key):
            m=re.search(r'<'+key+r'>\s*([^\r\n<]+)',block,re.I);return m[1].strip() if m else None
        kind,name=field('TYPE'),field('FILENAME');m=re.search(r'<TEXT>(.*)</TEXT>',block,re.S|re.I)
        if not kind or not name or not m:raise ValueError('INCOMPLETE_SUBMISSION_DOCUMENT')
        binary=bool(re.search(r'<(?:PDF|GRAPHIC|ZIP)>',m[1],re.I)) or name.lower().endswith(('.pdf','.jpg','.jpeg','.png','.gif','.zip','.xlsx'))
        structured=kind in ['XML','JSON','ZIP'] or name.lower().endswith(('.css','.js')) or kind.startswith(('EX-101','EX-104')) or name.lower().endswith(('.xsd','_cal.xml','_def.xml','_lab.xml','_pre.xml'))
        mode='STRUCTURED_DATA' if structured else 'BINARY_REVIEW_REQUIRED' if binary else 'TEXT'
        value=visible(m[1]) if mode=='TEXT' else None
        parser=VisibleText()
        if mode=='TEXT':parser.feed(m[1])
        result.append({'filename':name,'type':kind,'sequence':field('SEQUENCE'),'mode':mode,'text':value,'document_block_sha256':sha(block.encode()),'links':sorted(set(parser.links))})
    return result

def detect(text, accession, filename):
    # One candidate per occurrence; context is for triage, not proof or an event assertion.
    result=[]
    for m in TERMS.finditer(text):
        result.append({'candidate_id':'CANDIDATE:'+sha([accession,filename,m.start(),m[0].lower()])[:24],'accession':accession,'filename':filename,'term':m[0],'text_offset':m.start(),'context':text[max(0,m.start()-220):m.end()+350],'verification_status':'CANDIDATE_ONLY'})
    return result

def evidence_fingerprint(binding,cik,inventory,detector):return sha({'binding':binding,'cik':cik,'inventory':inventory,'detector':detector})

def verified_event(event,cik,security,as_of,catalog):
    errors=[]
    if event.get('verification_status')!='VERIFIED_PRIMARY':errors.append('EVENT_NOT_VERIFIED')
    if event.get('event_type') not in EVENT_TYPES:errors.append('INVALID_EVENT_TYPE')
    if event.get('issuer_cik')!=cik or security not in event.get('security_before',[]) or security not in event.get('security_after',[]):errors.append('EVENT_SCOPE_MISMATCH')
    if not '2026-04-01'<=event.get('effective_date','')<='2026-06-30':errors.append('EVENT_OUTSIDE_QUARTER')
    if event.get('evidence_as_of')!=as_of:errors.append('STALE_EVENT_EVIDENCE')
    if not event.get('source_sections') or not event.get('source_accessions'):errors.append('MISSING_PRIMARY_TERMS')
    refs=event.get('source_refs',[])
    if not refs or any(not valid_ref(r,catalog) or not re.search(r'/data/0*'+str(cik)+r'/',r.get('source_url','')) for r in refs):errors.append('UNBOUND_EVENT_SOURCE')
    return errors

def valid_ref(ref,catalog):
    from urllib.parse import urlparse
    u=ref.get('source_url','');h=ref.get('sha256')
    return urlparse(u).scheme=='https' and urlparse(u).hostname in {'www.sec.gov','data.sec.gov'} and isinstance(h,str) and bool(re.fullmatch(r'[a-f0-9]{64}',h)) and catalog.get(u)==h

def coverage(binding,cik,inventory,detector,review,catalog,as_of):
    errors=[];sec=binding['security_pair_id'];cik=cik or {}
    if binding.get('binding_status')!='EXACT_BOTH' or binding.get('continuity_signal')!='CONTINUITY_CANDIDATE':errors.append('LIST_IDENTITY_OR_TRANSFORMATION_UNRESOLVED')
    q1,q2=binding.get('q1_official_binding'),binding.get('q2_official_binding')
    if not q1 or not q2 or q1['quarter']!='2026Q1' or q2['quarter']!='2026Q2':errors.append('QUARTER_LIST_BINDING_MISSING')
    elif q1['canonical_key']!=q2['canonical_key'] or q1['issuer_description_official']!=q2['issuer_description_official'] or q1['issuer_name_official']!=q2['issuer_name_official'] or q1['status'] or q2['status']:errors.append('LIST_CONTINUITY_OR_AD_ANOMALY')
    for q in [q1,q2]:
        if q and catalog.get(q['source_url'])!=q['source_sha256']:errors.append('UNBOUND_LIST_SOURCE')
    if binding.get('position_type')!='LONG' or binding.get('instrument_type')!='SH':errors.append('OPTION_OR_DEBT_TERMS_UNREVIEWED')
    if not cik or cik.get('status')!='EXACT_VERIFIED':errors.append('ISSUER_CIK_UNVERIFIED')
    if not cik.get('source_refs') or any(not valid_ref(r,catalog) for r in cik.get('source_refs',[])):errors.append('UNBOUND_CIK_SOURCES')
    if inventory and (not valid_ref(inventory.get('index_ref',{}),catalog) or any(not valid_ref(r,catalog) for r in inventory.get('supplement_refs',[])) or any(e.get('complete_submission_ref') and not valid_ref(e['complete_submission_ref'],catalog) for e in inventory.get('entries',[]))):errors.append('UNBOUND_INVENTORY_SOURCES')
    if not inventory or inventory.get('index_complete') is not True or inventory.get('disclosure_window')!=[START,END] or not MINIMUM_FORMS.issubset(set(inventory.get('minimum_forms_considered',[]))):errors.append('INCOMPLETE_FILING_INVENTORY')
    elif inventory.get('issuer_cik')!=cik.get('cik') or not inventory.get('entries') or any(not e.get('complete_submission_ref') for e in inventory['entries']):errors.append('INCOMPLETE_ISSUER_DOCUMENTS')
    if not detector or detector.get('inventory_sha256')!=sha(inventory) or detector.get('all_inventory_documents_parsed') is not True:errors.append('INCOMPLETE_EVENT_DETECTION')
    fp=evidence_fingerprint(binding,cik,inventory,detector)
    if detector and any(not valid_ref(r,catalog) for r in detector.get('linked_prior_sources',[])):errors.append('UNBOUND_LINKED_PRIOR_SOURCES')
    if not review or review.get('evidence_fingerprint')!=fp or review.get('evidence_as_of')!=as_of or review.get('security_id')!=sec:errors.append('MISSING_OR_STALE_PRIMARY_REVIEW')
    else:
        required=['start_and_end_class_terms_reviewed','equity_rollforward_reviewed','all_filing_text_and_exhibits_reviewed','incorporated_prior_terms_closed','quantity_changing_events_checked','conflicts_resolved','all_list_anomalies_resolved']
        if any(review.get(k) is not True for k in required):errors.append('OPERATIONAL_COVERAGE_CHECK_FAILED')
        binary={(d['accession'],d['filename'],d['document_block_sha256']) for d in (detector or {}).get('documents',[]) if d['mode']=='BINARY_REVIEW_REQUIRED'}
        reviewed_binary={(d.get('accession'),d.get('filename'),d.get('document_block_sha256')) for d in review.get('non_text_exhibit_dispositions',[]) if d.get('primary_reason')}
        if binary!=reviewed_binary:errors.append('UNREVIEWED_BINARY_EXHIBITS')
        candidates={c['candidate_id'] for c in (detector or {}).get('candidates',[])}
        decisions=review.get('candidate_reviews',[])
        if len({r['candidate_id'] for r in decisions})!=len(decisions) or {r['candidate_id'] for r in decisions}!=candidates or any(r.get('disposition') not in ['VERIFIED_EVENT','VERIFIED_NOT_APPLICABLE'] or not r.get('primary_reason') for r in decisions):errors.append('UNREVIEWED_EVENT_CANDIDATES')
        if not review.get('primary_sections_reviewed'):errors.append('NO_NARRATIVE_COVERAGE_REVIEW')
        for e in review.get('events',[]):
            errors.extend(verified_event(e,cik.get('cik'),sec,as_of,catalog))
            if e.get('event_type') not in ['SPLIT','REVERSE_SPLIT']:errors.append('UNSUPPORTED_TRANSFORMATION')
        if len(review.get('events',[]))>1:errors.append('MULTIPLE_ADJUSTMENTS_REQUIRE_REVIEW')
        if any(r['disposition']=='VERIFIED_EVENT' and r.get('event_id') not in {e['event_id'] for e in review.get('events',[])} for r in decisions):errors.append('UNBOUND_CANDIDATE_EVENT')
    return {'security_id':sec,'corporate_action_state':'UNKNOWN' if errors else 'VERIFIED_CLEAR_FOR_COMPARABILITY','failed_checks':sorted(set(errors)),'evidence_fingerprint':fp,'events':review.get('events',[]) if review and not errors else [],'transaction_inference':None}

def normalize_quantities(previous,current,events,cik,security,as_of,catalog):
    raw=Fraction(str(previous));now=Fraction(str(current));factor=Fraction(1)
    if raw<0 or now<0:raise ValueError('INVALID_QUANTITY')
    seen=set()
    for event in events:
        if event.get('event_id') in seen:raise ValueError('DUPLICATE_EVENT')
        seen.add(event.get('event_id'))
        errors=verified_event(event,cik,security,as_of,catalog)
        if errors:raise ValueError(','.join(errors))
        if event['event_type'] not in ['SPLIT','REVERSE_SPLIT']:raise ValueError('UNSUPPORTED_TRANSFORMATION')
        terms=event.get('ratio_or_terms',{})
        if terms.get('basis')!='EXPLICIT_PRIMARY_RATIO' or terms.get('fractional_share_treatment_verified') is not True:raise ValueError('UNVERIFIED_RATIO_TERMS')
        if type(terms.get('numerator')) is not int or type(terms.get('denominator')) is not int:raise ValueError('NONINTEGER_RATIO_TERMS')
        try:ratio=Fraction(terms['numerator'],terms['denominator'])
        except (KeyError,TypeError,ZeroDivisionError):raise ValueError('INVALID_EXPLICIT_RATIO')
        if ratio<=0 or (event['event_type']=='SPLIT' and ratio<=1) or (event['event_type']=='REVERSE_SPLIT' and ratio>=1):raise ValueError('WRONG_RATIO_DIRECTION')
        factor*=ratio
    value=raw*factor
    if value.denominator!=1:raise ValueError('FRACTIONAL_UNITS_UNRESOLVED')
    status='REPORTED_INCREASED' if now>value else 'REPORTED_REDUCED' if now<value else 'REPORTED_UNCHANGED'
    return {'raw_previous_quantity':str(raw),'corporate_action_factor':str(factor),'normalized_previous_quantity':str(value),'current_quantity':str(now),'reported_status':status,'transaction_inference':None}

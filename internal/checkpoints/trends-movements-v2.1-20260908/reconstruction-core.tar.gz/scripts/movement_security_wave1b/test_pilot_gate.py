import unittest
from copy import deepcopy
from pilot import gate_errors
class GateTests(unittest.TestCase):
    def fixture(self):return {'state':'PASS','fingerprint':'fixed','false_positives':0,'confirmed_false_negatives':0,'tests_exit_code':0,'qualified_diversity':{'comparisons':501,'managers':19,'securities':66,'known_sectors':8},'unqualified_security_ids':[],'unreviewed_family_ids':[]}
    def test_complete_gate_pass(self):self.assertEqual(gate_errors(self.fixture(),'fixed'),[])
    def test_zero_fp_abstention_is_not_pass(self):
        g=self.fixture();g['qualified_diversity']['comparisons']=0;self.assertIn('QUALIFIED_DIVERSITY_COMPARISONS',gate_errors(g,'fixed'))
    def test_one_security_not_enough(self):
        g=self.fixture();g['qualified_diversity']['securities']=1;self.assertIn('QUALIFIED_DIVERSITY_SECURITIES',gate_errors(g,'fixed'))
    def test_stale_code_gate(self):self.assertIn('STALE_CODE_OR_EVIDENCE',gate_errors(self.fixture(),'changed'))
    def test_one_fp_blocks(self):
        g=self.fixture();g['false_positives']=1;self.assertIn('PILOT_ERRORS',gate_errors(g,'fixed'))
    def test_unqualified_security_blocks(self):
        g=self.fixture();g['unqualified_security_ids']=['x'];self.assertIn('INCOMPLETE_PILOT_EVENT_COVERAGE',gate_errors(g,'fixed'))
    def test_unreviewed_family_blocks(self):
        g=self.fixture();g['unreviewed_family_ids']=['x'];self.assertIn('UNREVIEWED_RESOLVED_FAMILY',gate_errors(g,'fixed'))
    def test_failed_tests_blocks(self):
        g=self.fixture();g['tests_exit_code']=1;self.assertIn('TESTS_NOT_PASS',gate_errors(g,'fixed'))
if __name__=='__main__':unittest.main()

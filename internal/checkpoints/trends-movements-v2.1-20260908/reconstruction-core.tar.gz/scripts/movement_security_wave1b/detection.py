"""Deterministic full-submission scanning, with missing documents and binary exhibits explicit."""
from collections import Counter
from common import *
from inventory import legacy_sources
from events import parse_submission,detect,visible

def build():
    inventories=read('issuer-filing-inventories.json');manifest=read('source-manifest.json');legacy=legacy_sources();out={};docmeta=[]
    for cik,inv in inventories.items():
        candidates=[];missing=[];errors=[];documents=[];complete=0
        for e in inv['entries']:
            u=e['complete_submission_url'];docs=[]
            if u in manifest:
                try:docs=parse_submission(source_bytes(u),e['accession']);complete+=1
                except ValueError as ex:errors.append({'accession':e['accession'],'reason':str(ex)})
            else:
                missing.append(e['accession'])
                # Screen retained primary documents for research candidates but never assert full text coverage.
                for ref in e.get('retained_primary_refs',[]):
                    r=legacy[ref['source_url']];docs.append({'type':e['form'],'filename':e['primary_url'].rsplit('/',1)[-1],'mode':'TEXT','text':visible(r['body']),'document_block_sha256':ref['sha256'],'partial_primary_only':True})
            for d in docs:
                record={k:v for k,v in d.items() if k!='text'};record.update(accession=e['accession'],submission_url=u,submission_sha256=manifest[u]['sha256'] if u in manifest else None)
                if d['mode']=='TEXT':
                    hits=detect(d['text'],e['accession'],d['filename']);candidates.extend(hits);record['candidate_count']=len(hits);record['visible_text_sha256']=sha(d['text'].encode());record['visible_text_characters']=len(d['text'])
                documents.append(record)
        linked=[]
        if cik=='320193' and (OUT/'apple-linked-prior-documents.json').exists():
            for e in read('apple-linked-prior-documents.json')['documents']:
                u=e['url'];docs=parse_submission(source_bytes(u),e['accession']);linked.append({'accession':e['accession'],'source_url':u,'sha256':manifest[u]['sha256'],'relation':'Q1_10Q_EXHIBITS_10_1_AND_10_2_INCORPORATED_PRIOR_TERMS','outside_disclosure_window':True})
                for doc in docs:
                    record={k:v for k,v in doc.items() if k!='text'};record.update(accession=e['accession'],submission_url=u,submission_sha256=manifest[u]['sha256'],linked_prior_document=True)
                    if doc['mode']=='TEXT':
                        hits=detect(doc['text'],e['accession'],doc['filename']);candidates.extend(hits);record['candidate_count']=len(hits);record['visible_text_sha256']=sha(doc['text'].encode());record['visible_text_characters']=len(doc['text'])
                    documents.append(record)
        d={'linked_prior_sources':linked,'issuer_cik':int(cik),'inventory_sha256':sha(inv),'all_inventory_documents_parsed':bool(inv['entries']) and not missing and not errors,'complete_accessions_parsed':complete,'missing_accessions':missing,'parse_errors':errors,'documents':documents,'candidates':candidates,'candidate_counts_by_term':dict(Counter(c['term'].lower() for c in candidates)),'review_status':'PRIMARY_REVIEW_REQUIRED','negative_proof_from_zero_keywords':False}
        out[cik]=d
    write('event-detection.json',out)
    stats={'issuers':len(out),'full_submission_issuers':sum(x['all_inventory_documents_parsed'] for x in out.values()),'candidates':sum(len(x['candidates']) for x in out.values()),'candidate_events_verified_by_detector':0,'parse_errors':[{'cik':k,**e} for k,v in out.items() for e in v['parse_errors']]}
    write('event-detection-stats.json',stats);print(canonical(stats))
if __name__=='__main__':build()

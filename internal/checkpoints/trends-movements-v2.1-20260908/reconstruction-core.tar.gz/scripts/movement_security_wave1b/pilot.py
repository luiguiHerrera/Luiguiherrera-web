"""Fixed 501 evaluation; existing v2.1 guards remain necessary. Expansion is gated."""
from copy import deepcopy
from collections import Counter
import subprocess
from common import *
from events import coverage,normalize_quantities
from inventory import legacy_sources
INPUTS=['source-manifest.json','security-bindings.json','issuer-security-packets.json','issuer-cik-bindings.json','issuer-filing-inventories.json','event-detection.json','coverage-manual-reviews.json','verified-events.json','pilot-movement-manual-review.json','apple-pilot-quantity-review-dossier.json','review-clock.json','MODEL.md']

def fingerprint():
    paths=[OUT/n for n in INPUTS]+list((ROOT/'scripts/movement_security_wave1b').glob('*.py'))
    paths += [ROOT/r['path'] for r in read('preflight.json')['preserved_files']]
    return sha({str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(paths)})

def gate_errors(g,current):
    errors=[]
    if g.get('state')!='PASS':errors.append('PILOT_NOT_PASS')
    if g.get('fingerprint')!=current:errors.append('STALE_CODE_OR_EVIDENCE')
    if g.get('false_positives')!=0 or g.get('confirmed_false_negatives')!=0:errors.append('PILOT_ERRORS')
    if g.get('tests_exit_code')!=0:errors.append('TESTS_NOT_PASS')
    for k,n in {'comparisons':500,'managers':10,'securities':20,'known_sectors':5}.items():
        if g.get('qualified_diversity',{}).get(k,0)<n:errors.append('QUALIFIED_DIVERSITY_'+k.upper())
    if g.get('unqualified_security_ids'):errors.append('INCOMPLETE_PILOT_EVENT_COVERAGE')
    if g.get('unreviewed_family_ids'):errors.append('UNREVIEWED_RESOLVED_FAMILY')
    return errors

class PilotEngine:
    def __init__(self,expansion=False):
        sys.path.insert(0,str(ROOT/'scripts/movement_evidence_wave1'))
        from engine import Engine
        self.engine=Engine();self.selection=old('pilot-selection.json');self.ids=set(self.selection['comparison_ids']);self.expansion=expansion
        assert len(self.ids)==501
        if expansion and gate_errors(read('pilot-results.json'),fingerprint()):raise ValueError('STOP_EXPANSION')
        self.bindings={b['security_pair_id']:b for b in read('security-bindings.json')};self.packets=read('issuer-security-packets.json');self.bysecurity={b['security_pair_id']:p for p in self.packets for b in p['securities']};self.ciks={c['packet_id']:c for c in read('issuer-cik-bindings.json')};self.inventories=read('issuer-filing-inventories.json');self.detectors=read('event-detection.json');review_records=read('coverage-manual-reviews.json');self.reviews={r['security_id']:r for r in review_records};assert len(self.reviews)==len(review_records),'DUPLICATE_SECURITY_REVIEW';self.asof=read('review-clock.json')['evidence_as_of']
        self.catalog={u:r['sha256'] for u,r in legacy_sources().items()};self.catalog.update({u:r['sha256'] for u,r in read('source-manifest.json').items()});self.engine.adapter.source_hashes=self.catalog;self.certificates={}
        for sec,p in self.bysecurity.items():
            c=self.ciks[p['packet_id']];i=self.inventories.get(str(c['cik']));d=self.detectors.get(str(c['cik']));self.certificates[sec]=coverage(self.bindings[sec],c,i,d,self.reviews.get(sec),self.catalog,self.asof)
    def evaluate(self,cid):
        if cid not in self.ids and not self.expansion:raise ValueError('OUTSIDE_FIXED_501_PILOT')
        if cid not in self.engine.comparisons:raise ValueError('OUTSIDE_EXISTING_5314')
        base=self.engine.evaluate(cid);row=self.engine.rows[cid];sec=row['security_id'];cert=self.certificates[sec]
        base.update(corporate_event_certificate=cert,official_list_binding_status=self.bindings[sec]['binding_status'])
        if cert['corporate_action_state']!='VERIFIED_CLEAR_FOR_COMPARABILITY':return base
        deps=self.engine.comparisons[cid]['dependencies'];core=[d for d in deps if d['evidence_type']!='CORPORATE_ACTION_STATE']
        if any(base['dependency_checks'].get(d['evidence_id'])!='VALID' for d in core):return base
        from engine import install_verified
        from resolver import ACTION_CHECKS,resolve
        from model import reported_semantics
        x=self.engine.adapter.make(row);c=self.ciks[self.bysecurity[sec]['packet_id']];issuer='sec-issuer-'+str(c['cik'])
        for side in ['previous','current']:
            if x[side] is not None:x[side]['issuer_id']=issuer
        inventory=self.inventories[str(c['cik'])];detector=self.detectors[str(c['cik'])];b=self.bindings[sec]
        refs=[inventory['index_ref']]+[e['complete_submission_ref'] for e in inventory['entries']]+detector.get('linked_prior_sources',[])
        refs += [{'source_url':b[q+'_official_binding']['source_url'],'sha256':b[q+'_official_binding']['source_sha256']} for q in ['q1','q2']]+c['source_refs']
        refs=[{'url':r['source_url'],'sha256':r['sha256']} for r in refs];refs=list({sha(r):r for r in refs}.values());events=[];checks={k:'CLEAR' for k in ACTION_CHECKS}
        for ev in cert['events']:
            typ=ev['event_type'];terms=ev['ratio_or_terms'];checks[typ]='ADJUSTED';events.append({'event_id':ev['event_id'],'issuer_id':issuer,'action_type':typ,'effective_date':ev['effective_date'],'affected_security_ids':[sec],'predecessor_security':sec,'successor_security':sec,'one_to_one':True,'rounding_policy':'EXACT_NO_CASH_IN_LIEU','ratio':{'numerator':terms['numerator'],'denominator':terms['denominator']}})
        node={'evidence_type':'CORPORATE_ACTION_STATE','period_start':row['previous_quarter'],'period_end':row['current_quarter'],'source_refs':refs,'payload':{'issuer_id':issuer,'security_ids':[sec],'checks':checks,'events':events}}
        x=install_verified(x,[self.engine.byid[d['evidence_id']] for d in core]+[node]);resolved=reported_semantics(resolve(x))
        if resolved['reported_status']=='INDETERMINATE':return {**base,**resolved}
        q=normalize_quantities(x['previous']['quantity'],x['current']['quantity'],cert['events'],c['cik'],sec,self.asof,self.catalog)
        assert q['reported_status']==resolved['reported_status'],'NORMALIZATION_ORACLE_CONFLICT'
        checks=dict(base['dependency_checks'])
        for dep in deps:
            if dep['evidence_type']=='CORPORATE_ACTION_STATE':checks[dep['evidence_id']]='VALID_VIA_WAVE1B_OPERATIONAL_CERTIFICATE'
        return {**base,**resolved,**q,'legacy_dependency_checks':base['dependency_checks'],'dependency_checks':checks,'resolution_bucket':'EVIDENCE_RESOLVED','evidence_family':sec}

def pilot():
    e=PilotEngine();manual=read('pilot-movement-manual-review.json');assert manual['selection_sha256']==sha(e.selection)
    for dossier in manual['quantity_dossiers']:
        assert dossier['sha256']==sha(read(dossier['path']))
    reviews=read('coverage-manual-reviews.json');assert manual['family_review_sha256_by_security']=={r['security_id']:sha(r) for r in reviews}
    results=[e.evaluate(cid) for cid in e.selection['comparison_ids']];qualified=[r for r in results if r['reported_status']!='INDETERMINATE'];oracle=manual['expected_by_comparison_id'];fp=[r['comparison_id'] for r in qualified if oracle.get(r['comparison_id'])!=r['reported_status']];fn=[r['comparison_id'] for r in results if r['comparison_id'] in oracle and r['reported_status']=='INDETERMINATE']
    rows=[e.engine.rows[r['comparison_id']] for r in qualified];known=old('sector-registry.json');sectors={known[r['security_id']]['sector'] for r in rows if r['security_id'] in known and known[r['security_id']]['sector']!='UNKNOWN'}
    diversity={'comparisons':len(rows),'managers':len({r['manager_id'] for r in rows}),'securities':len({r['security_id'] for r in rows}),'known_sectors':len(sectors)}
    test=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','scripts/movement_security_wave1b','-p','test_*.py'],cwd=ROOT,capture_output=True,text=True);(OUT/'python-tests.txt').write_text(test.stdout+test.stderr)
    unqualified=sorted({e.engine.rows[cid]['security_id'] for cid in e.ids if e.certificates[e.engine.rows[cid]['security_id']]['corporate_action_state']!='VERIFIED_CLEAR_FOR_COMPARABILITY'})
    unreviewed=sorted({r['evidence_family'] for r in qualified}-set(manual['reviewed_family_ids']))
    gate={'state':'PASS','fingerprint':fingerprint(),'selection_sha256':sha(e.selection),'pilot_before_resolved':0,'pilot_after_resolved':len(qualified),'pilot_still_unknown':501-len(qualified),'false_positives':len(fp),'false_positive_ids':fp,'confirmed_false_negatives':len(fn),'false_negative_ids':fn,'economic_ground_truth_unavailable':501-len(oracle),'tests_exit_code':test.returncode,'qualified_diversity':diversity,'selected_diversity':old('pilot-diversity.json'),'unqualified_security_ids':unqualified,'unreviewed_family_ids':unreviewed,'comparison_results':results,'global_application_authorized':False}
    errors=gate_errors(gate,gate['fingerprint']);gate['state']='FAIL' if fp or fn or test.returncode else 'BLOCKED_EVIDENCE_COVERAGE' if errors else 'PASS';gate['gate_errors']=errors
    write('corporate-event-coverage.json',list(e.certificates.values()));write('pilot-results.json',gate)
    write('expansion-gate.json',{'state':'NOT_EXECUTED','comparisons_applied':0,'baseline_preserved':True,'fingerprint':gate['fingerprint'],'reasons':gate_errors(gate,gate['fingerprint'])})
    print(canonical({k:v for k,v in gate.items() if k not in ['comparison_results','selected_diversity','unqualified_security_ids']}))

def expand():
    gate=read('pilot-results.json');errors=gate_errors(gate,fingerprint())
    if errors:raise SystemExit('STOP_EXPANSION: '+','.join(errors))
    e=PilotEngine(expansion=True);results=[e.evaluate(cid) for cid in sorted(e.engine.comparisons)];assert len(results)==5314
    (OUT/'qualification-results.jsonl.gz').write_bytes(gzip.compress(''.join(canonical(r)+'\n' for r in results).encode(),mtime=0));write('expansion-gate.json',{'state':'APPLIED','comparisons_applied':5314,'fingerprint':fingerprint()})
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='expand':expand()
    else:pilot()

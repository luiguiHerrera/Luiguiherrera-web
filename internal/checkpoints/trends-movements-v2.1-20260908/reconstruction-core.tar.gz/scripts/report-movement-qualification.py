"""Internal completeness/bias diagnostics; no publication-state mutation."""
from collections import defaultdict,Counter
from decimal import Decimal
import gzip
import json
import math
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'movement_qualification'))
from freeze import ROOT,OUT,canonical
from adapter import Adapter


def diagnostic():
    a=Adapter();rows={r['comparison_id']:r for r in a.rows};results=[json.loads(x) for x in gzip.decompress((OUT/'qualification-results.jsonl.gz').read_bytes()).decode().splitlines()]
    resolved=[r for r in results if r['movement_status']!='INDETERMINATE'];unresolved=[r for r in results if r['movement_status']=='INDETERMINATE']
    bymanager=defaultdict(list);bysecurity=defaultdict(list);presence=defaultdict(list);families=defaultdict(list);sectors=defaultdict(list)
    cr={r['comparison_id']:r for r in json.loads((OUT/'census-rows.json').read_text())}
    for r in results:
        row=rows[r['comparison_id']];bymanager[row['manager_id']].append(r);bysecurity[row['security_id']].append(r)
        presence['BOTH_PRESENT' if row['previous_quantity'] is not None and row['current_quantity'] is not None else 'PREVIOUS_ONLY' if row['previous_quantity'] is not None else 'CURRENT_ONLY'].append(r)
        families[cr[r['comparison_id']]['primary_family']].append(r)
        sector='UNKNOWN'
        if row['issuer_id']:
            cik=row['issuer_id'].removeprefix('sec-issuer-');url='https://data.sec.gov/submissions/CIK'+cik.zfill(10)+'.json'
            if url in a.sources:
                src=json.loads(a.sources[url]['body']);sic=str(src.get('sic',''))
                if sic:sector='SEC_SIC_2_DIGIT:'+sic[:2]
        sectors[sector].append(r)
    def stats(group):
        n=len(group);yes=sum(r['movement_status']!='INDETERMINATE' for r in group)
        return {'comparisons':n,'resolved':yes,'unresolved':n-yes,'resolution_percent':round(100*yes/n,6) if n else None}
    manager_stats={m:stats(g) for m,g in sorted(bymanager.items())}
    sizes=sorted(bymanager,key=lambda m:(len(bymanager[m]),m));large=set(sizes[-math.ceil(len(sizes)/4):]);small=[r for m,g in bymanager.items() if m not in large for r in g];big=[r for m,g in bymanager.items() if m in large for r in g]
    action_ids={r['comparison_id'] for r in results if 'F' in [cr[r['comparison_id']]['primary_family'],*cr[r['comparison_id']]['secondary_flags']]}
    material=[];unknown_material=[];pvalues={}
    for side in ['previous','current']:
        for q in a.snapshot[side]:
            total=sum(Decimal(str(h['reported_value'])) for h in q['positions'])
            top={__import__('freeze').key(h) for h in sorted(q['positions'],key=lambda h:Decimal(str(h['reported_value'])),reverse=True)[:10]}
            pvalues[(side,q['manager_id'])]=(total,top,{__import__('freeze').key(h):Decimal(str(h['reported_value'])) for h in q['positions']})
    for r in unresolved:
        row=rows[r['comparison_id']];flags=[]
        for side in ['previous','current']:
            total,top,values=pvalues[(side,r['manager_id'])];value=values.get(r['security_id'],Decimal(0))
            if r['security_id'] in top or total>0 and value/total>=Decimal('.01'):flags.append(side)
        if flags:material.append({'comparison_id':r['comparison_id'],'material_on_sides':flags})
        if row['previous_filing_status']!='available' or row['current_filing_status']!='available':unknown_material.append(r['comparison_id'])
    security_resolved={r['security_id'] for r in resolved};manager_resolved={r['manager_id'] for r in resolved}
    concentration=None
    if resolved and len(security_resolved)==1:
        N=len(results);K=len(bysecurity[next(iter(security_resolved))]);n=len(resolved)
        concentration={'single_security':next(iter(security_resolved)),'population_cases_for_security':K,'resolved_cases':n,'conditional_probability_all_from_this_security_under_uniform_resolution':math.prod((K-i)/(N-i) for i in range(n)),'interpretation':'Diagnostic conditional calculation, not a representative sampling guarantee; the evidence-selection mechanism is known to be nonrandom.'}
    reasons=[]
    if len(security_resolved)<len(bysecurity) and resolved:reasons.append('RESOLVED_SECURITY_SCOPE_CONCENTRATED')
    if any(stats(g)['resolved']==0 for g in presence.values()) and resolved:reasons.append('PRESENCE_TRANSITIONS_HAVE_ZERO_RESOLUTION')
    if any(v['resolved']==0 for v in manager_stats.values()) and resolved:reasons.append('MANAGER_COVERAGE_UNEVEN')
    bias='FAIL' if reasons else 'INDETERMINATE'
    report={'MOVEMENT_DATA_COMPLETENESS':{'resolved':len(resolved),'total':len(results),'percent':round(100*len(resolved)/len(results),6),'scope':'Only the frozen 8137; the two previously reviewed movements are excluded.'},
        'MOVEMENT_MANAGER_COVERAGE':{'with_any_resolved':len(manager_resolved),'expected_filers':sum(m['filing_expected'] for m in a.managers.values()),'corpus_managers':len(bymanager),'percent_any_resolved':round(100*len(manager_resolved)/len(bymanager),6),'fully_resolved':sum(all(r['movement_status']!='INDETERMINATE' for r in g) for g in bymanager.values())},
        'MOVEMENT_SECURITY_COVERAGE':{'with_any_resolved':len(security_resolved),'corpus_securities':len(bysecurity),'percent_any_resolved':round(100*len(security_resolved)/len(bysecurity),6),'fully_resolved':sum(all(r['movement_status']!='INDETERMINATE' for r in g) for g in bysecurity.values())},
        'UNRESOLVED_MATERIAL_CASES':len(material),'MATERIALITY_UNKNOWN_CASES':len(unknown_material),'materiality_definition':'Union of top ten holdings or >=1% of a manager reported 13F value in either usable quarter. This is a screening proxy, not total AUM; unavailable quarters remain separately unknown.',
        'RESOLUTION_BIAS_CHECK':bias,'bias_reasons':reasons,'by_manager':manager_stats,'portfolio_size_test':{'definition':'Top quartile by frozen comparison count, not AUM','large_portfolios':stats(big),'other_portfolios':stats(small),'large_manager_ids':sorted(large)},'by_presence':{k:stats(g) for k,g in sorted(presence.items())},'by_primary_family':{k:stats(g) for k,g in sorted(families.items())},'corporate_action_candidate_test':{'flagged':stats([r for r in results if r['comparison_id'] in action_ids]),'not_flagged':stats([r for r in results if r['comparison_id'] not in action_ids])},'sector_test':{'state':'INDETERMINATE','taxonomy':'Primary SEC SIC, first two digits; no ticker/name-derived sectors','unknown_cases':len(sectors['UNKNOWN']),'groups':{k:stats(g) for k,g in sorted(sectors.items())}},'single_security_concentration':concentration,'PRODUCTION_READINESS':'NOT_READY','publication_recommendation':'Do not publish aggregate movement views or rankings. Broaden issuer evidence, establish presence-transition qualification and resolve material manager/filing gaps before a new bias assessment. Separate explicit authorization remains mandatory.'}
    (OUT/'readiness-and-bias.json').write_text(canonical(report)+'\n');(OUT/'unresolved-material-cases.json').write_text(canonical({'material':material,'materiality_unknown':unknown_material})+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['by_manager','by_primary_family','sector_test']},indent=2))

if __name__=='__main__':diagnostic()

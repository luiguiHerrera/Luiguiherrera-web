"""Run existing required checks without writing any earlier wave artifacts."""
from closure import *
import os, subprocess, time

def run(name):
    specs={c['name']:c['command'] for c in read('validation.json')['checks']}
    specs['wave1d-python']=['python3','-B','-m','unittest','discover','-s','scripts/movement_pilot_wave1d','-p','test_*.py']
    specs['git-diff-check']=['git','diff','--check']
    if name not in specs or name in {'source-audit','offline-replay'}:raise ValueError('UNSUPPORTED_CHECK')
    env=dict(os.environ);env['PATH']='/private/tmp/npm-audit-remediation-20260907/node-v22.23.2-darwin-arm64/bin:'+env['PATH']
    env['STAT_LEVELS_QUALIFICATION_DIR']='/private/tmp/september-2026-final-on-a933-evidence/final-statistical-qualification'
    logs=OUT/'validation-logs';logs.mkdir(exist_ok=True);log=logs/(name+'.log');start=__import__('time').monotonic()
    with log.open('wb') as f:p=subprocess.run(specs[name],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    r={'name':name,'command':specs[name],'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-start,2),'log':str(log.relative_to(OUT)),'log_sha256':sha(log.read_bytes())}
    save('validation-'+name+'.json',r);print(canonical(r));return p.returncode

if __name__=='__main__':raise SystemExit(run(sys.argv[1]))

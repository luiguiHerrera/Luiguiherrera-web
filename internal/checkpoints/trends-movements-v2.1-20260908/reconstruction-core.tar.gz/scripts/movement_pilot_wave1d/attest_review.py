"""Record the primary agent's completed source review; excluded from automatic replay."""
from closure import *

TSM_REASON = ('The June 4 minutes, visually checked pages 4/6/38/39, approve only Article 19 board size (7–10 to 9–12) and Article 36 amendment history. The no-split response is intent as of June 4 only. The April 20-F EX-2.1 specifies one ADS representing five common shares and separately explains ADS issuance/ratio changes on common-stock distributions. Both quarter-end Note 21 disclosures report 1,062,690 thousand ADSs representing 5,313,451 thousand common shares; rounded totals corroborate, rather than define, the exact contractual 1:5 ratio. May 12 cancellation of 154,454 reclaimed employee RSAs is positively scoped to those awards; it is not a split or cancellation of existing ADSs. June 25 reports that May cancellation; July 24 reports no June cancellation. All 29 owned accessions through August 14, including Q2 earnings and final reviewed interim accounts, show no conflicting Q2 ADS ratio, class, conversion, reclassification or CUSIP event. Sony company split concerns Sony assets into a Sony-controlled future JV; TSMC contributes cash, not existing TSM ADS units. VIS disposal concerns an investee. Cash dividends, conditional charter/deposit powers, historic capital-surplus balances, FX conversions, financial assets, consolidation and PP&E reclassifications do not supply an executed holder-unit factor. Operational evidence supports factor 1/1 for existing pilot ADSs, not a claim of absolute absence of events.')
CVX_REASON = ('The Q2 10-Q full equity statement (including all column headings, Q2 and H1 rollforwards and footnotes 1–3) reports 2,442,676,580 issued common shares at both March 31 and June 30. The stock-dividend line is -$11m retained earnings, zero in common stock and treasury columns. The separate quantity reconciliation has no issued-share additions: treasury purchases 16,255,113 and reissuances 428,655 reconcile outstanding 1,991,597,732 to 1,975,771,274. The 14,168,000 Benefit Plan Trust shares are included consistently in all issued balances. Current award terms distinguish participant-specific dividend equivalents/vesting and settlement from proportional units for all existing holders. The $11m is not specifically attributed to awards; that accounting explanation is neither established nor needed for this class-scope conclusion. The May cash dividend is $1.78, payable June 10. The Hess acquisition closed July 18, 2025; 2026 purchase-price allocation is not a new holder exchange. All 12 owned accessions and relevant incorporated terms show no conflicting Q2 common split, reclassification or CUSIP event. Proxy retirement/separation, operational reorganization, fuel conversion, administrative CUSIP trademark, conditional change-in-control clauses and record-date powers are not an executed common-holder transformation. Existing common units remain comparable at 1/1; the issuer outstanding-share ratio is not a normalization factor.')

TSM_ACCESSIONS = {
'000027':'Cash dividend per-share adjustment from reclaimed RSAs; April 9 cash payment, no ADS unit allocation.',
'000031':'February revenue, subsidiary loans/guarantees and FX derivatives; no common/ADS transformation.',
'000076':'ADS-holder AGM proposal window March 31–April 7 under existing deposit agreement; no change to ratio.',
'000126':'February month-end capital/insider report; cancellation none; asset investments and nonconvertible bonds.',
'000136':'March revenue and subsidiary financing/FX disclosure; no holder-unit event.',
'000199':'Q1 earnings and EX-99.1/99.2; cash dividend recap, EPS denominators and existing ADR reporting.',
'000201':'Taiwan-IFRS versus IASB-IFRS differences relate to retained-earnings tax timing for 2025.',
'025362':'20-F registered ADS/CUSIP and common class; EX-2.1 depositary ratio/distributions/amendments; equity and linked charter/award/debt terms.',
'000203':'April 17 added AGM articles agenda; operative amendment now resolved by retained June 4 minutes.',
'000205':'March month-end insider, asset, bonds and capital report; no general share transformation.',
'000213':'April revenue and subsidiary financing/FX report; no holder-unit event.',
'000215':'Sony preliminary agreement for image-sensor JV; target operations, not TSM ADS restructuring.',
'000274':'May board Q1 results; NT$7 cash dividend September record/October payment; capital appropriations.',
'000275':'May 12 board approval cancels reclaimed employee RSAs; scope limited to award shares, not ADS holders.',
'000278':'Q1 interim accounts, Note 21 common/ADS equity and Note 26 RSA terms; ADS ratio corroboration.',
'000280':'Sale of 152 million VIS investee shares (8.1%); does not exchange existing TSM shares.',
'000292':'April month-end insider/assets/capital/bonds/cancellation report; no all-holder quantity transformation.',
'000294':'Cash dividend per-share adjustment due to reclaimed RSAs; July 9 cash payment, no new ADS allocation.',
'000302':'SEC confirms June 4 AGM and approved articles amendment; exact operative scope supplied by issuer minutes.',
'000367':'June 10 report covers May revenue, loans, guarantees and FX; no Q2 holder-unit transformation.',
'000377':'June 25 report covers May: 154,454 reclaimed employee RSAs cancelled effective May 12; not pro-rata common/ADS event.',
'000381':'July 1 Arizona subsidiary treasurer change, not a change in the security or depositary.',
'000447':'July 13 report covers June revenue, loans, guarantees and FX; no Q2 holder-unit transformation.',
'000451':'July 16 Q2 earnings and presentation; EPS/ADR units, cash dividend and VIS/JV recap, no Q2 ADS change.',
'000459':'July 24 report covers June: no common-share cancellation; insider transfers and fixed-income investment only.',
'000471':'August 10 July operating report; no retrospective Q2 security transformation.',
'000536':'August 11 approves Q2 accounts and cash dividend December record/January 2027 payment; optional USD cash currency is not an ADS ratio change.',
'000539':'August 11 Sony definitive JV: Sony asset company split and TSMC cash contribution; future third-party vehicle, not existing TSM ADSs.',
'000541':'August 14 Q2 reviewed interim accounts: Note 21 ADS/common units, dividend policy, RSA cancellation, Note 26 awards and subsequent events.'}
CVX_ACCESSIONS = {
'000158':'Chevron ESIP 2025 accounts filed June 24: participant choice of taxable cash dividends or reinvestment; savings-plan contribution/distribution rules. Note 8 evaluates subsequent events through June 24. No pro-rata event for common holders.',
'000160':'Hess savings-plan 2025 accounts filed June 24: Hess-share conversion July 18, 2025 and savings-plan merger December 31, 2025; both historical, neither transforms existing CVX common in Q2 2026.',
'000103':'March 25 bylaws update about nonemployee director compensation/board governance; stock-transfer and record-date powers remain conditional.',
'145617':'Annual proxy: six meeting matters, director/employee RSU and PSU dividend equivalents, vesting, benefit/deferred compensation and historical Hess context.',
'145625':'Annual meeting voting notice and administrative materials; no operative security terms.',
'145629':'Electronic voting materials, sample control number and CUSIP trademark; no CUSIP change.',
'145641':'Employee proxy-voting instructions for common/plan shares; no share-denomination event.',
'000108':'April 9 preliminary Q1: repurchases offset by employee option exercises; operational guidance, not a split.',
'000110':'May 1 earnings EX-99.1; $1.78 cash dividend payable June 10, record May 19.',
'000113':'March 31 10-Q: common capital, equity quantity reconciliation, award/treasury cash flows and historical Hess Note 18.',
'000123':'Pate future resignation December 31 and 2027 retirement; employment change only.',
'000125':'May 27 final annual votes: directors, auditor, pay and three shareholder proposals; no approved quantity or class amendment.',
'000162':'July 31 earnings EX-99.1; Q2 results/repurchases and next cash dividend September 10, outside Q2.',
'000167':'June 30 10-Q: full Q2/H1 equity, quantity and trust footnotes, treasury repurchases/reissuances, Note 18 historic acquisition, compensation/benefit scope.'}

def run():
    scopes,catalog=resources(); D=documents();byurl={d['document_url']:d for d in D}
    def section(label, suffix, start, end):
        ds=[d for d in D if d['document_url'].endswith(suffix)];assert len(ds)==1,(suffix,len(ds))
        d=ds[0];excerpt=d['text'][start:end]
        return {'label':label,**{k:d[k] for k in ['document_url','document_hash','source_ref']},'primary_excerpt':excerpt,'excerpt_sha256':sha(excerpt)}
    proofs={};reviews={}
    cvx_reason=CVX_REASON.replace('All 12 owned accessions','All 14 relevant owned accessions (12 corporate reports plus two benefit-plan 11-Ks)')+' June 24 ESIP Note 1 explicitly permits participant cash-dividend election or reinvestment; Hess Plan Note 1 dates both its corporate exchange and plan merger to 2025. Neither constitutes a Q2 pro-rata common-holder event.'
    for sec,reason,accession_reasons in [(TSM,TSM_REASON,TSM_ACCESSIONS),(CVX,cvx_reason,CVX_ACCESSIONS)]:
        b,c,inv,groups,docs=scopes[sec]
        ars=[]
        for e in inv['entries']:
            ars.append({'accession':e['accession'],'filing_date':e['filing_date'],'form':e['form'],'disposition':'INSPECTED_RELEVANT_PRIMARY','primary_reason':accession_reasons[e['accession'][-6:]],'primary_documents_sha256':sha([d for d in docs if d.get('accession')==e['accession']])})
        p={'security_id':sec,'issuer_cik':c['issuer_cik'],'economic_window':['2026-04-01','2026-06-30'],'disclosure_window':inv['disclosure_window'],'inventory_sha256':sha(inv),'accession_reviews':ars,'normalization_factor':'1/1','events':[],
            'same_official_class_both_quarters':True,'full_owned_narrative_review':True,'no_conflicting_authoritative_source':True,'ads_or_common_holder_scope_reviewed':True,'finding':reason,
            'reviewer':'Codex primary agent; manual source interpretation, not independent external human sign-off','evidence_as_of':'2026-09-07'}
        if sec==TSM:
            p.update(ads_common_ratio=[1,5],ads_ratio_state='VERIFIED_UNCHANGED_Q2',common_event_state='VERIFIED_CLEAR_FOR_COMPARABILITY_RSA_CANCELLATION_SCOPED',class_state='VERIFIED_UNCHANGED_ADS_CLASS_CUSIP',post_june4_event_state='VERIFIED_CLEAR_FOR_Q2_COMPARABILITY')
            p['agm']={'sha256':PDF_SHA,'bytes':4368300,'document_date':'2026-06-04','no_split_intent_scope':'AS_OF_2026_06_04_ONLY','no_split_intent_state':'VERIFIED','articles_amendment':'NON_SHARE_CAPITAL_AMENDMENT','directors_before':[7,10],'directors_after':[9,12],'article36_change':'Adds June 4, 2026 amendment date only','visually_reviewed_pages':[4,6,38,39],
                'ocr_sha256':sha((OUT/'tsmc-agm-ocr.json').read_bytes()),'text_sha256':sha((OUT/'tsmc-agm-text.json').read_bytes()),
                'render_hashes':{str(n):sha((OUT/f'qa/agm-{n:02d}.png').read_bytes()) for n in [4,6,38,39]},'custody':'USER_SUPPLIED_PRIMARY_PDF_NOT_SEC_OWNED','publisher_url':PDF_URL}
            p['sections']=[section('ads_deposit_terms','000162828026025362/exhibit21.htm',3900,8500),section('q1_ads_equity','a2026q1consolidatedreport-.htm',55000,58100),section('q2_ads_equity','a2026q2consolidatedreport-.htm',60000,64200),section('agm_sec','tsm-agmx20260604x6k.htm',1450,2150),section('june25_cancellation','tsm-monthend6kx20260625.htm',1450,10000),section('july24_month_end','tsm-monthend6kx20260724.htm',1450,10000)]
            q2=next(d for d in D if '000104617926000451/' in d['document_url'] and d['document_type']=='EX-99.1')
            p['sections'].append(section('q2_earnings',q2['document_url'],0,6000))
        else:
            p['stock_dividend_scope']='ACCOUNTING_EQUITY_ITEM_NOT_PRO_RATA_COMMON_SHARE_QUANTITY_EVENT'
            p['equity_quantities']={'issued_q1':2442676580,'issued_q2':2442676580,'stock_dividend_common_stock_usd_m':0,'stock_dividend_retained_earnings_usd_m':-11,'stock_dividend_treasury_usd_m':0,'treasury_purchased_units':16255113,'treasury_reissued_units':428655,'outstanding_q1':1991597732,'outstanding_q2':1975771274,'pro_rata_share_factor_required':False,'exact_11m_award_attribution':'NOT_ESTABLISHED_OR_REQUIRED'}
            cash=next(d for d in D if '000009341026000110/' in d['document_url'] and d['document_type']=='EX-99.1')
            p['sections']=[section('q2_equity','000009341026000167/cvx-20260630.htm',17300,21900),section('q1_equity','000009341026000113/cvx-20260331.htm',17100,20900),section('rsu_terms','a12312025rsushare.htm',7000,10000),section('q2_cash_dividend',cash['document_url'],0,6500),section('hess_scope','000009341026000167/cvx-20260630.htm',79100,82600)]
            p['sections'] += [section('esip_plan_scope','000009341026000158/cvx-20260624.htm',7400,10200),section('hess_plan_scope','000009341026000160/hes-20260624.htm',8000,10800)]
            p['additional_plan_accessions']=['0000093410-26-000158','0000093410-26-000160']
        proofs[sec]=p
        scope=augmented(scopes[sec],p)
        old=next(r for r in read('coverage-manual-reviews.json') if r['security_id']==sec)
        r=copy.deepcopy(old);r.update(state='VERIFIED_CLEAR_FOR_COMPARABILITY',unresolved_review_reason=None,evidence_fingerprint=scope_hash(*scope),accession_reviews=ars,primary_sections_reviewed=reason,closure_proof_sha256=sha(p))
        r.update({flag:True for flag in FLAGS})
        r['candidate_reviews']=[{'candidate_id':g['candidate_id'],'status':'APPLIES_TO_OTHER_CLASS' if sec==TSM and any('sonysemiconductorsolutions' in o['document_url'] for o in g['occurrences']) else 'NOT_RELEVANT','primary_reason':reason,'candidate_occurrences_sha256':sha(g['occurrences'])} for g in groups]
        if sec==TSM:r['supplemental_primary_refs']=[{'source_url':PDF_URL,'sha256':PDF_SHA,'bytes':4368300,'hash_domain':'EXACT_USER_SUPPLIED_PRIMARY_PDF_BODY','ownership':'USER_SUPPLIED_ISSUER_PUBLICATION_NOT_SEC_OWNED','corroborating_sec_accession':'0001046179-26-000302','sec_link_asserted':False}]
        if sec==CVX:r['source_refs'] += [{'source_url':x['source_url'],'sha256':x['sha256']} for x in load('additional-sec-source-manifest.json')]
        reviews[sec]=r
    save('closure-proofs.json',proofs);save('coverage-manual-reviews.json',reviews)
    # Values below were read directly from the four retained Ariel 13F XML rows.
    manual={};s=Store()
    for sec,q1,q2,cls,expect in [(TSM,16092,17838,'SPONSORED ADS','REPORTED_INCREASED'),(CVX,41499,34626,'COM','REPORTED_REDUCED')]:
        primary=[]
        for acc,q,period in [('0000936753-26-000025',q1,'2026-03-31'),('0000936753-26-000050',q2,'2026-06-30')]:
            u='https://www.sec.gov/Archives/edgar/data/936753/'+acc.replace('-','')+'/'+acc+'.txt';body=s.bytes(u).decode()
            rows=[m[0] for m in re.finditer(r'<infoTable>.*?</infoTable>',body,re.S) if sec.split('|')[0] in m[0]];assert len(rows)==1
            assert f'<sshPrnamt>{q}</sshPrnamt>' in rows[0] and f'<titleOfClass>{cls}</titleOfClass>' in rows[0] and '<sshPrnamtType>SH</sshPrnamtType>' in rows[0] and '<putCall>' not in rows[0]
            primary.append({'period':period,'source_ref':s.compact_ref(u),'raw_xml':rows[0],'raw_xml_sha256':sha(rows[0]),'reported_quantity':q,'security_class':cls,'cusip':sec.split('|')[0]})
        manual['ariel::'+sec]={'security_id':sec,'q1_reported_quantity':q1,'q2_reported_quantity':q2,'normalization_factor':'1/1','reported_delta':q2-q1,'expected_result':expect,'packet_proof_sha256':sha(proofs[sec]),'evidence_packet':'VERIFIED_CLEAR_FOR_COMPARABILITY','primary_rows':primary,'primary_rows_visually_or_textually_reviewed':True,'reviewer':'Codex primary agent','method':'Direct retained XML row reading and integer subtraction after independent class-specific closure; ADS ratio 1:5 is not a 5:1 inter-quarter factor.'}
    save('new-manual-comparison-checks.json',{'reviews':manual,'new_checks':2,'statistical_zero_error_claim':False})
    save('high-leverage-primary-node-review.json',{'security_id':TSM,'pilot_comparisons':10,'evidence_fingerprint':reviews[TSM]['evidence_fingerprint'],'primary_sections_reviewed':TSM_REASON,'node_manually_reviewed':True,'reviewer':'Codex primary agent','attestation_basis':'Completed primary SEC and visually reviewed exact issuer PDF, including post-AGM window and ADS mechanics; not generated in automatic replay.'})
    print('Recorded two manual packet reviews and two direct primary-quantity checks.')

if __name__=='__main__':
    if sys.argv[1:]!=['--attest-reviewed-primary']:raise SystemExit('EXPLICIT_MANUAL_REVIEW_ATTESTATION_REQUIRED')
    run()

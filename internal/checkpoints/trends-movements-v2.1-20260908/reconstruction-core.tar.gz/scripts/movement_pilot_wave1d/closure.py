"""Two-packet evidence overlay. Reuses the immutable resolver; never expands it."""
from pathlib import Path
import copy, json, sys, re
from collections import Counter
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'scripts/movement_pilot_wave1c'))
from context import Store, sha, canonical, read, selection, visible
from pilot_engine import FixedPilotEngine, resources as legacy_resources
from coverage import certificate, scope_hash, pilot_gate
from review_dossier import documents as legacy_documents
OUT = ROOT/'internal/trends-movements/wave1d'
ALLOWED = {'874039100|LONG|SH', '166764100|LONG|SH'}
TSM = '874039100|LONG|SH'
CVX = '166764100|LONG|SH'
PDF_URL = 'https://investor.tsmc.com/sites/ir/shareholders-meeting/2026-06-04/2026AGM_Minutes_wmn_0.pdf'
PDF_SHA = '3155817bb2f6fd5a52a6332a6f6a01ac36a71638a9c57e884abc65b1dddf9ee6'
PDF_PATH = OUT/'sources/2026AGM_Minutes_wmn_0.pdf'
FLAGS = ['list_name_status_anomalies_reviewed','registered_security_class_reviewed','quarter_equity_units_reviewed','quantity_changing_events_reviewed','required_forms_inspected','relevant_linked_terms_inspected','no_unresolved_relevant_link','no_conflicting_authoritative_source','amendment_blockers_reviewed','narrative_coverage_beyond_keywords_reviewed']

def save(name, obj):
    (OUT/name).write_text(canonical(obj)+'\n')

def load(name):
    return json.loads((OUT/name).read_text())

def additional_plan_documents():
    from context import parse_submission
    ds=[]
    expected={'0000093410-26-000158','0000093410-26-000160'}
    manifest=load('additional-sec-source-manifest.json')
    assert len(manifest)==2
    for r in manifest:
        acc=r['source_url'].rsplit('/',1)[-1].removesuffix('.txt')
        assert acc in expected and r['source_url']=='https://www.sec.gov/Archives/edgar/data/93410/'+acc.replace('-','')+'/'+acc+'.txt'
        path=(OUT/r['path']).resolve();assert path.is_relative_to((OUT/'sources').resolve())
        body=path.read_bytes();assert sha(body)==r['sha256'] and len(body)==r['bytes']
        for d in parse_submission(body,acc):
            ds.append({**d,'issuer_cik':93410,'accession':acc,'document_url':r['source_url'].rsplit('/',1)[0]+'/'+d['filename'],
                'document_type':d['type'],'document_hash':d['document_block_sha256'],'hash_domain':'SGML_DOCUMENT_BLOCK',
                'ownership':'ISSUER_OWNED_BENEFIT_PLAN_FILING','source_ref':{'source_url':r['source_url'],'sha256':r['sha256']}})
    assert {d['accession'] for d in ds}==expected
    return ds

def documents():
    return legacy_documents()+additional_plan_documents()

def resources():
    scopes,catalog=legacy_resources();b,c,inv,groups,docs=copy.deepcopy(scopes[CVX])
    extra=additional_plan_documents();accs={d['accession'] for d in extra}
    entries=[e for e in inv['all_owned_entries'] if e['accession'] in accs]
    assert len(entries)==2 and all(e['form']=='11-K' and e['filing_date']=='2026-06-24' for e in entries)
    inv['entries']=sorted(inv['entries']+entries,key=lambda e:(e['filing_date'],e['accession']))
    inv['forms_expected']=sorted(set(inv['forms_expected'])|{'11-K'})
    inv['forms_observed']={**inv['forms_observed'],'11-K':2}
    inv['excluded_forms'].pop('11-K',None)
    inv['wave1d_additional_form_scope']='Two issuer-associated benefit-plan 11-Ks, reviewed only for existing Chevron common comparability.'
    inv['inventory_sha256']=sha({k:v for k,v in inv.items() if k!='inventory_sha256'})
    for d in extra:
        docs.append({k:d.get(k) for k in ['issuer_cik','accession','document_url','document_type','document_hash','hash_domain','source_ref','mode','ownership']})
        catalog[d['source_ref']['source_url']]=d['source_ref']['sha256']
    scopes[CVX]=(b,c,inv,groups,sorted(docs,key=lambda d:(d['document_url'],d['document_hash'])))
    return scopes,catalog

def validate_manual(manual, proofs):
    s=Store()
    for cid,m in manual['reviews'].items():
        assert cid=='ariel::'+m['security_id'] and m['security_id'] in ALLOWED
        assert m['packet_proof_sha256']==sha(proofs[m['security_id']])
        assert len(m['primary_rows'])==2
        for i,r in enumerate(m['primary_rows']):
            ref=r['source_ref'];body=s.bytes(ref['source_url']).decode()
            assert sha(body.encode())==ref['sha256'] and r['raw_xml'] in body and sha(r['raw_xml'])==r['raw_xml_sha256']
            assert r['period']==['2026-03-31','2026-06-30'][i]
            assert f'<cusip>{m["security_id"].split("|")[0]}</cusip>' in r['raw_xml']
            assert f'<titleOfClass>{r["security_class"]}</titleOfClass>' in r['raw_xml']
            assert '<sshPrnamtType>SH</sshPrnamtType>' in r['raw_xml'] and '<putCall>' not in r['raw_xml']
            assert r['reported_quantity']==m[['q1_reported_quantity','q2_reported_quantity'][i]]
            assert f'<sshPrnamt>{r["reported_quantity"]}</sshPrnamt>' in r['raw_xml']
        assert m['reported_delta']==m['q2_reported_quantity']-m['q1_reported_quantity']
        assert m['expected_result']==('REPORTED_INCREASED' if m['reported_delta']>0 else 'REPORTED_REDUCED' if m['reported_delta']<0 else 'REPORTED_UNCHANGED')

def augmented(scope, proof):
    b,c,inv,groups,docs = copy.deepcopy(scope)
    inv['wave1d_closure_proof_sha256'] = sha(proof)
    # User-supplied PDF is bound through the independently verified proof hash.
    # It is never inserted into the SEC-owned document index or SEC-only DAG.
    return b,c,inv,groups,sorted(docs,key=lambda d:(d['document_url'],d['document_hash']))

def validate_proof(proof, scope, indexed, pdf_body=None):
    """A narrative assertion alone cannot substitute for quarter/class/source scope."""
    errors=[]
    b,c,inv,groups,ds=scope
    sec=b['security_pair_id']
    if proof.get('security_id')!=sec or sec not in ALLOWED: errors.append('WRONG_CLOSURE_SECURITY')
    if proof.get('economic_window')!=['2026-04-01','2026-06-30'] or proof.get('disclosure_window')!=inv['disclosure_window']: errors.append('WRONG_CLOSURE_WINDOW')
    if proof.get('normalization_factor')!='1/1' or proof.get('events')!=[]: errors.append('UNSUPPORTED_NEW_FACTOR')
    if proof.get('inventory_sha256')!=sha(inv): errors.append('STALE_OWNED_INVENTORY')
    owned={e['accession'] for e in inv['entries']}
    rows=proof.get('accession_reviews',[])
    if len(rows)!=len(owned) or {r.get('accession') for r in rows}!=owned or any(not r.get('primary_reason') for r in rows): errors.append('INCOMPLETE_ACCESSION_REVIEW')
    for p in proof.get('sections',[]):
        d=indexed.get((p.get('document_url'),p.get('document_hash')))
        if not d or d['issuer_cik']!=c['issuer_cik'] or d['source_ref']!=p.get('source_ref') or not p.get('primary_excerpt') or p.get('excerpt_sha256')!=sha(p['primary_excerpt']) or p['primary_excerpt'] not in d.get('text',''): errors.append('UNBOUND_CLOSURE_SECTION')
    by={p['label']:p for p in proof.get('sections',[])}
    if not all(proof.get(f) is True for f in ['same_official_class_both_quarters','full_owned_narrative_review','no_conflicting_authoritative_source','ads_or_common_holder_scope_reviewed']): errors.append('INCOMPLETE_CLOSURE_ATTESTATION')
    if sec==TSM:
        body=PDF_PATH.read_bytes() if pdf_body is None else pdf_body
        if sha(body)!=PDF_SHA or len(body)!=4368300 or not body.startswith(b'%PDF-'): errors.append('EXACT_USER_PDF_MISMATCH')
        p=proof.get('agm',{})
        if p.get('sha256')!=PDF_SHA or p.get('document_date')!='2026-06-04' or p.get('no_split_intent_scope')!='AS_OF_2026_06_04_ONLY' or p.get('articles_amendment')!='NON_SHARE_CAPITAL_AMENDMENT' or p.get('directors_before')!=[7,10] or p.get('directors_after')!=[9,12] or p.get('visually_reviewed_pages')!=[4,6,38,39]: errors.append('UNPROVEN_AGM_SCOPE')
        for key,name in [('ocr_sha256','tsmc-agm-ocr.json'),('text_sha256','tsmc-agm-text.json')]:
            if p.get(key)!=sha((OUT/name).read_bytes()): errors.append('PDF_EXTRACTION_CHANGED')
        required={'ads_deposit_terms','q1_ads_equity','q2_ads_equity','agm_sec','june25_cancellation','july24_month_end','q2_earnings'}
        if not required<=set(by): errors.append('MISSING_ADS_OR_POST_AGM_PRIMARY')
        else:
            if 'Each ADS represents ownership of five common shares' not in by['ads_deposit_terms']['primary_excerpt'] or 'ADS-to-common share ratio will be modified' not in by['ads_deposit_terms']['primary_excerpt']: errors.append('UNPROVEN_ADS_MECHANICS')
            for q,date in [('q1','March 31, 2026'),('q2','June 30, 2026')]:
                text=by[q+'_ads_equity']['primary_excerpt']
                if date not in text or '1,062,690 thousand units, representing 5,313,451 thousand common shares' not in text: errors.append('UNPROVEN_QUARTER_ADS_RATIO')
            if '154,454' not in by['june25_cancellation']['primary_excerpt'] or 'reclaimed employee restricted stock awards' not in by['june25_cancellation']['primary_excerpt']: errors.append('UNSCOPED_RSA_CANCELLATION')
        if proof.get('ads_common_ratio')!=[1,5] or proof.get('ads_ratio_state')!='VERIFIED_UNCHANGED_Q2' or proof.get('post_june4_event_state')!='VERIFIED_CLEAR_FOR_Q2_COMPARABILITY': errors.append('ADS_OR_POST_AGM_NOT_CLEARED')
    elif sec==CVX:
        required={'q2_equity','q1_equity','rsu_terms','q2_cash_dividend','hess_scope','esip_plan_scope','hess_plan_scope'}
        if not required<=set(by): errors.append('MISSING_COMMON_QUANTITY_PRIMARY')
        else:
            text=by['q2_equity']['primary_excerpt']
            for term in ['Balance at March 31 2,442,676,580','Balance at June 30 2,442,676,580','Stock dividends — ( 11 ) — — ( 11 ) — ( 11 )','Purchases — ( 16,255,113 ) ( 16,255,113 )','Issuances — 428,655 428,655','14,168,000 shares associated with Chevron’s Benefit Plan Trust for all periods']:
                if term not in text: errors.append('UNPROVEN_COMMON_QUANTITY_ROLLFORWARD')
        expected={'issued_q1':2442676580,'issued_q2':2442676580,'stock_dividend_common_stock_usd_m':0,'stock_dividend_retained_earnings_usd_m':-11,'stock_dividend_treasury_usd_m':0,'treasury_purchased_units':16255113,'treasury_reissued_units':428655,'outstanding_q1':1991597732,'outstanding_q2':1975771274,'pro_rata_share_factor_required':False,'exact_11m_award_attribution':'NOT_ESTABLISHED_OR_REQUIRED'}
        if proof.get('equity_quantities')!=expected: errors.append('COMMON_QUANTITY_INTERPRETATION_CONFLICT')
        if proof.get('stock_dividend_scope')!='ACCOUNTING_EQUITY_ITEM_NOT_PRO_RATA_COMMON_SHARE_QUANTITY_EVENT': errors.append('STOCK_DIVIDEND_SCOPE_NOT_CLEARED')
    return sorted(set(errors))

class ClosedPilotEngine(FixedPilotEngine):
    def __init__(self, proofs=None, reviews=None):
        super().__init__()
        self.prior_certificates=copy.deepcopy(self.certificates)
        expanded,catalog=resources()
        self.scopes[CVX]=expanded[CVX];self.catalog.update(catalog)
        self.proofs=load('closure-proofs.json') if proofs is None else proofs
        overlay=load('coverage-manual-reviews.json') if reviews is None else reviews
        if set(self.proofs)!=ALLOWED or set(overlay)!=ALLOWED: raise ValueError('ONLY_TWO_PACKET_OVERLAY_ALLOWED')
        indexed={(d['document_url'],d['document_hash']):d for d in documents()}
        self.catalog[PDF_URL]=PDF_SHA
        for sec in sorted(ALLOWED):
            errors=validate_proof(self.proofs[sec],self.scopes[sec],indexed)
            scope=augmented(self.scopes[sec],self.proofs[sec]);self.scopes[sec]=scope
            self.reviews[sec]=overlay[sec]
            cert=certificate(*scope,overlay[sec],self.catalog)
            cert['closure_proof_sha256']=sha(self.proofs[sec])
            cert['supplemental_primary_refs']=overlay[sec].get('supplemental_primary_refs',[])
            if errors:cert.update(state='UNKNOWN',events=[],failed_checks=sorted(set(cert['failed_checks']+errors)))
            self.certificates[sec]=cert
        self.engine.adapter.source_hashes=self.catalog
        assert all(self.certificates[s]==self.prior_certificates[s] for s in set(self.certificates)-ALLOWED)

def result():
    e=ClosedPilotEngine(); prior=read('pilot-results.json');rs=[e.evaluate(cid) for cid in e.selection['comparison_ids']]
    old={r['comparison_id']:r for r in prior['comparison_results']}
    assert len(rs)==501 and len(e.certificates)==66 and len({e.engine.rows[c]['manager_id'] for c in e.ids})==19
    assert sha(e.selection)=='93c6596bf8fcc5c9c26b0dcbb56c47a8743c62336d095f479ffb6f80fa647145'
    for r in rs:
        if r['security_id'] not in ALLOWED: assert r==old[r['comparison_id']],'PRESERVED_COMPARISON_CHANGED'
    now=[r for r in rs if r['reported_status']!='INDETERMINATE']
    newly=[r for r in now if old[r['comparison_id']]['reported_status']=='INDETERMINATE']
    assert len(newly)<=19 and {r['security_id'] for r in newly}<=ALLOWED
    assert all(r['reported_status'] in ['REPORTED_INCREASED','REPORTED_REDUCED','REPORTED_UNCHANGED'] for r in newly)
    assert all(r['reported_status']=='INDETERMINATE' for r in rs if r['security_id'] in ['31428X106|LONG|SH','084670108|LONG|SH'])
    manual=load('new-manual-comparison-checks.json')
    validate_manual(manual,e.proofs)
    expectations=dict(prior['manual_expected_by_comparison_id'])
    for cid,m in manual['reviews'].items():
        assert m['packet_proof_sha256']==sha(e.proofs[m['security_id']])
        assert m['normalization_factor']=='1/1' and m['primary_rows_visually_or_textually_reviewed'] is True
        expectations[cid]=m['expected_result']
    fp=[r['comparison_id'] for r in now if r['comparison_id'] in expectations and r['reported_status']!=expectations[r['comparison_id']]]
    if any(e.certificates[s]['state'].startswith('VERIFIED_CLEAR') for s in ALLOWED):
        assert {m['security_id'] for m in manual['reviews'].values()}==ALLOWED
    node=load('high-leverage-primary-node-review.json')
    assert node['security_id']==TSM and node['evidence_fingerprint']==e.reviews[TSM]['evidence_fingerprint'] and node['node_manually_reviewed'] is True
    gate=pilot_gate(list(e.certificates.values()),set(e.certificates),len(fp))
    return {'state':'FIXED_PILOT_EVIDENCE_COVERAGE_PASS' if gate['state']=='PASS' else 'FIXED_PILOT_EVIDENCE_COVERAGE_INCOMPLETE',
        'selection_sha256':sha(e.selection),'fixed_comparisons':501,'fixed_securities':66,'fixed_managers':19,
        'gate':gate,'pilot_resolved_before':468,'pilot_newly_resolved':len(newly),'pilot_total_resolved':len(now),'pilot_still_indeterminate':501-len(now),
        'resolved_status_counts':dict(Counter(r['reported_status'] for r in now)),
        'newly_resolved_status_counts':dict(Counter(r['reported_status'] for r in newly)),
        'manual_comparison_check_count':len(expectations),'new_manual_checks':len(manual['reviews']),
        'false_positives_observed':len(fp),'new_false_positives_observed':sum(cid in manual['reviews'] for cid in fp),'false_positive_ids':fp,
        'statistical_zero_error_claim':False,'manual_expected_by_comparison_id':expectations,
        'preserved_packet_count':64,'global_expansion_performed':False,'global_resolved_preserved':9,'global_indeterminate_preserved':8128,
        'comparison_results':rs}, list(e.certificates.values())

if __name__=='__main__':
    out,certs=result();save('pilot-results.json',out);save('corporate-event-coverage.json',certs)
    save('expansion-gate.json',{'state':'NOT_EXECUTED','reason':'GLOBAL_EXPANSION_FORBIDDEN_EVEN_AFTER_PILOT_PASS','comparisons_applied':0})
    print(canonical({k:v for k,v in out.items() if k not in ['comparison_results','manual_expected_by_comparison_id']}))

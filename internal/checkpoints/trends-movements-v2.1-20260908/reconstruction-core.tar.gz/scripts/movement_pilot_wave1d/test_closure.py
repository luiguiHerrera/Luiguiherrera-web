import unittest
from closure import *

class ClosureGuards(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scopes,cls.catalog=resources();cls.proofs=load('closure-proofs.json')
        cls.indexed={(d['document_url'],d['document_hash']):d for d in documents()}
    def verify(self,p,sec=TSM,scope=None,body=None):
        return validate_proof(p,self.scopes[sec] if scope is None else scope,self.indexed,body)
    def test_valid_primary_packets(self):
        for sec in ALLOWED:self.assertEqual(self.verify(self.proofs[sec],sec),[])
    def test_altered_original_pdf_fails_closed(self):
        self.assertIn('EXACT_USER_PDF_MISMATCH',self.verify(self.proofs[TSM],body=PDF_PATH.read_bytes()+b'x'))
    def test_agm_intent_is_not_quarter_coverage(self):
        p=copy.deepcopy(self.proofs[TSM]);p['sections']=[x for x in p['sections'] if x['label']=='agm_sec']
        self.assertIn('MISSING_ADS_OR_POST_AGM_PRIMARY',self.verify(p))
    def test_missing_post_agm_accession(self):
        p=copy.deepcopy(self.proofs[TSM]);p['accession_reviews']=[r for r in p['accession_reviews'] if not r['accession'].endswith('000541')]
        self.assertIn('INCOMPLETE_ACCESSION_REVIEW',self.verify(p))
    def test_disclosure_window_cannot_end_at_agm(self):
        p=copy.deepcopy(self.proofs[TSM]);p['disclosure_window'][1]='2026-06-04'
        self.assertIn('WRONG_CLOSURE_WINDOW',self.verify(p))
    def test_ratio_is_not_interquarter_factor(self):
        p=copy.deepcopy(self.proofs[TSM]);p['normalization_factor']='5/1'
        self.assertIn('UNSUPPORTED_NEW_FACTOR',self.verify(p))
    def test_common_only_review_rejected(self):
        p=copy.deepcopy(self.proofs[TSM]);p['ads_or_common_holder_scope_reviewed']=False
        self.assertIn('INCOMPLETE_CLOSURE_ATTESTATION',self.verify(p))
    def test_changed_ads_ratio_rejected(self):
        p=copy.deepcopy(self.proofs[TSM]);p['ads_common_ratio']=[1,10]
        self.assertIn('ADS_OR_POST_AGM_NOT_CLEARED',self.verify(p))
    def test_forged_excerpt_with_recomputed_hash_rejected(self):
        p=copy.deepcopy(self.proofs[TSM]);p['sections'][0]['primary_excerpt']='Each ADS represents ten common shares';p['sections'][0]['excerpt_sha256']=sha(p['sections'][0]['primary_excerpt'])
        self.assertIn('UNBOUND_CLOSURE_SECTION',self.verify(p))
    def test_omitted_rsa_scope_rejected(self):
        p=copy.deepcopy(self.proofs[TSM]);p['sections']=[x for x in p['sections'] if x['label']!='june25_cancellation']
        self.assertIn('MISSING_ADS_OR_POST_AGM_PRIMARY',self.verify(p))
    def test_share_capital_amendment_cannot_be_cleared(self):
        p=copy.deepcopy(self.proofs[TSM]);p['agm']['articles_amendment']='SHARE_CAPITAL_AMENDMENT'
        self.assertIn('UNPROVEN_AGM_SCOPE',self.verify(p))
    def test_changed_inventory_invalidates_attestation(self):
        scope=copy.deepcopy(self.scopes[TSM]);scope[2]['entries'].pop()
        self.assertIn('STALE_OWNED_INVENTORY',self.verify(self.proofs[TSM],scope=scope))
    def test_missing_q2_equity_not_cleared_by_label(self):
        p=copy.deepcopy(self.proofs[CVX]);p['sections']=[x for x in p['sections'] if x['label']!='q2_equity']
        self.assertIn('MISSING_COMMON_QUANTITY_PRIMARY',self.verify(p,CVX))
    def test_missing_plan_scope_not_cleared(self):
        p=copy.deepcopy(self.proofs[CVX]);p['sections']=[x for x in p['sections'] if x['label']!='esip_plan_scope']
        self.assertIn('MISSING_COMMON_QUANTITY_PRIMARY',self.verify(p,CVX))
    def test_changed_issued_units_rejected(self):
        p=copy.deepcopy(self.proofs[CVX]);p['equity_quantities']['issued_q2']+=1
        self.assertIn('COMMON_QUANTITY_INTERPRETATION_CONFLICT',self.verify(p,CVX))
    def test_retained_earnings_cannot_be_issued_units(self):
        p=copy.deepcopy(self.proofs[CVX]);p['equity_quantities']['stock_dividend_common_stock_usd_m']=11
        self.assertIn('COMMON_QUANTITY_INTERPRETATION_CONFLICT',self.verify(p,CVX))
    def test_treasury_factor_rejected(self):
        p=copy.deepcopy(self.proofs[CVX]);p['normalization_factor']='1975771274/1991597732'
        self.assertIn('UNSUPPORTED_NEW_FACTOR',self.verify(p,CVX))
    def test_unproven_exact_award_attribution_rejected(self):
        p=copy.deepcopy(self.proofs[CVX]);p['equity_quantities']['exact_11m_award_attribution']='ALL_RSU'
        self.assertIn('COMMON_QUANTITY_INTERPRETATION_CONFLICT',self.verify(p,CVX))
    def test_manual_quantities_bound_to_original_xml(self):
        p=copy.deepcopy(load('new-manual-comparison-checks.json'));next(iter(p['reviews'].values()))['q1_reported_quantity']+=1
        with self.assertRaises(AssertionError):validate_manual(p,self.proofs)
    def test_fixed_pilot_and_preserved_64_packets(self):
        r,certs=result()
        self.assertEqual((r['pilot_newly_resolved'],r['pilot_total_resolved'],r['pilot_still_indeterminate']),(19,487,14))
        self.assertEqual(r['gate']['state'],'PASS');self.assertEqual(r['false_positives_observed'],0)
        prior={c['security_id']:c for c in read('corporate-event-coverage.json')}
        self.assertTrue(all(c==prior[c['security_id']] for c in certs if c['security_id'] not in ALLOWED))
    def test_no_expansion_or_extra_packet(self):
        p=copy.deepcopy(self.proofs);p['084670108|LONG|SH']=p[TSM]
        with self.assertRaisesRegex(ValueError,'ONLY_TWO_PACKET'):ClosedPilotEngine(proofs=p)
        e=ClosedPilotEngine()
        with self.assertRaisesRegex(ValueError,'OUTSIDE_FIXED'):e.evaluate('outside-pilot')
    def test_changed_proof_leaves_only_target_unknown(self):
        p=copy.deepcopy(self.proofs);p[TSM]['ads_common_ratio']=[1,10];e=ClosedPilotEngine(proofs=p)
        self.assertEqual(e.certificates[TSM]['state'],'UNKNOWN')
        self.assertEqual(e.certificates[CVX]['state'],'VERIFIED_CLEAR_FOR_COMPARABILITY')
        self.assertEqual(e.evaluate('ariel::'+TSM)['reported_status'],'INDETERMINATE')
    def test_supplement_is_not_sec_owned_or_new_event(self):
        e=ClosedPilotEngine();c=e.certificates[TSM]
        self.assertEqual(c['events'],[])
        self.assertTrue(all('sec.gov/' in r['source_url'] for r in c['reviewed_source_refs']))
        self.assertFalse(c['supplemental_primary_refs'][0]['sec_link_asserted'])
        self.assertFalse(any(d['document_url']==PDF_URL for d in e.scopes[TSM][4]))

if __name__=='__main__':unittest.main()

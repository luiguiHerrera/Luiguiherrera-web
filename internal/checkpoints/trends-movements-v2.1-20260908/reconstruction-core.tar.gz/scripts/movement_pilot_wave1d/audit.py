"""Offline replay, custody, source reconstruction and unchanged-public-files audit."""
from closure import *
import gzip, subprocess
from unittest.mock import patch
from owned_inventory import owned

def run():
    pre=load('preflight.json')
    for r in pre['preserved_files']:
        assert sha((ROOT/r['path']).read_bytes())==r['sha256'],('PRESERVED_FILE_CHANGED',r['path'])
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==pre['base_commit']
    assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip()
    assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
    subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
    corpus=gzip.decompress((ROOT/'internal/trends-movements/v2.1/corpus.jsonl.gz').read_bytes())
    assert sha(corpus)=='d270f69dc303daa6d694fbafa6d4c91166cdcfb60c4e1fb5bc90b105b5143ac3' and len(corpus.splitlines())==8137
    public_sha=sha((ROOT/'lib/trends/capital/generated/snapshot.json.gz').read_bytes())
    assert public_sha=='42d0ac9e2168dec775d589d255c13052fcf757f83e89c688ebbd117b3490274a'
    scopes,catalog=resources();s=Store();D=documents();bodies={};parsed={};counts={}
    for sec in sorted(ALLOWED):
        b,c,inv,groups,docs=scopes[sec];current=owned(c['issuer_cik'],s)
        expected_entries=current['entries']
        if sec==CVX:expected_entries=sorted(expected_entries+[x for x in current['all_owned_entries'] if x['form']=='11-K'],key=lambda e:(e['filing_date'],e['accession']))
        assert expected_entries==inv['entries'] and current['all_associated_entries']==inv['all_associated_entries']
        assert current['inventory_complete'] and not current['missing_history_shards']
        selected=[d for d in D if d['issuer_cik']==c['issuer_cik']]
        for d in selected:
            u=d['source_ref']['source_url']
            extra={r['source_url']:r for r in load('additional-sec-source-manifest.json')}
            if u not in bodies:bodies[u]=(OUT/extra[u]['path']).read_bytes() if u in extra else s.bytes(u)
            assert sha(bodies[u])==d['source_ref']['sha256']
            if d['hash_domain']=='ORIGINAL_DOCUMENT_BYTES':
                assert sha(bodies[u])==d['document_hash'];raw=bodies[u].decode('utf-8',errors='replace')
            else:
                if u not in parsed:parsed[u]={sha(x.encode()):x for x in re.findall(r'<DOCUMENT>(.*?)</DOCUMENT>',bodies[u].decode('utf-8',errors='replace'),re.S|re.I)}
                assert d['document_hash'] in parsed[u]
                block=parsed[u][d['document_hash']];match=re.search(r'<TEXT>(.*)</TEXT>',block,re.S|re.I);raw=match[1] if match else ''
            if d.get('mode')=='TEXT':assert visible(raw)==d['text'],('PRIMARY_NARRATIVE_DIVERGES',d['document_url'])
        counts[sec]={'owned_accessions':len(expected_entries),'all_associated_accessions':len(current['all_associated_entries']),'checked_historical_shards':len(current['historical_submission_files_checked']),'primary_document_records':len(selected),'forms_observed':inv['forms_observed'],'submissions_ref':current['submissions_ref']}
    body=PDF_PATH.read_bytes();assert sha(body)==PDF_SHA and len(body)==4368300
    for p in load('closure-proofs.json').values():
        for n,h in p.get('agm',{}).get('render_hashes',{}).items():assert sha((OUT/f'qa/agm-{int(n):02d}.png').read_bytes())==h
    validate_manual(load('new-manual-comparison-checks.json'),load('closure-proofs.json'))
    def no_network(*args,**kwargs):raise AssertionError('NETWORK_FORBIDDEN_DURING_REPLAY')
    with patch('socket.socket',no_network),patch('socket.create_connection',no_network):
        a,ca=result();b,cb=result()
    assert a==b and ca==cb
    assert a==load('pilot-results.json') and ca==load('corporate-event-coverage.json')
    for p in list((ROOT/'.next/static').rglob('*'))+list((ROOT/'.next/server/app').rglob('*.nft.json')):
        if p.is_file():assert not any(t in p.read_bytes() for t in [b'wave1d',b'internal/trends-movements',b'pilot-results.json']),('PUBLIC_INTERNAL_LEAK',str(p))
    r={'state':'PASS','preserved_files_unchanged':len(pre['preserved_files']),'prior_packets_unchanged':64,'prior_comparison_results_unchanged':482,'corpus_count':8137,'corpus_sha256':sha(corpus),'public_snapshot_sha256':public_sha,'tracked_or_staged_changes':0,'head_unchanged':pre['base_commit'],'new_sec_holdings_fetches':0,'new_sec_event_fetches':0,'user_pdf_exact_bytes':len(body),'user_pdf_sha256':PDF_SHA,'sec_primary_source_urls_rehashed':len(bodies),'issuer_inventory_reconstruction':counts,'offline_replay_passes':2,'network_disabled_during_replay':True,'manual_attestation_not_reexecuted':True,'replayed_results_sha256':sha(a),'replayed_certificates_sha256':sha(ca),'global_expansion_performed':False,'public_bundle_internal_matches':0}
    r['new_sec_event_fetches']=2;r['new_sec_event_bytes']=sum(x['bytes'] for x in load('additional-sec-source-manifest.json'))
    save('final-source-and-isolation-audit.json',r);print(canonical(r))

if __name__=='__main__':run()

"""Emit the requested review output; this does not publish or authorize expansion."""
from closure import *

def run():
    r=load('pilot-results.json');audit=load('final-source-and-isolation-audit.json');proof=load('closure-proofs.json')
    checks=[json.loads(p.read_text()) for p in sorted(OUT.glob('validation-*.json'))]
    expected={'app-tests','baseline-python','wave1-python','wave1b-python','xml','wave1c-python','wave1d-python','typecheck','lint','build','seo','snapshot','git-diff-check'}
    assert {c['name'] for c in checks}==expected and all(c['exit_code']==0 for c in checks)
    tests=0
    for c in checks:
        body=(OUT/c['log']).read_bytes();assert sha(body)==c['log_sha256']
        if c['name'] in {'app-tests','baseline-python','wave1-python','wave1b-python','xml','wave1c-python','wave1d-python'}:
            match=re.search(r'# pass (\d+)',body.decode()) if c['name']=='app-tests' else re.search(r'Ran (\d+) tests?',body.decode())
            assert match,c['name'];tests+=int(match[1])
    assert audit['state']=='PASS' and r['gate']['state']=='PASS' and r['false_positives_observed']==0
    save('validation.json',{'state':'PASS','tests_passed':tests,'checks':checks,'source_and_isolation_audit_sha256':sha(audit),'lint_warnings_existing':17})
    values={
      'STATE':r['state'],'TSMC_AGM_PDF_SHA256':PDF_SHA,'TSMC_AGM_PDF_SIZE':4368300,'TSMC_AGM_DOCUMENT_DATE':'2026-06-04','TSMC_AGM_EVIDENCE_RETAINED':'YES',
      'NO_SPLIT_INTENT_AS_OF_2026_06_04':'VERIFIED','JUNE_4_ARTICLES_AMENDMENT':'NON_SHARE_CAPITAL_AMENDMENT',
      'TSMC_COMMON_EVENT_STATE':'VERIFIED_CLEAR_FOR_COMPARABILITY; RECLAIMED_RSA_CANCELLATION_SCOPED',
      'TSMC_ADS_RATIO_STATE':'VERIFIED_UNCHANGED_Q2; 1_ADS_TO_5_COMMON_SHARES',
      'TSMC_CLASS_STATE':'VERIFIED_UNCHANGED_ADS_CLASS_AND_CUSIP_874039100',
      'TSMC_POST_JUNE4_EVENT_STATE':'VERIFIED_CLEAR_FOR_Q2_COMPARABILITY',
      'TSMC_PACKET':'VERIFIED_CLEAR_FOR_COMPARABILITY','TSMC_NORMALIZATION_FACTOR':'1/1',
      'CHEVRON_ISSUED_SHARES_Q1_END':2442676580,'CHEVRON_ISSUED_SHARES_Q2_END':2442676580,
      'STOCK_DIVIDEND_COMMON_STOCK_COLUMN_EFFECT':'USD_0','RETAINED_EARNINGS_EFFECT':'USD_-11000000',
      'TREASURY_SHARE_EFFECT':'STOCK_DIVIDEND_LINE=0; PURCHASES=-16255113; REISSUANCES=428655',
      'PRO_RATA_SHARE_FACTOR_REQUIRED':'NO','CHEVRON_STOCK_DIVIDEND_SCOPE':proof[CVX]['stock_dividend_scope'],
      'CHEVRON_NORMALIZATION_FACTOR':'1/1','CHEVRON_PACKET':'VERIFIED_CLEAR_FOR_COMPARABILITY',
      'PILOT_PACKET_CLEAR':64,'PILOT_PACKET_EVENT_NORMALIZED':0,'PILOT_PACKET_VERIFIED_BLOCK':2,'PILOT_PACKET_UNKNOWN':0,'PILOT_EVIDENCE_COVERAGE':'PASS',
      'PILOT_RESOLVED_BEFORE':468,'PILOT_NEWLY_RESOLVED':r['pilot_newly_resolved'],'PILOT_TOTAL_RESOLVED':r['pilot_total_resolved'],'PILOT_STILL_INDETERMINATE':r['pilot_still_indeterminate'],
      'PILOT_REPORTED_INCREASED':r['resolved_status_counts']['REPORTED_INCREASED'],'PILOT_REPORTED_REDUCED':r['resolved_status_counts']['REPORTED_REDUCED'],'PILOT_REPORTED_UNCHANGED':r['resolved_status_counts']['REPORTED_UNCHANGED'],
      'PILOT_MANUAL_CHECKS':r['manual_comparison_check_count'],'NEW_MANUAL_CHECKS':2,'NEW_FALSE_POSITIVES':0,'PILOT_FALSE_POSITIVES':0,'STATISTICAL_ZERO_ERROR_CLAIM':'NO',
      'GLOBAL_TOTAL_RESOLVED':9,'GLOBAL_STILL_INDETERMINATE':8128,'GLOBAL_EXPANSION_PERFORMED':'NO',
      'MOVEMENT_PUBLICATION':'REVIEW_PENDING','MOVEMENT_UI_PRESENT':'NO','MOVEMENT_FIELDS_PUBLIC':'NONE','PUBLIC_DATA_CHANGED':'NO','PUBLIC_SNAPSHOT_CHANGED':'NO','SEC_HOLDINGS_REFRESH':'NO',
      'COMMIT':'NO','PUSH':'NO','DEPLOY':'NO','TESTS':f'PASS ({tests})','TYPECHECK':'PASS','LINT':'PASS (17 existing warnings)','BUILD':'PASS','GIT_DIFF_CHECK':'PASS',
      'PRODUCTION_READINESS':'NOT_READY','NEXT_RECOMMENDED_STEP':'REVIEW_FIXED_PILOT_RESULTS; EXPLICIT_AUTHORIZATION_REQUIRED_BEFORE_ANY_GLOBAL_EXPANSION'}
    save('requested-output.json',values)
    lines=['**Wave 1D — cierre del piloto fijo para revisión**','',
      'La cobertura de evidencia pasa para las mismas 501 comparaciones, 66 valores y 19 gestores. Solo cambian los paquetes TSMC ADS y Chevron common; se preservan los otros 64 certificados y las 482 comparaciones ajenas a esos dos valores. Las 14 comparaciones bloqueadas corresponden a FedEx common (8) y Berkshire A (6).',
      '', '```text']+[f'{k}={v}' for k,v in values.items()]+['```','',
      'TSMC: el acta aporta evidencia puntual de intención el 4 de junio y el texto operativo de la reforma, que solo cambia el número de consejeros y la fecha de modificación. El cierre trimestral también exige el inventario SEC del 1 de marzo al 14 de agosto, los informes de ambos cierres y las condiciones del depositario. El contrato establece 1 ADS = 5 acciones ordinarias; ambos informes muestran 1.062.690 miles de ADS y 5.313.451 miles de acciones subyacentes. Esos totales redondeados corroboran la ratio contractual y no se usan para calcularla. La cancelación de 154.454 acciones de remuneración, efectiva el 12 de mayo y reportada el 25 de junio, afecta acciones recuperadas de empleados; no genera un factor para los ADS existentes.',
      '', 'El PDF de 43 páginas conserva sus 4.368.300 bytes exactos. Se comprobaron visualmente las páginas 4, 6, 38 y 39. La extracción OCR se guarda como auxiliar; el PDF es la fuente. Su custodia se identifica como documento primario aportado por el usuario. El 6-K del 4 de junio corrobora la junta y su aprobación: no se presenta el PDF como archivo SEC ni como enlace contenido en ese 6-K. El certificado lo vincula por hash mediante la prueba suplementaria.',
      '', 'Chevron: el estado de patrimonio conserva 2.442.676.580 acciones emitidas. La línea de dividendos de acciones registra −11 millones de USD en resultados retenidos, sin efecto en las columnas de capital o tesorería. Las acciones en circulación se concilian como 1.991.597.732 − 16.255.113 + 428.655 = 1.975.771.274. Los 14.168.000 títulos del Benefit Plan Trust están incluidos en todos los saldos emitidos. Los términos de RSU y los dos 11-K de planes distinguen prestaciones, elecciones de reinversión y conversiones históricas de un reparto proporcional a todos los titulares. No se atribuyen los 11 millones a un plan concreto. El factor para las unidades common existentes es 1/1.',
      '', 'Reconstrucciones nuevas leídas directamente en las cuatro filas XML de Ariel:', '',
      '| Valor | CUSIP / clase | Q1 | Q2 | Factor | Diferencia | Resultado |',
      '|---|---|---:|---:|---|---:|---|',
      '| TSMC | 874039100 / SPONSORED ADS | 16.092 | 17.838 | 1/1 | +1.746 | REPORTED_INCREASED |',
      '| Chevron | 166764100 / COM | 41.499 | 34.626 | 1/1 | −6.873 | REPORTED_REDUCED |',
      '', 'Hay 73 comprobaciones manuales acumuladas con resultado evaluable, incluidas estas dos nuevas. Se observaron cero falsos positivos en esas comprobaciones; no es una estimación estadística de error cero. Las nuevas 19 resoluciones se reparten en 6 aumentos, 10 reducciones y 3 sin cambio de cantidad reportada.',
      '', 'Fuentes principales y trazabilidad:', '',
      '- [TSMC: junta, 6-K del 4 de junio](https://www.sec.gov/Archives/edgar/data/1046179/000104617926000302/tsm-agmx20260604x6k.htm).',
      '- [TSMC: condiciones de los ADS, Exhibit 2.1](https://www.sec.gov/Archives/edgar/data/1046179/000162828026025362/exhibit21.htm).',
      '- [TSMC: Q1, Note 21](https://www.sec.gov/Archives/edgar/data/1046179/000104617926000278/a2026q1consolidatedreport-.htm) y [Q2, Note 21](https://www.sec.gov/Archives/edgar/data/1046179/000104617926000541/a2026q2consolidatedreport-.htm).',
      '- [Chevron: 10-Q Q2, estado de patrimonio y notas](https://www.sec.gov/Archives/edgar/data/93410/000009341026000167/cvx-20260630.htm).',
      '- [Chevron ESIP: 11-K, Note 1](https://www.sec.gov/Archives/edgar/data/93410/000009341026000158/cvx-20260624.htm) y [Hess savings plan: 11-K, Note 1](https://www.sec.gov/Archives/edgar/data/93410/000009341026000160/hes-20260624.htm).',
      '', f'La auditoría vuelve a construir ambos inventarios desde las respuestas SEC conservadas y verifica los cuerpos originales y los bloques de documentos. Preserva {audit["preserved_files_unchanged"]} archivos previos por hash, el HEAD, el corpus de 8.137 comparaciones y el snapshot público. Dos repeticiones sin red producen el mismo resultado. Se descargaron únicamente dos 11-K adicionales para esta revisión; no se actualizaron posiciones 13F.',
      '', 'Detalle de los formularios relevantes revisados; la clasificación se refiere a su efecto sobre las unidades de los dos valores del piloto:', '',
      '| Emisor | Fecha | Formulario / accession | Alcance revisado |','|---|---|---|---|']
    for sec in [TSM,CVX]:
        for x in proof[sec]['accession_reviews']:
            lines.append(f'| {"TSMC" if sec==TSM else "Chevron"} | {x["filing_date"]} | {x["form"]} / {x["accession"]} | {x["primary_reason"]} |')
    lines += ['', 'El inventario completo también contabiliza formularios de insiders y titulares, informes de minerales de conflicto, reportes de posiciones/votos y material anual fuera de la selección de formularios corporativos. Los dos 11-K se incorporaron por su relevancia al alcance de planes; no alteran la selección del piloto.', '', 'Reproducción local: `python3 -B scripts/movement_pilot_wave1d/closure.py`; auditoría: `python3 -B scripts/movement_pilot_wave1d/audit.py`. Las atestaciones manuales no se vuelven a generar durante la repetición. Todos los artefactos de Wave 1D están en este directorio y el código está en `scripts/movement_pilot_wave1d` del worktree aislado. No se ha realizado commit, push ni deploy.']
    (OUT/'REVIEW.md').write_text('\n'.join(lines)+'\n')
    print(canonical({'state':values['STATE'],'tests':tests,'report':str(OUT/'REVIEW.md')}))

if __name__=='__main__':run()

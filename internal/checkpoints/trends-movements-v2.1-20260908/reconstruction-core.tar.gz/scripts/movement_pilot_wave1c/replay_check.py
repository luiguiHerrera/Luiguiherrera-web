"""Prove deterministic evaluation without network or automatic manual attestation."""
from context import *
from pilot_engine import run

def check():
    names=['corporate-event-coverage.json','pilot-results.json','sector-coverage.json','expansion-gate.json']
    before={n:sha((OUT/n).read_bytes()) for n in names}
    def forbidden(*args,**kwargs):raise AssertionError('NETWORK_FORBIDDEN_DURING_REPLAY')
    urllib.request.urlopen=forbidden
    run()
    after={n:sha((OUT/n).read_bytes()) for n in names}
    assert before==after,'NONDETERMINISTIC_PILOT_REPLAY'
    write('offline-replay-check.json',{'state':'PASS','network_disabled':True,'deterministic_output_hashes':after,'manual_attestation_not_reexecuted':True})
    print('OFFLINE_DETERMINISTIC_REPLAY_PASS')

if __name__=='__main__':check()

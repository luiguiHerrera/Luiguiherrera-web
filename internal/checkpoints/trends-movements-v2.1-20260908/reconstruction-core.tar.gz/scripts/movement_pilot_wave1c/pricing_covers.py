"""Bounded document-cover discovery. Prefix bytes can prove product scope, never event clearance."""
from concurrent.futures import ThreadPoolExecutor,as_completed
import threading
from context import *
LIMIT=32768

def run():
    entries=read('primary-event-document-plan.json')['pricing_prospectus_class_triage_pending']
    previous=read('pricing-cover-index.json') if (OUT/'pricing-cover-index.json').exists() else {'records':[]}
    retained={r['accession']:r for r in previous['records']};lock=threading.Lock();last=[0.0]
    def get(e):
        if e['accession'] in retained:return retained[e['accession']]
        url=e['primary_url'];assert url.startswith('https://www.sec.gov/Archives/edgar/data/')
        with lock:
            delay=max(0,.22-(time.monotonic()-last[0]));time.sleep(delay);last[0]=time.monotonic()
        req=urllib.request.Request(url,headers={'User-Agent':'LHI Trends research (https://www.luiguiherrera.com)','Accept-Encoding':'identity','Range':f'bytes=0-{LIMIT-1}'})
        with urllib.request.urlopen(req,timeout=30) as r:
            assert urllib.parse.urlparse(r.url).hostname=='www.sec.gov'
            b=r.read(LIMIT);status=r.status;headers={k:r.headers.get(k) for k in ['Content-Length','Content-Range','Content-Type']}
        if b'Your Request Originates from an Undeclared Automated Tool' in b:raise ValueError('SEC_BLOCK_PAGE')
        h=sha(b);path='sources/'+h+'.prefix.raw.gz';packed=gzip.compress(b,mtime=0);(OUT/path).write_bytes(packed)
        # Many Inline XBRL files have long resource headers. Such prefixes stay unclassified.
        text=visible(b.decode('utf-8',errors='replace'))
        return {'accession':e['accession'],'issuer_cik':e['issuer_cik'],'form':e['form'],'filing_date':e['filing_date'],'document_url':url,'document_type':'PRICING_PROSPECTUS_PREFIX_FOR_CLASS_DISCOVERY','source_hash':h,'hash_domain':'EXACT_RETAINED_RESPONSE_PREFIX; NOT_FULL_DOCUMENT','path':path,'bytes_received':len(b),'bytes_retained':len(packed),'request_range':f'bytes=0-{LIMIT-1}','response_status':status,'response_headers':headers,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':text,'full_document_retained':headers.get('Content-Length') is not None and int(headers['Content-Length'])<=len(b) and status==200,'allowed_use':'POSITIVE_PRODUCT_CLASS_PROOF_ONLY; CANNOT_VERIFY_EVENT_OR_NEGATIVE_EVENT_COVERAGE'}
    failures=[]
    with ThreadPoolExecutor(max_workers=3) as pool:
        pending={pool.submit(get,e):e for e in entries}
        for f in as_completed(pending):
            e=pending[f]
            try:r=f.result();retained[e['accession']]=r
            except Exception as ex:failures.append({'accession':e['accession'],'error':str(ex)})
            if len(retained)%25==0:write('pricing-cover-index.json',{'records':sorted(retained.values(),key=lambda x:x['accession']),'failures':failures});print('PRICING_COVERS',len(retained),flush=True)
    write('pricing-cover-index.json',{'records':sorted(retained.values(),key=lambda x:x['accession']),'failures':failures,'planned':len(entries),'max_bytes_per_document':LIMIT,'method':'Bounded cover retrieval, maximum 3 concurrent and at most one new request per 220ms. Partial sources are explicitly typed and cannot verify events.'})
    print('DONE',len(retained),'FAILURES',failures,flush=True)
if __name__=='__main__':run()

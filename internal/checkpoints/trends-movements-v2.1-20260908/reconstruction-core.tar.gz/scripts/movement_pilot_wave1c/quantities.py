"""Reconstruct frozen 13F quantities independently of movement classification."""
from decimal import Decimal
from collections import defaultdict
from context import *

def run():
    sys.path.insert(0,str(ROOT/'scripts/movement_evidence_wave1'));from build import load
    a=load();ids=set(selection()['comparison_ids']);rows=[r for r in a.rows if r['comparison_id'] in ids];out=[];bysec=defaultdict(list)
    for row in sorted(rows,key=lambda r:r['comparison_id']):
        proof={}
        for side in ['previous','current']:
            raw=[]
            for u in row[side+'_sources']:
                for r in a.raw[u]['rows'].get(row['security_id'],[]):raw.append({**r,'source_url':u,'source_sha256':a.sources[u]['sha256'],'accession':u.rsplit('/',1)[-1].removesuffix('.txt')})
            total=sum((Decimal(r['quantity']) for r in raw),Decimal(0));assert total==Decimal(str(row[side+'_quantity']))
            proof[side]={'raw_rows':raw,'sum_quantity':str(total),'quarter':row[side+'_quarter'],'unit':row['instrument_type']}
        prev=Decimal(proof['previous']['sum_quantity']);cur=Decimal(proof['current']['sum_quantity'])
        item={'comparison_id':row['comparison_id'],'security_id':row['security_id'],'manager_id':row['manager_id'],'primary_observations':proof,'raw_arithmetic_status':'REPORTED_INCREASED' if cur>prev else 'REPORTED_REDUCED' if cur<prev else 'REPORTED_UNCHANGED','semantic_qualification':'CONDITIONAL_ON_INDEPENDENT_SECURITY_EVENT_CERTIFICATE; NOT_A_MOVEMENT_DECISION'}
        out.append(item);bysec[row['security_id']].append(item)
    assert len(out)==501 and len(bysec)==66
    write('pilot-primary-quantity-reconstruction.json',out)
    reps=[]
    for sec,rs in sorted(bysec.items()):
        reps.append(min(rs,key=lambda r:(sum(len(p['raw_rows']) for p in r['primary_observations'].values()),r['comparison_id'])))
    write('pilot-manual-quantity-dossier.json',{'selection_sha256':sha(selection()),'selection_rule':'One representative from every original security family, fewest primary aggregation rows then comparison id; pilot itself unchanged.','representatives':reps})
    print('PRIMARY_RECONSTRUCTION',len(out),'FAMILY_REPRESENTATIVES',len(reps))
if __name__=='__main__':run()

"""Retained manual image/PDF supplements, bound to an existing SEC parent.

An issuer-publication PDF corroborates coverage only. It is not promoted to an
issuer-owned SEC accession or accepted by the SEC-only event verifier.
"""
from context import *

def checked_supplements(store, primary):
    path=OUT/'supplemental-primary-documents.json'
    records=read(path.name) if path.exists() else []
    for d in records:
        authority=d['ownership_authority']
        if d['hash_domain']=='EXACT_LINKED_ISSUER_PDF_BODY':
            if d.get('ownership')!='LINKED_ISSUER_PUBLICATION_NOT_SEC_OWNED':raise ValueError('SUPPLEMENT_CANNOT_BECOME_SEC_OWNED')
            parent=next((p for p in primary if p['document_url']==authority['parent_document_url'] and p['issuer_cik']==d['issuer_cik'] and p['accession']==d['parent_accession']),None)
            if not parent or parent['source_ref']!=d['source_ref'] or authority['parent_source_ref']!=d['source_ref']:raise ValueError('UNBOUND_SUPPLEMENT_PARENT')
            store.bytes(parent['source_ref']['source_url'])
            link=authority['parent_reference_text']
            if link not in (parent.get('text') or '') or link.replace('http://','https://',1)!=d['document_url']:raise ValueError('SUPPLEMENT_LINK_NOT_IN_OWNED_PARENT')
            r=authority['source_storage'];p=(OUT/r['path']).resolve()
            if not p.is_relative_to((OUT/'sources').resolve()):raise ValueError('INVALID_SUPPLEMENT_PATH')
            body=gzip.decompress(p.read_bytes())
            if r['source_url']!=d['document_url'] or sha(body)!=d['document_hash'] or r['sha256']!=d['document_hash'] or not body.startswith(b'%PDF'):raise ValueError('SUPPLEMENT_SOURCE_HASH_MISMATCH')
        else:
            if sha(store.bytes(d['document_url']))!=d['document_hash']:raise ValueError('SUPPLEMENT_SOURCE_HASH_MISMATCH')
    return records

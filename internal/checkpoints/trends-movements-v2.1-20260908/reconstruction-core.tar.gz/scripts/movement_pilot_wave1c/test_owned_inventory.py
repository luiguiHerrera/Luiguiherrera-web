import unittest
from copy import deepcopy
from owned_inventory import *

def rec(forms=['10-Q'],dates=['2026-05-01']):
    return {'accessionNumber':[f'0000000001-26-{i:06d}' for i in range(len(forms))],'form':forms,'filingDate':dates,'primaryDocument':[f'p{i}.htm' for i in range(len(forms))]}

class FakeStore:
    def __init__(self,doc,shards=None):self.doc=doc;self.shards=shards or {}
    def json(self,u):return self.shards[u] if u in self.shards else self.doc
    def ref(self,u):return {'sha256':'a'*64} if u.endswith('CIK0000000001.json') or u in self.shards else None
    def compact_ref(self,u):return {'source_url':u,'sha256':'a'*64}

class InventoryTests(unittest.TestCase):
    def doc(self,r=None):return {'cik':1,'name':'Issuer','filings':{'recent':r or rec(),'files':[]}}
    def test_owned_inventory_authority(self):
        x=owned(1,FakeStore(self.doc()));self.assertTrue(x['inventory_complete']);self.assertEqual(x['authority'],'ISSUER_SUBMISSIONS_CURRENT_AND_HISTORICAL');self.assertEqual(len(x['entries']),1)
    def test_wrong_cik_fails(self):
        with self.assertRaisesRegex(ValueError,'WRONG_SUBMISSIONS_CIK'):owned(2,FakeStore(self.doc()))
    def test_historical_shard_traversal(self):
        d=self.doc(rec(['10-Q'],['2026-09-01']));f={'name':'CIK0000000001-submissions-001.json','filingFrom':'2026-01-01','filingTo':'2026-08-01'};d['filings']['files']=[f];r=rec();r['accessionNumber']=['0000000001-26-000020'];s=FakeStore(d,{'https://data.sec.gov/submissions/'+f['name']:r});x=owned(1,s);self.assertEqual(len(x['entries']),1);self.assertEqual(len(x['historical_submission_files_checked']),1)
    def test_missing_shard_cannot_be_complete(self):
        d=self.doc();d['filings']['files']=[{'name':'CIK0000000001-submissions-001.json','filingFrom':'2026-01-01','filingTo':'2026-08-01'}];self.assertFalse(owned(1,FakeStore(d))['inventory_complete'])
    def test_other_issuer_shard_rejected(self):
        d=self.doc();d['filings']['files']=[{'name':'CIK0000000002-submissions-001.json','filingFrom':'2026-01-01','filingTo':'2026-08-01'}]
        with self.assertRaisesRegex(ValueError,'FOREIGN_HISTORY_SHARD'):owned(1,FakeStore(d))
    def test_partial_arrays_rejected(self):
        r=rec();r['form']=[]
        with self.assertRaisesRegex(ValueError,'INCOMPLETE_HISTORY_SHARD'):list(rows_from(r,'recent'))
    def test_conflicting_duplicate_rejected(self):
        r=rec(['10-Q','8-K'],['2026-05-01','2026-05-01']);r['accessionNumber'][1]=r['accessionNumber'][0]
        with self.assertRaisesRegex(ValueError,'CONFLICTING_SUBMISSION_HISTORY'):owned(1,FakeStore(self.doc(r)))
    def test_global_search_hits_not_accepted_as_index(self):
        d={'cik':1,'hits':{'hits':[{'_source':{'ciks':['1']}}]}}
        with self.assertRaises(KeyError):owned(1,FakeStore(d))
    def test_outside_disclosure_window_excluded(self):
        r=rec(['10-Q','8-K'],['2026-05-01','2026-08-15']);x=owned(1,FakeStore(self.doc(r)));self.assertEqual(len(x['entries']),1)
    def test_foreign_forms(self):
        r=rec(['20-F','6-K','F-4','8-K'],['2026-04-01']*4);x=owned(1,FakeStore(self.doc(r)));self.assertEqual(x['regime'],'FOREIGN_PRIVATE_ISSUER');self.assertIn('F-4/A',x['forms_expected']);self.assertNotIn('10-Q',x['forms_expected']);self.assertEqual(len(x['entries']),3)
    def test_foreign_domicile_not_automatic_foreign_regime(self):
        d=self.doc();d['stateOfIncorporation']='Ireland';self.assertEqual(owned(1,FakeStore(d))['regime'],'DOMESTIC_OPERATING_COMPANY')
    def test_registered_fund(self):
        d=self.doc(rec(['N-CSR'],['2026-04-01']));self.assertEqual(owned(1,FakeStore(d))['regime'],'REGISTERED_FUND_OR_TRUST')
    def test_conflicting_regime_fails_closed(self):
        d=self.doc(rec(['N-CSR','10-Q'],['2026-04-01']*2));self.assertEqual(owned(1,FakeStore(d))['regime'],'UNSUPPORTED_OR_INDETERMINATE')
    def test_empty_history_not_domestic(self):
        d=self.doc(rec([],[]));self.assertEqual(owned(1,FakeStore(d))['regime'],'UNSUPPORTED_OR_INDETERMINATE')
    def test_required_registration_forms_retained(self):
        r=rec(['10-Q','S-4','S-4/A','425','424B3','8-A12B','8-A12G'],['2026-04-01']*7);self.assertEqual(len(owned(1,FakeStore(self.doc(r)))['entries']),7)

if __name__=='__main__':unittest.main()

"""Retrieve the fixed plan's primary files, reusing earlier full submissions."""
from context import *
from documents import primary, full_documents

def run():
    s=Store();out=[];fail=[];complete=[]
    for n,e in enumerate(read('primary-event-document-plan.json')['entries'],1):
        try:
            d=primary(e,s,True);out.append({**e,**d})
            if s.ref(e['complete_submission_url']):
                for x in full_documents(e['complete_submission_url']):
                    if x['filename']==e['primary_document'] or x['mode']=='STRUCTURED_DATA':continue
                    stem=e['primary_url'].rsplit('/',1)[0]+'/'
                    out.append({'issuer_cik':e['issuer_cik'],'accession':e['accession'],'parent_accession':e['accession'],'form':e['form'],'filing_date':e['filing_date'],'document_type':x['type'],'document_url':stem+x['filename'],'text':x.get('text'),'links':x['links'],'source_ref':s.compact_ref(e['complete_submission_url']),'document_hash':x['document_block_sha256'],'hash_domain':'RETAINED_SGML_DOCUMENT_BLOCK','mode':x['mode'],'role':'ATTACHED_EXHIBIT'})
            complete.append(e['accession'])
            if n%10==0:print(n,len(out),e['issuer_cik'],flush=True)
        except Exception as ex:fail.append({'accession':e['accession'],'error':str(ex)});print('ERROR',e['accession'],str(ex),flush=True)
    (OUT/'event-primary-documents.json.gz').write_bytes(gzip.compress((canonical(out)+'\n').encode(),mtime=0))
    write('primary-event-retrieval.json',{'planned':748,'complete_primary_accessions':complete,'retained_document_records':len(out),'failures':fail,'linked_exhibits_of_new_primaries':'PENDING_TARGETED_FOLLOWUP'})
if __name__=='__main__':run()

"""SEC index candidate generation is deliberately separate from CIK verification."""
from context import *
INDEX='https://www.sec.gov/files/company_tickers_exchange.json'
# Reviewed search expansions of truncated official labels. These generate candidates only.
SEARCH_NAMES={
'036752103':'Elevance Health, Inc.','038222105':'APPLIED MATERIALS INC /DE','064058100':'Bank of New York Mellon Corp',
'084670108':'BERKSHIRE HATHAWAY INC','084670702':'BERKSHIRE HATHAWAY INC','09290D101':'BlackRock, Inc.',
'149123101':'CATERPILLAR INC','20030N101':'COMCAST CORP','22160K105':'COSTCO WHOLESALE CORP /NEW',
'235851102':'DANAHER CORP /DE/','254687106':'Walt Disney Co','31488V107':'Ferguson Enterprises Inc. /DE/',
'38141G104':'GOLDMAN SACHS GROUP INC','45866F104':'Intercontinental Exchange, Inc.','46625H100':'JPMORGAN CHASE & CO',
'57636Q104':'Mastercard Inc','615369105':'MOODYS CORP /DE/','67066G104':'NVIDIA CORP','68389X105':'ORACLE CORP',
'718172109':'Philip Morris International Inc.','882508104':'TEXAS INSTRUMENTS INC','89832Q109':'TRUIST FINANCIAL CORP',
'907818108':'UNION PACIFIC CORP','949746101':'WELLS FARGO & COMPANY/MN','G0403H108':'Aon plc',
'G51502105':'Johnson Controls International plc','L8681T102':'Spotify Technology S.A.'}

def build():
    s=Store(); data=s.json(INDEX);old={b['packet_id']:b for b in read('issuer-cik-bindings.json',B)}
    ps={b['security_pair_id']:p['packet_id'] for p in read('issuer-security-packets.json',B) for b in p['securities']};out=[]
    for b in pilot_bindings():
        prev=old[ps[b['security_pair_id']]]; candidates={r['cik']:{'cik':r['cik'],'name':r['name'],'source':'PRESERVED_SEC_CIK_DIRECTORY'} for r in prev['directory_candidates']}
        if prev['cik']: candidates.setdefault(prev['cik'],{'cik':prev['cik'],'name':None,'source':'PRESERVED_REVIEWED_BINDING'})
        name=SEARCH_NAMES.get(b['q1_cusip'])
        for rowno,row in enumerate(data['data']):
            if name and row[1]==name:
                candidates[row[0]]={'cik':row[0],'name':row[1],'source':'SEC_COMPANY_INDEX_CANDIDATE_ONLY','index_row':rowno,'index_ref':s.compact_ref(INDEX)}
        out.append({'security_id':b['security_pair_id'],'official_13f_name':[b['issuer_name_q1'],b['issuer_name_q2']],'official_13f_class':[b['class_q1'],b['class_q2']],'cusip':b['q1_cusip'],'previous_cik_status':prev['status'],'previous_cik':prev['cik'],'search_expansion':name,'candidates':sorted(candidates.values(),key=lambda c:c['cik']),'status':'CANDIDATES_ONLY'})
    assert len(out)==66 and sum(x['previous_cik'] is None for x in out)==27
    write('cik-candidates.json',out)

def retrieve_metadata():
    s=Store(); failures=[]
    ciks=sorted({c['cik'] for x in read('cik-candidates.json') for c in x['candidates']})
    for cik in ciks:
        u=f'https://data.sec.gov/submissions/CIK{cik:010d}.json'
        try:
            s.get(u,'PILOT_ISSUER_IDENTITY_AND_OWNED_SUBMISSION_INDEX');doc=s.json(u)
            assert int(doc['cik'])==cik
            for f in doc['filings'].get('files',[]):
                if f['filingFrom']<='2026-08-14' and f['filingTo']>='2026-03-01':
                    s.get('https://data.sec.gov/submissions/'+f['name'],'PILOT_ISSUER_OWNED_HISTORICAL_SUBMISSION_SHARD')
            print(cik,doc['name'],len(doc['filings']['recent']['accessionNumber']),flush=True)
        except Exception as e: failures.append({'cik':cik,'error':str(e)});print('ERROR',cik,str(e),flush=True)
    write('metadata-retrieval.json',{'candidate_ciks':ciks,'failures':failures})
if __name__=='__main__':
    if sys.argv[-1]=='retrieve':retrieve_metadata()
    else:build()

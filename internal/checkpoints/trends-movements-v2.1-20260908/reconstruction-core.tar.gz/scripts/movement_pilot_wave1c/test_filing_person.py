import unittest
from owned_inventory import distinct_425_filer

class FilingPersonTests(unittest.TestCase):
    def test_subject_company_is_not_filing_person(self):
        self.assertTrue(distinct_425_filer('Filed by New Slider Holdco, Inc. (Commission File No. 333-297217) Pursuant to Rule 425 Subject Company: Sysco Corporation (Commission File No. 001-06544)'))
    def test_same_filer_and_subject(self):
        self.assertFalse(distinct_425_filer('Filed by Visa Inc. pursuant to Rule 425 Subject Company: Visa Inc. Commission File No.: 001-33977'))
    def test_punctuation_and_case_not_new_entity(self):
        self.assertFalse(distinct_425_filer('Filed by VISA, INC. Pursuant to Rule 425 Subject Company: Visa Inc. (Commission File No. 001)'))

"""Target primary documents first; reuse retained submissions without duplicating their raw bytes."""
from functools import lru_cache
import re
from context import *
from owned_inventory import rows_from

@lru_cache(maxsize=4)
def full_documents(url):
    s=Store();acc=url.rsplit('/',1)[1].removesuffix('.txt')
    return parse_submission(s.bytes(url),acc)

def primary(entry,store,fetch=False):
    full=entry['complete_submission_url'];url=entry['primary_url']
    if store.ref(full):
        docs=full_documents(full);matches=[d for d in docs if d['filename']==entry['primary_document']]
        if len(matches)!=1 or matches[0]['mode']!='TEXT':raise ValueError('PRIMARY_DOCUMENT_UNAVAILABLE')
        d=matches[0]
        return {'accession':entry['accession'],'document_url':url,'document_type':d['type'],'text':d['text'],'links':d['links'],'source_ref':store.compact_ref(full),'document_hash':d['document_block_sha256'],'hash_domain':'RETAINED_SGML_DOCUMENT_BLOCK','parent_accession':entry['accession']}
    if not store.ref(url):
        if not fetch:raise KeyError(url)
        store.get(url,'TARGETED_PILOT_ISSUER_PRIMARY_DOCUMENT')
    body=store.bytes(url)
    parser=NarrativeText();parser.feed(body.decode('utf-8',errors='replace'))
    return {'accession':entry['accession'],'document_url':url,'document_type':entry['form'],'text':visible(body.decode('utf-8',errors='replace')),'links':sorted(set(parser.links)),'source_ref':store.compact_ref(url),'document_hash':sha(body),'hash_domain':'ORIGINAL_DOCUMENT_BYTES','parent_accession':entry['accession']}

def identity_plan():
    s=Store();inventories=read('candidate-owned-inventories.json');plan=[]
    for cik,i in inventories.items():
        if i['regime']=='UNSUPPORTED_OR_INDETERMINATE':continue
        periodic=[e for e in i['entries'] if e['form'] in ['10-Q','10-K','20-F','40-F']]
        if not periodic:
            doc=s.json(f'https://data.sec.gov/submissions/CIK{int(cik):010d}.json')
            rr=[r for r in rows_from(doc['filings']['recent'],'recent') if r['form'] in ['20-F','40-F'] and r['filing_date']<='2026-08-14']
            for r in sorted(rr,key=lambda x:x['filing_date'])[-1:]:
                stem=f'https://www.sec.gov/Archives/edgar/data/{int(cik)}/{r["accession"].replace("-","")}/'
                periodic.append({**r,'issuer_cik':int(cik),'primary_url':stem+r['primary_document'],'complete_submission_url':stem+r['accession']+'.txt','identity_only_outside_discovery_window':True})
        for e in periodic:plan.append({**e,'purpose':'CIK_CLASS_PROOF_AND_QUARTER_EQUITY_TERMS'})
    write('identity-document-plan.json',plan)

def retrieve_identity():
    s=Store();out=[];fail=[]
    for e in read('identity-document-plan.json'):
        try:
            d=primary(e,s,True);out.append({**e,**d});print(e['issuer_cik'],e['accession'],e['form'],len(d['text']),flush=True)
        except Exception as ex:fail.append({'accession':e['accession'],'error':str(ex)});print('ERROR',e['accession'],str(ex),flush=True)
    # Derived text is losslessly compressed. The primary source is separately hash-bound.
    (OUT/'identity-primary-documents.json.gz').write_bytes(gzip.compress((canonical(out)+'\n').encode(),mtime=0))
    write('identity-document-retrieval.json',{'documents':len(out),'failures':fail})
    dossier=[]
    for b in pilot_bindings():
        ca=next(x for x in read('cik-candidates.json') if x['security_id']==b['security_pair_id'])
        documents=[]
        for d in out:
            if d['issuer_cik'] not in {x['cik'] for x in ca['candidates']}:continue
            text=d['text'];terms=[]
            for m in re.finditer(r'CUSIP|'+re.escape(b['q1_cusip'])+r'|Title of each class|Securities registered|ordinary shares|Class [ABCD][\s,]|common stock',text,re.I):
                if m.start()>14000 and b['q1_cusip'] not in m[0]:continue
                terms.append({'offset':m.start(),'excerpt':text[max(0,m.start()-80):m.end()+260]})
            documents.append({k:d[k] for k in ['issuer_cik','accession','form','filing_date','document_url','document_hash','source_ref']}|{'cover_text':text[:8500],'class_occurrences':terms[:20]})
        dossier.append({'security_id':b['security_pair_id'],'official_13f_names':ca['official_13f_name'],'official_13f_classes':ca['official_13f_class'],'candidate_documents':documents})
    write('identity-review-dossier.json',dossier)
if __name__=='__main__':
    if sys.argv[-1]=='plan':identity_plan()
    else:retrieve_identity()

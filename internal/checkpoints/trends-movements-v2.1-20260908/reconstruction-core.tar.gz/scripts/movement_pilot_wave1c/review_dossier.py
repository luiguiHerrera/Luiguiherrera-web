"""Primary excerpts for manual review; no automated clearance decisions."""
from context import *
from collections import defaultdict

def documents():
    ds=json.loads(gzip.decompress((OUT/'event-primary-documents.json.gz').read_bytes()))+json.loads(gzip.decompress((OUT/'linked-primary-documents.json.gz').read_bytes()))
    return list({(d['issuer_cik'],d['document_url'],d['document_hash']):d for d in ds}.values())

def spans(text, intervals):
    merged=[]
    for start,end in sorted(intervals):
        if merged and start<=merged[-1][1]:merged[-1][1]=max(end,merged[-1][1])
        else:merged.append([max(0,start),min(len(text),end)])
    return [{'start':a,'end':b,'text':text[a:b],'sha256':sha(text[a:b])} for a,b in merged]

def build():
    ds=documents();groups=read('event-candidates.json')['candidates'];out=[]
    for c in read('pilot-cik-bindings.json'):
        cik=c['issuer_cik'];records=[]
        for d in ds:
            if d['issuer_cik']!=cik or not d.get('text'):continue
            t=d['text'];intervals=[]
            for g in groups:
                if g['issuer_cik']!=cik:continue
                for o in g['occurrences']:
                    if o['document_url']==d['document_url'] and o['document_hash']==d['document_hash']:intervals.append((max(0,o['offset']-250),min(len(t),o['offset']+len(o['term'])+450)))
            narrative=[]
            if d['document_type'] in ['10-Q','10-K'] or d['document_type']=='6-K' and len(t)>60000:
                patterns=[r'(?:Note\s+\d+\s*[-–.:]?\s*)?(?:Stockholders[’\x27]?|Shareholders[’\x27]?|Equityholders[’\x27]?)\s+Equity',r'(?:Note\s+\d+\s*[-–.:]?\s*)?(?:Share Capital|Ordinary Shares|Common Stock)',r'(?:CONSOLIDATED|CONDENSED).*?STATEMENTS OF (?:CHANGES IN )?(?:STOCKHOLDERS|SHAREHOLDERS|EQUITY)',r'(?:Note\s+\d+\s*[-–.:]?\s*)?(?:Earnings Per Share|Net Income Per Share)',r'(?:Item\s+2\.?\s*)Unregistered Sales of Equity']
                for pat in patterns:
                    ms=[m for m in re.finditer(pat,t,re.I) if m.start()>1800]
                    for m in ms[:3]:narrative.append((max(0,m.start()-80),min(len(t),m.end()+2800)))
            if d['document_type']=='8-K':
                m=re.search(r'Item\s+\d',t,re.I)
                if m:narrative.append((m.start(),len(t)))
            records.append({**{k:d.get(k) for k in ['accession','document_url','document_hash','source_ref','document_type','items','parent_accession','linked_accession']},'narrative_sections':spans(t,narrative),'candidate_contexts':spans(t,intervals),'nested_links':d.get('links',[]),'full_text_length':len(t)})
        out.append({'security_id':c['security_id'],'issuer_cik':cik,'name':c['sec_entity_name'],'documents':records})
    write('operational-review-dossier.json',out)

if __name__=='__main__':
    if len(sys.argv)==1:build()
    else:
        c=next(c for c in read('operational-review-dossier.json') if c['issuer_cik']==int(sys.argv[1]));print(c['name'],c['security_id'])
        kind=sys.argv[2] if len(sys.argv)>2 else 'candidate_contexts'
        for d in c['documents']:
            if not d[kind]:continue
            print('\n',d['accession'],d['document_type'],d['document_url'])
            for x in d[kind]:print(x['start'],x['text'])

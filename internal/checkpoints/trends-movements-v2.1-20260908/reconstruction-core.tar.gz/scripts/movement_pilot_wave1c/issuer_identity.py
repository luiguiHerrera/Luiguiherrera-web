"""Primary class proof is mandatory; SEC index candidates never verify themselves."""
import re
from context import *
PROOFS={'EXACT_CUSIP_IN_ISSUER_FILING','EXACT_SECURITY_CLASS_IN_ISSUER_FILING','UNIQUE_SEC_LEGAL_ENTITY_WITH_CLASS_EVIDENCE','VERIFIED_SUCCESSOR_PREDECESSOR','OTHER_PRIMARY_SEC_PROOF'}

def identity_scope(candidate):
    return sha({k:candidate.get(k) for k in ['security_id','cusip','official_13f_name','official_13f_class']})

def verify(candidate,review,documents,inventories,catalog):
    if not review:return {'status':'CIK_NOT_FOUND','issuer_cik':None,'reason':'PRIMARY_PROOF_NOT_REVIEWED'}
    cik=review.get('issuer_cik');matched=[c for c in candidate['candidates'] if c['cik']==cik]
    if not matched:return {'status':'CIK_AMBIGUOUS','issuer_cik':None,'reason':'CIK_OUTSIDE_SEC_CANDIDATES'}
    if review.get('proof_type') not in PROOFS:return {'status':'CIK_AMBIGUOUS','issuer_cik':None,'reason':'INVALID_PROOF_TYPE'}
    inv=inventories.get(str(cik));proofs=review.get('proofs',[]);errors=[]
    if review.get('identity_scope_sha256')!=identity_scope(candidate):errors.append('STALE_IDENTITY_CLASS_REVIEW')
    if not inv or inv['issuer_cik']!=cik:errors.append('CIK_INDEX_UNBOUND')
    if review.get('security_id')!=candidate['security_id'] or review.get('cusip')!=candidate['cusip']:errors.append('WRONG_SECURITY')
    if not proofs or not review.get('identity_reason') or not review.get('class_reason'):errors.append('MISSING_CLASS_IDENTITY_PROOF')
    for p in proofs:
        ds=[d for d in documents if d['accession']==p.get('source_accession') and d['issuer_cik']==cik]
        if len(ds)!=1:errors.append('PRIMARY_NOT_OWNED');continue
        d=ds[0];ref=d['source_ref'];snippet=p.get('class_excerpt','')
        if p.get('source_url')!=ref['source_url'] or p.get('document_hash')!=d['document_hash']:errors.append('WRONG_PRIMARY_DOCUMENT')
        if p.get('source_hash')!=ref['sha256'] or catalog.get(ref['source_url'])!=ref['sha256']:errors.append('PRIMARY_HASH_MISMATCH')
        if not snippet or snippet not in d['text'] or not p.get('source_section'):errors.append('CLASS_EXCERPT_NOT_IN_PRIMARY')
        if review['proof_type']=='EXACT_CUSIP_IN_ISSUER_FILING' and candidate['cusip'] not in d['text']:errors.append('CUSIP_NOT_IN_PRIMARY')
    if set(review.get('candidate_dispositions',{}))!={str(c['cik']) for c in candidate['candidates']}:errors.append('UNREVIEWED_CIK_CANDIDATE')
    if errors:return {'status':'CIK_AMBIGUOUS','issuer_cik':None,'reason':','.join(sorted(set(errors)))}
    return {'status':'CIK_VERIFIED','issuer_cik':cik,'sec_entity_name':inv['entity_name'],'proof_type':review['proof_type'],'proofs':proofs,'identity_reason':review['identity_reason'],'class_reason':review['class_reason'],'regime':inv['regime'],'sic':inv['sic'],'sic_description':inv['sic_description'],'submissions_ref':inv['submissions_ref'],'review_sha256':sha(review)}

def build():
    s=Store();docs=json.loads(gzip.decompress((OUT/'identity-primary-documents.json.gz').read_bytes()));inv=read('candidate-owned-inventories.json');reviews={r['security_id']:r for r in read('identity-manual-review.json')};catalog={d['source_ref']['source_url']:s.ref(d['source_ref']['source_url'])['sha256'] for d in docs};out=[]
    for c in read('cik-candidates.json'):
        result=verify(c,reviews.get(c['security_id']),docs,inv,catalog)
        out.append({k:c[k] for k in ['security_id','official_13f_name','official_13f_class','cusip','previous_cik','previous_cik_status']}|result)
    write('pilot-cik-bindings.json',out)
    print(canonical({'statuses':__import__('collections').Counter(x['status'] for x in out),'newly_verified':sum(x['previous_cik'] is None and x['status']=='CIK_VERIFIED' for x in out)}))
if __name__=='__main__':build()

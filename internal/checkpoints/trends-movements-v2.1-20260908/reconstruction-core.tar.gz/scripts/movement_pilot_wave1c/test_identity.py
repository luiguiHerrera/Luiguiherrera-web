import unittest
from issuer_identity import *

def f():
    u='https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm';h='a'*64
    c={'security_id':'A','cusip':'111111111','official_13f_name':['Issuer','Issuer'],'official_13f_class':['CL A','CL A'],'candidates':[{'cik':1}]}
    d={'accession':'ACC','issuer_cik':1,'text':'Issuer registered Class A common stock.','document_hash':h,'source_ref':{'source_url':u,'sha256':h}}
    r={'security_id':'A','cusip':'111111111','issuer_cik':1,'proof_type':'UNIQUE_SEC_LEGAL_ENTITY_WITH_CLASS_EVIDENCE','identity_reason':'Reviewed exact SEC issuer entity.','class_reason':'Reviewed Class A on official list and primary cover.','candidate_dispositions':{'1':'SELECTED_WITH_PRIMARY_PROOF'},'identity_scope_sha256':identity_scope(c),'proofs':[{'source_accession':'ACC','source_hash':h,'source_url':u,'source_section':'Registered securities cover','class_excerpt':'Class A common stock','document_hash':h}]}
    i={'1':{'issuer_cik':1,'entity_name':'Issuer','regime':'DOMESTIC_OPERATING_COMPANY','sic':'1234','sic_description':'Test','submissions_ref':{'source_url':u,'sha256':h}}}
    return c,r,[d],i,{u:h}

class IdentityTests(unittest.TestCase):
    def test_primary_review_verifies(self):self.assertEqual(verify(*f())['status'],'CIK_VERIFIED')
    def test_candidate_only_does_not_verify(self):x=list(f());x[1]=None;self.assertNotEqual(verify(*x)['status'],'CIK_VERIFIED')
    def test_ticker_proof_rejected(self):x=f();x[1]['proof_type']='TICKER_MATCH';self.assertEqual(verify(*x)['status'],'CIK_AMBIGUOUS')
    def test_same_name_wrong_cik(self):x=f();x[2][0]['issuer_cik']=2;self.assertEqual(verify(*x)['status'],'CIK_AMBIGUOUS')
    def test_class_b_cannot_reuse_a_review(self):x=f();x[0]['official_13f_class']=['CL B','CL B'];self.assertEqual(verify(*x)['status'],'CIK_AMBIGUOUS')
    def test_wrong_cusip(self):x=f();x[0]['cusip']='222222222';self.assertEqual(verify(*x)['status'],'CIK_AMBIGUOUS')
    def test_name_scope_change_requires_review(self):x=f();x[0]['official_13f_name']=['Different','Different'];self.assertEqual(verify(*x)['status'],'CIK_AMBIGUOUS')
    def test_unreviewed_alternate_candidate(self):x=f();x[0]['candidates'].append({'cik':2});self.assertEqual(verify(*x)['status'],'CIK_AMBIGUOUS')
    def test_excerpt_not_in_primary(self):x=f();x[1]['proofs'][0]['class_excerpt']='Class B common stock';self.assertEqual(verify(*x)['status'],'CIK_AMBIGUOUS')
    def test_wrong_primary_url(self):x=f();x[1]['proofs'][0]['source_url']='https://example.com';self.assertEqual(verify(*x)['status'],'CIK_AMBIGUOUS')
    def test_exact_cusip_proof_requires_cusip(self):x=f();x[1]['proof_type']='EXACT_CUSIP_IN_ISSUER_FILING';self.assertEqual(verify(*x)['status'],'CIK_AMBIGUOUS')

if __name__=='__main__':unittest.main()

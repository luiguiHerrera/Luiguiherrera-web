"""Cluster discovery occurrences; neither keyword absence nor clustering verifies an event."""
from collections import defaultdict,Counter
import re
from context import *
from events import TERMS as LEGACY_TERMS
TERMS=re.compile(LEGACY_TERMS.pattern+r"|\b(?:separation|reincorporation|redomestication|domestication|share[\s-]+consolidation|stock[\s-]+combination)\b",re.I)

def family(term):
    t=term.lower()
    if 'reverse' in t and 'split' in t:return 'REVERSE_SPLIT'
    if 'spin' in t or 'split-off' in t or 'split-up' in t or t=='separation':return 'SPINOFF'
    if 'split' in t or ('dividend' in t and ('stock' in t or 'share' in t)):return 'SPLIT_OR_STOCK_DIVIDEND'
    if 'merger' in t or 'business' in t:return 'MERGER_BUSINESS_COMBINATION'
    if 'conversion' in t or 'exchange' in t:return 'CONVERSION_EXCHANGE'
    if 'CUSIP'==term.upper():return 'CUSIP_CHANGE'
    if 'reclass' in t or 'redesign' in t or 'recapital' in t or 'reorg' in t or 'redomic' in t or 'domestic' in t or 'reincorp' in t or 'consolidation' in t or 'combination' in t:return 'CLASS_REORGANIZATION'
    return 'DISTRIBUTION_OR_OTHER'

def lexical_non_event(text,start,end):
    near=text[max(0,start-65):min(len(text),end+100)].lower()
    if re.search(r'exchange (act|commission|on which|rate|rates|traded|trading)|stock exchange|currency exchange|foreign exchange',near):
        if text[start:end].lower()=='exchange':return 'EXCHANGE_MARKET_LAW_OR_FX_REFERENCE'
    return None

def cluster(documents,security_ciks):
    bycik=defaultdict(list)
    for sec,cik in security_ciks.items():bycik[cik].append(sec)
    groups={};raw=0;lexical=Counter();dupes=0;seen_occ=set()
    for d in documents:
        text=d.get('text')
        if not text:continue
        cik=d['issuer_cik'];acc=d['accession']
        for m in TERMS.finditer(text):
            raw+=1;context=text[max(0,m.start()-250):min(len(text),m.end()+450)]
            non=lexical_non_event(text,m.start(),m.end())
            if non:lexical[non]+=1;continue
            # Candidate scope is an explicit unresolved claim, never a verified class assignment.
            classes=sorted(set(re.findall(r'\bclass\s+([A-D](?:-?\d)?)\b',context,re.I)))
            scope='MENTIONED_CLASSES:'+','.join(c.upper() for c in classes) if classes else 'ISSUER_LEVEL_UNRESOLVED'
            years=sorted(set(re.findall(r'\b20(?:0\d|1\d|2\d)\b',context)))
            period='MENTIONED_YEARS:'+','.join(years) if years else 'EFFECTIVE_PERIOD_UNRESOLVED'
            key=(cik,acc,family(m[0]),scope,period)
            if key not in groups:groups[key]={'candidate_id':'EVENT_CANDIDATE:'+sha(key)[:24],'issuer_cik':cik,'pilot_security_ids':sorted(bycik[cik]),'accessions':[acc],'event_family':key[2],'candidate_class_scope':scope,'class_binding_status':'AMBIGUOUS_CLASS_SCOPE' if classes else 'ISSUER_LEVEL_ONLY','effective_period_candidate':period,'effective_date_verified':None,'verification_status':'CANDIDATE_ONLY','occurrences':[]}
            sig=(key,sha(context))
            if sig in seen_occ:dupes+=1
            seen_occ.add(sig)
            groups[key]['occurrences'].append({'accession':acc,'document_url':d['document_url'],'document_hash':d['document_hash'],'source_ref':d['source_ref'],'term':m[0],'offset':m.start(),'context':context,'context_sha256':sha(context),'duplicate_context':sum(x['context_sha256']==sha(context) for x in groups[key]['occurrences'])>0})
    values=sorted(groups.values(),key=lambda x:x['candidate_id'])
    for g in values:g['occurrence_count']=len(g['occurrences']);g['distinct_contexts']=len({o['context_sha256'] for o in g['occurrences']})
    return {'keyword_occurrences':raw,'lexical_non_event_occurrences':dict(lexical),'duplicate_context_occurrences':dupes,'distinct_event_candidates':len(values),'candidate_compression_percent':round(100*(1-len(values)/raw),6) if raw else None,'candidates':values,'unit':'REVIEW_CANDIDATE_GROUP; NOT_VERIFIED_OR_UNIQUE_ECONOMIC_EVENT','clustering_key':'issuer + accession + event family + explicitly unresolved security/class scope + mentioned-year set; repeated exhibits preserve all provenance'}

def run():
    docs=json.loads(gzip.decompress((OUT/'event-primary-documents.json.gz').read_bytes()));links=json.loads(gzip.decompress((OUT/'linked-primary-documents.json.gz').read_bytes())) if (OUT/'linked-primary-documents.json.gz').exists() else []
    mapping={c['security_id']:c['issuer_cik'] for c in read('pilot-cik-bindings.json') if c['status']=='CIK_VERIFIED'}
    # An attached exhibit later encountered through its primary's link is one document.
    unique={}
    expanded=[]
    for d in links:
        roots=sorted({edge['parent_cik'] for edge in d.get('link_edges',[])}) or [d['issuer_cik']]
        for cik in roots:
            parents=sorted({edge['parent_accession'] for edge in d.get('link_edges',[]) if edge['parent_cik']==cik})
            expanded.append({**d,'issuer_cik':cik,'accession':parents[0] if parents else d['accession'],'root_parent_accessions':parents})
    for d in docs+expanded:
        key=(d['issuer_cik'],d['document_url'],d['document_hash'])
        if key not in unique:unique[key]=d
    excluded={(int(cik),e['accession']) for cik,i in read('candidate-owned-inventories.json').items() for e in i['all_associated_entries'] if e['ownership_authority'].startswith('ASSOCIATED_DISTINCT_425')}
    associated=[d for d in unique.values() if (d['issuer_cik'],d['accession']) in excluded]
    write('associated-third-party-discovery.json',{'authority':'SUPPLEMENTAL_DISCOVERY_ONLY; NOT_ISSUER_OWNED','documents':[{k:d.get(k) for k in ['issuer_cik','accession','document_url','document_hash','source_ref']} for d in associated]})
    unique={k:d for k,d in unique.items() if (d['issuer_cik'],d['accession']) not in excluded}
    out=cluster(list(unique.values()),mapping);out['document_records_before_deduplication']=len(docs)+len(links);out['document_records_after_deduplication']=len(unique);write('event-candidates.json',out)
    print(canonical({k:v for k,v in out.items() if k!='candidates'}))
if __name__=='__main__':run()

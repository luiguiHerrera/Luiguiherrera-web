"""Fixed-pilot research only; source versions and the public snapshot stay immutable."""
from pathlib import Path
import datetime, gzip, hashlib, json, sys, time, urllib.parse, urllib.request

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'internal/trends-movements/wave1c'
B = ROOT / 'internal/trends-movements/wave1b'
W1 = ROOT / 'internal/trends-movements/wave1'
sys.path.insert(0, str(ROOT / 'scripts/movement_security_wave1b'))
from inventory import legacy_sources
from events import parse_submission as legacy_parse_submission
from html.parser import HTMLParser
import re

class NarrativeText(HTMLParser):
    """Exclude non-rendered Inline XBRL resources while preserving visible tagged facts."""
    def __init__(self):super().__init__(convert_charrefs=True);self.stack=[];self.parts=[];self.links=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs);hidden=tag in {'head','script','style','ix:header','ix:hidden','ix:resources'} or bool(re.search(r'display\s*:\s*none',a.get('style',''),re.I))
        if tag not in {'br','img','meta','link','hr','input','wbr','source'}:self.stack.append((tag,hidden))
        if any(v for _,v in self.stack):return
        if tag=='a' and a.get('href') and not a['href'].startswith('#'):self.links.append(a['href'])
        if tag in {'p','div','tr','td','th','br','li'}:self.parts.append(' ')
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i][0]==tag:self.stack=self.stack[:i];break
        if tag in {'p','div','tr','td','th','li'}:self.parts.append(' ')
    def handle_data(self,data):
        if not any(v for _,v in self.stack):self.parts.append(data)

def visible(text):
    p=NarrativeText();p.feed(text);return re.sub(r'\s+',' ',' '.join(p.parts)).strip()

def parse_submission(body, accession):
    docs=legacy_parse_submission(body,accession)
    blocks=re.findall(r'<DOCUMENT>(.*?)</DOCUMENT>',body.decode('utf-8',errors='replace'),re.S|re.I)
    for d,block in zip(docs,blocks):
        if d['mode']!='TEXT':continue
        raw=re.search(r'<TEXT>(.*)</TEXT>',block,re.S|re.I)[1];p=NarrativeText();p.feed(raw)
        d['text']=visible(raw);d['links']=sorted(set(p.links))
    return docs

def canonical(x): return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
def sha(x): return hashlib.sha256(x if isinstance(x, bytes) else canonical(x).encode()).hexdigest()
def read(name, directory=OUT): return json.loads((directory/name).read_text())
def write(name, x): (OUT/name).write_text(canonical(x)+'\n')
def pilot_bindings(): return read('pilot-security-bindings.json', B)['bindings']
def selection(): return read('pilot-selection.json', W1)

class Store:
    def __init__(self):
        self.manifest = read('source-manifest.json') if (OUT/'source-manifest.json').exists() else {}
        self.prior = read('source-manifest.json', B)
        self.legacy = None
    def ref(self, url):
        if url in self.manifest: return self.manifest[url]
        if url in self.prior: return {**self.prior[url], 'archive':'PRESERVED_WAVE1B'}
        if self.legacy is None: self.legacy = legacy_sources()
        if url in self.legacy: return {**{k:v for k,v in self.legacy[url].items() if k!='body'},'source_url':url,'archive':'PRESERVED_BASELINE_OR_WAVE1'}
        return None
    def bytes(self, url):
        r=self.ref(url)
        if not r: raise KeyError(url)
        if url in self.manifest: b=(OUT/r['path']).read_bytes()
        elif url in self.prior: b=(B/r['path']).read_bytes()
        else: b=self.legacy[url]['body'].encode()
        if r.get('storage_encoding')=='gzip': b=gzip.decompress(b)
        assert sha(b)==r['sha256'], 'SOURCE_HASH_MISMATCH'
        return b
    def get(self,url,purpose):
        r=self.ref(url)
        if r: self.bytes(url); return r
        u=urllib.parse.urlparse(url)
        if u.scheme!='https' or u.hostname not in {'www.sec.gov','data.sec.gov'}: raise ValueError('NON_SEC_SOURCE')
        if '/search-index' in u.path and purpose!='SUPPLEMENTAL_DISCOVERY': raise ValueError('SEARCH_IS_NOT_INVENTORY')
        req=urllib.request.Request(url,headers={'User-Agent':'LHI Trends research (https://www.luiguiherrera.com)','Accept-Encoding':'identity'})
        with urllib.request.urlopen(req,timeout=30) as res:
            assert urllib.parse.urlparse(res.url).hostname in {'www.sec.gov','data.sec.gov'}
            b=res.read(); final=res.url; ct=res.headers.get('Content-Type')
        if not b or b'Your Request Originates from an Undeclared Automated Tool' in b: raise ValueError('SEC_BLOCK_PAGE')
        h=sha(b); path='sources/'+h+'.raw.gz'; packed=gzip.compress(b,mtime=0);(OUT/path).write_bytes(packed)
        r={'source_url':url,'final_url':final,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':h,'bytes':len(b),'stored_bytes':len(packed),'path':path,'storage_encoding':'gzip','content_type':ct,'purpose':purpose}
        self.manifest[url]=r;write('source-manifest.json',self.manifest);time.sleep(.15);return r
    def json(self,url): return json.loads(self.bytes(url))
    def compact_ref(self,url):
        r=self.ref(url);return {'source_url':url,'sha256':r['sha256'],**({'archive':r['archive']} if r.get('archive') else {})}

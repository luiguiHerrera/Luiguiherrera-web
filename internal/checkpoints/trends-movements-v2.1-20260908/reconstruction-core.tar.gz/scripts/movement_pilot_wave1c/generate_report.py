"""Publish local internal review artifacts; no public output, commit or network."""
from context import *
from collections import Counter
import subprocess

def run():
    r=read('pilot-results.json');audit=read('final-source-and-isolation-audit.json');st=audit['storage'];pre=read('preflight.json');cand=read('event-candidates.json');cs=read('pilot-cik-bindings.json');reviews=read('coverage-manual-reviews.json');invs=read('candidate-owned-inventories.json');checks=read('validation.json');events=read('verified-events.json')
    assert checks['state']=='PASS' and audit['state']=='PASS' and read('offline-replay-check.json')['state']=='PASS'
    counts=r['gate']['packet_counts'];reg=Counter(c['regime'] for c in cs);statuses=r['newly_resolved_status_counts'];bac=invs['70858'];oldinv=read('issuer-filing-inventories.json',B)
    fields=dict(STATE=r['state'],BASE_COMMIT=pre['base_commit'],REMOTE_HEAD=read('remote-end-check.json')['remote_head'],MOVEMENT_CORPUS_COUNT=8137,MOVEMENT_CORPUS_SHA256=audit['corpus_sha256'],MOVEMENT_CORPUS_CHANGED='NO',FIXED_PILOT_COMPARISONS=501,FIXED_PILOT_SECURITIES=66,FIXED_PILOT_MANAGERS=19,PILOT_CIK_UNVERIFIED_BEFORE=27,PILOT_CIK_VERIFIED_ADDED=sum(c['previous_cik_status']!='EXACT_VERIFIED' and c['status']=='CIK_VERIFIED' for c in cs),PILOT_CIK_AMBIGUOUS=0,PILOT_CIK_UNRESOLVED=0,PILOT_FILING_REGIME_DOMESTIC=reg['DOMESTIC_OPERATING_COMPANY'],PILOT_FILING_REGIME_FOREIGN=reg['FOREIGN_PRIVATE_ISSUER'],PILOT_FILING_REGIME_FUND_TRUST=0,PILOT_FILING_REGIME_OTHER=0,PILOT_FILING_REGIME_UNSUPPORTED=0,OLD_GLOBAL_SEARCH_ACCESSIONS=0,ISSUER_OWNED_ACCESSIONS=st['issuer_owned_relevant_form_accessions'],NOISE_REDUCTION_PERCENT=None,BANK_OF_AMERICA_OLD_ACCESSIONS=4677,BANK_OF_AMERICA_ISSUER_OWNED_ACCESSIONS=len(bac['entries']),KEYWORD_OCCURRENCES_BEFORE=46641,KEYWORD_OCCURRENCES=cand['keyword_occurrences'],DISTINCT_EVENT_CANDIDATES=cand['distinct_event_candidates'],CANDIDATE_COMPRESSION_PERCENT=cand['candidate_compression_percent'],PILOT_EVENT_PACKETS=66,PILOT_VERIFIED_EVENTS=len(events),PILOT_VERIFIED_CLEAR_PACKETS=counts.get('VERIFIED_CLEAR_FOR_COMPARABILITY',0),PILOT_VERIFIED_BLOCK_PACKETS=counts.get('VERIFIED_BLOCK',0),PILOT_UNKNOWN_EVENT_PACKETS=counts.get('UNKNOWN',0),PILOT_RESOLVED_BEFORE=10,PILOT_NEWLY_RESOLVED=r['pilot_newly_resolved'],PILOT_TOTAL_RESOLVED=r['pilot_total_resolved'],PILOT_STILL_UNKNOWN=r['pilot_still_unknown'],PILOT_REPORTED_INCREASED=statuses.get('REPORTED_INCREASED',0),PILOT_REPORTED_REDUCED=statuses.get('REPORTED_REDUCED',0),PILOT_REPORTED_UNCHANGED=statuses.get('REPORTED_UNCHANGED',0),PILOT_BOTH_PRESENT_SECURITY_PACKETS=66,PILOT_PACKET_CLEAR=counts.get('VERIFIED_CLEAR_FOR_COMPARABILITY',0),PILOT_PACKET_EVENT_NORMALIZED=counts.get('VERIFIED_EVENT_NORMALIZATION_AVAILABLE',0),PILOT_PACKET_VERIFIED_BLOCK=counts.get('VERIFIED_BLOCK',0),PILOT_PACKET_UNKNOWN=counts.get('UNKNOWN',0),PILOT_EVIDENCE_COVERAGE=r['gate']['state'],PILOT_MANUAL_CHECK_COUNT=r['manual_comparison_check_count'],PILOT_FALSE_POSITIVES=r['false_positives_observed'],PILOT_CONFIRMED_FALSE_NEGATIVES=r['confirmed_false_negatives'],PILOT_UNEVALUABLE=r['manual_semantically_unevaluable'],PILOT_SECTOR_UNKNOWN_BEFORE=375,PILOT_SECTOR_UNKNOWN_AFTER=r['sector_unknown_after'],GLOBAL_TOTAL_RESOLVED=9,GLOBAL_STILL_INDETERMINATE=8128,GLOBAL_EXPANSION_PERFORMED='NO',RESOLUTION_BIAS_CHECK='FAIL',REPORTED_QUANTITY_MODEL='EXACT_REPORTED_SHARES_WITH_EXPLICIT_RATIONAL_NORMALIZATION',TRANSACTION_INFERENCE_PUBLIC='NO',MOVEMENT_PUBLICATION='REVIEW_PENDING',MOVEMENT_UI_PRESENT='NO',MOVEMENT_FIELDS_PUBLIC='NONE',PUBLIC_DATA_CHANGED='NO',PUBLIC_SNAPSHOT_CHANGED='NO',SEC_HOLDINGS_REFRESH='NO',SOURCE_BYTES_DOWNLOADED=st['source_bytes_downloaded_this_wave_raw'],SOURCE_BYTES_RETAINED=st['source_bytes_retained_this_wave_stored'],DOCUMENTS_INDEXED=st['documents_indexed_before_deduplication'],DOCUMENTS_RETAINED=st['documents_retained_in_scoped_review_catalog'],TESTS=f"PASS ({checks['tests_passed']} tests)",TYPECHECK='PASS',LINT='PASS (0 errors; 17 existing warnings)',BUILD='PASS',GIT_DIFF_CHECK='PASS',FILES_CHANGED=0,PRODUCTION_READINESS='NOT_READY',NEXT_RECOMMENDED_STEP='Close the two remaining evidence gaps within the same 66-security pilot: retain the official TSMC June 4 AGM operative amendment and bind Chevron Q2 stock-dividend scope. Then rerun the same 501 and inspect quality; no global expansion.',COMMIT='NO',PUSH='NO',DEPLOY='NO')
    fields.update(PILOT_REPORTED_COUNT_BASIS='Newly resolved 458 only; all-resolved counts reported separately',PILOT_ALL_RESOLVED_REPORTED_COUNTS=r['resolved_status_counts'],PILOT_RESOLUTION_RATE_PERCENT=round(100*r['pilot_total_resolved']/501,6),PILOT_MANUAL_NEW_FAMILIES=61,PILOT_MANUAL_ARITHMETIC_FAMILIES=66,HIGH_LEVERAGE_PRIMARY_NODES_MANUALLY_REVIEWED=len(read('high-leverage-primary-node-review.json')),STATISTICAL_ZERO_ERROR_CLAIM='NO',PILOT_UNEVALUABLE_DEFINITION='501 minus 71 comparisons manually evaluated for semantic expectation; includes unreviewed resolved comparisons. Distinct from the 33 engine-indeterminate comparisons.',NOISE_REDUCTION_NOTE='Not computable against global search: retained Wave1B inventory already used SEC submissions, not global search. Its 4,677 BAC entries were broad form selection, including 4,664 424B2. The new relevant-form BAC inventory has 10 entries; all-form owned inventory remains separately visible.',BANK_OF_AMERICA_FORM_FILTER_REDUCTION_PERCENT=round(100*(1-len(bac['entries'])/4677),6),BANK_OF_AMERICA_ASSOCIATED_ALL_FORMS=bac['accessions_observed'],BANK_OF_AMERICA_OWNED_ALL_FORMS=bac['owned_accessions_observed'],OLD_OWNED_BROAD_FORM_ACCESSIONS=sum(len(i['entries']) for i in oldinv.values()),VERIFIED_DISTINCT_ISSUERS=st['verified_distinct_issuers'],SOURCE_BYTES_RETAINED_RAW_UNIQUE=st['source_bytes_retained_this_wave_uncompressed_unique'],SOURCE_STORAGE_DEFINITIONS=audit['storage_definitions'],VERIFIED_EVENTS_NOTE='Three inherited verified records: two Visa events affecting other classes and one FedEx spin-off. No new split normalization. Berkshire A positive conversion interval is a block, not a VERIFIED_EVENT with an invented exact date.',BIAS_DIMENSIONS_FAILED=read('readiness-and-bias.json',B)['BIAS_DIMENSIONS_FAILED'])
    pending=[]
    byc={c['security_id']:c for c in cs}
    for rev in reviews:
        if rev['state']=='VERIFIED_CLEAR_FOR_COMPARABILITY':continue
        sec=rev['security_id'];pending.append({'security_id':sec,'name':byc[sec]['sec_entity_name'],'state':rev['state'],'comparisons':rev['pilot_comparisons'],'reason':rev.get('unresolved_review_reason') or rev.get('primary_block_proof'),'source_refs':rev['source_refs'],'action':'Retain class-specific missing primary proof; do not infer an event from absent evidence.' if rev['state']=='UNKNOWN' else 'Keep blocked until the unsupported event or holder-election allocation can be modeled from primary evidence.'})
    write('remaining-pilot-packets.json',pending)
    write('readiness-and-bias.json',{'state':'NOT_READY','global_result_unchanged':True,'resolution_bias_check':'FAIL','dimensions_failed':fields['BIAS_DIMENSIONS_FAILED'],'basis':'Fixed pilot is selected BOTH_PRESENT coverage research; it does not validate global selection, transitions or transaction inference.','global_expansion_authorized':False})
    text='''# Wave 1C — piloto fijo

**Cobertura FAIL: 62 claros, 2 bloqueos verificados y 2 UNKNOWN.**

Se resuelven **468/501 (93,41%)**, con 458 resoluciones nuevas: 163 incrementos declarados, 222 reducciones y 73 sin cambio. El total resuelto contiene 166 incrementos, 226 reducciones y 76 sin cambio. Los 27 CIK pendientes quedan verificados; la cobertura sectorial desconocida baja de 375 a 0.

| Valor | Estado | Comparaciones | Motivo |
|---|---|---:|---|
| TSMC ADS | UNKNOWN | 10 | Acta oficial visible, pero PDF operativo de la reforma de junio no conservado con hash; descarga HTTP 403 y visor sin archivo exportable. |
| Chevron común | UNKNOWN | 9 | Partida de dividendos en acciones por $11m en Q2 sin vinculación suficiente al alcance de las unidades existentes. |
| FedEx común | VERIFIED_BLOCK | 8 | Distribución de FedEx Freight del 1 de junio; evento aún no soportado por el normalizador. |
| Berkshire A | VERIFIED_BLOCK | 6 | 4.372 acciones A convertidas a B durante Q2 por elección del titular; faltan fechas y asignación por gestor. |

Berkshire B y Visa A tienen certificados propios. No reciben automáticamente factores de otras clases. Los dos UNKNOWN no se han convertido en bloqueos para hacer pasar la cobertura.

Se reconstruyeron cantidades desde las tablas SEC para las 501 comparaciones, con una revisión aritmética representativa por cada uno de los 66 valores. Hay 71 comprobaciones semánticas manuales, 61 familias nuevas y nueve nodos de evidencia que desbloquean al menos diez comparaciones. Se observaron 0 falsos positivos y 0 falsos negativos confirmados; no es una estimación estadística de error cero. Las 430 comparaciones sin evaluación semántica manual son una métrica distinta de las 33 indeterminadas del motor.

El corpus de 8.137 filas conserva su SHA256 original. Se preservan 612 archivos de la base y 696 archivos internos heredados. No hay commit, push, deploy, cambios públicos, actualización de holdings ni expansión global. Producción continúa **NOT_READY**, publicación **REVIEW_PENDING**, y el sesgo global sigue en **FAIL** en sus seis dimensiones.

## Procedencia y volumen

El archivo anterior ya utilizaba submissions SEC. Por ello no se inventa una reducción porcentual frente a un inexistente inventario global. Bank of America pasa de 4.677 formularios seleccionados de forma amplia —4.664 eran 424B2— a 10 del conjunto de formularios relevantes; su inventario completo de otros formularios se conserva en metadatos. Un 425 presentado por New Slider, asociado a Sysco, queda separado como descubrimiento de un tercero.

Hay 68.148 ocurrencias y 4.345 grupos candidatos, compresión del 93,624171%. Los grupos conservan accesiones, clases mencionadas y periodos candidatos; no equivalen a eventos económicos verificados. Se revisaron por alcance positivo de deuda 691 portadas de 424B3 de bancos, sin usar sus prefijos como prueba negativa de eventos.

Los documentos primarios se seleccionaron a partir de metadatos, reutilizando 449 submissions completas y obteniendo 299 documentos primarios; se siguieron 876 URL de documentos vinculados. El inventario final excluye la presentación asociada de New Slider. Los documentos binarios/XML contenidos en archivos heredados no equivalen a miles de nuevas descargas o documentos leídos manualmente. Se conservaron 14 imágenes de artículos de Diageo y su PDF de resultados de 42 páginas como evidencia suplementaria explícita.

La descarga de esta fase consumió 460.692.776 bytes de cuerpos de respuesta; se retienen 35.068.409 bytes comprimidos en fuentes nuevas. Se reutilizan por separado 490 URL de fuentes heredadas (2.214.366.764 bytes originales sumados por URL). Se descartaron 35 documentos administrativos no referenciados, conservando su registro. El catálogo de revisión contiene 6.414 documentos tras deduplicación y separación de terceros, incluidos suplementos; las 691 portadas tienen su índice separado.

## Validación y revisión

627 pruebas pasan: 337 de la aplicación, 185 previas de Python/XML y 105 de Wave 1C. Typecheck, lint, build, SEO y snapshot check pasan; lint conserva 17 advertencias existentes. La comprobación HTTP verifica ocho rutas públicas con 200 y tres rutas internas/de movimientos con 404. No aparecen archivos del piloto en bundles públicos o trazas de la aplicación. La repetición del motor con acceso de red deshabilitado genera hashes idénticos.

La revisión manual la realizó el agente principal a partir de secciones primarias de clase, capital, eventos, enmiendas y términos vinculados. No constituye una firma humana independiente ni lectura íntegra de cada línea ajena a esas materias. La siguiente fase sigue siendo cerrar los dos huecos de evidencia del mismo piloto y volver a evaluar sus 501 comparaciones.

## Artefactos

- [Campos completos](RESULTS.json)
- [Comparaciones y resultados](pilot-results.json)
- [Certificados por clase](corporate-event-coverage.json)
- [Inventario y formularios por clase](class-inventory-certificates.json)
- [Revisión primaria y candidatos](coverage-manual-reviews.json)
- [Paquetes pendientes/bloqueados](remaining-pilot-packets.json)
- [Reconstrucción de cantidades](pilot-primary-quantity-reconstruction.json)
- [Comprobaciones manuales](pilot-manual-arithmetic-review.json)
- [Nodos de mayor alcance](high-leverage-primary-node-review.json)
- [Auditoría de fuentes y aislamiento](final-source-and-isolation-audit.json)
- [Validación](validation.json)
- [Repetición sin red](offline-replay-check.json)

## Salida solicitada

```text
'''
    reserved={'internal/trends-movements/wave1c/RESULTS.json','internal/trends-movements/wave1c/RESULTS.md','internal/trends-movements/wave1c/files-created.json'}
    paths=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines())|reserved
    fields['FILES_CREATED']=len(paths);fields['FILES_CREATED_WAVE1C_ONLY']=len([p for p in paths if p.startswith(('internal/trends-movements/wave1c/','scripts/movement_pilot_wave1c/'))])
    write('files-created.json',{'basis':'All untracked deliverable files against actual remote base; inherited internal implementation included. Build/dependency directories are ignored.','paths':sorted(paths)})
    write('RESULTS.json',fields)
    text+='\n'.join(k+'='+('null' if v is None else canonical(v) if isinstance(v,(list,dict)) else str(v)) for k,v in fields.items())+'\n```\n'
    (OUT/'RESULTS.md').write_text(text)
    print(canonical({k:fields[k] for k in ['STATE','PILOT_TOTAL_RESOLVED','PILOT_STILL_UNKNOWN','FILES_CREATED','FILES_CREATED_WAVE1C_ONLY','TESTS']}))

if __name__=='__main__':run()

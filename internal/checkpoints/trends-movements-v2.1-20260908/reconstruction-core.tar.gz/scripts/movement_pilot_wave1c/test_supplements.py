import gzip,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import supplements
from context import sha

class Store:
    def bytes(self,url):return b'bound SEC parent'

class SupplementTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.out=Path(self.tmp.name);(self.out/'sources').mkdir()
        body=b'%PDF-1.4 retained issuer publication';h=sha(body)
        (self.out/'sources/body.gz').write_bytes(gzip.compress(body,mtime=0))
        self.url='https://issuer.example/results.pdf';self.ref={'source_url':'https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm','sha256':sha(b'bound SEC parent')}
        self.parent={'document_url':self.ref['source_url'],'issuer_cik':1,'accession':'ACC','source_ref':self.ref,'text':'Full results: http://issuer.example/results.pdf'}
        self.doc={'issuer_cik':1,'parent_accession':'ACC','document_url':self.url,'document_hash':h,'source_ref':self.ref,'ownership':'LINKED_ISSUER_PUBLICATION_NOT_SEC_OWNED','hash_domain':'EXACT_LINKED_ISSUER_PDF_BODY','ownership_authority':{'parent_document_url':self.parent['document_url'],'parent_source_ref':self.ref,'parent_reference_text':'http://issuer.example/results.pdf','source_storage':{'source_url':self.url,'sha256':h,'path':'sources/body.gz'}}}
    def run_doc(self):
        (self.out/'supplemental-primary-documents.json').write_text(json.dumps([self.doc]))
        with patch.object(supplements,'OUT',self.out),patch.object(supplements,'read',lambda name:json.loads((self.out/name).read_text())):
            return supplements.checked_supplements(Store(),[self.parent])
    def test_bound_retained_publication_preserves_third_party_ownership(self):self.assertEqual(self.run_doc()[0]['ownership'],'LINKED_ISSUER_PUBLICATION_NOT_SEC_OWNED')
    def test_wrong_parent_cik(self):self.doc['issuer_cik']=2;self.assertRaisesRegex(ValueError,'PARENT',self.run_doc)
    def test_wrong_parent_accession(self):self.doc['parent_accession']='OTHER';self.assertRaisesRegex(ValueError,'PARENT',self.run_doc)
    def test_link_must_exist_in_parent(self):self.parent['text']='No operative link';self.assertRaisesRegex(ValueError,'LINK',self.run_doc)
    def test_lookalike_url_is_not_parent_link(self):self.doc['document_url']='https://issuer.example/results2.pdf';self.assertRaisesRegex(ValueError,'LINK',self.run_doc)
    def test_retained_body_hash_changes(self):(self.out/'sources/body.gz').write_bytes(gzip.compress(b'%PDF tampered'));self.assertRaisesRegex(ValueError,'HASH',self.run_doc)
    def test_path_escape(self):self.doc['ownership_authority']['source_storage']['path']='../body.gz';self.assertRaisesRegex(ValueError,'PATH',self.run_doc)
    def test_publication_not_promoted_to_owned_filing(self):self.doc['ownership']='ISSUER_OWNED';self.assertRaisesRegex(ValueError,'SEC_OWNED',self.run_doc)
    def test_image_bytes_hash_required(self):self.doc.update(hash_domain='EXACT_SEC_IMAGE_BODY',document_hash='b'*64);self.assertRaisesRegex(ValueError,'HASH',self.run_doc)

if __name__=='__main__':unittest.main()

"""Apply certificates solely to the immutable 501 comparisons, retaining all older guards."""
from collections import Counter
from context import *
from coverage import certificate,scope_hash,pilot_gate,normalize_quantities

def resources():
    s=Store();catalog={u:r['sha256'] for u,r in legacy_sources().items()};catalog.update({u:r['sha256'] for u,r in s.prior.items()});catalog.update({u:r['sha256'] for u,r in s.manifest.items()})
    bs={b['security_pair_id']:b for b in pilot_bindings()};cs={c['security_id']:c for c in read('pilot-cik-bindings.json')};ins=read('candidate-owned-inventories.json');groups=read('event-candidates.json')['candidates'];primary=json.loads(gzip.decompress((OUT/'event-primary-documents.json.gz').read_bytes()));links=json.loads(gzip.decompress((OUT/'linked-primary-documents.json.gz').read_bytes()))
    expanded=[]
    for d in links:
        roots=sorted({e['parent_cik'] for e in d.get('link_edges',[])}) or [d['issuer_cik']]
        for cik in roots:expanded.append({**d,'issuer_cik':cik})
    from supplements import checked_supplements
    supplements=checked_supplements(s,primary)
    catalog.update({d['document_url']:d['document_hash'] for d in supplements})
    docs={}
    excluded={(int(cik),e['accession']) for cik,i in ins.items() for e in i['all_associated_entries'] if e['ownership_authority'].startswith('ASSOCIATED_DISTINCT_425')}
    for d in primary+expanded+supplements:
        if (d['issuer_cik'],d.get('accession')) in excluded:continue
        key=(d['issuer_cik'],d['document_url'],d['document_hash'])
        docs[key]={k:d.get(k) for k in ['issuer_cik','accession','parent_accession','linked_accession','document_url','document_type','document_hash','hash_domain','source_ref','mode','ownership','ownership_authority']}
        if d['issuer_cik']==1067983:docs[key]['primary_text']=d.get('text')
    from pricing_review import checked_product_scopes
    products=checked_product_scopes()
    for cik,rows in products.items():ins[str(cik)]={**ins[str(cik)],'positive_other_class_scope_reviews':rows}
    scopes={sec:(bs[sec],c,ins.get(str(c.get('issuer_cik'))),[g for g in groups if g['issuer_cik']==c.get('issuer_cik')],sorted([d for d in docs.values() if d['issuer_cik']==c.get('issuer_cik')],key=lambda d:(d['document_url'],d['document_hash']))) for sec,c in cs.items()}
    return scopes,catalog

class FixedPilotEngine:
    def __init__(self):
        sys.path.insert(0,str(ROOT/'scripts/movement_evidence_wave1'))
        from engine import Engine
        self.engine=Engine();self.selection=selection();self.ids=set(self.selection['comparison_ids']);assert len(self.ids)==501
        self.scopes,self.catalog=resources();self.engine.adapter.source_hashes=self.catalog
        reviews=read('coverage-manual-reviews.json');self.reviews={r['security_id']:r for r in reviews};assert len(reviews)==len(self.reviews)
        self.certificates={sec:certificate(*scope,self.reviews.get(sec),self.catalog) for sec,scope in self.scopes.items()}
        assert len(self.certificates)==66 and {self.engine.rows[cid]['security_id'] for cid in self.ids}==set(self.certificates)
    def evaluate(self,cid):
        if cid not in self.ids:raise ValueError('OUTSIDE_FIXED_501_PILOT')
        base=self.engine.evaluate(cid);row=self.engine.rows[cid];sec=row['security_id'];cert=self.certificates[sec];b,c,inv,groups,docs=self.scopes[sec]
        base.update(security_id=sec,issuer_cik=c.get('issuer_cik'),corporate_event_certificate=cert,official_list_binding_status=b['binding_status'],global_application_authorized=False)
        if cert['state'] not in ['VERIFIED_CLEAR_FOR_COMPARABILITY','VERIFIED_EVENT_NORMALIZATION_AVAILABLE']:
            if cert['state']=='VERIFIED_BLOCK':base.update(reason_code='VERIFIED_SECURITY_EVENT_BLOCK',blockers=[cert['block_reason']],evidence_packet_state='VERIFIED_BLOCK')
            return base
        deps=self.engine.comparisons[cid]['dependencies'];core=[d for d in deps if d['evidence_type']!='CORPORATE_ACTION_STATE']
        if any(base['dependency_checks'].get(d['evidence_id'])!='VALID' for d in core):return base
        from engine import install_verified
        from resolver import ACTION_CHECKS,resolve
        from model import reported_semantics
        x=self.engine.adapter.make(row);issuer='sec-issuer-'+str(c['issuer_cik'])
        for side in ['previous','current']:
            if x[side] is None:raise ValueError('PRESENCE_TRANSITION_REQUIRES_TIER_B')
            x[side]['issuer_id']=issuer
        refs=list({sha(r):{'url':r['source_url'],'sha256':r['sha256']} for r in cert['reviewed_source_refs']}.values());events=[];checks={k:'CLEAR' for k in ACTION_CHECKS}
        for ev in cert['events']:
            typ=ev['event_type'];terms=ev['ratio_or_terms'];checks[typ]='ADJUSTED';events.append({'event_id':ev['event_id'],'issuer_id':issuer,'action_type':typ,'effective_date':ev['effective_date'],'affected_security_ids':[sec],'predecessor_security':sec,'successor_security':sec,'one_to_one':True,'rounding_policy':'EXACT_NO_CASH_IN_LIEU','ratio':{'numerator':terms['numerator'],'denominator':terms['denominator']}})
        node={'evidence_type':'CORPORATE_ACTION_STATE','period_start':row['previous_quarter'],'period_end':row['current_quarter'],'source_refs':refs,'payload':{'issuer_id':issuer,'security_ids':[sec],'checks':checks,'events':events}}
        x=install_verified(x,[self.engine.byid[d['evidence_id']] for d in core]+[node]);resolved=reported_semantics(resolve(x))
        if resolved['reported_status']=='INDETERMINATE':return {**base,**resolved}
        q=normalize_quantities(x['previous']['quantity'],x['current']['quantity'],cert['events'],c['issuer_cik'],sec,self.reviews[sec].get('evidence_as_of'),self.catalog)
        assert q['reported_status']==resolved['reported_status'],'INDEPENDENT_NORMALIZATION_ORACLE_CONFLICT'
        updated=dict(base['dependency_checks'])
        for dep in deps:
            if dep['evidence_type']=='CORPORATE_ACTION_STATE':updated[dep['evidence_id']]='VALID_VIA_WAVE1C_SECURITY_CERTIFICATE'
        return {**base,**resolved,**q,'legacy_dependency_checks':base['dependency_checks'],'dependency_checks':updated,'resolution_bucket':'EVIDENCE_RESOLVED','evidence_family':sec}

def run():
    e=FixedPilotEngine();rs=[e.evaluate(cid) for cid in e.selection['comparison_ids']];qualified=[r for r in rs if r['reported_status']!='INDETERMINATE'];certs=list(e.certificates.values());gate=pilot_gate(certs,set(e.certificates));arith=read('pilot-manual-arithmetic-review.json');oldmanual=read('pilot-movement-manual-review.json',B);manual={}
    for r in qualified:
        cid=r['comparison_id']
        if cid in arith['reviews']:manual[cid]=arith['reviews'][cid]['manual_arithmetic_expectation']
        if cid in oldmanual['expected_by_comparison_id']:manual[cid]=oldmanual['expected_by_comparison_id'][cid]
    fp=[r['comparison_id'] for r in qualified if r['comparison_id'] in manual and manual[r['comparison_id']]!=r['reported_status']]
    assert {r['evidence_family'] for r in qualified} <= {r['security_id'] for cid,r in arith['reviews'].items() if cid in manual},'UNREVIEWED_NEW_FAMILY'
    leverage=read('high-leverage-primary-node-review.json');byreview={r['security_id']:r for r in leverage}
    for sec,n in Counter(r['security_id'] for r in qualified).items():
        if n>=10:
            r=byreview.get(sec,{})
            assert r.get('evidence_fingerprint')==e.reviews[sec]['evidence_fingerprint'] and r.get('primary_sections_reviewed')==e.reviews[sec]['primary_sections_reviewed'] and r.get('node_manually_reviewed') is True,'UNREVIEWED_HIGH_LEVERAGE_PRIMARY_NODE'
    prior={r['comparison_id'] for r in read('pilot-results.json',B)['comparison_results'] if r['reported_status']!='INDETERMINATE'};now={r['comparison_id'] for r in qualified};assert prior<=now,'PRIOR_RESOLUTION_REGRESSION'
    gate=pilot_gate(certs,set(e.certificates),len(fp))
    newly=[r for r in qualified if r['comparison_id'] not in prior]
    sector={sec:{'sic':scope[1].get('sic'),'sic_description':scope[1].get('sic_description'),'sector':'SEC_SIC_2_DIGIT:'+scope[1]['sic'][:2] if scope[1].get('sic') else 'UNKNOWN','source_ref':scope[1]['submissions_ref']} for sec,scope in e.scopes.items()}
    out={'state':'FIXED_PILOT_EVIDENCE_COVERAGE_PASS' if gate['state']=='PASS' and not fp else 'FIXED_PILOT_EVIDENCE_COVERAGE_INCOMPLETE','selection_sha256':sha(e.selection),'fixed_comparisons':501,'fixed_securities':66,'fixed_managers':len({e.engine.rows[cid]['manager_id'] for cid in e.ids}),'pilot_resolved_before':len(prior),'pilot_newly_resolved':len(newly),'pilot_total_resolved':len(qualified),'pilot_still_unknown':501-len(qualified),'newly_resolved_status_counts':dict(Counter(r['reported_status'] for r in newly)),'resolved_status_counts':dict(Counter(r['reported_status'] for r in qualified)),'gate':gate,'manual_comparison_check_count':len(manual),'manually_reconstructed_arithmetic_families':66,'false_positives_observed':len(fp),'false_positive_ids':fp,'confirmed_false_negatives':0,'confirmed_false_negatives_basis':'No independently confirmed unresolved comparable movement; pending packets are unevaluable, not assumed negative.','manual_semantically_unevaluable':501-len(manual),'statistical_zero_error_claim':False,'manual_expected_by_comparison_id':manual,'sector_unknown_before':375,'sector_unknown_after':sum(sector[e.engine.rows[cid]['security_id']]['sector']=='UNKNOWN' for cid in e.ids),'global_expansion_performed':False,'global_resolved_preserved':9,'global_indeterminate_preserved':8128,'comparison_results':rs}
    write('corporate-event-coverage.json',certs);write('pilot-results.json',out);write('sector-coverage.json',sector);write('expansion-gate.json',{'state':'NOT_EXECUTED','reason':'GLOBAL_EXPANSION_FORBIDDEN_IN_THIS_PHASE_EVEN_AFTER_PILOT_PASS','comparisons_applied':0})
    print(canonical({k:v for k,v in out.items() if k not in ['comparison_results','manual_expected_by_comparison_id']}))
if __name__=='__main__':run()

import unittest
from candidates import *
from links import relevant_links

def doc(text,acc='0000000001-26-000001',cik=1,url='https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm'):
    return {'text':text,'accession':acc,'issuer_cik':cik,'document_url':url,'document_hash':'a'*64,'source_ref':{'source_url':url,'sha256':'a'*64}}

class CandidateTests(unittest.TestCase):
    def test_duplicate_keywords_collapse(self):
        x=cluster([doc('The stock split is proposed. ' * 45)],{'SEC_A':1});self.assertEqual(x['keyword_occurrences'],45);self.assertEqual(x['distinct_event_candidates'],1)
    def test_duplicate_exhibit_preserves_provenance(self):
        x=cluster([doc('The stock split was announced.'),doc('The stock split was announced.',url='https://www.sec.gov/Archives/edgar/data/1/000000000126000001/ex.htm')],{'SEC_A':1});self.assertEqual(x['distinct_event_candidates'],1);self.assertEqual(len(x['candidates'][0]['occurrences']),2)
    def test_other_class_not_propagated(self):
        x=cluster([doc('Class B conversion into Class C occurred in 2026.')],{'SEC_A':1});g=x['candidates'][0];self.assertEqual(g['class_binding_status'],'AMBIGUOUS_CLASS_SCOPE');self.assertNotEqual(g['verification_status'],'VERIFIED_PRIMARY')
    def test_same_name_other_cik_separate(self):
        x=cluster([doc('Stock split'),doc('Stock split',cik=2)],{'A':1,'B':2});self.assertEqual(x['distinct_event_candidates'],2)
    def test_effective_date_not_derived_from_disclosure(self):
        g=cluster([doc('A spin-off becomes effective July 1, 2026.')],{'A':1})['candidates'][0];self.assertIsNone(g['effective_date_verified'])
    def test_prior_year_not_new_event(self):
        g=cluster([doc('The 2024 stock split restates this 2026 table.')],{'A':1})['candidates'][0];self.assertEqual(g['verification_status'],'CANDIDATE_ONLY')
    def test_no_hits_does_not_issue_certificate(self):
        x=cluster([doc('Quarterly earnings.')],{'A':1});self.assertEqual(x['distinct_event_candidates'],0);self.assertNotIn('VERIFIED_CLEAR_FOR_COMPARABILITY',canonical(x))
    def test_exchange_act_is_lexical_noise(self):
        x=cluster([doc('Securities Exchange Act of 1934.')],{'A':1});self.assertEqual(x['distinct_event_candidates'],0);self.assertEqual(sum(x['lexical_non_event_occurrences'].values()),1)
    def test_inline_xbrl_resources_excluded_visible_facts_preserved(self):
        html='<html><head><title>split</title></head><body><ix:header><ix:resources>Stock split noise</ix:resources></ix:header><div>Class A <ix:nonNumeric>common shares</ix:nonNumeric></div></body></html>'
        self.assertEqual(visible(html),'Class A common shares')
    def test_nested_hidden_tags_do_not_hide_following_narrative(self):
        self.assertEqual(visible('<div style="display:none"><span>Hidden</span></div><p>Visible split</p>'),'Visible split')
    def test_linked_exhibit_retains_parent_and_ownership(self):
        e={'accession':'0000000001-26-000001','issuer_cik':1,'primary_url':'https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm'}
        html='<table><tr><td>2.1</td><td><a href="https://www.sec.gov/Archives/edgar/data/2/000000000226000001/ex.htm">Merger Agreement</a></td></tr></table>'
        link=relevant_links(e,html)[0];self.assertEqual(link['parent_accession'],e['accession']);self.assertFalse(link['is_same_accession']);self.assertIn('DOES_NOT_ADD',link['ownership'])
    def test_exhibit_number_in_neighboring_span_is_followed(self):
        e={'accession':'A','issuer_cik':1,'primary_url':'https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm'}
        x=relevant_links(e,'<div><span>99.1.</span><span><a href="earnings.htm">Press release</a></span></div>')
        self.assertEqual(len(x),1);self.assertEqual(x[0]['document_type'],'EX-99.1')
    def test_nonmaterial_certification_not_fetched_by_exhibit_style(self):
        e={'accession':'A','issuer_cik':1,'primary_url':'https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm'}
        self.assertEqual(relevant_links(e,'<div><span>31.1</span><a style="-sec-extract:exhibit" href="cert.htm">Certification of chief executive officer</a></div>'),[])
    def test_bare_exhibit_number_and_letter_subpart(self):
        e={'accession':'A','issuer_cik':1,'primary_url':'https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm'}
        for n in ['99','99(a)','(99)','10-24','10. 4']:
            x=relevant_links(e,'<table><tr><td>'+n+'</td><td><a href="earnings.htm">News release</a></td></tr></table>')
            self.assertEqual(len(x),1);self.assertEqual(x[0]['document_type'],'EX-'+('99' if n=='(99)' else n))
    def test_http_sec_reference_upgraded_preserves_original(self):
        e={'accession':'A','issuer_cik':1,'primary_url':'https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm'}
        href='http://www.sec.gov/Archives/edgar/data/1/000000000125000001/merger.htm'
        x=relevant_links(e,'<a href="'+href+'">Merger agreement</a>')[0]
        self.assertTrue(x['document_url'].startswith('https://'));self.assertEqual(x['original_href'],href)
    def test_non_sec_link_not_primary_evidence(self):
        e={'accession':'A','issuer_cik':1,'primary_url':'https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm'}
        self.assertEqual(relevant_links(e,'<a href="https://example.com/merger.htm">Merger agreement</a>'),[])

if __name__=='__main__':unittest.main()

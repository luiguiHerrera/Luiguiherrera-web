"""Submissions identify issuer-associated filings; holder/subject reports are not issuer-owned."""
from collections import Counter
import re
from context import *
START='2026-03-01';END='2026-08-14'
DOMESTIC={'8-K','8-K/A','10-Q','10-Q/A','10-K','10-K/A','S-4','S-4/A','424B3','425','DEF 14A','PRE 14A','DEFA14A','8-A12B','8-A12B/A','8-A12G','8-A12G/A','SC TO-I','SC TO-I/A','SC 13E3','SC 13E3/A'}
FOREIGN={'6-K','6-K/A','20-F','20-F/A','40-F','40-F/A','F-4','F-4/A','424B3','425','8-A12B','8-A12B/A','8-A12G','8-A12G/A','SC TO-I','SC TO-I/A','SC 13E3','SC 13E3/A'}
SUBJECT_OR_HOLDER_FORMS={'3','3/A','4','4/A','5','5/A','144','144/A','SC 13D','SC 13D/A','SC 13G','SC 13G/A','SCHEDULE 13D','SCHEDULE 13D/A','SCHEDULE 13G','SCHEDULE 13G/A'}
FUND={'N-1A','N-2','N-14','N-14/A','N-CSR','N-CSRS','N-CEN','497','497K','8-A12B','8-K','DEF 14A','DEFA14A'}

def distinct_425_filer(text):
    """A subject-company index must not promote another named filing person."""
    filed=re.search(r'Filed by\s+(.+?)(?:\s*\(|\s+Pursuant)',text[:3000],re.I)
    subject=re.search(r'Subject Company:\s+(.+?)(?:\s*\(|\s+Commission)',text[:3000],re.I)
    clean=lambda s:re.sub('[^a-z0-9]','',s.lower())
    return bool(filed and subject and clean(filed[1])!=clean(subject[1]))

def regime(doc,rows):
    forms={r['form'] for r in rows if r['filing_date']<='2026-08-14' and r['filing_date']>='2025-01-01'}
    domestic=bool(forms&{'10-K','10-Q'});foreign=bool(forms&{'20-F','40-F'}) or ('6-K' in forms and not domestic)
    fund=bool(forms&{'N-1A','N-2','N-CSR','N-CSRS','N-CEN','N-14'}) or doc.get('entityType')=='investment'
    if sum([domestic,foreign,fund])!=1:return 'UNSUPPORTED_OR_INDETERMINATE'
    return 'REGISTERED_FUND_OR_TRUST' if fund else 'FOREIGN_PRIVATE_ISSUER' if foreign else 'DOMESTIC_OPERATING_COMPANY'

def rows_from(rec,partition):
    required=['accessionNumber','form','filingDate','primaryDocument'];n=len(rec.get('accessionNumber',[]))
    if any(len(rec.get(k,[]))!=n for k in required):raise ValueError('INCOMPLETE_HISTORY_SHARD')
    for k in ['reportDate','items','isXBRL','isInlineXBRL']:
        if k in rec and len(rec[k])!=n:raise ValueError('INCOMPLETE_HISTORY_SHARD')
    for i,acc in enumerate(rec['accessionNumber']):
        if not re.fullmatch(r'\d{10}-\d{2}-\d{6}',acc):raise ValueError('INVALID_ACCESSION')
        yield {'accession':acc,'form':rec['form'][i],'filing_date':rec['filingDate'][i],'primary_document':rec['primaryDocument'][i],'report_date':rec.get('reportDate',['']*n)[i],'items':rec.get('items',['']*n)[i],'partition':partition}

def owned(cik,store):
    url=f'https://data.sec.gov/submissions/CIK{cik:010d}.json';doc=store.json(url)
    if int(doc['cik'])!=cik:raise ValueError('WRONG_SUBMISSIONS_CIK')
    rows=list(rows_from(doc['filings']['recent'],'recent'));checked=[];missing=[]
    for f in doc['filings'].get('files',[]):
        if f['filingFrom']>END or f['filingTo']<START:continue
        if not re.fullmatch(r'CIK'+f'{cik:010d}'+r'-submissions-\d+\.json',f['name']):raise ValueError('FOREIGN_HISTORY_SHARD')
        u='https://data.sec.gov/submissions/'+f['name']
        if not store.ref(u):missing.append(f);continue
        shard=list(rows_from(store.json(u),f['name']))
        # SEC file ranges can include a spillover date; exact arrays, not counts, provide the inventory.
        rows.extend(shard);checked.append({'name':f['name'],'declared_range':[f['filingFrom'],f['filingTo']],'source_ref':store.compact_ref(u),'rows':len(shard)})
    byacc={}
    for r in rows:
        prior=byacc.get(r['accession'])
        if prior and {k:v for k,v in prior.items() if k!='partition'}!={k:v for k,v in r.items() if k!='partition'}:raise ValueError('CONFLICTING_SUBMISSION_HISTORY')
        byacc[r['accession']]=r
    kind=regime(doc,list(byacc.values()));forms=DOMESTIC if kind=='DOMESTIC_OPERATING_COMPANY' else FOREIGN if kind=='FOREIGN_PRIVATE_ISSUER' else FUND if kind=='REGISTERED_FUND_OR_TRUST' else set()
    allwindow=[];selected=[]
    for r in sorted(byacc.values(),key=lambda x:(x['filing_date'],x['accession'])):
        if not START<=r['filing_date']<=END:continue
        e={**r,'issuer_cik':cik,'ownership_authority':'ISSUER_SUBMISSIONS_CHAIN','primary_url':f'https://www.sec.gov/Archives/edgar/data/{cik}/{r["accession"].replace("-","")}/{r["primary_document"]}','complete_submission_url':f'https://www.sec.gov/Archives/edgar/data/{cik}/{r["accession"].replace("-","")}/{r["accession"]}.txt'}
        if r['form'] in SUBJECT_OR_HOLDER_FORMS:e['ownership_authority']='ASSOCIATED_SUBJECT_OR_HOLDER_FILING; NOT_ISSUER_OWNED'
        if r['form']=='425':
            rawurl=next((u for u in [e['primary_url'],e['complete_submission_url']] if store.ref(u)),None)
            if rawurl:
                body=store.bytes(rawurl)
                if rawurl.endswith('.txt'):
                    parsed=parse_submission(body,r['accession']);narrative=next((d.get('text') or '' for d in parsed if d['filename']==r['primary_document']),'')
                else:narrative=visible(body.decode('utf-8',errors='replace'))
                if distinct_425_filer(narrative):e['ownership_authority']='ASSOCIATED_DISTINCT_425_FILING_PERSON; NOT_ISSUER_OWNED';e['filing_person_primary_ref']=store.compact_ref(rawurl)
        allwindow.append(e)
        if r['form'] in forms and e['ownership_authority']=='ISSUER_SUBMISSIONS_CHAIN':selected.append(e)
    result={'issuer_cik':cik,'entity_name':doc['name'],'entity_type':doc.get('entityType'),'sic':doc.get('sic'),'sic_description':doc.get('sicDescription'),'regime':kind,'regime_basis':sorted({r['form'] for r in rows if '2025-01-01'<=r['filing_date']<=END}),'submissions_ref':store.compact_ref(url),'authority':'ISSUER_SUBMISSIONS_CURRENT_AND_HISTORICAL','disclosure_window':[START,END],'economic_window':['2026-04-01','2026-06-30'],'forms_expected':sorted(forms),'forms_observed':dict(Counter(e['form'] for e in selected)),'accessions_observed':len(allwindow),'historical_submission_files_checked':checked,'missing_history_shards':missing,'inventory_complete':not missing,'entries':selected,'all_owned_entries':[e for e in allwindow if e['form'] not in SUBJECT_OR_HOLDER_FORMS],'all_associated_entries':allwindow,'associated_subject_or_holder_accessions':sum(e['form'] in SUBJECT_OR_HOLDER_FORMS for e in allwindow),'owned_accessions_observed':sum(e['form'] not in SUBJECT_OR_HOLDER_FORMS for e in allwindow),'excluded_forms':dict(Counter(e['form'] for e in allwindow if e['form'] not in forms)),'linked_exhibits_followed':[],'primary_review_complete':False}
    result['all_owned_entries']=[e for e in allwindow if e['ownership_authority']=='ISSUER_SUBMISSIONS_CHAIN']
    result['owned_accessions_observed']=len(result['all_owned_entries']);result['associated_subject_or_holder_accessions']=len(allwindow)-result['owned_accessions_observed']
    result['inventory_sha256']=sha(result);return result

def build():
    s=Store();ciks=sorted({c['cik'] for x in read('cik-candidates.json') for c in x['candidates']});out={}
    for cik in ciks:
        if not s.ref(f'https://data.sec.gov/submissions/CIK{cik:010d}.json'):continue
        out[str(cik)]=owned(cik,s)
    write('candidate-owned-inventories.json',out)
    print(canonical([{'cik':k,'name':v['entity_name'],'regime':v['regime'],'selected':len(v['entries']),'all':v['accessions_observed'],'complete':v['inventory_complete']} for k,v in out.items()]))
if __name__=='__main__':build()

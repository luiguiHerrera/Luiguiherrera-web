"""Security-specific coverage and explicit blocks. Global expansion is always disabled."""
from context import *
from owned_inventory import DOMESTIC,FOREIGN,START,END
from events import normalize_quantities as legacy_normalize_quantities,verified_event,valid_ref
from fractions import Fraction
STATES={'VERIFIED_CLEAR_FOR_COMPARABILITY','VERIFIED_EVENT_NORMALIZATION_AVAILABLE','VERIFIED_BLOCK','UNKNOWN'}
BLOCK_REASONS={'UNSUPPORTED_ISSUER_FILING_REGIME','AMBIGUOUS_ISSUER_CIK','UNRESOLVED_CLASS_TRANSFORMATION','CONFLICTING_EVENT_TERMS','UNSUPPORTED_VERIFIED_CORPORATE_EVENT'}

def scope_hash(binding,cik,inventory,candidates,documents):
    return sha({'binding':binding,'cik':cik,'inventory':inventory,'candidates':candidates,'documents':documents})

def class_transformation_block(proof,sec,cik,documents,catalog):
    """A disclosed nonuniform conversion can block without inventing an exact day.

    Two cumulative quarter observations establish execution within Q2. They do
    not identify which manager elected conversion, and are never a split factor.
    Free-text review-pending reasons and mere conversion authority cannot pass.
    """
    if not isinstance(proof,dict):return ['MISSING_POSITIVE_CLASS_TRANSFORMATION_EVIDENCE']
    errors=[];obs=proof.get('observations',[])
    if proof.get('issuer_cik')!=cik or proof.get('security_before')!=sec or not proof.get('security_after') or proof.get('security_after')==sec or proof.get('allocation')!='HOLDER_ELECTION_NOT_UNIFORM' or proof.get('event_family')!='CONVERSION':errors.append('WRONG_CLASS_TRANSFORMATION_SCOPE')
    if proof.get('effective_interval')!=['2026-04-01','2026-06-30'] or proof.get('exact_effective_date') is not None:errors.append('UNSUPPORTED_CLASS_TRANSFORMATION_DATE')
    if len(obs)!=2 or [o.get('cumulative_period') for o in obs]!=[['2026-01-01','2026-03-31'],['2026-01-01','2026-06-30']]:errors.append('CLASS_TRANSFORMATION_PERIOD_NOT_PROVEN')
    if len({o.get('document_url') for o in obs})!=2:errors.append('DUPLICATED_CUMULATIVE_OBSERVATION')
    terms=proof.get('terms',{});parts=obs+[terms]
    for p in parts:
        matches=[d for d in documents if d.get('document_url')==p.get('document_url') and d.get('document_hash')==p.get('document_hash') and d.get('issuer_cik')==cik and d.get('source_ref')==p.get('source_ref')]
        if not matches or not valid_ref(p.get('source_ref',{}),catalog) or not re.search(r'/data/0*'+str(cik)+r'/',p.get('document_url','')):errors.append('UNBOUND_CLASS_TRANSFORMATION_PRIMARY')
        if not p.get('primary_excerpt') or p.get('excerpt_sha256')!=sha(p.get('primary_excerpt')):errors.append('MISSING_CLASS_TRANSFORMATION_PRIMARY_TERMS')
        if not any(p.get('primary_excerpt') and p['primary_excerpt'] in (d.get('primary_text') or '') for d in matches):errors.append('CLASS_TRANSFORMATION_EXCERPT_NOT_IN_DOCUMENT')
    for o in obs:
        match=re.search(r'Conversions of Class A to Class B common stock\s*\(\s*([0-9,]+)\s*\)',o.get('primary_excerpt',''))
        if not match or int(match[1].replace(',',''))!=o.get('converted_before_units'):errors.append('EXECUTED_CONVERSION_COUNT_NOT_IN_PRIMARY_TABLE')
    nums=[o.get('converted_before_units') for o in obs]
    if len(nums)!=2 or any(type(n) is not int or n<0 for n in nums) or nums[1]<=nums[0] or proof.get('affected_before_units_in_window')!=nums[1]-nums[0]:errors.append('NO_POSITIVE_EXECUTED_CLASS_TRANSFORMATION')
    if not terms.get('holder_election_explicit') or terms.get('uniform_factor_for_existing_holders') is not False:errors.append('UNPROVEN_NONUNIFORM_CLASS_TRANSFORMATION')
    return errors

def certificate(binding,cik,inventory,groups,document_index,review,catalog):
    sec=binding['security_pair_id'];errors=[];events=[]
    fp=scope_hash(binding,cik,inventory,groups,document_index)
    base={'security_id':sec,'state':'UNKNOWN','evidence_fingerprint':fp,'events':[],'failed_checks':[],'global_application_authorized':False}
    if not review or review.get('evidence_fingerprint')!=fp or review.get('security_id')!=sec:
        return {**base,'failed_checks':['MISSING_OR_STALE_SECURITY_PRIMARY_REVIEW']}
    refs=review.get('source_refs',[])
    if not refs or any(not valid_ref(r,catalog) for r in refs):errors.append('UNBOUND_PRIMARY_REVIEW')
    if any(r.get('hash_domain','').startswith('EXACT_RETAINED_RESPONSE_PREFIX') for r in refs):errors.append('PREFIX_IS_NOT_EVENT_OR_COVERAGE_AUTHORITY')
    if review.get('state')=='VERIFIED_BLOCK':
        reason=review.get('block_reason')
        if reason not in BLOCK_REASONS or not review.get('primary_block_proof'):errors.append('UNPROVEN_BLOCK')
        if reason=='AMBIGUOUS_ISSUER_CIK' and cik.get('status')!='CIK_AMBIGUOUS':errors.append('CIK_BLOCK_CONTRADICTS_VERIFIED_IDENTITY')
        if reason=='UNSUPPORTED_ISSUER_FILING_REGIME' and cik.get('regime') not in ['UNSUPPORTED_OR_INDETERMINATE','REGISTERED_FUND_OR_TRUST']:errors.append('SUPPORTED_REGIME_CANNOT_BE_BLOCKED_AS_UNSUPPORTED')
        if reason=='UNRESOLVED_CLASS_TRANSFORMATION':errors+=class_transformation_block(review.get('class_transformation_evidence'),sec,cik.get('issuer_cik'),document_index,catalog)
        # No conflict packet is supported in this pilot yet. A prose allegation
        # must not become a verified block without a terms-conflict verifier.
        if reason=='CONFLICTING_EVENT_TERMS':errors.append('POSITIVE_TERMS_CONFLICT_VERIFIER_REQUIRED')
        if reason=='UNSUPPORTED_VERIFIED_CORPORATE_EVENT':
            event=review.get('blocking_event',{})
            if event.get('verification_status')!='VERIFIED_PRIMARY' or event.get('issuer_cik')!=cik.get('issuer_cik') or sec not in event.get('security_before',[]) or not '2026-04-01'<=event.get('effective_date','')<='2026-06-30' or not event.get('source_sections'):errors.append('BLOCKING_EVENT_NOT_VERIFIED_IN_SCOPE')
            if event.get('event_type') in ['SPLIT','REVERSE_SPLIT']:errors.append('SUPPORTED_NORMALIZATION_REQUIRES_TERMS_REVIEW')
            erefs=event.get('source_refs',[])
            if not erefs or any(not valid_ref(r,catalog) or not re.search(r'/data/0*'+str(cik.get('issuer_cik'))+r'/',r.get('source_url','')) for r in erefs):errors.append('UNBOUND_BLOCKING_EVENT_SOURCE')
            if not event.get('primary_excerpt') or not event.get('source_accessions'):errors.append('MISSING_BLOCKING_EVENT_PRIMARY_TERMS')
            if event.get('event_type') not in {'MERGER','SPINOFF','CONVERSION','EXCHANGE','CUSIP_CHANGE','SHARE_CLASS_CHANGE','RECLASSIFICATION','REORGANIZATION','OTHER'}:errors.append('UNSUPPORTED_BLOCK_EVENT_TYPE')
        return {**base,'state':'UNKNOWN' if errors else 'VERIFIED_BLOCK','block_reason':reason,'block_proof':review.get('primary_block_proof'),'failed_checks':errors,'blocking_event':review.get('blocking_event'),'class_transformation_evidence':review.get('class_transformation_evidence')}
    if review.get('state') not in ['VERIFIED_CLEAR_FOR_COMPARABILITY','VERIFIED_EVENT_NORMALIZATION_AVAILABLE']:errors.append('PRIMARY_REVIEW_NOT_CLEARED')
    if cik.get('status')!='CIK_VERIFIED':errors.append('ISSUER_CIK_NOT_VERIFIED')
    regime=cik.get('regime');expected=DOMESTIC if regime=='DOMESTIC_OPERATING_COMPANY' else FOREIGN if regime=='FOREIGN_PRIVATE_ISSUER' else set()
    if not expected:errors.append('UNSUPPORTED_ISSUER_FILING_REGIME')
    if not inventory or inventory.get('issuer_cik')!=cik.get('issuer_cik') or inventory.get('authority')!='ISSUER_SUBMISSIONS_CURRENT_AND_HISTORICAL' or not inventory.get('inventory_complete') or inventory.get('missing_history_shards') or not expected.issubset(set(inventory.get('forms_expected',[]))):errors.append('INCOMPLETE_ISSUER_OWNED_INVENTORY')
    for q in ['q1','q2']:
        official=binding.get(q+'_official_binding') or {}
        if official.get('quarter')!={'q1':'2026Q1','q2':'2026Q2'}[q] or official.get('cusip')!=binding.get(q+'_cusip') or catalog.get(official.get('source_url'))!=official.get('source_sha256'):errors.append('UNBOUND_OFFICIAL_PERIOD_SOURCE')
    if not cik.get('proofs') or any(catalog.get(p.get('source_url'))!=p.get('source_hash') for p in cik.get('proofs',[])):errors.append('UNBOUND_VERIFIED_CIK_PROOF')
    if inventory:
        irefs=[inventory.get('submissions_ref',{})]+[h.get('source_ref',{}) for h in inventory.get('historical_submission_files_checked',[])]
        if any(not valid_ref(r,catalog) for r in irefs):errors.append('UNBOUND_INVENTORY_SOURCE')
        if inventory.get('disclosure_window')!=[START,END] or inventory.get('economic_window')!=['2026-04-01','2026-06-30']:errors.append('WRONG_COVERAGE_WINDOW')
    if binding.get('binding_status')!='EXACT_BOTH' or not binding.get('q1_official_binding') or not binding.get('q2_official_binding'):errors.append('OFFICIAL_PERIOD_BINDING_MISSING')
    if binding.get('q1_cusip')!=binding.get('q2_cusip') or binding.get('class_q1')!=binding.get('class_q2'):errors.append('CLASS_TRANSFORMATION_UNRESOLVED')
    flags=['list_name_status_anomalies_reviewed','registered_security_class_reviewed','quarter_equity_units_reviewed','quantity_changing_events_reviewed','required_forms_inspected','relevant_linked_terms_inspected','no_unresolved_relevant_link','no_conflicting_authoritative_source','amendment_blockers_reviewed','narrative_coverage_beyond_keywords_reviewed']
    if any(review.get(k) is not True for k in flags):errors.append('INCOMPLETE_OPERATIONAL_PRIMARY_REVIEW')
    owned={e['accession'] for e in (inventory or {}).get('entries',[])}
    products=(inventory or {}).get('positive_other_class_scope_reviews',[])
    inspected={d.get('accession') for d in document_index}
    for p in products:
        if p.get('issuer_cik')!=cik.get('issuer_cik') or p.get('accession') not in owned or p.get('class_binding_status')!='APPLIES_TO_OTHER_CLASS' or p.get('coverage_authority') is not False or p.get('event_verification_authority') is not False or not p.get('primary_excerpt'):errors.append('UNBOUND_OTHER_CLASS_PRODUCT_SCOPE')
        else:inspected.add(p['accession'])
    if not owned.issubset(inspected):errors.append('OWNED_ACCESSION_WITHOUT_PRIMARY_OR_POSITIVE_OTHER_CLASS_PROOF')
    records=review.get('accession_reviews',[])
    if {r['accession'] for r in records}!=owned or len(records)!=len(owned) or any(not r.get('primary_reason') or r.get('disposition') not in ['INSPECTED_RELEVANT_PRIMARY','VERIFIED_OTHER_SECURITY_SCOPE'] for r in records):errors.append('UNREVIEWED_OWNED_ACCESSIONS')
    decisions=review.get('candidate_reviews',[]);groupids={g['candidate_id'] for g in groups}
    if {r.get('candidate_id') for r in decisions}!=groupids or len(decisions)!=len(groupids) or any(r.get('status') not in ['APPLIES_TO_SECURITY','APPLIES_TO_OTHER_CLASS','NOT_RELEVANT'] or not r.get('primary_reason') for r in decisions):errors.append('UNRESOLVED_CLASS_EVENT_CANDIDATE')
    if any(not valid_ref(d.get('source_ref',{}),catalog) for d in document_index):errors.append('UNBOUND_DOCUMENT_INDEX')
    if any(d.get('hash_domain')=='EXACT_LINKED_ISSUER_PDF_BODY' and (catalog.get(d.get('document_url'))!=d.get('document_hash') or d.get('ownership')!='LINKED_ISSUER_PUBLICATION_NOT_SEC_OWNED') for d in document_index):errors.append('UNBOUND_ISSUER_SUPPLEMENT')
    if any(d.get('issuer_cik')!=cik.get('issuer_cik') for d in document_index):errors.append('FOREIGN_DOCUMENT_ROOT')
    if not review.get('primary_sections_reviewed'):errors.append('NO_PRIMARY_NARRATIVE_COVERAGE')
    events=review.get('events',[])
    for event in events:errors+=verified_event(event,cik.get('issuer_cik'),sec,review.get('evidence_as_of'),catalog)
    if any(e.get('event_type') not in ['SPLIT','REVERSE_SPLIT'] for e in events):errors.append('UNSUPPORTED_TRANSFORMATION')
    for d in decisions:
        if d.get('status')=='APPLIES_TO_SECURITY' and d.get('event_id') not in {e.get('event_id') for e in events}:errors.append('UNBOUND_APPLICABLE_EVENT')
    state='UNKNOWN' if errors else 'VERIFIED_EVENT_NORMALIZATION_AVAILABLE' if events else 'VERIFIED_CLEAR_FOR_COMPARABILITY'
    return {**base,'state':state,'failed_checks':sorted(set(errors)),'events':events if not errors else [],'review_sha256':sha(review),'reviewed_source_refs':refs}

def pilot_gate(certificates,eligible_security_ids,manual_errors=0):
    by={c['security_id']:c for c in certificates}
    if len(by)!=len(certificates) or set(by)!=set(eligible_security_ids):raise ValueError('PILOT_SECURITY_SCOPE_DRIFT')
    counts=__import__('collections').Counter(c['state'] for c in certificates)
    if any(k not in STATES for k in counts):raise ValueError('INVALID_PACKET_STATE')
    return {'state':'PASS' if not counts['UNKNOWN'] and not manual_errors else 'FAIL','packet_counts':dict(counts),'unknown_packets':counts['UNKNOWN'],'global_expansion_authorized':False,'global_expansion_performed':False,'basis':'All BOTH_PRESENT fixed-pilot securities have explicit clear, normalized-event or evidenced-block disposition; resolution rate reported separately.'}

def expand(*args,**kwargs):raise ValueError('GLOBAL_EXPANSION_FORBIDDEN_IN_WAVE1C')


def normalize_quantities(previous,current,events,cik,security,as_of,catalog):
    result=legacy_normalize_quantities(previous,current,events,cik,security,as_of,catalog)
    factor=Fraction(result['corporate_action_factor'])
    return {**result,'previous_quantity':str(Fraction(str(previous))),'normalization_numerator':factor.numerator,'normalization_denominator':factor.denominator,'quantity_model':'EXACT_REPORTED_SHARES_WITH_EXPLICIT_RATIONAL_NORMALIZATION'}

"""Positive product-scope triage; deliberately cannot certify event absence."""
from context import *

def classify(text):
    head=text[:7000]
    rules=[('STRUCTURED_NOTES_PRODUCT',r'(?:notes offered by|Structured Investments.{0,450}Notes Linked|Medium-Term Notes|notes are not bank deposits)'),('INDEX_METHOD_OR_PERFORMANCE',r'(?:index fact sheet|indices supplement|index supplement)')]
    for rule,pat in rules:
        m=re.search(pat,head,re.I)
        if m:return {'class_binding_status':'APPLIES_TO_OTHER_CLASS','rule':rule,'primary_excerpt':head[max(0,m.start()-180):min(len(head),m.end()+900)],'primary_reason':'Explicit prospectus product scope is a structured note or an index methodology/performance supplement. Referenced equity/ETF names are underlyings, not a conversion of the pilot issuer common class.'}
    return {'class_binding_status':'AMBIGUOUS_CLASS_SCOPE','rule':None,'primary_excerpt':head[:1000],'primary_reason':'Cover alone did not establish product scope.'}

def run():
    p=read('pricing-cover-index.json');out=[]
    for r in p['records']:
        b=gzip.decompress((OUT/r['path']).read_bytes());assert sha(b)==r['source_hash']
        c=classify(r['text']);out.append({**{k:r[k] for k in ['issuer_cik','accession','document_url','source_hash','hash_domain','full_document_retained']},**c,'coverage_authority':False,'event_verification_authority':False,'method':'Deterministic positive product-scope rule, with manual template inspection and individual inspection of 13 initial rule exceptions. No absence conclusion from a prefix.'})
    write('pricing-product-scope-review.json',{'records':out,'classification_counts':dict(__import__('collections').Counter(r['class_binding_status'] for r in out)),'coverage_certificate':False,'all_691_covers_available':len(out)==691 and not p['failures']})
    print(__import__('collections').Counter(r['class_binding_status'] for r in out))

def checked_product_scopes():
    """Bind positive other-product decisions to exact retained bytes, never absence."""
    p=read('pricing-cover-index.json');covers={r['accession']:r for r in p['records']};out={}
    for r in read('pricing-product-scope-review.json')['records']:
        c=covers[r['accession']];body=gzip.decompress((OUT/c['path']).read_bytes())
        if sha(body)!=r['source_hash'] or c['source_hash']!=r['source_hash'] or c['issuer_cik']!=r['issuer_cik'] or c['document_url']!=r['document_url']:raise ValueError('UNBOUND_PRODUCT_SCOPE_SOURCE')
        t=visible(body.decode('utf-8',errors='replace'));decision=classify(t)
        if c['text']!=t or any(r[k]!=decision[k] for k in decision):raise ValueError('PRODUCT_SCOPE_PRIMARY_REVIEW_MISMATCH')
        if r['class_binding_status']!='APPLIES_TO_OTHER_CLASS' or r['coverage_authority'] is not False or r['event_verification_authority'] is not False:raise ValueError('PREFIX_CANNOT_BECOME_COVERAGE_AUTHORITY')
        out.setdefault(r['issuer_cik'],[]).append(r)
    return out
if __name__=='__main__':run()

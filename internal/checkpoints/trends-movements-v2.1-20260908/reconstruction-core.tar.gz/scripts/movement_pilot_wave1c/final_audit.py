"""Offline source/storage and product-isolation audit for the fixed pilot only."""
from context import *
from pilot_engine import resources
import subprocess
from collections import Counter

def run():
    pre=read('preflight.json');s=Store();scopes,catalog=resources()
    for group in ['tracked_files','preserved_files']:
        for r in pre[group]:assert sha((ROOT/r['path']).read_bytes())==r['sha256'],('IMMUTABLE_FILE_CHANGED',r['path'])
    corpus=gzip.decompress((ROOT/'internal/trends-movements/v2.1/corpus.jsonl.gz').read_bytes())
    assert sha(corpus)=='d270f69dc303daa6d694fbafa6d4c91166cdcfb60c4e1fb5bc90b105b5143ac3'
    assert len(corpus.splitlines())==8137
    assert sha((ROOT/'lib/trends/capital/generated/snapshot.json.gz').read_bytes())=='42d0ac9e2168dec775d589d255c13052fcf757f83e89c688ebbd117b3490274a'
    assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip()
    subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
    source_urls=set(s.manifest)
    for b,c,i,g,ds in scopes.values():
        source_urls.update(d['source_ref']['source_url'] for d in ds)
        source_urls.update([i['submissions_ref']['source_url']]+[h['source_ref']['source_url'] for h in i['historical_submission_files_checked']])
        source_urls.update(p['source_url'] for p in c['proofs'])
        source_urls.update(b[q+'_official_binding']['source_url'] for q in ['q1','q2'])
    for u in sorted(source_urls):s.bytes(u)
    from review_dossier import documents
    indexed=documents();blocks={}
    for d in indexed:
        u=d['source_ref']['source_url']
        if d['hash_domain']=='ORIGINAL_DOCUMENT_BYTES':assert d['document_hash']==sha(s.bytes(u))
        else:
            if u not in blocks:blocks[u]={sha(b.encode()):b for b in re.findall(r'<DOCUMENT>(.*?)</DOCUMENT>',s.bytes(u).decode('utf-8',errors='replace'),re.S|re.I)}
            assert d['document_hash'] in blocks[u],('DOCUMENT_BLOCK_HASH_MISMATCH',d['document_url'])
        if d['issuer_cik']==1067983 and d.get('text') and d['document_type']=='10-Q':
            raw=s.bytes(u).decode('utf-8',errors='replace') if d['hash_domain']=='ORIGINAL_DOCUMENT_BYTES' else re.search(r'<TEXT>(.*)</TEXT>',blocks[u][d['document_hash']],re.S|re.I)[1]
            assert visible(raw)==d['text'],'BLOCK_PRIMARY_TEXT_DIVERGES_FROM_RAW'
    inherited={u:s.ref(u) for u in source_urls if u not in s.manifest}
    external=[d['ownership_authority']['source_storage'] for d in read('supplemental-primary-documents.json') if d['hash_domain']=='EXACT_LINKED_ISSUER_PDF_BODY']
    prefixes=[{'source_url':r['document_url'],'sha256':r['source_hash'],'path':r['path'],'bytes':r['bytes_received']} for r in read('pricing-cover-index.json')['records']]
    current=list(s.manifest.values())+external+prefixes
    unique={r['sha256']:r for r in current}
    disk={str(p.relative_to(OUT)):p for p in (OUT/'sources').glob('*.gz')}
    assert set(disk)=={r['path'] for r in current},'UNACCOUNTED_SOURCE_FILE'
    for path,p in disk.items():assert sha(gzip.decompress(p.read_bytes()))==p.name.split('.')[0]
    excluded=read('excluded-download-ledger.json')['sources']
    noise=[]
    for p in list((ROOT/'.next/static').rglob('*'))+list((ROOT/'.next/server/app').rglob('*.nft.json')):
        if p.is_file() and any(t in p.read_bytes() for t in [b'wave1c',b'internal/trends-movements',b'pilot-results.json']):noise.append(str(p.relative_to(ROOT)))
    assert not noise,('PUBLIC_BUNDLE_CONTAINS_INTERNAL_EVIDENCE',noise)
    invs={str(c['issuer_cik']):i for b,c,i,g,ds in scopes.values()};groups=read('event-candidates.json')
    stats={'source_bytes_downloaded_this_wave_raw':sum(r['bytes'] for r in current)+sum(r['bytes'] for r in excluded.values()),'source_bytes_retained_this_wave_stored':sum(p.stat().st_size for p in disk.values()),'source_bytes_retained_this_wave_uncompressed_unique':sum(r['bytes'] for r in unique.values()),'new_unique_source_bodies':len(unique),'new_source_urls':len(current),'discarded_unreferenced_admin_source_urls':len(excluded),'discarded_raw_bytes':sum(r['bytes'] for r in excluded.values()),'reused_source_urls':len(inherited),'reused_source_bytes_raw_url_sum':sum(r.get('bytes',len(s.bytes(u))) for u,r in inherited.items()),'documents_indexed_before_deduplication':groups['document_records_before_deduplication'],'documents_retained_in_scoped_review_catalog':groups['document_records_after_deduplication']+len(read('supplemental-primary-documents.json')),'issuer_associated_metadata_accessions':sum(i['accessions_observed'] for i in invs.values()),'issuer_owned_all_forms_accessions':sum(i['owned_accessions_observed'] for i in invs.values()),'issuer_owned_relevant_form_accessions':sum(len(i['entries']) for i in invs.values()),'filing_regimes_by_security':dict(Counter(c['regime'] for b,c,i,g,d in scopes.values())),'verified_distinct_issuers':len(invs),'checked_historical_shards':sum(len(i['historical_submission_files_checked']) for i in invs.values()),'source_urls_verified':len(source_urls)}
    result={'state':'PASS','tracked_files_unchanged':len(pre['tracked_files']),'preserved_files_unchanged':len(pre['preserved_files']),'corpus_count':8137,'corpus_sha256':sha(corpus),'public_snapshot_sha256':sha((ROOT/'lib/trends/capital/generated/snapshot.json.gz').read_bytes()),'public_bundle_internal_matches':noise,'storage':stats,'storage_definitions':'Downloaded = successful source response bytes newly acquired in Wave 1C, including later-discarded admin bodies. Retained = unique gzip bytes physically stored in wave1c/sources. Reused inherited evidence is reported separately, never counted as a new download. Review documents include exhibits contained in reused complete submissions; 42 PDF pages count as one PDF, and keyword hits are not documents.'}
    write('final-source-and-isolation-audit.json',result)
    reviews={r['security_id']:r for r in read('coverage-manual-reviews.json')}
    write('class-inventory-certificates.json',[{'security_id':sec,'issuer_cik':c['issuer_cik'],'regime':c['regime'],'forms_expected':i['forms_expected'],'forms_observed':i['forms_observed'],'accessions_observed':[e['accession'] for e in i['entries']],'historical_submission_files_checked':i['historical_submission_files_checked'],'linked_exhibits_followed':[d for d in ds if d.get('parent_accession') and d.get('document_type') not in ['10-Q','10-K','8-K','6-K','20-F']],'inventory_complete':i['inventory_complete'],'positive_product_class_scopes':i.get('positive_other_class_scope_reviews',[]),'primary_review_complete':reviews[sec]['state']!='UNKNOWN','review_state':reviews[sec]['state'],'inventory_sha256':i['inventory_sha256'],'coverage_fingerprint':reviews[sec]['evidence_fingerprint']} for sec,(b,c,i,g,ds) in scopes.items()])
    print(canonical(result))

if __name__=='__main__':run()

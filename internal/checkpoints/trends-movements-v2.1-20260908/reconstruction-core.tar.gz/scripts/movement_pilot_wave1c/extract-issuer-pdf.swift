import Foundation
import PDFKit
import Vision
import AppKit
let source = CommandLine.arguments[1]
let output = CommandLine.arguments[2]
let doc = PDFDocument(url: URL(fileURLWithPath: source))!
var results = [[String: Any]]()
for index in 0..<doc.pageCount {
    let page = doc.page(at: index)!
    let thumbnail = page.thumbnail(of: NSSize(width: 1600, height: 2200), for: .mediaBox)
    var rect = NSRect(origin: .zero, size: thumbnail.size)
    let cg = thumbnail.cgImage(forProposedRect: &rect, context: nil, hints: nil)!
    let req = VNRecognizeTextRequest()
    req.recognitionLevel = .accurate
    req.recognitionLanguages = ["en-US"]
    try VNImageRequestHandler(cgImage: cg).perform([req])
    let lines = (req.results ?? []).compactMap { $0.topCandidates(1).first?.string }
    results.append(["page": index + 1, "text": lines.joined(separator: "\n"), "method": "APPLE_VISION_OCR_1600x2200_RENDER"])
}
let data = try JSONSerialization.data(withJSONObject: results, options: [.sortedKeys])
try data.write(to: URL(fileURLWithPath: output))
print("OCR pages:", doc.pageCount)

"""Follow relevant SEC exhibits from issuer-owned accessions; preserve the parent edge."""
from functools import lru_cache
from urllib.parse import urljoin,urlparse,urldefrag,urlsplit,urlunsplit
from bs4 import BeautifulSoup
import re
from context import *
from documents import primary,full_documents

@lru_cache(maxsize=3)
def raw_blocks(full):
    s=Store();out={}
    for b in re.findall(r'<DOCUMENT>(.*?)</DOCUMENT>',s.bytes(full).decode('utf-8',errors='replace'),re.S|re.I):
        name=re.search(r'<FILENAME>\s*([^\r\n<]+)',b,re.I);text=re.search(r'<TEXT>(.*)</TEXT>',b,re.S|re.I)
        if name and text:out[name[1].strip()]=text[1]
    return out

def primary_html(e,s):
    if s.ref(e['complete_submission_url']):return raw_blocks(e['complete_submission_url'])[e['primary_document']]
    return s.bytes(e['primary_url']).decode('utf-8',errors='replace')

def relevant_links(e,html):
    soup=BeautifulSoup(html,'html.parser');out=[]
    for a in soup.find_all('a',href=True):
        href=a['href'];u=urldefrag(urljoin(e['primary_url'],href))[0]
        parsed=urlsplit(u)
        if parsed.scheme=='http' and parsed.hostname in ['www.sec.gov','data.sec.gov']:
            u=urlunsplit(('https',parsed.netloc,parsed.path,parsed.query,''))
        if u==e['primary_url'] or href.startswith('#'):continue
        if urlparse(u).hostname not in ['www.sec.gov','www.sec.gov.','data.sec.gov'] or '/Archives/edgar/data/' not in u:continue
        label=a.get_text(' ',strip=True);parent=a.find_parent('tr') or a.find_parent(['div','p','li','td']);context=parent.get_text(' ',strip=True) if parent else a.parent.get_text(' ',strip=True)
        context=re.sub(r'\s+',' ',context.replace('\u200b',''))
        kind=re.search(r'\b(?:EX-?|Exhibit\s*)?((?:2|3|4|10|99)[.-]\s*\d+)\b',context,re.I)
        if not kind:
            # SEC exhibit numbers may be bare (e.g. "99 News Release") or
            # use letter subparts. Anchor this fallback to the row start so
            # a narrative date or an EX-31 certification is not selected.
            kind=re.match(r'\s*[*(]*(?:EX-?|Exhibit\s*)?((?:2|3|4|10|99)(?:\([a-z]\)|[a-z])?)(?=\s|[).:*+]|$)',context,re.I)
        current=u.rsplit('/',1)[0]==e['primary_url'].rsplit('/',1)[0]
        material=bool(re.search(r'certificate|articles|bylaws|by-laws|capital stock|ordinary shares|common stock|merger|separation|spin.off|exchange agreement|conversion|deposit(?:ary|\s+agreement)|recapital|stock.*(?:plan|purchase|award)|equity.*(?:plan|award|distribution agreement)',context,re.I))
        if not ((current and kind) or material):continue
        if u.lower().endswith(('.jpg','.jpeg','.png','.gif','.zip','.xsd')):continue
        out.append({'parent_accession':e['accession'],'parent_cik':e['issuer_cik'],'parent_source_url':e['primary_url'],'document_url':u,'original_href':href,'document_type':'EX-'+kind[1] if kind else 'INCORPORATED_MATERIAL_TERMS','link_label':label,'link_context':context[:3500],'is_same_accession':current,'ownership':'ATTACHED_OR_LINKED_DOCUMENT; DOES_NOT_ADD_ISSUER_OWNED_ACCESSION'})
    return list({sha(x):x for x in out}.values())

def plan():
    s=Store();out=[];fail=[]
    for n,e in enumerate(read('primary-event-document-plan.json')['entries'],1):
        try:out.extend(relevant_links(e,primary_html(e,s)))
        except Exception as ex:fail.append({'accession':e['accession'],'error':str(ex)})
        if n%100==0:print(n,len(out),flush=True)
    supplemental=OUT/'supplemental-class-link-plan.json'
    if supplemental.exists():
        for edge in read('supplemental-class-link-plan.json')['edges']:
            ref=edge.get('parent_source_ref',{})
            assert s.ref(ref.get('source_url')) and s.ref(ref['source_url'])['sha256']==ref.get('sha256'),'UNBOUND_SUPPLEMENTAL_PARENT'
            out.append(edge)
    write('linked-document-plan.json',{'edges':out,'failures':fail,'authority':'STARTS_AT_ISSUER_OWNED_PRIMARY_ACCESSION','all_links_are_candidates_for_materiality_review':True})
    print('LINK_EDGES',len(out),'URLS',len({x['document_url'] for x in out}),flush=True)

def retrieve():
    s=Store();plan=read('linked-document-plan.json');out=[];fail=[]
    existing=json.loads(gzip.decompress((OUT/'event-primary-documents.json.gz').read_bytes()));byurl={d['document_url']:d for d in existing}
    urls=sorted({x['document_url'] for x in plan['edges']})
    for n,u in enumerate(urls,1):
        edge=next(x for x in plan['edges'] if x['document_url']==u)
        if u in byurl:
            d=byurl[u];out.append({**d,'link_edges':[x for x in plan['edges'] if x['document_url']==u],'reused_attached_document':True});continue
        try:
            s.get(u,'TARGETED_LINKED_CLASS_EVENT_OR_EQUITY_EXHIBIT');b=s.bytes(u)
            if b.startswith(b'%PDF'):text=None;mode='PDF_REVIEW_REQUIRED';links=[]
            else:
                raw=b.decode('utf-8',errors='replace');p=NarrativeText();p.feed(raw);text=visible(raw);links=sorted(set(p.links));mode='TEXT'
            m=re.search(r'/data/(\d+)/(\d{18})/',u)
            if m:a=m[2];acc=a[:10]+'-'+a[10:12]+'-'+a[12:];path_cik=int(m[1])
            else:
                m=re.search(r'/data/(\d+)/(\d{10}-\d{2}-\d{6})\.(?:txt|html?)$',u,re.I)
                assert m,'LINKED_URL_HAS_NO_ACCESSION';path_cik=int(m[1]);acc=m[2]
            out.append({'issuer_cik':edge['parent_cik'],'source_filer_path_cik':path_cik,'accession':edge['parent_accession'],'linked_accession':acc,'parent_accession':edge['parent_accession'],'document_url':u,'document_type':edge['document_type'],'text':text,'links':links,'mode':mode,'source_ref':s.compact_ref(u),'document_hash':sha(b),'hash_domain':'ORIGINAL_DOCUMENT_BYTES','link_edges':[x for x in plan['edges'] if x['document_url']==u],'ownership':'LINKED_ONLY; NOT_ADDED_TO_OWNED_INVENTORY'})
        except Exception as ex:fail.append({'document_url':u,'error':str(ex)});print('ERROR',u,str(ex),flush=True)
        if n%20==0:print(n,len(urls),flush=True)
    (OUT/'linked-primary-documents.json.gz').write_bytes(gzip.compress((canonical(out)+'\n').encode(),mtime=0));write('linked-document-retrieval.json',{'unique_urls_planned':len(urls),'retained':len(out),'failures':fail,'recursive_link_closure':'REQUIRES_PRIMARY_REVIEW; ONE_HOP_RETRIEVAL_IS_NOT_A_CLEAR_CERTIFICATE'})
if __name__=='__main__':
    if sys.argv[-1]=='plan':plan()
    else:retrieve()

import unittest
from copy import deepcopy
from coverage import *

U='https://www.sec.gov/Archives/edgar/data/1/000000000126000001/p.htm';H='a'*64;REF={'source_url':U,'sha256':H}

def fixture():
    b={'security_pair_id':'A','binding_status':'EXACT_BOTH','q1_cusip':'111111111','q2_cusip':'111111111','class_q1':'CL A','class_q2':'CL A'}
    for q in ['q1','q2']:b[q+'_official_binding']={'quarter':{'q1':'2026Q1','q2':'2026Q2'}[q],'cusip':'111111111','source_url':U,'source_sha256':H}
    c={'status':'CIK_VERIFIED','issuer_cik':1,'regime':'DOMESTIC_OPERATING_COMPANY','proofs':[{'source_url':U,'source_hash':H}]}
    i={'issuer_cik':1,'authority':'ISSUER_SUBMISSIONS_CURRENT_AND_HISTORICAL','inventory_complete':True,'forms_expected':sorted(DOMESTIC),'entries':[{'accession':'ACC'}],'submissions_ref':REF,'disclosure_window':[START,END],'economic_window':['2026-04-01','2026-06-30']}
    g=[{'candidate_id':'G'}];ds=[{'issuer_cik':1,'accession':'ACC','source_ref':REF}]
    r={'security_id':'A','state':'VERIFIED_CLEAR_FOR_COMPARABILITY','source_refs':[REF],'accession_reviews':[{'accession':'ACC','disposition':'INSPECTED_RELEVANT_PRIMARY','primary_reason':'Reviewed owned primary.'}],'candidate_reviews':[{'candidate_id':'G','status':'NOT_RELEVANT','primary_reason':'Hypothetical adjustment clause, not an executed event.'}],'primary_sections_reviewed':['Common shares and quarter equity rollforward'],'evidence_as_of':'2026-09-07'}
    for k in ['list_name_status_anomalies_reviewed','registered_security_class_reviewed','quarter_equity_units_reviewed','quantity_changing_events_reviewed','required_forms_inspected','relevant_linked_terms_inspected','no_unresolved_relevant_link','no_conflicting_authoritative_source','amendment_blockers_reviewed','narrative_coverage_beyond_keywords_reviewed']:r[k]=True
    r['evidence_fingerprint']=scope_hash(b,c,i,g,ds)
    return b,c,i,g,ds,r,{U:H}

def event(typ='SPLIT'):
    return {'event_id':'E','verification_status':'VERIFIED_PRIMARY','event_type':typ,'issuer_cik':1,'security_before':['A'],'security_after':['A'],'effective_date':'2026-06-01','source_refs':[REF],'source_sections':['Explicit primary terms'],'source_accessions':['ACC'],'primary_excerpt':'One child share for two parent shares effective June 1, 2026.','evidence_as_of':'2026-09-07','ratio_or_terms':{'basis':'EXPLICIT_PRIMARY_RATIO','numerator':2,'denominator':1,'fractional_share_treatment_verified':True}}

def refresh(x):x[5]['evidence_fingerprint']=scope_hash(*x[:5]);return x

class CoverageTests(unittest.TestCase):
    def test_inventory_boolean_without_retained_primary_fails(self):
        x=fixture();x[4][0].pop('accession');self.assertEqual(certificate(*refresh(x))['state'],'UNKNOWN')
    def test_positive_other_class_scope_can_cover_excluded_product(self):
        x=fixture();x[4][0].pop('accession');x[2]['positive_other_class_scope_reviews']=[{'issuer_cik':1,'accession':'ACC','class_binding_status':'APPLIES_TO_OTHER_CLASS','coverage_authority':False,'event_verification_authority':False,'primary_excerpt':'Senior Notes'}];self.assertEqual(certificate(*refresh(x))['state'],'VERIFIED_CLEAR_FOR_COMPARABILITY')
    def test_prefix_cannot_supply_negative_coverage(self):
        x=fixture();x[2]['positive_other_class_scope_reviews']=[{'issuer_cik':1,'accession':'ACC','class_binding_status':'APPLIES_TO_OTHER_CLASS','coverage_authority':True,'event_verification_authority':False,'primary_excerpt':'No event keyword'}];self.assertEqual(certificate(*refresh(x))['state'],'UNKNOWN')
    def result(self,x):return certificate(*x)
    def test_complete_clear_certificate(self):self.assertEqual(self.result(fixture())['state'],'VERIFIED_CLEAR_FOR_COMPARABILITY')
    def test_no_manual_review_is_unknown(self):x=list(fixture());x[5]=None;self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_no_keywords_not_clear(self):x=list(fixture());x[3]=[];x[5]['candidate_reviews']=[];x[5]['narrative_coverage_beyond_keywords_reviewed']=False;self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_partial_historical_chain(self):x=fixture();x[2]['missing_history_shards']=['A'];self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_global_search_not_inventory(self):x=fixture();x[2]['authority']='GLOBAL_FULL_TEXT_SEARCH';self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_foreign_document_root(self):x=fixture();x[4][0]['issuer_cik']=2;self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_stale_primary_review(self):x=fixture();x[2]['entries'].append({'accession':'NEW'});self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_unreviewed_accession(self):x=fixture();x[5]['accession_reviews']=[];self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_unresolved_class_candidate(self):x=fixture();x[5]['candidate_reviews'][0]['status']='AMBIGUOUS_CLASS_SCOPE';self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_issuer_level_not_clear(self):x=fixture();x[5]['candidate_reviews'][0]['status']='ISSUER_LEVEL_ONLY';self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_other_class_can_be_excluded_with_primary_reason(self):x=fixture();x[5]['candidate_reviews'][0]['status']='APPLIES_TO_OTHER_CLASS';self.assertEqual(self.result(x)['state'],'VERIFIED_CLEAR_FOR_COMPARABILITY')
    def test_applicable_candidate_needs_bound_event(self):x=fixture();x[5]['candidate_reviews'][0]['status']='APPLIES_TO_SECURITY';self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_q1_q2_class_transformation_not_boolean_override(self):x=fixture();x[0]['class_q2']='CL B';self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_wrong_official_quarter(self):x=fixture();x[0]['q2_official_binding']['quarter']='2026Q1';self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_wrong_cik_hash(self):x=fixture();x[1]['proofs'][0]['source_hash']='b'*64;self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_unbound_source(self):x=fixture();x[6].clear();self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_prefix_not_clear(self):x=fixture();x[5]['source_refs']=[{**REF,'hash_domain':'EXACT_RETAINED_RESPONSE_PREFIX; NOT_FULL_DOCUMENT'}];self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_link_not_closed(self):x=fixture();x[5]['no_unresolved_relevant_link']=False;self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_fpi_uses_fpi_forms(self):x=fixture();x[1]['regime']='FOREIGN_PRIVATE_ISSUER';x[2]['forms_expected']=sorted(FOREIGN);self.assertEqual(self.result(refresh(x))['state'],'VERIFIED_CLEAR_FOR_COMPARABILITY')
    def test_fpi_domestic_forms_fail(self):x=fixture();x[1]['regime']='FOREIGN_PRIVATE_ISSUER';self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_unsupported_regime_not_clear(self):x=fixture();x[1]['regime']='UNSUPPORTED_OR_INDETERMINATE';self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_fund_not_operating_company(self):x=fixture();x[1]['regime']='REGISTERED_FUND_OR_TRUST';self.assertEqual(self.result(refresh(x))['state'],'UNKNOWN')
    def test_verified_event_block(self):x=fixture();x[5].update(state='VERIFIED_BLOCK',block_reason='UNSUPPORTED_VERIFIED_CORPORATE_EVENT',primary_block_proof='Primary June 1 spin-off terms.',blocking_event=event('SPINOFF'));self.assertEqual(self.result(x)['state'],'VERIFIED_BLOCK')
    def test_pending_review_not_a_block(self):x=fixture();x[5].update(state='VERIFIED_BLOCK',block_reason='REVIEW_PENDING',primary_block_proof='Not read.');self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_supported_regime_not_unsupported_block(self):x=fixture();x[5].update(state='VERIFIED_BLOCK',block_reason='UNSUPPORTED_ISSUER_FILING_REGIME',primary_block_proof='Has 6-K.');self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_wrong_class_event_block_fails(self):x=fixture();e=event('SPINOFF');e['security_before']=['B'];x[5].update(state='VERIFIED_BLOCK',block_reason='UNSUPPORTED_VERIFIED_CORPORATE_EVENT',primary_block_proof='Terms.',blocking_event=e);self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_post_q2_event_cannot_block(self):x=fixture();e=event('SPINOFF');e['effective_date']='2026-07-01';x[5].update(state='VERIFIED_BLOCK',block_reason='UNSUPPORTED_VERIFIED_CORPORATE_EVENT',primary_block_proof='Terms.',blocking_event=e);self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_event_hash_required_for_block(self):x=fixture();e=event('SPINOFF');e['source_refs']=[{'source_url':U,'sha256':'b'*64}];x[5].update(state='VERIFIED_BLOCK',block_reason='UNSUPPORTED_VERIFIED_CORPORATE_EVENT',primary_block_proof='Terms.',blocking_event=e);self.assertEqual(self.result(x)['state'],'UNKNOWN')
    def test_exact_rational_fields(self):x=normalize_quantities(100,200,[event()],1,'A','2026-09-07',{U:H});self.assertEqual((x['normalization_numerator'],x['normalization_denominator'],x['normalized_previous_quantity'],x['reported_status']),(2,1,'200','REPORTED_UNCHANGED'))
    def test_reverse_split_fraction_not_inferred(self):e=event('REVERSE_SPLIT');e['ratio_or_terms'].update(numerator=1,denominator=3);self.assertRaises(ValueError,normalize_quantities,10,3,[e],1,'A','2026-09-07',{U:H})
    def test_float_not_ratio_authority(self):e=event();e['ratio_or_terms']['numerator']=2.0;self.assertRaises(ValueError,normalize_quantities,100,200,[e],1,'A','2026-09-07',{U:H})
    def test_old_event_not_applied(self):e=event();e['effective_date']='2024-06-01';self.assertRaises(ValueError,normalize_quantities,100,200,[e],1,'A','2026-09-07',{U:H})
    def test_class_b_factor_not_applied_to_a(self):e=event();e['security_before']=['B'];self.assertRaises(ValueError,normalize_quantities,100,200,[e],1,'A','2026-09-07',{U:H})
    def test_gate_block_is_valid_but_unknown_is_not(self):self.assertEqual(pilot_gate([{'security_id':'A','state':'VERIFIED_BLOCK'}],['A'])['state'],'PASS');self.assertEqual(pilot_gate([{'security_id':'A','state':'UNKNOWN'}],['A'])['state'],'FAIL')
    def test_gate_scope_cannot_shrink(self):self.assertRaises(ValueError,pilot_gate,[{'security_id':'A','state':'VERIFIED_BLOCK'}],['A','B'])
    def test_manual_error_fails_gate(self):self.assertEqual(pilot_gate([{'security_id':'A','state':'VERIFIED_BLOCK'}],['A'],1)['state'],'FAIL')
    def test_no_global_expansion_even_after_pass(self):self.assertRaises(ValueError,expand);self.assertFalse(pilot_gate([{'security_id':'A','state':'VERIFIED_BLOCK'}],['A'])['global_expansion_authorized'])

def conversion_block_fixture():
    x=list(fixture());u2=U.replace('/p.htm','/q2.htm');ref2={'source_url':u2,'sha256':'b'*64};x[6][u2]='b'*64
    ds=[];obs=[]
    for ref,end,n in [(REF,'2026-03-31',9851),(ref2,'2026-06-30',14223)]:
        excerpt='Conversions of Class A to Class B common stock ( '+format(n,',')+' )'
        d={'issuer_cik':1,'document_url':ref['source_url'],'document_hash':ref['sha256'],'source_ref':ref,'primary_text':excerpt};ds.append(d)
        obs.append({**d,'primary_excerpt':excerpt,'excerpt_sha256':sha(excerpt),'converted_before_units':n,'cumulative_period':['2026-01-01',end]})
    proof={'issuer_cik':1,'security_before':'A','security_after':'B','allocation':'HOLDER_ELECTION_NOT_UNIFORM','event_family':'CONVERSION','effective_interval':['2026-04-01','2026-06-30'],'observations':obs,'affected_before_units_in_window':4372,'terms':{**obs[1],'holder_election_explicit':True,'uniform_factor_for_existing_holders':False}}
    x[4]=ds;x[5].update(state='VERIFIED_BLOCK',block_reason='UNRESOLVED_CLASS_TRANSFORMATION',primary_block_proof='Two primary cumulative observations establish elected conversions.',class_transformation_evidence=proof)
    return refresh(x)

class PositiveBlockTests(unittest.TestCase):
    def test_forged_excerpt_with_recomputed_hash_is_rejected(self):
        x=conversion_block_fixture();p=x[5]['class_transformation_evidence']['observations'][1];p['primary_excerpt']+=' invented evidence';p['excerpt_sha256']=sha(p['primary_excerpt']);self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_two_primary_observations_can_block_without_inventing_exact_day(self):self.assertEqual(certificate(*conversion_block_fixture())['state'],'VERIFIED_BLOCK')
    def test_pending_review_not_disguised_as_class_block(self):x=fixture();x[5].update(state='VERIFIED_BLOCK',block_reason='UNRESOLVED_CLASS_TRANSFORMATION',primary_block_proof='Still reviewing the merger.');self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_wrong_existing_class(self):x=conversion_block_fixture();x[5]['class_transformation_evidence']['security_before']='B';self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_no_actual_conversions(self):x=conversion_block_fixture();x[5]['class_transformation_evidence']['observations'][1]['converted_before_units']=9851;self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_wrong_period(self):x=conversion_block_fixture();x[5]['class_transformation_evidence']['observations'][1]['cumulative_period'][1]='2026-09-30';self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_false_count_not_primary_table(self):x=conversion_block_fixture();p=x[5]['class_transformation_evidence'];p['observations'][1]['converted_before_units']=15000;p['affected_before_units_in_window']=5149;self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_wrong_source_hash(self):x=conversion_block_fixture();x[5]['class_transformation_evidence']['observations'][1]['document_hash']='c'*64;self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_prose_conflict_does_not_verify_block(self):x=fixture();x[5].update(state='VERIFIED_BLOCK',block_reason='CONFLICTING_EVENT_TERMS',primary_block_proof='May conflict.');self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_unknown_not_cleared_by_old_boolean_flags(self):x=fixture();x[5]['state']='UNKNOWN';self.assertEqual(certificate(*x)['state'],'UNKNOWN')
    def test_image_or_pdf_without_narrative_review_not_negative_authority(self):x=fixture();x[4][0].update(mode='IMAGE',text='');x[5]['narrative_coverage_beyond_keywords_reviewed']=False;self.assertEqual(certificate(*refresh(x))['state'],'UNKNOWN')

if __name__=='__main__':unittest.main()

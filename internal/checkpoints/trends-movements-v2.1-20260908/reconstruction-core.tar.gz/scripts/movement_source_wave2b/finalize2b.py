"""Audit immutable inputs and emit the Wave 2B feasibility decision and cost report."""
import subprocess,datetime,hashlib
from context2b import *

def audit():
    frozen();pre=read('preflight.json');bad=[]
    for domain in ['tracked_files','preserved_files']:
        for entry in pre[domain]:
            p=ROOT/entry['path'];actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
            if actual!=entry['sha256']:bad.append({'domain':domain,'path':entry['path'],'expected':entry['sha256'],'actual':actual})
    assert not bad, 'STOP_IMMUTABLE_INPUT_DRIFT'
    result={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tracked_files_checked':len(pre['tracked_files']),
        'inherited_files_checked':len(pre['preserved_files']),'differences':bad,'tracked_diff':subprocess.check_output(['git','diff','--stat'],cwd=ROOT,text=True),
        'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'prior_wave_outputs_changed':False,
        'corpus_changed':False,'target_changed':False,'movement_statuses_changed':False,'public_data_changed':False,'public_snapshot_changed':False,
        'holdings_refreshed':False,'commit_created':False,'push_performed':False,'deploy_performed':False}
    assert result['head']==pre['base_commit'] and result['tracked_diff']==''
    write('final-isolation-audit.json',result)
    return result

def main():
    isolation=audit();pre=read('preflight.json');net=Net();sample=read('sample-100.json');finra=read('finra-historical-query-results.json')
    bodybytes=sum(r['bytes'] for r in net.log);retained=sum((OUT/p).stat().st_size for p in {r['path'] for r in net.log})
    source_seconds=sum(r['elapsed_seconds'] for r in net.log);assert bodybytes<=Net.LIMIT
    cost={'SOURCE_REQUESTS':len(net.log),'HTTP_RESPONSES_RECEIVED':sum(r['status'] is not None for r in net.log),
        'FAILED_DNS_ATTEMPTS':sum(r['status'] is None for r in net.log),'SOURCE_BYTES_DOWNLOADED':bodybytes,'SOURCE_BYTES_RETAINED':retained,
        'BYTE_SCOPE':'Exact metered HTTP response bodies only, including HTTP errors. Gzip-deduplicated bodies retained; PDFs retained natively.',
        'UNMETERED_COMPONENT':'Managed web-search/browser transport does not expose request counts or body bytes. No exact total across those surfaces is claimed.',
        'BODY_CAP_BYTES':500000000,'METERED_CAP_STATUS':'WITHIN_LIMIT','FULL_TRANSPORT_CAP_AUDIT':'NOT_MEASURABLE_FOR_MANAGED_WEB_BROWSER',
        'SOURCE_ELAPSED_SECONDS':source_seconds,'SECONDS_PER_SECURITY':source_seconds/166,
        'SECONDS_PER_SECURITY_SCOPE':'Shared public source-probe wait time amortized across 66+100 securities. Not latency of 166 successful CUSIP queries; operational per-security latency NOT_MEASURABLE.',
        'LOCAL_REPLAY':read('offline-benchmark-timing.json'),'MANUAL_REVIEW_ITEMS_CREATED':len(read('manual-source-prerequisites.json')),
        'MANUAL_REVIEW_SCOPE':'Source-level access/identity/lifecycle prerequisites only; zero new issuer-review queue items.',
        'PREVIOUS_WAVE_SOURCE_BYTES':5089019968,'BYTE_RATIO_TO_PREVIOUS_WAVE':bodybytes/5089019968,
        'EXPECTED_COST_PER_1000_PACKETS':{'model':'Public feasibility-probe amortization only; observed shared cost * 1000/166.',
            'source_request_attempts':len(net.log)*1000/166,'downloaded_body_bytes':round(bodybytes*1000/166),
            'retained_body_bytes':round(retained*1000/166),'source_wait_seconds':source_seconds*1000/166,
            'same_window_shared_setup_bytes':bodybytes,'additional_local_classifications_require_new_downloads':False,
            'commercial_dataset_price':'UNKNOWN_NO_QUOTE_REQUESTED','operational_feed_query_cost':'NOT_MEASURABLE_WITHOUT_ACCESS',
            'manual_review_minutes':'NOT_ESTIMATED','resolution_rate_extrapolated':False,
            'limitations':'Excludes managed-web transport and analyst time; shared setup is reusable, so linear scaling is a comparison proxy, not a forecast of production throughput.'}}
    write('cost-benchmark.json',cost)
    validation={k:read('validation-'+k+'.json') for k in ['source-tests','app-tests','typecheck','lint','build','git-diff-check']}
    assert all(v['exit_code']==0 for v in validation.values())
    result={
        'STATE':'WAVE_2B_FEASIBILITY_COMPLETE_ACCESS_LIMITED','BASE_COMMIT':pre['base_commit'],'REMOTE_HEAD':pre['remote_head'],
        'REMOTE_HEAD_SCOPE':'origin/vercel-deployment observed at preflight','OLD_MANAGER_AUDIT_REQUIREMENT':20,'NEW_MANAGER_AUDIT_REQUIREMENT':'19_OF_19',
        'CHANGE_REASON':'IMPOSSIBLE_REQUIREMENT_RELATIVE_TO_FROZEN_POPULATION','MANAGER_AUDIT_TARGET':'19/19','MANAGER_POPULATION_GATE':'PASS',
        'OTHER_DIVERSITY_AND_EVIDENCE_GATES':'PRESERVED; NO_NEW_GLOBAL_QUALIFICATION',
        'MOVEMENT_CORPUS_COUNT':8137,'MOVEMENT_CORPUS_SHA256':'d270f69dc303daa6d694fbafa6d4c91166cdcfb60c4e1fb5bc90b105b5143ac3','MOVEMENT_CORPUS_CHANGED':'NO',
        'BOTH_PRESENT_TARGET_COUNT':4162,'BOTH_PRESENT_TARGET_SHA256':'307cfb419c1134e020b7b0e57f8f7fab024a81ec2c8790af168f33c6de6559e6','BOTH_PRESENT_TARGET_CHANGED':'NO',
        'DTCC_ACCESS_STATE':'AUTHENTICATION_REQUIRED','DTCC_ACCESS_DETAIL':'CA Web/processing: authentication required; CA 20022: commercial access required; Important Notices: partial public access.',
        'DTCC_EVENT_DISCOVERY_CAPABLE':'YES_PUBLIC_NOTICES_ONLY; OPERATIONAL_FEED_NOT_ACCESSIBLE',
        'DTCC_NEGATIVE_COVERAGE_CERTIFICATE_CAPABLE':'NO','DTCC_HISTORICAL_Q2_ACCESS':'NOT_DEMONSTRATED_FOR_SECURITY_LEVEL_EVENT_QUERIES',
        'FINRA_OTC_ACCESS_STATE':'PARTIAL_PUBLIC_ACCESS_AVAILABLE','FINRA_HISTORICAL_Q2_DATE_TYPE_ACCESS':'YES','FINRA_CUSIP_ACCESS':'PUBLIC_FIELD_UNAVAILABLE; ORF_AUTHENTICATION_AND_CUSIP_LICENSE_REQUIRED',
        'PILOT_SECURITIES':66,'PILOT_SOURCE_COVERAGE_COUNT':0,'PILOT_KNOWN_EVENTS_RECALLED':0,
        'PILOT_KNOWN_EVENTS_RECALL_DETAIL':'0/2 retrieved; dataset recall NOT_MEASURABLE because no scoreable source records available.',
        'PILOT_KNOWN_CLEAR_CONTRADICTIONS':0,'PILOT_FALSE_EVENT_SIGNALS':0,'PILOT_ERROR_METRICS_DETAIL':'0 observed, 0 scoreable records; not a zero-error or clear-consistency claim.',
        'PILOT_DTC_ELIGIBLE':{'YES':0,'NO':0,'UNKNOWN':66},'PILOT_STATUSES_PRESERVED':{'CLEAR':64,'VERIFIED_BLOCK':2},
        'SAMPLE_PACKETS':100,'SAMPLE_SHA256':sample['selection_sha256'],'SAMPLE_COMPLETE_NEGATIVE_COVERAGE':0,
        'SAMPLE_PARTIAL_COVERAGE':sample['PARTIAL_COVERAGE'],'SAMPLE_NO_COVERAGE':sample['NO_COVERAGE'],
        'SAMPLE_PARTIAL_SCOPE':sample['partial_definition'],'SAMPLE_NEW_SECURITY_LEVEL_SOURCE_COVERAGE':0,
        'OTC_SECURITIES_IN_TARGET':'UNKNOWN','OTC_TARGET_CONFIRMED_LOWER_BOUND':0,'FINRA_COVERED_SECURITIES':0,'FINRA_EVENT_MATCHES':0,
        'FINRA_ZERO_COUNTS_SCOPE':'No authoritative target identity matches; not evidence of no OTC securities or events.',
        **{k:cost[k] for k in ['SOURCE_REQUESTS','SOURCE_BYTES_DOWNLOADED','SOURCE_BYTES_RETAINED','SECONDS_PER_SECURITY','MANUAL_REVIEW_ITEMS_CREATED','EXPECTED_COST_PER_1000_PACKETS']},
        'SOURCE_COST_SCOPE':cost['BYTE_SCOPE'],'UNMETERED_SOURCE_COMPONENT':cost['UNMETERED_COMPONENT'],
        'ARCHITECTURE_DECISION':'SECURITY_LEVEL_SOURCE_NOT_ACCESSIBLE','ARCHITECTURE_DECISION_CODE':'C',
        'MOVEMENT_PUBLICATION':'REVIEW_PENDING','MOVEMENT_UI_PRESENT':'NO','MOVEMENT_FIELDS_PUBLIC':'NONE',
        'BOTH_PRESENT_RESOLVED':517,'BOTH_PRESENT_BLOCKED':14,'BOTH_PRESENT_UNKNOWN':3631,'GLOBAL_TOTAL_RESOLVED':526,'GLOBAL_STILL_INDETERMINATE':7611,
        'NEW_MOVEMENTS_RESOLVED':0,'PUBLIC_DATA_CHANGED':'NO','PUBLIC_SNAPSHOT_CHANGED':'NO','SEC_HOLDINGS_REFRESH':'NO',
        'TESTS':'PASS: 33 source feasibility tests + 343 existing application tests passed; 1 existing test skipped','TYPECHECK':'PASS','LINT':'PASS_WITH_17_EXISTING_WARNINGS','BUILD':'PASS','GIT_DIFF_CHECK':'PASS',
        'BUILD_NOTE':'Initial sandbox compile stalled and was terminated after 216 seconds; same build command passed outside sandbox. Attempt log retained.',
        'FILES_CHANGED':0,'FILES_CREATED':0,'FILES_MANIFEST':'files-created.json','COMMIT':'NONE','PUSH':'NONE','DEPLOY':'NONE',
        'PRODUCTION_READINESS':'NOT_READY',
        'NEXT_RECOMMENDED_STEP':'Obtain an already authorized historical DTCC sample/export plus completeness and eligibility documentation, or licensed historical FINRA CUSIP-symbol data for a verified OTC subset. Repeat the same 66 controls and frozen 100 sample before proposing certificates; do not resume mass issuer downloads.'}
    # Keep the full manifest separate from the human-readable decision.
    projected={'internal/trends-movements/wave2b/RESULT.json','internal/trends-movements/wave2b/REPORT.md','internal/trends-movements/wave2b/files-created.json'}
    created=sorted(projected | {str(p.relative_to(ROOT)) for folder in [OUT,ROOT/'scripts/movement_source_wave2b'] for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts})
    result['FILES_CREATED']=len(created);write('RESULT.json',result)
    qtable='\n'.join(f"| {field} | {info['returned']:,} | Sí, a Record-Total observado |" for field,info in finra['groups'].items())
    report=f"""La decisión de Wave 2B es **C — SECURITY_LEVEL_SOURCE_NOT_ACCESSIBLE**. Los servicios documentados contienen los campos de eventos e identidad necesarios, pero no hay acceso autorizado al dataset DTCC ni al master histórico FINRA con CUSIP en este proyecto. La viabilidad de sustituir la mayor parte de la reconstrucción por emisor no quedó demostrada. No se crean certificados ni se resuelven movimientos.

Se mantiene **517 BOTH_PRESENT resueltos y 526 globales**, con publicación REVIEW_PENDING. Se corrige exclusivamente el gate imposible de 20 gestores a **19/19**. Los demás requisitos de diversidad y calidad permanecen vigentes; esto no convierte la calificación global anterior en PASS.

| Fuente oficial | Acceso observado | Utilidad disponible | Certificado negativo Q2 |
|---|---|---|---|
| [DTCC CA Web](https://www.dtcc.com/data-services/corporate-actions-and-reference-data/ca-web-service) | AUTHENTICATION_REQUIRED | Documentación de búsquedas por CUSIP, CAID, tipos y fechas | No |
| [DTCC CA 20022](https://www.dtcc.com/data-services/corporate-actions-and-reference-data/dtcc-ca-20022-service) | COMMERCIAL_ACCESS_REQUIRED | Documentación de anuncios ISO 20022 y modalidades de entrega | No |
| [DTC Corporate Actions Processing](https://www.dtcc.com/asset-services/corporate-actions-processing) | AUTHENTICATION_REQUIRED | Descripción de procesamiento para participantes | No |
| [Important Notices](https://www.dtcc.com/legal/important-notices) | PARTIAL_PUBLIC_ACCESS_AVAILABLE | Avisos públicos identificados por fecha y CUSIP; descubrimiento parcial | No |
| [FINRA Daily List público](https://developer.finra.org/docs) | PARTIAL_PUBLIC_ACCESS_AVAILABLE | Consultas históricas OTC ejecutadas, sin campo CUSIP | No |
| [FINRA ORF: master y archivos](https://www.finra.org/sites/default/files/2024-08/Equity_API_File_Downloads_ORF.pdf) | AUTHENTICATION_REQUIRED; CUSIP sujeto a licencia | Esquema incluye CUSIP y DTC_ELGBL_FL; datos operativos no accedidos | No |

La [guía CA Web](https://www.dtcc.com/products/training/helpfiles/asset_services/corp_actions_browser/help/Corporate_Actions_Web.pdf), páginas 11–20, documenta búsquedas sobre bases actuales y archivadas. Permite fechas históricas en tramos de 90 días y distingue fechas críticas de fechas de actualización. Los filtros de estado, actividad o cartera pueden restringir resultados. No se estableció una garantía de retención, elegibilidad histórica ni exhaustividad que habilite certificados negativos. Se revisó visualmente la página 19. El portal devolvió un formulario de acceso; no se inició sesión.

La guía FINRA ORF, páginas PDF 6, 16, 18 y 23, describe autenticación TRAQS, CUSIP condicionado a licencia, elegibilidad DTC y cambios de identificador. Se revisó visualmente la tabla de la página 16. Un master actual tampoco demostraría por sí solo la historia de Q2. No se solicitaron tokens ni cotizaciones ni se aceptaron términos comerciales.

El navegador pudo leer Important Notices, aunque el cliente HTTP recibió 403. Se intentó buscar FDX por CUSIP y seleccionar 2026; la lista siguió mostrando septiembre sin confirmar ejecución del filtro. Las búsquedas públicas complementarias de los cuatro controles no recuperaron un evento Q2 utilizable. **Esto no es una respuesta negativa del dataset DTCC.** La página de elegibilidad pública contiene documentos y formularios, no una tabla histórica de los 66 CUSIP.

Las pruebas FINRA produjeron estas poblaciones históricas. Se consultó Q2 por cada fecha del evento y marzo 1–agosto 14 por fecha de anuncio, sin exigir que todas las condiciones fueran simultáneas:

| Campo consultado | Filas recuperadas | Paginación |
|---|---:|---|
{qtable}

La primera página de anuncios devolvió 3.283 filas aunque se solicitaron 5.000; se continuó desde el offset real hasta 6.328. La unión conserva **6.551 versiones de filas**, incluyendo adiciones, bajas, cambios de símbolo/nombre, dividendos/distribuciones/splits y atributos. El identificador 331496 tiene dos versiones con distinta fecha de calendario y comentario; una consulta puntual confirmó ambas. Se conservan sin sobrescribir. **61 filas con ex-date en Q2 fueron anunciadas fuera de la ventana auxiliar**: una búsqueda solo por anuncio perdería esos casos. Las respuestas se consultaron en septiembre y no constituyen una reconstrucción del conocimiento disponible el 14 de agosto.

Una consulta explícita al campo CUSIP recibió HTTP 400 porque no existe en el Daily List público. El número exacto de títulos OTC de la población sigue **UNKNOWN**: hay cero vínculos OTC históricos confirmados, no una afirmación de que no existan títulos OTC. No se aplicó FINRA como autoridad a valores NYSE/Nasdaq ni se unieron símbolos por semejanza de nombre. Los ejemplos OTC del índice prueban capacidad del endpoint, no cobertura de los CUSIP objetivo.

Se evaluaron los **66 títulos del piloto** frente a las barreras de acceso, elegibilidad e identidad. La barrera compartida impide ejecutar las consultas DTCC por CUSIP; no se contabilizan 66 consultas remotas ficticias. Cada fila incluye CUSIP normalizado, DTC_ELIGIBLE=UNKNOWN y resultados nuevos no observables (`null`, no listas vacías). Las 64 certificaciones CLEAR y los dos BLOCK previos permanecen idénticos.

| Control | Evidencia previa conservada | Resultado con nueva fuente |
|---|---|---|
| FDX | Spin-off efectivo 2026-06-01; registro 2026-05-15 | No recuperado; acceso operativo no disponible |
| BRK.A | 4.372 conversiones a elección del titular durante Q2; sin factor uniforme | No recuperado; cobertura de elecciones individuales no demostrada |
| TSM ADS | Certificación de la clase ADS preservada | Cobertura de eventos ADR nueva no demostrada |
| CVX | Partida contable de stock dividend no equivale a cambio de cantidad | El modelo rechaza esa señal contable; sin registro nuevo para medir discriminación |

PILOT_SOURCE_COVERAGE_COUNT=0 y controles recuperados=0/2. Hay cero contradicciones y falsas señales observadas sobre **cero registros nuevos evaluables**. Recall, sensibilidad y tasa de error del dataset son **no medibles**; no se afirma éxito de los controles ni tasa de error cero. Los eventos anteriores no se vuelven a contar como descubrimientos de Wave 2B.

Después del piloto se fijaron exactamente **100 paquetes UNKNOWN**, sin solapamiento: 30 de leverage 5–9, 35 de 2–4 y 35 de 1; 19 gestores; 26 SIC conocidos; 21 emisores domésticos verificados, 7 extranjeros y 72 sin régimen verificado; 11 ADS/ADR, 71 comunes, 17 fondos/ETF y 1 otro. Las portadas previas permiten observar 21 NYSE y 7 Nasdaq, con 72 indeterminados; son observaciones a la fecha del documento, no prueba de continuidad bursátil histórica. No se inventó un estrato OTC.

El resultado de la muestra es **0 cobertura negativa completa, 28 cobertura parcial y 72 sin cobertura utilizable vinculada al título**. Las 28 parciales corresponden a documentos primarios ya retenidos y vinculados a la clase, disponibles como respaldo por emisor; no representan éxito de DTCC/FINRA ni una revisión nueva de eventos. El acceso nuevo a una fuente de eventos por CUSIP alcanza 0/100. SHA de selección: `{sample['selection_sha256']}`. Es una muestra de diversidad deliberada, no una estimación estadística de cobertura global.

La matriz contiene los 2.135 títulos y las seis familias requeridas. Señala DTCC como fuente preferida condicionada a acceso, respaldo de depositario para ADS y respaldo SEC/emisor cuando esté disponible. Conserva aparte las certificaciones previas con su conjunto de fuentes; no atribuye ese certificado combinado a SEC en solitario. Los booleanos superiores se refieren a la adecuación de **nuevas fuentes por título**; los 1.969 títulos fuera de los dos grupos son inventario de fuentes, no consultas remotas adicionales. No se continuó la cola de revisión de emisores.

Se midieron **{bodybytes:,} bytes descargados ({bodybytes/1e6:.2f} MB), {retained:,} bytes retenidos y {len(net.log)} intentos HTTP**, de los que 10 fallaron por DNS en el sandbox y {cost["HTTP_RESPONSES_RECEIVED"]} recibieron respuesta. El acumulado medido está por debajo de 500.000.000 bytes. Los bytes de transporte del navegador/buscador administrados no están expuestos: el total de todas las superficies no es medible y no se presenta el contador HTTP como ese total. No hubo descarga masiva de emisores.

El tiempo de espera de fuentes medido es {source_seconds:.3f} s: **{source_seconds/166:.6f} s por título amortizados** sobre 166. No es latencia de consultas CUSIP exitosas ni tiempo de revisión humana. Frente a los 5.089.019.968 bytes de Wave 2A, esta fase consume el {bodybytes/5089019968*100:.3f}% en cuerpos HTTP medidos. Se crearon cinco pendientes de arquitectura/acceso y cero nuevas revisiones por emisor.

El proxy de coste por 1.000 paquetes, multiplicando el coste compartido por 1.000/166, es {round(bodybytes*1000/166):,} bytes descargados y {source_seconds*1000/166:.2f} s de espera de fuente. El coste inicial puede reutilizarse sin nuevas descargas para más clasificaciones del mismo intervalo. Precios comerciales, coste operativo de consultas y minutos de revisión son desconocidos. No se extrapolan resoluciones.

La decisión A requiere cobertura completa que no se obtuvo; B requiere un subconjunto objetivo con fuente utilizable que no quedó vinculado; D exigiría recuperar los eventos de los controles pero no demostrar ausencia. Aquí la limitación decisiva es el acceso al dataset y al master necesario: **se selecciona únicamente C**. Incluso con acceso futuro, BRK.A obliga a comprobar elecciones de titulares y no asumir que un feed de anuncios sustituye toda la evidencia del emisor.

Pasaron 33 pruebas nuevas del modelo y del benchmark, además de 343 pruebas existentes de la aplicación (1 prueba adicional omitida), typecheck, lint (17 avisos previos), build y git diff --check. El primer build quedó detenido en compilación dentro del sandbox; se guardó ese intento y el mismo comando pasó fuera del sandbox. No hubo cambios de aplicación para resolverlo. La auditoría comparó 613 archivos versionados y 5.509 archivos heredados: **cero diferencias**, incluidos corpus, target, resultados de Wave 2A y datos públicos.

Los entregables principales son [RESULT.json](RESULT.json), [matriz completa](CORPORATE_ACTION_SOURCE_MATRIX.json), [piloto](pilot-source-benchmark.json), [muestra de 100](sample-100.json), [consultas y barreras por título](cohort-query-coverage.json), [resultados históricos FINRA](finra-historical-query-results.json), [fuentes y acceso](source-access-assessment.json), [coste](cost-benchmark.json), [auditoría de aislamiento](final-isolation-audit.json) y [manifest de archivos](files-created.json). No hubo commit, push, deploy ni actualización de holdings. PRODUCTION_READINESS=NOT_READY.

El siguiente paso recomendado es conseguir un extracto histórico DTCC ya autorizado con garantías de cobertura y elegibilidad, o un master FINRA histórico con licencia para un subconjunto OTC demostrado. Repetir después los mismos 66 controles y la misma muestra de 100 antes de proponer certificados. No reanudar descargas masivas de emisores.

Valores de salida solicitados:

```text
"""
    requested=(OUT/'user-request.txt').read_text().split('\nOUTPUT\n',1)[1]
    keys=[line.split('=')[0] for line in requested.splitlines() if '=' in line and not line.startswith('=')]
    assert all(k in result for k in keys),[k for k in keys if k not in result]
    report+='\n'.join(k+'='+ (canonical(result[k]) if isinstance(result[k],(list,dict)) else str(result[k])) for k in keys)+'\n```\n'
    report=re.sub(r'\]\(([^:)]+\.(?:json|md))\)',lambda m:']('+str(OUT/m.group(1))+')',report)
    (OUT/'REPORT.md').write_text(report)
    write('files-created.json',{'files_changed':[],'files_created_count':len(created),'scope':'New Wave 2B deliverables only; inherited Wave 1/2A files and node_modules are excluded.',
        'files':[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest() if p!='internal/trends-movements/wave2b/files-created.json' else None} for p in created]})
    print(canonical({k:result[k] for k in ['STATE','ARCHITECTURE_DECISION','SOURCE_BYTES_DOWNLOADED','SOURCE_BYTES_RETAINED','FILES_CREATED','TESTS','BUILD']}))

if __name__=='__main__':main()

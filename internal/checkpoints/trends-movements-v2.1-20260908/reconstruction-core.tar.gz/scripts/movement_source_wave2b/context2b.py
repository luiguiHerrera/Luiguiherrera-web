"""Feasibility-only context: immutable movement evidence, metered public reads."""
from pathlib import Path
import sys,json,gzip,hashlib,re,time,datetime,urllib.request,urllib.error,urllib.parse
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'internal/trends-movements/wave2b'
PRIOR=ROOT/'internal/trends-movements/wave2a'
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(x):return hashlib.sha256(x if isinstance(x,bytes) else canonical(x).encode()).hexdigest()
def read(name,base=OUT):return json.loads((base/name).read_text())
def write(name,x):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(canonical(x)+'\n')
def gzread(name,base=PRIOR):return json.loads(gzip.decompress((base/name).read_bytes()))
def frozen():
    b=gzip.decompress((ROOT/'internal/trends-movements/v2.1/corpus.jsonl.gz').read_bytes())
    assert sha(b)=='d270f69dc303daa6d694fbafa6d4c91166cdcfb60c4e1fb5bc90b105b5143ac3','STOP_CORPUS_DRIFT'
    rows=[json.loads(x) for x in b.splitlines()];assert len(rows)==8137
    target=read('target.json',PRIOR);assert sha(target)=='307cfb419c1134e020b7b0e57f8f7fab024a81ec2c8790af168f33c6de6559e6','STOP_TARGET_DRIFT'
    assert len(target['comparison_ids'])==4162
    result=read('RESULT.json',PRIOR);assert result['BOTH_PRESENT_RESOLVED']==517 and result['GLOBAL_TOTAL_RESOLVED']==526
    return rows,target

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

class Net:
    LIMIT=500_000_000
    def __init__(self):self.log=read('request-log.json') if (OUT/'request-log.json').exists() else []
    def body(self,r):
        p=OUT/r['path'];raw=p.read_bytes();b=gzip.decompress(raw) if p.suffix=='.gz' else raw;assert sha(b)==r['sha256'];return b
    def fetch(self,url,label,query=None,refresh=False):
        method='POST' if query is not None else 'GET';request_body=canonical(query).encode() if query is not None else None
        key=sha([method,url,query]);old=next((r for r in reversed(self.log) if r['request_key']==key and r['status'] is not None and not r['error']),None)
        if old and old['status'] is not None and not old['error'] and not refresh:return old,self.body(old)
        if not any(urllib.parse.urlparse(url).hostname==h or (urllib.parse.urlparse(url).hostname or '').endswith('.'+h) for h in ['dtcc.com','dtcclearning.com','finra.org','jpmorgan.com','adr.com','citi.com','adrbnymellon.com','sec.gov','bnymellon.com']):raise ValueError('UNAUTHORIZED_SOURCE_HOST')
        total=sum(r['bytes'] for r in self.log);remaining=self.LIMIT-total
        if remaining<=0:raise RuntimeError('STOP_COST_LIMIT')
        start=time.monotonic();headers={'User-Agent':'Mozilla/5.0 (compatible; LHI source feasibility research)','Accept-Encoding':'identity','Accept':'application/json' if 'api.finra.org' in url else 'text/html,application/pdf,*/*'}
        if query is not None:headers['Content-Type']='application/json'
        req=urllib.request.Request(url,data=request_body,method=method,headers=headers);error=None;response=None;b=b'';status=None;rh={}
        try:
            try:response=urllib.request.build_opener(NoRedirect()).open(req,timeout=30)
            except urllib.error.HTTPError as e:response=e
            status=response.code;rh={k.lower():v for k,v in response.headers.items() if k.lower() in ['content-type','content-length','location','total-records','record-total','record-offset','record-limit','link','last-modified']}
            declared=int(rh.get('content-length','0') or '0')
            if declared>min(remaining,40_000_000):error='BODY_NOT_READ_COST_GUARD'
            else:
                chunks=[];count=0
                while True:
                    piece=response.read(min(65536,remaining-count+1))
                    if not piece:break
                    count+=len(piece);chunks.append(piece)
                    if count>remaining:error='STOP_COST_LIMIT';break
                    if count>=40_000_000:error='BODY_TRUNCATED_PER_RESPONSE_GUARD';break
                b=b''.join(chunks)
        except RuntimeError:raise
        except Exception as ex:error=type(ex).__name__+': '+str(ex)
        finally:
            if response:response.close()
        h=sha(b);is_pdf=b.startswith(b'%PDF');p='sources/'+h+('.pdf' if is_pdf else '.body.gz');(OUT/p).write_bytes(b if is_pdf else gzip.compress(b,mtime=0))
        r={'request_key':key,'url':url,'method':method,'query':query,'label':label,'status':status,'headers':rh,'error':error,'bytes':len(b),'path':p,'sha256':h,'elapsed_seconds':time.monotonic()-start,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'credentials_used':False}
        self.log.append(r);write('request-log.json',self.log);print(label,status,len(b),error or '',flush=True)
        if error=='STOP_COST_LIMIT':raise RuntimeError('STOP_COST_LIMIT')
        return r,b

if __name__=='__main__':
    n=Net()
    for item in read(sys.argv[1]):n.fetch(item['url'],item['label'],item.get('query'))

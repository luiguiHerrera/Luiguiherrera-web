"""Checks write only Wave 2B logs. Application commands are inherited read-only checks."""
import subprocess,sys,time,os
from context2b import *

def main():
    env=os.environ.copy();env['NEXT_TELEMETRY_DISABLED']='1'
    tests=[sys.executable,'-m','unittest','discover','-s','scripts/movement_source_wave2b','-p','test_*.py','-v']
    commands=[('source-tests',tests)]
    for name in ['app-tests','typecheck','lint','build']:
        commands.append((name,read('validation-'+name+'.json',PRIOR)['command']))
    commands.append(('git-diff-check',['git','diff','--check']))
    if len(sys.argv)>1:
        commands=[item for item in commands if item[0] in sys.argv[1:]]
    for name,cmd in commands:
        start=time.monotonic()
        p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        extra_checks=0
        if name=='git-diff-check' and p.returncode==0:
            for folder in [OUT,ROOT/'scripts/movement_source_wave2b']:
                for path in sorted(folder.rglob('*')):
                    if path.is_file() and path.suffix in {'.py','.md','.json','.txt'} and '__pycache__' not in path.parts:
                        check=subprocess.run(['git','diff','--no-index','--check','/dev/null',str(path)],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
                        extra_checks+=1
                        # --no-index implies --exit-code: 1 with no diagnostics is the expected new-file diff.
                        if check.returncode not in (0,1) or check.stdout.strip():
                            p=check;break
                if p.returncode:break
        (OUT/('validation-'+name+'.log')).write_text(p.stdout)
        write('validation-'+name+'.json',{'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'log':'validation-'+name+'.log','new_text_files_whitespace_checked':extra_checks})
        print(name,p.returncode,round(time.monotonic()-start,2),flush=True)
        if p.returncode:print(p.stdout[-4000:],flush=True);sys.exit(p.returncode)

if __name__=='__main__':main()

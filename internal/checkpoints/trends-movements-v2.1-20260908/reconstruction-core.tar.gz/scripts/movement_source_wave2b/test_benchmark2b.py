import unittest
from collections import Counter
from context2b import *
from coverage2b import *

class SourceBenchmarkTests(unittest.TestCase):
    def test_fixed_population_and_unchanged_resolutions(self):
        rows,target=frozen();self.assertEqual(len(rows),8137);self.assertEqual(len(target['comparison_ids']),4162)
    def test_pilot_covers_all_fixed_security_classes(self):
        p=read('pilot-source-benchmark.json')['securities']
        baseline=read('corporate-event-coverage.json',ROOT/'internal/trends-movements/wave1d')
        self.assertEqual({x['security_id']:x['baseline_evidence_state'] for x in p},{x['security_id']:x['state'] for x in baseline})
        self.assertTrue(all(x['EVENTS_FOUND'] is None for x in p))
    def test_sample_unknown_and_disjoint_with_manager_diversity(self):
        s=read('sample-100.json');p=read('pilot-source-benchmark.json')
        ids={x['security_id'] for x in s['securities']}
        self.assertEqual(len(ids),100);self.assertFalse(ids & {x['security_id'] for x in p['securities']})
        self.assertEqual(s['manager_count'],19);self.assertTrue(all(x['prior_packet_state']=='UNKNOWN' for x in s['securities']))
        self.assertEqual(s['selection_sha256'],sha([x['security_id'] for x in s['securities']]))
    def test_partial_fallback_does_not_become_security_level_clear(self):
        s=read('sample-100.json');self.assertEqual(s['COMPLETE_NEGATIVE_COVERAGE'],0)
        self.assertEqual(s['PARTIAL_COVERAGE']+s['NO_COVERAGE'],100)
        self.assertTrue(all(not x['negative_certificate_supported'] for x in s['securities']))
    def test_matrix_families_and_no_new_certificates(self):
        m=read('CORPORATE_ACTION_SOURCE_MATRIX.json')['securities'];self.assertEqual(len(m),2135)
        self.assertTrue(all({f['family'] for f in x['source_families']}==set(FAMILIES) for x in m))
        self.assertTrue(all(not x['negative_certificate_supported'] and x['DTC_ELIGIBLE']=='UNKNOWN' for x in m))
    def test_historical_query_field_results_and_pagination(self):
        r=read('finra-historical-query-results.json')
        self.assertEqual(set(r['groups']),{'dailyListDatetime','exDate','recordDate','paymentDate'})
        self.assertTrue(all(x['enumeration_complete_at_observation'] for x in r['groups'].values()))
        self.assertGreater(r['q2_effective_announced_outside_discovery_count'],0)
        self.assertTrue(r['Q2_EFFECTIVE_DATE_AND_EVENT_TYPE_COMBINED_TEST']['all_rows_validated'])
    def test_finra_record_variants_are_preserved(self):
        rows=read('finra-event-index.json')['rows'];variants=[x for x in rows if x['OTCDailyListID']==331496]
        self.assertEqual(len(variants),2);self.assertNotEqual(variants[0]['calendarDay'],variants[1]['calendarDay'])
        self.assertEqual(read('finra-historical-query-results.json')['FINRA_COVERED_SECURITIES'],0)
    def test_access_block_is_not_reported_as_query_success(self):
        q=read('cohort-query-coverage.json');self.assertEqual(len(q),166)
        self.assertTrue(all(x['DTCC_query']=='NOT_EXECUTED_AUTHENTICATION_REQUIRED' and x['negative_result'] is False for x in q))

if __name__=='__main__':unittest.main()

"""Offline, reproducible cohort and source-access benchmark. No movement resolution."""
from collections import Counter
import json,time,re
from context2b import *
from coverage2b import *

def compact_ref(proof):
    return {k:proof[k] for k in ['source_url','source_hash','document_hash','source_accession'] if k in proof}

def load_population():
    frozen()
    packets=read('target-packets.json',PRIOR)
    bindings={b['security_id']:b for b in read('issuer-cik-bindings.json',PRIOR)}
    queue={p['security_id']:p for p in read('remaining-review-queue.json',PRIOR)}
    covered={p['security_id']:p for p in read('corporate-event-coverage.json',PRIOR)}
    rows=[]
    for p in packets:
        sid=p['security_id'];b=bindings[sid];official=p['binding'];cl=official.get('class_q2') or official.get('class_q1') or ''
        issuer=official.get('issuer_name_q2') or official.get('issuer_name_q1') or ''
        verified=b['status']=='CIK_VERIFIED'
        text=' '.join(x.get('class_excerpt','') for x in b.get('proofs',[])) if verified else ''
        exchanges=set()
        if re.search(r'NASDAQ',text,re.I):exchanges.add('NASDAQ')
        if re.search(r'New York Stock Exchange|NYSE',text,re.I):exchanges.add('NYSE')
        exchange=next(iter(exchanges)) if len(exchanges)==1 else 'UNKNOWN'
        # Descriptive sample strata only. No CIK, OTC, or DTC verification by labels.
        kind='ADS_ADR' if re.search(r'\bADS?\b|\bADR\b',cl) else 'ETF_FUND' if re.search(r'ETF|ISHARES|VANGUARD|\bFDS?\b|\bFUND\b|SPDR',cl+' '+issuer) else 'COMMON' if re.search(r'COM|CL |CAP STK|ORD|REGISTRY',cl) else 'OTHER_UNKNOWN'
        try:cusip=normalize_cusip(sid.split('|')[0]);query_valid=True
        except ValueError:cusip=sid.split('|')[0];query_valid=False
        rows.append({'security_id':sid,'cusip':cusip,'cusip_query_valid':query_valid,'issuer':issuer,'class':cl,
                     'tier':p['leverage_tier'],'manager_ids':p['manager_ids'],'comparisons_affected':p['comparisons_affected'],
                     'sic':str(b.get('sic')) if verified and b.get('sic') else 'UNKNOWN','regime':b.get('regime') if verified else 'UNKNOWN',
                     'instrument_stratum':kind,'exchange_observed':exchange,'exchange_scope':'RETAINED_CLASS_BOUND_COVER_AT_REPORT_DATE_ONLY' if exchange!='UNKNOWN' else 'UNDETERMINED',
                     'historical_otc_scope':'UNKNOWN','DTC_ELIGIBLE':'UNKNOWN','dtc_eligibility_period':list(Q2),
                     'identity_verified':verified,'identity_source_refs':[compact_ref(x) for x in b.get('proofs',[])] if verified else [],
                     'prior_packet_state':covered[sid]['state'],'in_unknown_queue':sid in queue})
    return rows,covered

def finra_inventory():
    net=Net();groups={};union={};conflicts=[];by_event_id={}
    for field in ['dailyListDatetime','exDate','recordDate','paymentDate']:
        pages=sorted([r for r in net.log if r['label'].startswith('finra-window-'+field+'-')],key=lambda r:r['query']['offset'])
        allrows=[];offset=0;totals=set();refs=[]
        for r in pages:
            assert r['status']==200 and r['error'] is None
            assert r['query']['offset']==offset
            data=json.loads(net.body(r));offset+=len(data);allrows+=data
            totals.add(int(r['headers']['record-total']));refs.append({'request_key':r['request_key'],'sha256':r['sha256'],'rows':len(data),'offset':r['query']['offset']})
            bounds=(DISCOVERY if field=='dailyListDatetime' else Q2)
            assert all(inside(x[field],bounds) for x in data)
        ids=[x['OTCDailyListID'] for x in allrows]
        enumeration_complete=len(totals)==1 and offset==next(iter(totals)) and len(allrows)==len({sha(x) for x in allrows})
        assert enumeration_complete, 'STOP_FINRA_ENUMERATION_INCOMPLETE'
        groups[field]={'returned':offset,'server_record_totals':sorted(totals),'enumeration_complete_at_observation':True,'event_id_unique':len(ids)==len(set(ids)),'negative_security_coverage':False,'pages':refs}
        for x in allrows:
            key=str(x['OTCDailyListID']);h=sha(x)
            if key in by_event_id and by_event_id[key]!=h:conflicts.append(key)
            by_event_id[key]=h
            union[h]=x  # Preserve conflicting versions; never silently overwrite by event ID.
    data=list(union.values())
    write('finra-event-index.json',{'rows':data,'scope':'PUBLIC_OTC_DAILY_LIST_ONLY; NO_TARGET_CUSIP_BINDINGS','query_groups':groups,'conflicting_record_ids':sorted(set(conflicts))})
    outside=[{'OTCDailyListID':x['OTCDailyListID'],'symbol':x['oldSymbolCode'],'announcement':x['dailyListDatetime'],'effective':x['exDate']} for x in data if inside(x.get('exDate')) and not inside(x.get('dailyListDatetime'),DISCOVERY)]
    families={
        'ADDITIONS':[x for x in data if x.get('securityAddFlag')=='Y'],
        'DELETIONS':[x for x in data if x.get('securityDeleteFlag')=='Y'],
        'SYMBOL_NAME_CHANGES':[x for x in data if x.get('changeSymbolFlag')=='Y' or x.get('changeSecurityDescriptionFlag')=='Y'],
        'DIVIDENDS_DISTRIBUTIONS_SPLITS':[x for x in data if x.get('dailyListEventCode') in {'DA','DC','DD'}],
        'SECURITY_ATTRIBUTE_CHANGES':[x for x in data if x.get('changeSecurityAttributeFlag')=='Y']}
    examples={k:{'records':len(v),'examples':[{a:x.get(a) for a in ['OTCDailyListID','oldSymbolCode','newSymbolCode','oldMarketCategoryCode','newMarketCategoryCode','dailyListReasonDescription','exDate','dailyListDatetime']} for x in v[:3]]} for k,v in families.items()}
    type_request=next(r for r in net.log if r['label']=='finra-q2-effective-forward-split')
    type_rows=json.loads(net.body(type_request))
    assert type_request['status']==200 and all(x['dividendTypeCode']=='FS' and inside(x['exDate']) for x in type_rows)
    write('finra-historical-query-results.json',{'groups':groups,'unique_records':len(data),'event_family_counts':dict(Counter(x.get('dailyListEventCode') for x in data)),
        'required_family_tests':examples,'q2_effective_announced_outside_discovery_count':len(outside),'outside_discovery_examples':outside[:8],
        'CUSIP_QUERY':'HTTP_400_FIELD_NOT_AVAILABLE','CUSIP_JOIN':'UNAVAILABLE_WITHOUT_HISTORICAL_AUTHORIZED_SECURITY_MASTER',
        'OTC_SECURITIES_IN_TARGET':'UNKNOWN','TARGET_VERIFIED_OTC_LOWER_BOUND':0,'FINRA_COVERED_SECURITIES':0,'FINRA_EVENT_MATCHES':0,
        'target_zero_counts_mean':'No authoritative target CUSIP matches established; not zero OTC securities or zero target events.',
        'NEGATIVE_COVERAGE_CERTIFICATE_CAPABLE':False,'conflicting_record_ids':sorted(set(conflicts)),
        'Q2_EFFECTIVE_DATE_AND_EVENT_TYPE_COMBINED_TEST':{'status':200,'request_key':type_request['request_key'],'rows':len(type_rows),'total_matching':int(type_request['headers']['record-total']),'all_rows_validated':True}})
    return groups

def source_row(p,cohort):
    adr=p['instrument_stratum']=='ADS_ADR'
    # Reused issuer cover proves primary-source accessibility only, never negative event coverage.
    available=p['identity_verified'] and bool(p['identity_source_refs'])
    existing_clear=p['prior_packet_state']=='VERIFIED_CLEAR_FOR_COMPARABILITY'
    families=[]
    for fam in FAMILIES:
        observed=available and fam=='SEC_ISSUER_FILINGS'
        families.append({'family':fam,'coverage_complete':False,
            'event_detection_supported':'PRIMARY_DOCUMENT_RECONSTRUCTION_REQUIRED' if observed else 'NOT_DEMONSTRATED_FOR_SECURITY',
            'negative_certificate_supported':False,
            'evidence_scope':'REUSED_CLASS_BOUND_PRIMARY_BODIES_ONLY' if observed else 'UNVERIFIED_ACCESS_OR_SCOPE',
            'access_state':'AUTHENTICATION_REQUIRED' if fam=='DTCC_CA' else 'PARTIAL_PUBLIC_ACCESS_AVAILABLE' if fam=='FINRA_OTC' or observed else 'UNAVAILABLE',
            'access_interpretation':'No usable security-specific evidence established; not a claim that this source does not exist.'})
    return {**p,'cohort':cohort,'preferred_source':'DTCC_CA','preferred_source_status':'REQUIRES_AUTHORIZED_HISTORICAL_ACCESS',
        'inherited_certificate':{'state':p['prior_packet_state'],'source_artifact':'internal/trends-movements/wave2a/corporate-event-coverage.json',
            'lookup_security_id':p['security_id'],'preserved_without_reevaluation':True,
            'scope':'Original combined source bundle; not attributed to a single new source family.'},
        'fallback_source':fallback_order(adr=adr)[1:],'currently_usable_fallback':'SEC_ISSUER_FILINGS' if available else None,
        'coverage_complete':False,'event_detection_supported':False,'negative_certificate_supported':False,
        'source_level_coverage':'PARTIAL' if available else 'NONE','coverage_basis':'ACCESSIBLE_REUSED_ISSUER_PRIMARY_FALLBACK' if available else 'NO_SECURITY_BOUND_USABLE_EVENT_SOURCE',
        'source_families':families,'new_source_events':None,'new_source_event_observability':'NOT_OBSERVABLE_WITH_AUTHORIZED_SECURITY_BINDING',
        'movement_status_mutation':False}

def pilot(population,covered):
    prior=read('corporate-event-coverage.json',ROOT/'internal/trends-movements/wave1d')
    ids={x['security_id'] for x in prior};byid={p['security_id']:p for p in population}
    assert len(ids)==66
    rows=[]
    for sid in sorted(ids):
        p=byid[sid];c=covered[sid]
        r=source_row(p,'FIXED_PILOT');r.update({'SOURCE_COVERAGE':'UNAVAILABLE_SECURITY_LEVEL_HISTORICAL_ACCESS',
            'EVENTS_FOUND':None,'EVENT_IDS':None,'EVENT_TYPES':None,'EVENT_EFFECTIVE_DATES':None,
            'source_test_status':'SHARED_ACCESS_BARRIER_AND_PER_SECURITY_SCOPE_CHECK_COMPLETED',
            'remote_cusip_query_executed':False,'baseline_evidence_state':c['state']})
        if sid.startswith('31428X106'):
            r['positive_control']={'name':'FDX','expected':'SPINOFF_BLOCK','baseline_event_id':c['blocking_event']['event_id'],'effective_date':'2026-06-01','record_date':'2026-05-15','new_source_recalled':False,'recall_reason':'NO_ACCESSIBLE_DTCC_EVENT_RECORD'}
        elif sid.startswith('084670108'):
            r['positive_control']={'name':'BRK.A','expected':'HOLDER_ELECTED_CLASS_CONVERSION_BLOCK','baseline_event_id':None,'effective_interval':list(Q2),'converted_class_a_units':4372,'uniform_factor_allowed':False,'new_source_recalled':False,'recall_reason':'NO_ACCESSIBLE_DTCC_EVENT_RECORD; PRIVATE_HOLDER_ELECTION_COVERAGE_UNPROVEN'}
        elif sid.startswith('874039100'):
            r['discrimination_control']={'name':'TSM_ADS','expected':'EXACT_ADS_CLASS_AND_RATIO_REQUIRED','outcome':'ADR_FEED_COVERAGE_NOT_DEMONSTRATED','baseline_preserved':True}
        elif sid.startswith('166764100'):
            r['discrimination_control']={'name':'CVX','expected':'ACCOUNTING_STOCK_DIVIDEND_ITEM_IS_NOT_QUANTITY_EVENT','outcome':'MODEL_REJECTS_ACCOUNTING_ONLY_SIGNAL; NO_NEW_SOURCE_RECORD_TO_SCORE','baseline_preserved':True}
        rows.append(r)
    assert Counter(x['baseline_evidence_state'] for x in rows)=={'VERIFIED_CLEAR_FOR_COMPARABILITY':64,'VERIFIED_BLOCK':2}
    write('pilot-source-benchmark.json',{'securities':rows,'PILOT_SECURITIES':66,'PILOT_SOURCE_COVERAGE_COUNT':0,
        'PILOT_COMPLETE_NEGATIVE_COVERAGE':0,'PILOT_KNOWN_EVENTS_RECALLED':0,'known_positive_control_denominator':2,
        'PILOT_KNOWN_CLEAR_CONTRADICTIONS':0,'PILOT_FALSE_EVENT_SIGNALS':0,'scored_new_source_records':0,
        'recall_interpretation':'0/2 retrieved; source access failure, not estimated dataset sensitivity.',
        'error_interpretation':'0 observed with no scoreable source records; error rate and clear consistency NOT_MEASURABLE.',
        'DTC_ELIGIBILITY_COUNTS':{'YES':0,'NO':0,'UNKNOWN':66},'selection_complete_before_sample':True})
    return ids

def select_sample(population):
    candidates=[p for p in population if p['in_unknown_queue']]
    quotas={'5_9':30,'2_4':35,'1':35};chosen=[];seen=set();counts=Counter()
    def features(p):
        return {'manager:'+x for x in p['manager_ids']} | {'sic:'+p['sic'],'regime:'+str(p['regime']),'class:'+p['instrument_stratum'],'exchange:'+p['exchange_observed']}
    # Preserve all determinable foreign regimes, both retained but unfinished event corpora,
    # ETF/fund strata, and manager/SIC diversity without changing the 19-manager population.
    force=[p for p in candidates if p['identity_verified'] and p['regime']=='FOREIGN_PRIVATE_ISSUER']
    for p in sorted(force,key=lambda p:p['security_id']):
        chosen.append(p);counts[p['tier']]+=1;seen |= features(p)
    while len(chosen)<100:
        chosenids={p['security_id'] for p in chosen}
        eligible_rows=[p for p in candidates if p['security_id'] not in chosenids and counts[p['tier']]<quotas[p['tier']]]
        def score(p):
            fresh=features(p)-seen
            weighted=sum(8 if f.startswith('manager:') else 3 if f.startswith('sic:') and f!='sic:UNKNOWN' else 2 for f in fresh)
            fundbonus=4 if p['instrument_stratum']=='ETF_FUND' and sum(x['instrument_stratum']=='ETF_FUND' for x in chosen)<10 else 0
            adrbonus=4 if p['instrument_stratum']=='ADS_ADR' and sum(x['instrument_stratum']=='ADS_ADR' for x in chosen)<10 else 0
            return (weighted+fundbonus+adrbonus, int(p['identity_verified']),p['comparisons_affected'])
        p=sorted(eligible_rows,key=lambda p:tuple(-v for v in score(p))+(p['security_id'],))[0]
        chosen.append(p);counts[p['tier']]+=1;seen |= features(p)
    assert counts==quotas
    assert all(p['prior_packet_state']=='UNKNOWN' for p in chosen)
    managers=sorted({m for p in chosen for m in p['manager_ids']});assert len(managers)==19
    rows=[source_row(p,'UNKNOWN_SAMPLE') for p in chosen]
    summary={'sample_packets':100,'selection_sha256':sha([x['security_id'] for x in rows]),'selection_policy':'DETERMINISTIC_DIVERSITY_GREEDY_WITH_FIXED_LEVERAGE_QUOTAS',
        'quotas':quotas,'manager_ids':managers,'manager_count':len(managers),'sic':dict(Counter(x['sic'] for x in rows)),
        'regime':dict(Counter(str(x['regime']) for x in rows)),'instrument_stratum':dict(Counter(x['instrument_stratum'] for x in rows)),
        'exchange_observed':dict(Counter(x['exchange_observed'] for x in rows)),
        'exchange_limit':'Only a retained class-bound report cover observation. Historical OTC classification remains UNKNOWN without security master.',
        'SOURCE_LEVEL_COVERAGE':dict(Counter(x['source_level_coverage'] for x in rows)),
        'COMPLETE_NEGATIVE_COVERAGE':0,'PARTIAL_COVERAGE':sum(x['source_level_coverage']=='PARTIAL' for x in rows),
        'NO_COVERAGE':sum(x['source_level_coverage']=='NONE' for x in rows),'NEW_SECURITY_LEVEL_SOURCE_COVERAGE':0,
        'partial_definition':'An already retained, class-bound issuer primary document is accessible as fallback; its event coverage has not been completed. No new issuer reviews or downloads.',
        'resolved_in_wave2b':0,'securities':rows}
    write('sample-100.json',summary)
    return rows

def main():
    start=time.monotonic();population,covered=load_population();finra_inventory()
    pilot_ids=pilot(population,covered)
    sample=select_sample(population);sample_ids={x['security_id'] for x in sample};assert not pilot_ids & sample_ids
    matrix=[source_row(p,'FIXED_PILOT' if p['security_id'] in pilot_ids else 'UNKNOWN_SAMPLE' if p['security_id'] in sample_ids else 'UNTESTED_POPULATION_INVENTORY') for p in population]
    write('CORPORATE_ACTION_SOURCE_MATRIX.json',{'securities':matrix,'families':list(FAMILIES),'matrix_rows':2135,
        'feasibility_cohort_rows':166,'other_rows':'Population source inventory only; no per-security remote-query claim.',
        'boolean_scope':'Booleans describe adequacy proved in Wave 2B. The inherited combined-source certificate is preserved separately and not attributed to a single family.'})
    queries=[]
    for p in matrix:
        if p['cohort']=='UNTESTED_POPULATION_INVENTORY':continue
        queries.append({'security_id':p['security_id'],'normalized_cusip':p['cusip'],'valid_cusip':p['cusip_query_valid'],'effective_window':list(Q2),
            'record_window':list(Q2),'payment_window':list(Q2),'announcement_window':list(DISCOVERY),'event_types':'ALL; INCLUDING_CANCELLATIONS_AMENDMENTS_HOLDER_ELECTIONS',
            'DTCC_query':'NOT_EXECUTED_AUTHENTICATION_REQUIRED','DTCC_public_notice_search':'NONEXHAUSTIVE_SHARED_UI_TEST; NO_PER_SECURITY_SEARCH_CLAIM',
            'FINRA_query':'HISTORICAL_BATCH_RETRIEVED; SECURITY_JOIN_BLOCKED_MISSING_CUSIP_SYMBOL_HISTORY',
            'negative_result':False})
    write('cohort-query-coverage.json',queries)
    write('offline-benchmark-timing.json',{'elapsed_seconds':time.monotonic()-start,'securities_in_population_inventory':2135,'securities_in_feasibility_cohorts':166,
        'timing_scope':'LOCAL_ARTIFACT_REPLAY_AND_COVERAGE_CLASSIFICATION; NOT_SOURCE_QUERY_LATENCY'})
    print(json.dumps({k:v for k,v in read('sample-100.json').items() if k!='securities'},indent=2))

if __name__=='__main__':main()

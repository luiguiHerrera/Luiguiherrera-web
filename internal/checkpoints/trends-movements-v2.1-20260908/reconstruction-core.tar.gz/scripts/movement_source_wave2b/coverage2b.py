"""Source feasibility only. Never imports or updates the movement resolver."""
from dataclasses import dataclass, field
from datetime import date
import re

Q2 = ('2026-04-01', '2026-06-30')
DISCOVERY = ('2026-03-01', '2026-08-14')
FAMILIES = ('DTCC_CA', 'FINRA_OTC', 'SEC_ISSUER_FILINGS',
            'DEPOSITARY_ADR_DOCUMENTS', 'OFFICIAL_ISSUER_PRIMARY', 'OTHER_AUTHORIZED_PRIMARY')
REQUIRED = ('authoritative', 'security_class_bound', 'historical_eligibility_complete',
            'effective_window_complete', 'announcement_reach_complete', 'archive_complete',
            'pagination_complete', 'all_event_types', 'amendments_cancellations_complete',
            'holder_elections_covered', 'no_source_disagreement')

def normalize_cusip(value):
    # Preserve leading zeroes and the security's class/check digit; never infer a CUSIP from a ticker.
    if not isinstance(value, str):
        raise ValueError('CUSIP_MUST_BE_TEXT')
    result = re.sub(r'[\s-]', '', value).upper()
    if not re.fullmatch(r'[0-9A-Z*@#]{8}[0-9]', result):
        raise ValueError('CUSIP_REQUIRES_NINE_CHARACTERS')
    values = [int(c) if c.isdigit() else ord(c)-55 if c.isalpha() else {'*':36,'@':37,'#':38}[c] for c in result[:8]]
    total = sum(sum(map(int, str(v * (2 if i % 2 else 1)))) for i,v in enumerate(values))
    if (10-total%10)%10 != int(result[-1]):
        raise ValueError('CUSIP_CHECK_DIGIT')
    return result

def inside(value, window=Q2):
    if not value:
        return False
    d = date.fromisoformat(value[:10])
    return date.fromisoformat(window[0]) <= d <= date.fromisoformat(window[1])

def relevance(event):
    # Announcement/payment/record dates are searchable attributes, not substitutions for execution.
    if not event.get('effective_date'):
        interval = event.get('effective_interval')
        if interval and interval[0] <= Q2[1] and interval[1] >= Q2[0]:
            return 'INTERVAL_REQUIRES_REVIEW'
        return 'EFFECTIVE_DATE_UNKNOWN'
    return 'IN_Q2' if inside(event['effective_date']) else 'OUTSIDE_Q2'

def quantity_signal(event):
    if event.get('accounting_only') is True or event.get('event_type') == 'CASH_DIVIDEND':
        return False
    return event.get('execution_evidence') is True and event.get('event_type') in {
        'SPLIT', 'REVERSE_SPLIT', 'STOCK_DIVIDEND', 'SPINOFF', 'MERGER', 'CONVERSION',
        'EXCHANGE', 'ADR_RATIO_CHANGE', 'REORGANIZATION'}

def eligible(state, history_complete=False):
    if state not in {'YES', 'NO', 'UNKNOWN'}:
        raise ValueError('INVALID_ELIGIBILITY_STATE')
    return state == 'YES' and history_complete

def otc_applicable(scope, historical_symbol_bound=False):
    return scope == 'OTC_VERIFIED_Q2' and historical_symbol_bound

def fallback_order(adr=False, otc=False):
    return (['FINRA_OTC', 'DTCC_CA'] if otc else ['DTCC_CA']) + (
        ['DEPOSITARY_ADR_DOCUMENTS', 'SEC_ISSUER_FILINGS', 'OFFICIAL_ISSUER_PRIMARY'] if adr
        else ['SEC_ISSUER_FILINGS', 'OFFICIAL_ISSUER_PRIMARY']) + ['OTHER_AUTHORIZED_PRIMARY']

@dataclass
class Coverage:
    family: str
    access: str
    dtc_eligible: str = 'UNKNOWN'
    otc_scope: str = 'UNKNOWN'
    symbol_bound: bool = False
    flags: dict = field(default_factory=dict)

    def complete(self):
        if self.family not in FAMILIES or self.access != 'FULL_HISTORICAL_ACCESS_AVAILABLE':
            return False
        if not all(self.flags.get(k) is True for k in REQUIRED):
            return False
        if self.family == 'DTCC_CA' and not eligible(self.dtc_eligible, self.flags.get('historical_eligibility_complete')):
            return False
        if self.family == 'FINRA_OTC' and not otc_applicable(self.otc_scope, self.symbol_bound):
            return False
        return True

    def negative(self, events):
        # None denotes an unobservable result. An empty list alone is never sufficient.
        if events is None or not self.complete():
            return False
        for e in events:
            if e.get('accounting_only') is True or e.get('event_type') == 'CASH_DIVIDEND':
                continue
            if relevance(e) != 'OUTSIDE_Q2':
                return False
        return True

def choose_source(coverages, adr=False, otc=False):
    available = {c.family:c for c in coverages}
    for family in fallback_order(adr, otc):
        c = available.get(family)
        if c and c.access in {'FULL_HISTORICAL_ACCESS_AVAILABLE','PARTIAL_PUBLIC_ACCESS_AVAILABLE'}:
            return family
    return None

import unittest
from coverage2b import *

class CoverageTests(unittest.TestCase):
    def full(self, **kw):
        d = dict(family='DTCC_CA', access='FULL_HISTORICAL_ACCESS_AVAILABLE',dtc_eligible='YES', flags={k:True for k in REQUIRED})
        d.update(kw)
        return Coverage(**d)
    def test_cusip_preserves_zero_and_class(self):
        self.assertEqual(normalize_cusip(' 084670-108 '),'084670108')
        self.assertNotEqual(normalize_cusip('084670108'),normalize_cusip('084670702'))
    def test_cusip_alpha_and_check(self):
        self.assertEqual(normalize_cusip('31428x106'),'31428X106')
        for x in ['FDX',31428,'31428X107','08467010']:
            with self.subTest(x=x), self.assertRaises(ValueError): normalize_cusip(x)
    def test_period_boundaries(self):
        self.assertTrue(inside('2026-04-01'));self.assertTrue(inside('2026-06-30'))
        self.assertFalse(inside('2026-03-31'));self.assertFalse(inside('2026-07-01'))
    def test_early_announcement_does_not_hide_q2_event(self):
        e={'announcement_date':'2025-12-12','effective_date':'2026-05-14'}
        self.assertFalse(inside(e['announcement_date'],DISCOVERY));self.assertEqual(relevance(e),'IN_Q2')
    def test_q2_announcement_does_not_move_outside_event(self):
        self.assertEqual(relevance({'announcement_date':'2026-06-01','effective_date':'2026-07-01'}),'OUTSIDE_Q2')
    def test_record_and_payment_do_not_imply_execution(self):
        self.assertEqual(relevance({'record_date':'2026-05-15','payment_date':'2026-06-01'}),'EFFECTIVE_DATE_UNKNOWN')
    def test_conversion_interval_stays_review(self):
        self.assertEqual(relevance({'effective_interval':Q2}),'INTERVAL_REQUIRES_REVIEW')
    def test_eligibility_unknown_and_current_are_insufficient(self):
        self.assertFalse(eligible('UNKNOWN',True));self.assertFalse(eligible('NO',True));self.assertFalse(eligible('YES',False))
        self.assertTrue(eligible('YES',True))
    def test_invalid_eligibility_rejected(self):
        with self.assertRaises(ValueError):eligible('LIKELY')
    def test_otc_requires_historical_binding(self):
        for scope in ['NYSE','NASDAQ','UNKNOWN','OTC_CANDIDATE']:
            self.assertFalse(otc_applicable(scope,True))
        self.assertFalse(otc_applicable('OTC_VERIFIED_Q2',False))
        self.assertTrue(otc_applicable('OTC_VERIFIED_Q2',True))
    def test_partial_source_never_negates(self):
        self.assertFalse(self.full(access='PARTIAL_PUBLIC_ACCESS_AVAILABLE').negative([]))
    def test_auth_required_never_negates(self):
        self.assertFalse(self.full(access='AUTHENTICATION_REQUIRED').negative([]))
    def test_unobserved_events_never_negate(self):
        self.assertFalse(self.full().negative(None))
    def test_each_completeness_flag_is_required(self):
        for k in REQUIRED:
            with self.subTest(flag=k):
                c=self.full();c.flags[k]=False;self.assertFalse(c.negative([]))
    def test_complete_empty_result_may_certify(self):
        self.assertTrue(self.full().negative([]))
    def test_unknown_dtc_blocks_otherwise_full_source(self):
        self.assertFalse(self.full(dtc_eligible='UNKNOWN').negative([]))
    def test_finra_cannot_certify_listed_security(self):
        self.assertFalse(self.full(family='FINRA_OTC',otc_scope='NYSE',symbol_bound=True).negative([]))
    def test_source_disagreement_blocks_certificate(self):
        c=self.full();c.flags['no_source_disagreement']=False;self.assertFalse(c.negative([]))
    def test_known_spinoff_blocks(self):
        e={'event_type':'SPINOFF','effective_date':'2026-06-01','execution_evidence':True}
        self.assertTrue(quantity_signal(e));self.assertFalse(self.full().negative([e]))
    def test_holder_conversion_blocks_without_uniform_factor(self):
        self.assertFalse(self.full().negative([{'event_type':'CONVERSION','effective_interval':Q2}]))
    def test_accounting_stock_dividend_is_not_quantity_signal(self):
        self.assertFalse(quantity_signal({'event_type':'STOCK_DIVIDEND','accounting_only':True,'execution_evidence':True}))
    def test_adr_ratio_change_is_separate_event(self):
        self.assertTrue(quantity_signal({'event_type':'ADR_RATIO_CHANGE','execution_evidence':True}))
    def test_cash_dividend_does_not_block_quantity(self):
        e={'event_type':'CASH_DIVIDEND','effective_date':'2026-04-10'}
        self.assertFalse(quantity_signal(e));self.assertTrue(self.full().negative([e]))
    def test_fallback_uses_accessible_primary(self):
        self.assertEqual(choose_source([self.full(access='AUTHENTICATION_REQUIRED'),Coverage('SEC_ISSUER_FILINGS','PARTIAL_PUBLIC_ACCESS_AVAILABLE')]),'SEC_ISSUER_FILINGS')
    def test_adr_fallback_and_otc_priority(self):
        self.assertEqual(fallback_order(adr=True)[1],'DEPOSITARY_ADR_DOCUMENTS')
        self.assertEqual(fallback_order(otc=True)[0],'FINRA_OTC')

if __name__=='__main__':unittest.main()

La decisión de Wave 2B es **C — SECURITY_LEVEL_SOURCE_NOT_ACCESSIBLE**. Los servicios documentados contienen los campos de eventos e identidad necesarios, pero no hay acceso autorizado al dataset DTCC ni al master histórico FINRA con CUSIP en este proyecto. La viabilidad de sustituir la mayor parte de la reconstrucción por emisor no quedó demostrada. No se crean certificados ni se resuelven movimientos.

Se mantiene **517 BOTH_PRESENT resueltos y 526 globales**, con publicación REVIEW_PENDING. Se corrige exclusivamente el gate imposible de 20 gestores a **19/19**. Los demás requisitos de diversidad y calidad permanecen vigentes; esto no convierte la calificación global anterior en PASS.

| Fuente oficial | Acceso observado | Utilidad disponible | Certificado negativo Q2 |
|---|---|---|---|
| [DTCC CA Web](https://www.dtcc.com/data-services/corporate-actions-and-reference-data/ca-web-service) | AUTHENTICATION_REQUIRED | Documentación de búsquedas por CUSIP, CAID, tipos y fechas | No |
| [DTCC CA 20022](https://www.dtcc.com/data-services/corporate-actions-and-reference-data/dtcc-ca-20022-service) | COMMERCIAL_ACCESS_REQUIRED | Documentación de anuncios ISO 20022 y modalidades de entrega | No |
| [DTC Corporate Actions Processing](https://www.dtcc.com/asset-services/corporate-actions-processing) | AUTHENTICATION_REQUIRED | Descripción de procesamiento para participantes | No |
| [Important Notices](https://www.dtcc.com/legal/important-notices) | PARTIAL_PUBLIC_ACCESS_AVAILABLE | Avisos públicos identificados por fecha y CUSIP; descubrimiento parcial | No |
| [FINRA Daily List público](https://developer.finra.org/docs) | PARTIAL_PUBLIC_ACCESS_AVAILABLE | Consultas históricas OTC ejecutadas, sin campo CUSIP | No |
| [FINRA ORF: master y archivos](https://www.finra.org/sites/default/files/2024-08/Equity_API_File_Downloads_ORF.pdf) | AUTHENTICATION_REQUIRED; CUSIP sujeto a licencia | Esquema incluye CUSIP y DTC_ELGBL_FL; datos operativos no accedidos | No |

La [guía CA Web](https://www.dtcc.com/products/training/helpfiles/asset_services/corp_actions_browser/help/Corporate_Actions_Web.pdf), páginas 11–20, documenta búsquedas sobre bases actuales y archivadas. Permite fechas históricas en tramos de 90 días y distingue fechas críticas de fechas de actualización. Los filtros de estado, actividad o cartera pueden restringir resultados. No se estableció una garantía de retención, elegibilidad histórica ni exhaustividad que habilite certificados negativos. Se revisó visualmente la página 19. El portal devolvió un formulario de acceso; no se inició sesión.

La guía FINRA ORF, páginas PDF 6, 16, 18 y 23, describe autenticación TRAQS, CUSIP condicionado a licencia, elegibilidad DTC y cambios de identificador. Se revisó visualmente la tabla de la página 16. Un master actual tampoco demostraría por sí solo la historia de Q2. No se solicitaron tokens ni cotizaciones ni se aceptaron términos comerciales.

El navegador pudo leer Important Notices, aunque el cliente HTTP recibió 403. Se intentó buscar FDX por CUSIP y seleccionar 2026; la lista siguió mostrando septiembre sin confirmar ejecución del filtro. Las búsquedas públicas complementarias de los cuatro controles no recuperaron un evento Q2 utilizable. **Esto no es una respuesta negativa del dataset DTCC.** La página de elegibilidad pública contiene documentos y formularios, no una tabla histórica de los 66 CUSIP.

Las pruebas FINRA produjeron estas poblaciones históricas. Se consultó Q2 por cada fecha del evento y marzo 1–agosto 14 por fecha de anuncio, sin exigir que todas las condiciones fueran simultáneas:

| Campo consultado | Filas recuperadas | Paginación |
|---|---:|---|
| dailyListDatetime | 6,328 | Sí, a Record-Total observado |
| exDate | 3,319 | Sí, a Record-Total observado |
| paymentDate | 2,197 | Sí, a Record-Total observado |
| recordDate | 2,308 | Sí, a Record-Total observado |

La primera página de anuncios devolvió 3.283 filas aunque se solicitaron 5.000; se continuó desde el offset real hasta 6.328. La unión conserva **6.551 versiones de filas**, incluyendo adiciones, bajas, cambios de símbolo/nombre, dividendos/distribuciones/splits y atributos. El identificador 331496 tiene dos versiones con distinta fecha de calendario y comentario; una consulta puntual confirmó ambas. Se conservan sin sobrescribir. **61 filas con ex-date en Q2 fueron anunciadas fuera de la ventana auxiliar**: una búsqueda solo por anuncio perdería esos casos. Las respuestas se consultaron en septiembre y no constituyen una reconstrucción del conocimiento disponible el 14 de agosto.

Una consulta explícita al campo CUSIP recibió HTTP 400 porque no existe en el Daily List público. El número exacto de títulos OTC de la población sigue **UNKNOWN**: hay cero vínculos OTC históricos confirmados, no una afirmación de que no existan títulos OTC. No se aplicó FINRA como autoridad a valores NYSE/Nasdaq ni se unieron símbolos por semejanza de nombre. Los ejemplos OTC del índice prueban capacidad del endpoint, no cobertura de los CUSIP objetivo.

Se evaluaron los **66 títulos del piloto** frente a las barreras de acceso, elegibilidad e identidad. La barrera compartida impide ejecutar las consultas DTCC por CUSIP; no se contabilizan 66 consultas remotas ficticias. Cada fila incluye CUSIP normalizado, DTC_ELIGIBLE=UNKNOWN y resultados nuevos no observables (`null`, no listas vacías). Las 64 certificaciones CLEAR y los dos BLOCK previos permanecen idénticos.

| Control | Evidencia previa conservada | Resultado con nueva fuente |
|---|---|---|
| FDX | Spin-off efectivo 2026-06-01; registro 2026-05-15 | No recuperado; acceso operativo no disponible |
| BRK.A | 4.372 conversiones a elección del titular durante Q2; sin factor uniforme | No recuperado; cobertura de elecciones individuales no demostrada |
| TSM ADS | Certificación de la clase ADS preservada | Cobertura de eventos ADR nueva no demostrada |
| CVX | Partida contable de stock dividend no equivale a cambio de cantidad | El modelo rechaza esa señal contable; sin registro nuevo para medir discriminación |

PILOT_SOURCE_COVERAGE_COUNT=0 y controles recuperados=0/2. Hay cero contradicciones y falsas señales observadas sobre **cero registros nuevos evaluables**. Recall, sensibilidad y tasa de error del dataset son **no medibles**; no se afirma éxito de los controles ni tasa de error cero. Los eventos anteriores no se vuelven a contar como descubrimientos de Wave 2B.

Después del piloto se fijaron exactamente **100 paquetes UNKNOWN**, sin solapamiento: 30 de leverage 5–9, 35 de 2–4 y 35 de 1; 19 gestores; 26 SIC conocidos; 21 emisores domésticos verificados, 7 extranjeros y 72 sin régimen verificado; 11 ADS/ADR, 71 comunes, 17 fondos/ETF y 1 otro. Las portadas previas permiten observar 21 NYSE y 7 Nasdaq, con 72 indeterminados; son observaciones a la fecha del documento, no prueba de continuidad bursátil histórica. No se inventó un estrato OTC.

El resultado de la muestra es **0 cobertura negativa completa, 28 cobertura parcial y 72 sin cobertura utilizable vinculada al título**. Las 28 parciales corresponden a documentos primarios ya retenidos y vinculados a la clase, disponibles como respaldo por emisor; no representan éxito de DTCC/FINRA ni una revisión nueva de eventos. El acceso nuevo a una fuente de eventos por CUSIP alcanza 0/100. SHA de selección: `7d7eb7a1967e3cdebae4db90df8cc0369f77d0875f3a8c9249b7dc7c5ac2cc2b`. Es una muestra de diversidad deliberada, no una estimación estadística de cobertura global.

La matriz contiene los 2.135 títulos y las seis familias requeridas. Señala DTCC como fuente preferida condicionada a acceso, respaldo de depositario para ADS y respaldo SEC/emisor cuando esté disponible. Conserva aparte las certificaciones previas con su conjunto de fuentes; no atribuye ese certificado combinado a SEC en solitario. Los booleanos superiores se refieren a la adecuación de **nuevas fuentes por título**; los 1.969 títulos fuera de los dos grupos son inventario de fuentes, no consultas remotas adicionales. No se continuó la cola de revisión de emisores.

Se midieron **34,228,312 bytes descargados (34.23 MB), 20,338,826 bytes retenidos y 34 intentos HTTP**, de los que 10 fallaron por DNS en el sandbox y 24 recibieron respuesta. El acumulado medido está por debajo de 500.000.000 bytes. Los bytes de transporte del navegador/buscador administrados no están expuestos: el total de todas las superficies no es medible y no se presenta el contador HTTP como ese total. No hubo descarga masiva de emisores.

El tiempo de espera de fuentes medido es 42.598 s: **0.256617 s por título amortizados** sobre 166. No es latencia de consultas CUSIP exitosas ni tiempo de revisión humana. Frente a los 5.089.019.968 bytes de Wave 2A, esta fase consume el 0.673% en cuerpos HTTP medidos. Se crearon cinco pendientes de arquitectura/acceso y cero nuevas revisiones por emisor.

El proxy de coste por 1.000 paquetes, multiplicando el coste compartido por 1.000/166, es 206,194,651 bytes descargados y 256.62 s de espera de fuente. El coste inicial puede reutilizarse sin nuevas descargas para más clasificaciones del mismo intervalo. Precios comerciales, coste operativo de consultas y minutos de revisión son desconocidos. No se extrapolan resoluciones.

La decisión A requiere cobertura completa que no se obtuvo; B requiere un subconjunto objetivo con fuente utilizable que no quedó vinculado; D exigiría recuperar los eventos de los controles pero no demostrar ausencia. Aquí la limitación decisiva es el acceso al dataset y al master necesario: **se selecciona únicamente C**. Incluso con acceso futuro, BRK.A obliga a comprobar elecciones de titulares y no asumir que un feed de anuncios sustituye toda la evidencia del emisor.

Pasaron 33 pruebas nuevas del modelo y del benchmark, además de 343 pruebas existentes de la aplicación (1 prueba adicional omitida), typecheck, lint (17 avisos previos), build y git diff --check. El primer build quedó detenido en compilación dentro del sandbox; se guardó ese intento y el mismo comando pasó fuera del sandbox. No hubo cambios de aplicación para resolverlo. La auditoría comparó 613 archivos versionados y 5.509 archivos heredados: **cero diferencias**, incluidos corpus, target, resultados de Wave 2A y datos públicos.

Los entregables principales son [RESULT.json](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/RESULT.json), [matriz completa](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/CORPORATE_ACTION_SOURCE_MATRIX.json), [piloto](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/pilot-source-benchmark.json), [muestra de 100](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/sample-100.json), [consultas y barreras por título](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/cohort-query-coverage.json), [resultados históricos FINRA](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/finra-historical-query-results.json), [fuentes y acceso](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/source-access-assessment.json), [coste](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/cost-benchmark.json), [auditoría de aislamiento](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/final-isolation-audit.json) y [manifest de archivos](/private/tmp/trends-wave2b-20260908/worktree/internal/trends-movements/wave2b/files-created.json). No hubo commit, push, deploy ni actualización de holdings. PRODUCTION_READINESS=NOT_READY.

El siguiente paso recomendado es conseguir un extracto histórico DTCC ya autorizado con garantías de cobertura y elegibilidad, o un master FINRA histórico con licencia para un subconjunto OTC demostrado. Repetir después los mismos 66 controles y la misma muestra de 100 antes de proponer certificados. No reanudar descargas masivas de emisores.

Valores de salida solicitados:

```text
STATE=WAVE_2B_FEASIBILITY_COMPLETE_ACCESS_LIMITED
BASE_COMMIT=ea9737a55742f318f417048a8cbf0c06a82f0545
REMOTE_HEAD=ea9737a55742f318f417048a8cbf0c06a82f0545
OLD_MANAGER_AUDIT_REQUIREMENT=20
NEW_MANAGER_AUDIT_REQUIREMENT=19_OF_19
MOVEMENT_CORPUS_CHANGED=NO
BOTH_PRESENT_TARGET_CHANGED=NO
DTCC_ACCESS_STATE=AUTHENTICATION_REQUIRED
DTCC_EVENT_DISCOVERY_CAPABLE=YES_PUBLIC_NOTICES_ONLY; OPERATIONAL_FEED_NOT_ACCESSIBLE
DTCC_NEGATIVE_COVERAGE_CERTIFICATE_CAPABLE=NO
DTCC_HISTORICAL_Q2_ACCESS=NOT_DEMONSTRATED_FOR_SECURITY_LEVEL_EVENT_QUERIES
FINRA_OTC_ACCESS_STATE=PARTIAL_PUBLIC_ACCESS_AVAILABLE
PILOT_SECURITIES=66
PILOT_SOURCE_COVERAGE_COUNT=0
PILOT_KNOWN_EVENTS_RECALLED=0
PILOT_KNOWN_CLEAR_CONTRADICTIONS=0
PILOT_FALSE_EVENT_SIGNALS=0
SAMPLE_PACKETS=100
SAMPLE_COMPLETE_NEGATIVE_COVERAGE=0
SAMPLE_PARTIAL_COVERAGE=28
SAMPLE_NO_COVERAGE=72
OTC_SECURITIES_IN_TARGET=UNKNOWN
FINRA_COVERED_SECURITIES=0
SOURCE_REQUESTS=34
SOURCE_BYTES_DOWNLOADED=34228312
SOURCE_BYTES_RETAINED=20338826
SECONDS_PER_SECURITY=0.25661746836746996
MANUAL_REVIEW_ITEMS_CREATED=5
EXPECTED_COST_PER_1000_PACKETS={"additional_local_classifications_require_new_downloads":false,"commercial_dataset_price":"UNKNOWN_NO_QUOTE_REQUESTED","downloaded_body_bytes":206194651,"limitations":"Excludes managed-web transport and analyst time; shared setup is reusable, so linear scaling is a comparison proxy, not a forecast of production throughput.","manual_review_minutes":"NOT_ESTIMATED","model":"Public feasibility-probe amortization only; observed shared cost * 1000/166.","operational_feed_query_cost":"NOT_MEASURABLE_WITHOUT_ACCESS","resolution_rate_extrapolated":false,"retained_body_bytes":122523048,"same_window_shared_setup_bytes":34228312,"source_request_attempts":204.81927710843374,"source_wait_seconds":256.61746836746994}
ARCHITECTURE_DECISION=SECURITY_LEVEL_SOURCE_NOT_ACCESSIBLE
MOVEMENT_PUBLICATION=REVIEW_PENDING
MOVEMENT_UI_PRESENT=NO
MOVEMENT_FIELDS_PUBLIC=NONE
BOTH_PRESENT_RESOLVED=517
GLOBAL_TOTAL_RESOLVED=526
PUBLIC_DATA_CHANGED=NO
PUBLIC_SNAPSHOT_CHANGED=NO
TESTS=PASS: 33 source feasibility tests + 343 existing application tests passed; 1 existing test skipped
TYPECHECK=PASS
LINT=PASS_WITH_17_EXISTING_WARNINGS
BUILD=PASS
GIT_DIFF_CHECK=PASS
FILES_CHANGED=0
FILES_CREATED=75
PRODUCTION_READINESS=NOT_READY
NEXT_RECOMMENDED_STEP=Obtain an already authorized historical DTCC sample/export plus completeness and eligibility documentation, or licensed historical FINRA CUSIP-symbol data for a verified OTC subset. Repeat the same 66 controls and frozen 100 sample before proposing certificates; do not resume mass issuer downloads.
```

# Wave 2A — expansión interna incompleta

Se resuelven **517 de 4.162 comparaciones BOTH_PRESENT (12.42%)**: 487 reproducidas exactamente del piloto y 30 nuevas, correspondientes a McDonald’s, Nucor, Phillips 66, State Street y Verizon. Quedan **14 bloqueadas y 3.631 desconocidas**. El total del corpus pasa de los 9 resultados previos a **526 resueltos y 7.611 indeterminados** al aplicar el piloto y esta expansión.

**STATE=WAVE_2A_INCOMPLETE_EVIDENCE_COVERAGE. PRODUCTION_READINESS=NOT_READY.** No se ha completado la revisión global: 2.064 de 2.135 paquetes (96.67%) siguen UNKNOWN. La descarga de documentación no equivale a una revisión favorable. No se ha relajado el certificado del piloto.

El censo de todo el corpus tiene 5.771 BOTH_PRESENT. Los 4.162 conocidos corresponden exactamente al grupo EVIDENCE_RESOLVABLE y contienen 19 gestores. Se congeló ese conjunto, sin incorporar los otros 1.609 casos con resultados previos, revisión humana o bloqueos estructurales. La pregunta sobre el mínimo de 20 gestores sigue pendiente; **no se ha dispensado ese requisito**. Véase [censo](/private/tmp/trends-wave2a-20260907/worktree/internal/trends-movements/wave2a/target-census.json) y [conjunto congelado](/private/tmp/trends-wave2a-20260907/worktree/internal/trends-movements/wave2a/target.json).

La identidad oficial reutilizada es autoritativa para 2.058 pares y queda pendiente para 77. Hay 2.073 coincidencias EXACT_BOTH, pero 15 no tienen identidad de periodo autoritativa; no se confunden ambas cifras. Se intentó descubrir CIK para los 2.135 paquetes y se retuvieron inventarios de 1.539 candidatos. Hay 126 bindings CIK verificados (66 previos y 60 nuevos), 95 ambiguos y 1.914 sin verificación. Los nombres y tickers de candidatos nunca autorizan movimientos.

La revisión nueva de eventos empezó por los siete paquetes nuevos con al menos seis comparaciones, en el orden congelado. Cinco están cerrados; Alibaba y Unilever conservan UNKNOWN. Los otros 53 emisores con identidad primaria nueva aún necesitan su revisión de eventos. El [registro por paquete](/private/tmp/trends-wave2a-20260907/worktree/internal/trends-movements/wave2a/packet-review-ledger.json) y la [cola restante](/private/tmp/trends-wave2a-20260907/worktree/internal/trends-movements/wave2a/remaining-review-queue.json) separan ausencia de candidato, identidad sin revisar, falta de documentación y cobertura primaria pendiente. El alcance y este punto de avance no constituyen una pasada completa por todos los niveles.

| Nivel | Paquetes | Comparaciones | Resueltas | Resolución |
| --- | ---: | ---: | ---: | ---: |
| 20+ | 0 | 0 | 0 | No aplicable |
| 10–19 | 10 | 115 | 115 | 100.00% |
| 5–9 | 121 | 718 | 402 | 55.99% |
| 2–4 | 849 | 2174 | 0 | 0.00% |
| 1 | 1155 | 1155 | 0 | 0.00% |

No hay paquetes de 20 o más comparaciones dentro del conjunto congelado. Se usa la frecuencia dentro de ese conjunto, aunque un título aparezca más veces en el corpus completo. No hay familias normalizadas en este resultado; todos los factores aplicados son 1/1. Los dos bloques verificados del piloto permanecen indeterminados.

La [auditoría primaria](/private/tmp/trends-wave2a-20260907/worktree/internal/trends-movements/wave2a/manual-audit.json) reconstruye 110 comparaciones, 69 valores, 19 gestores y 26 grupos SIC: 73 revisiones explícitas previas y 37 nuevas. Se observaron cero falsos positivos bajo el modelo auditado; **no es una afirmación estadística de error cero ni una firma humana independiente**. No se identificó ningún falso negativo confirmado; los casos con evidencia pendiente no permiten estimarlo. Se cubren todos los valores resueltos; no existen familias distintas de 1/1 ni paquetes que resuelvan 50 o más comparaciones. El mínimo de 20 gestores no se cumple.

El [análisis de sesgo](/private/tmp/trends-wave2a-20260907/worktree/internal/trends-movements/wave2a/resolution-bias.json) falla en las siete dimensiones solicitadas sobre el denominador congelado. Es un control descriptivo de disparidad, no un test estadístico. Las transiciones de presencia quedan fuera de ese control y se reportan aparte como FAIL_EXPECTED_PRESENCE_TRANSITIONS_UNRESOLVED. El umbral operativo de UNKNOWN se fijó en 5% antes de la aplicación como referencia conservadora; no fue aprobado por el usuario ni autoriza publicación. El resultado actual queda muy lejos de ese umbral.

Se retuvieron 1629 documentos primarios únicos en los índices de esta fase. Descarga nueva: 5,089,019,968 bytes de cuerpo HTTP; conservación nueva: 321,488,443 bytes de fuentes comprimidas únicas. La eficiencia es 1.6081 comparaciones resueltas por MB, o 0.0933 nuevas más allá del piloto por MB. La primera cifra incluye la ventaja de reutilizar el piloto. Los bytes heredados se excluyen de ambas medidas de coste. Los dos PDF retenidos pendientes de lectura no se usan para certificar CLEAR. Véase [custodia y definiciones](/private/tmp/trends-wave2a-20260907/worktree/internal/trends-movements/wave2a/source-audit.json).

**Validación:** 679 pruebas pasan; typecheck, build y diff check pasan; lint tiene 17 avisos existentes y ningún error. SEO valida 76 rutas y 35 pares de idiomas. Los ataques de clase/CUSIP, periodo, formularios extranjeros, enmiendas, split con CUSIP estable, perímetro, metadatos y filtración de certificados cierran sin resolver. Dos construcciones independientes con red deshabilitada reproducen los resultados, certificados y bindings exactamente. Se verificaron los hashes de 613 archivos versionados y 2.320 archivos heredados y se inspeccionó la salida pública del build sin encontrar campos de movimientos.

Todo el trabajo reside en `/private/tmp/trends-wave2a-20260907/worktree` sobre `01c5dcfe60d4c3ca37ab0e8c9af40a160a495be0`. No hubo commit, push, despliegue, cambio público ni actualización de holdings. La publicación permanece REVIEW_PENDING. Los archivos reconstituidos de Wave 1A–1D son copias idénticas; solo se crearon archivos nuevos de Wave 2A. [Manifest de archivos nuevos](/private/tmp/trends-wave2a-20260907/worktree/internal/trends-movements/wave2a/files-created.json).

## Salida solicitada completa

```text
STATE=WAVE_2A_INCOMPLETE_EVIDENCE_COVERAGE
BASE_COMMIT=01c5dcfe60d4c3ca37ab0e8c9af40a160a495be0
REMOTE_HEAD=01c5dcfe60d4c3ca37ab0e8c9af40a160a495be0
MOVEMENT_CORPUS_COUNT=8137
MOVEMENT_CORPUS_SHA256=d270f69dc303daa6d694fbafa6d4c91166cdcfb60c4e1fb5bc90b105b5143ac3
MOVEMENT_CORPUS_CHANGED=NO
BOTH_PRESENT_TARGET_COUNT=4162
BOTH_PRESENT_TARGET_SHA256=307cfb419c1134e020b7b0e57f8f7fab024a81ec2c8790af168f33c6de6559e6
PILOT_REPLAY=PASS
PILOT_TOTAL_RESOLVED=487
PILOT_PACKET_CLEAR=64
PILOT_PACKET_VERIFIED_BLOCK=2
PILOT_PACKET_UNKNOWN=0
TARGET_SECURITY_PAIRS=2135
TARGET_SECURITY_BINDINGS_ALREADY_VERIFIED=2058
TARGET_SECURITY_BINDINGS_NEWLY_VERIFIED=0
TARGET_SECURITY_BINDINGS_UNKNOWN=77
CIK_VERIFIED_TOTAL=126
CIK_AMBIGUOUS_TOTAL=95
CIK_UNRESOLVED_TOTAL=1914
PACKETS_TOTAL=2135
PACKETS_CLEAR=69
PACKETS_EVENT_NORMALIZED=0
PACKETS_VERIFIED_BLOCK=2
PACKETS_UNKNOWN=2064
BOTH_PRESENT_RESOLVED=517
BOTH_PRESENT_BLOCKED=14
BOTH_PRESENT_UNKNOWN=3631
REPORTED_INCREASED=181
REPORTED_REDUCED=251
REPORTED_UNCHANGED=85
NEW=0
EXITED=0
BOTH_PRESENT_COMPLETENESS=0.12421912542047092
BOTH_PRESENT_MANAGER_COVERAGE={"fraction":1.0,"resolved_managers":19,"target_managers":19}
BOTH_PRESENT_SECURITY_COVERAGE={"fraction":0.03231850117096019,"resolved_securities":69,"target_securities":2135}
PACKETS_AFFECTING_20_PLUS=0
PACKETS_10_19=10
PACKETS_5_9=121
PACKETS_2_4=849
PACKETS_1=1155
MANUAL_CHECKS=110
DISTINCT_SECURITIES_MANUALLY_CHECKED=69
DISTINCT_MANAGERS_MANUALLY_CHECKED=19
NORMALIZATION_FAMILIES_CHECKED=["1/1"]
FALSE_POSITIVES_OBSERVED=0
CONFIRMED_FALSE_NEGATIVES=0
BOTH_PRESENT_RESOLUTION_BIAS_CHECK=FAIL
BOTH_PRESENT_BIAS_DIMENSIONS_FAILED=["manager","portfolio_breadth","security_frequency","trend_category","sector_SIC","filing_regime","event_complexity"]
FULL_MOVEMENT_BIAS_CHECK=FAIL_EXPECTED_PRESENCE_TRANSITIONS_UNRESOLVED
SOURCE_BYTES_DOWNLOADED=5089019968
SOURCE_BYTES_RETAINED=321488443
DOCUMENTS_INDEXED=1629
DOCUMENTS_RETAINED=1629
TESTS={"count":679,"state":"PASS"}
TYPECHECK=PASS
LINT=PASS_WITH_17_EXISTING_WARNINGS
BUILD=PASS
GIT_DIFF_CHECK=PASS
OFFLINE_REPLAY=PASS
MOVEMENT_PUBLICATION=REVIEW_PENDING
MOVEMENT_UI_PRESENT=NO
MOVEMENT_FIELDS_PUBLIC=NONE
PUBLIC_DATA_CHANGED=NO
PUBLIC_SNAPSHOT_CHANGED=NO
SEC_HOLDINGS_REFRESH=NO
FILES_CHANGED=0
FILES_CREATED={"count":3189,"manifest":"/private/tmp/trends-wave2a-20260907/worktree/internal/trends-movements/wave2a/files-created.json"}
PRODUCTION_READINESS=NOT_READY
NEXT_RECOMMENDED_STEP=Resolve the 4162-case/19-manager versus 20-manager audit constraint, then close the remaining ranked primary evidence queue, starting with retained Alibaba and Unilever coverage and 53 other newly verified issuer scopes. No publication, commit, push, deploy or holdings refresh.
PACKET_UNKNOWN_RATE=0.9667447306791569
PACKET_UNKNOWN_OPERATIONAL_THRESHOLD=0.05
UNKNOWN_THRESHOLD_BASIS=Conservative predeclared operational threshold; not statistical confidence or a publication gate.
GLOBAL_TOTAL_RESOLVED=526
GLOBAL_STILL_INDETERMINATE=7611
NEW_RESOLVED_BEYOND_PILOT=30
CIK_NEWLY_VERIFIED=60
COMPARISONS_RESOLVED_PER_MB_RETAINED=1.6081448999396846
NEW_COMPARISONS_RESOLVED_PER_MB_RETAINED=0.09331595164060065
STATISTICAL_ZERO_ERROR_CLAIM=NO
MANUAL_REVIEW_AUTHORITY=Codex primary agent textual review with retained primary reconstruction; 73 preserved prior reviews plus 37 new reviews. Not independent human sign-off.
MANUAL_AUDIT_STATE=INCOMPLETE_TWENTY_MANAGER_REQUIREMENT
DISTINCT_SIC_GROUPS_MANUALLY_CHECKED=26
UNFINISHED_WORK=["2064 packet coverage certificates remain UNKNOWN; acquisition of metadata and identity documents is not event coverage.","Only five new event packets have completed primary review; two retrieved foreign-issuer event scopes still need closure.","The frozen target contains 19 managers; the requested 20-manager audit requirement is unmet, not waived.","All seven observed BOTH_PRESENT bias dimensions fail."]
PRESENCE_TRANSITIONS_UNCHANGED=true
OUTSIDE_TARGET_COMPARISONS_PRESERVED=3975
COMMIT=NO
PUSH=NO
DEPLOY=NO
```

# Shared evidence qualification — Wave 1

This layer is internal and operates only on the 5,314 comparisons previously classified EVIDENCE_RESOLVABLE. The 8,137-row corpus, 9 previous qualifications, 2,348 human-review cases and 466 structural cases remain frozen. No issuer-name or ticker match creates an issuer identity. No holdings are fetched.

## Evidence and dependency scopes

Comparison roots reference terminal MANAGER_PERIMETER, two quarterly AMENDMENT_STATE, two quarterly FILING_USABILITY, SECURITY_CONTINUITY and CORPORATE_ACTION_STATE nodes. One-sided observations also reference a deferred, manager/security-specific PRESENCE_TRANSITION node. Edges include independently checked type, subject, quarter and scope. Reverse edges list dependent comparisons; `unlocks_count` is conditional reach, never a count of achieved resolutions. Evidence IDs encode the type and hash of subject/period. Each node has structured payload, status, primary refs, verification time/method, source horizon, conflicts and a hash over the entire node except its hash field.

Manager scopes include filer ID, economic group and cover CIK. Quarterly decisions include all and selected accessions plus the retained SEC submission-index hash. The date of evidence is distinct from its reporting period. A newer/different source hash or evidence horizon invalidates the decision; the layer does not assert that historical evidence includes subsequent amendments. Unknown confidentiality never becomes false.

Continuity requires the complete CUSIP/instrument/option key in both quarters and identical class descriptions within each manager comparison. SEC XML rows, indices and quantities are retained in the dossier. Different filers may use different textual descriptions of an identical issue key; those labels are recorded and are not equated. ADR unit ratios remain a corporate-action question. Known issuer IDs are separate claims. One-sided data cannot establish a NEW/EXIT conclusion from a continuity certificate borrowed from another holder.

Supported relationships are SAME_SECURITY, SUCCESSOR, PREDECESSOR, CLASS_CONVERSION, CUSIP_CHANGE_SAME_SECURITY, DISTINCT_SECURITIES and UNKNOWN. The latter two never authorize comparison. A declared relationship is insufficient: the unchanged v2.1 resolver also requires the correctly scoped transformation event and exact normalization where needed.

## VERIFIED_CLEAR corporate-action standard

Every item below must have primary-source coverage, a reproducible locator and explicit review before a clear certificate is signed:

1. The issuer, CUSIP, instrument and class are bound by authoritative evidence.
2. A period-complete issuer filing/disclosure inventory covers the comparison interval and subsequent reporting that describes it. Paginated historical indices and incorporated-by-reference documents are examined where necessary. The screen includes exchange-offer and registration forms (including S-4/F-4), amendments and prospectus supplements; a list of 8-K/10-Q filings alone is insufficient.
3. Share-class terms at both endpoints and the relevant equity rollforward are reviewed. Fiscal reporting dates that differ from the 13F endpoints require coverage of the intervening dates.
4. Relevant interim events, effective dates, referenced terms and exhibits are reviewed and reconciled with the periodic filing.
5. Split, reverse split, merger, spinoff, conversion, identifier/class changes, ticker changes, reorganization and other unit transformations have an explicit class-specific disposition. Issuer outstanding-share changes are not holder unit factors. Rights of another class cannot be applied to the target class.
6. Conflicting authoritative claims are resolved explicitly. An unresolved conflict invalidates the shared node for all dependants.

These are coverage requirements, not keyword-search rules. No search results, no detected event, a single earnings report, unchanged CUSIP or arithmetic alone cannot certify absence. Unavailable or expensive-to-establish coverage remains UNKNOWN. Verified occurrence of an event is distinct from a complete clearance for an affected or potentially related class.

## Reported quantities and transactions

The legacy resolver performs exact rational arithmetic after all evidence guards. Its internal INCREASED/REDUCED/UNCHANGED outputs are wrapped as REPORTED_INCREASED/REPORTED_REDUCED/REPORTED_UNCHANGED under REPORTED_QUANTITY_CHANGE. INFERRED_MANAGER_TRANSACTION is null. Neither purchases nor sales are inferred from the reported observations. Missing observations remain unknown and strict Tier B remains deferred. No current route imports this layer.

## Reviewed certificate ingestion

`reviewed-node-attestations.json` is the explicit certificate input. Its record list is empty in this wave because no additional corporate-action clearance met the standard. The builder accepts only valid, source-hashed certificates matching an existing node’s exact scope and dependent comparison set; duplicates, source changes, unknown issuer upgrades and quarter changes stop the build. Primary supplement bodies are rehashed before trust. A changed certificate changes the fixed pilot dossier and requires versioned review of the same selected comparisons before any expansion. No automatic generator converts missing research to VERIFIED_CLEAR.

## Priority, pilot and gate

Tasks rank by conditional BOTH_PRESENT reach, distinct managers, presence in the current public capital view, top-ten holding overlap, trend links and retained primary evidence strength. Ties use a stable evidence hash, not issuer alphabetical order. Materiality affects review ordering only; it never changes movement arithmetic or confidence.

The prospective selection fixes at least 500 affected comparisons before results. Diversity minimums are 10 managers, 20 securities and 5 known SEC SIC two-digit industry groups; this taxonomy is explicitly not GICS. Unknown sector cases are reported separately. The selection also records quantities and issuer concentration.

Manual review is performed by Codex on retained primary XML cover/row dossiers and issuer documents; it is not independent external human certification. The signed local review binds every reviewed node and the fixed dossier hash. Insufficient coverage produces an indeterminate oracle, with economic false negatives unevaluable. Zero false positives from abstaining on all cases cannot pass the pilot. Expansion additionally requires at least 500 qualified results with the same diversity minimums, all pilot dependencies reviewed and qualified, no confirmed errors, passing tests and unchanged source/code fingerprints. This stricter useful-coverage gate prevents repeating the previous Alphabet-only outcome. No failed or blocked pilot writes expansion results.

## Queue and bias interpretation

Atomic DAG nodes are claims, not interchangeable with operational research packets. A packet can collect the issuer's class-specific corporate-action, identity and deferred presence questions for one period; each question still needs its own scope and qualification. Manager-period packets similarly group cover and amendment work. Report both raw unresolved nodes and packet counts, active high-leverage work and deferred Tier B. Count unique comparisons, not sums of overlapping task reach. Unknown issuer bindings remain separate full-security packets.

Global bias is assessed over all 8,137 frozen comparisons, including preserved prior qualifications. Compare resolved and unresolved by manager, top-quartile portfolio breadth, security frequency, current public trend/category mappings, movement family and presence status. A nonempty group with zero resolution while another resolves, or a greater than twofold observed rate disparity, fails this conservative coverage diagnostic. This is not a causal or statistical fairness claim. No new resolutions means within-Wave-1 bias is indeterminate; the previous global FAIL remains meaningful and is reported separately.

MOVEMENT_PUBLICATION=REVIEW_PENDING; MOVEMENT_UI_PRESENT=NO; MOVEMENT_FIELDS_PUBLIC=NONE. No commit, push, deploy or public data mutation is part of this phase.

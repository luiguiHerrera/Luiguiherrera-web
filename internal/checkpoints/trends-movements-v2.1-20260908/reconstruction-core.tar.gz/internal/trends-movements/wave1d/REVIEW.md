**Wave 1D — cierre del piloto fijo para revisión**

La cobertura de evidencia pasa para las mismas 501 comparaciones, 66 valores y 19 gestores. Solo cambian los paquetes TSMC ADS y Chevron common; se preservan los otros 64 certificados y las 482 comparaciones ajenas a esos dos valores. Las 14 comparaciones bloqueadas corresponden a FedEx common (8) y Berkshire A (6).

```text
STATE=FIXED_PILOT_EVIDENCE_COVERAGE_PASS
TSMC_AGM_PDF_SHA256=3155817bb2f6fd5a52a6332a6f6a01ac36a71638a9c57e884abc65b1dddf9ee6
TSMC_AGM_PDF_SIZE=4368300
TSMC_AGM_DOCUMENT_DATE=2026-06-04
TSMC_AGM_EVIDENCE_RETAINED=YES
NO_SPLIT_INTENT_AS_OF_2026_06_04=VERIFIED
JUNE_4_ARTICLES_AMENDMENT=NON_SHARE_CAPITAL_AMENDMENT
TSMC_COMMON_EVENT_STATE=VERIFIED_CLEAR_FOR_COMPARABILITY; RECLAIMED_RSA_CANCELLATION_SCOPED
TSMC_ADS_RATIO_STATE=VERIFIED_UNCHANGED_Q2; 1_ADS_TO_5_COMMON_SHARES
TSMC_CLASS_STATE=VERIFIED_UNCHANGED_ADS_CLASS_AND_CUSIP_874039100
TSMC_POST_JUNE4_EVENT_STATE=VERIFIED_CLEAR_FOR_Q2_COMPARABILITY
TSMC_PACKET=VERIFIED_CLEAR_FOR_COMPARABILITY
TSMC_NORMALIZATION_FACTOR=1/1
CHEVRON_ISSUED_SHARES_Q1_END=2442676580
CHEVRON_ISSUED_SHARES_Q2_END=2442676580
STOCK_DIVIDEND_COMMON_STOCK_COLUMN_EFFECT=USD_0
RETAINED_EARNINGS_EFFECT=USD_-11000000
TREASURY_SHARE_EFFECT=STOCK_DIVIDEND_LINE=0; PURCHASES=-16255113; REISSUANCES=428655
PRO_RATA_SHARE_FACTOR_REQUIRED=NO
CHEVRON_STOCK_DIVIDEND_SCOPE=ACCOUNTING_EQUITY_ITEM_NOT_PRO_RATA_COMMON_SHARE_QUANTITY_EVENT
CHEVRON_NORMALIZATION_FACTOR=1/1
CHEVRON_PACKET=VERIFIED_CLEAR_FOR_COMPARABILITY
PILOT_PACKET_CLEAR=64
PILOT_PACKET_EVENT_NORMALIZED=0
PILOT_PACKET_VERIFIED_BLOCK=2
PILOT_PACKET_UNKNOWN=0
PILOT_EVIDENCE_COVERAGE=PASS
PILOT_RESOLVED_BEFORE=468
PILOT_NEWLY_RESOLVED=19
PILOT_TOTAL_RESOLVED=487
PILOT_STILL_INDETERMINATE=14
PILOT_REPORTED_INCREASED=172
PILOT_REPORTED_REDUCED=236
PILOT_REPORTED_UNCHANGED=79
PILOT_MANUAL_CHECKS=73
NEW_MANUAL_CHECKS=2
NEW_FALSE_POSITIVES=0
PILOT_FALSE_POSITIVES=0
STATISTICAL_ZERO_ERROR_CLAIM=NO
GLOBAL_TOTAL_RESOLVED=9
GLOBAL_STILL_INDETERMINATE=8128
GLOBAL_EXPANSION_PERFORMED=NO
MOVEMENT_PUBLICATION=REVIEW_PENDING
MOVEMENT_UI_PRESENT=NO
MOVEMENT_FIELDS_PUBLIC=NONE
PUBLIC_DATA_CHANGED=NO
PUBLIC_SNAPSHOT_CHANGED=NO
SEC_HOLDINGS_REFRESH=NO
COMMIT=NO
PUSH=NO
DEPLOY=NO
TESTS=PASS (650)
TYPECHECK=PASS
LINT=PASS (17 existing warnings)
BUILD=PASS
GIT_DIFF_CHECK=PASS
PRODUCTION_READINESS=NOT_READY
NEXT_RECOMMENDED_STEP=REVIEW_FIXED_PILOT_RESULTS; EXPLICIT_AUTHORIZATION_REQUIRED_BEFORE_ANY_GLOBAL_EXPANSION
```

TSMC: el acta aporta evidencia puntual de intención el 4 de junio y el texto operativo de la reforma, que solo cambia el número de consejeros y la fecha de modificación. El cierre trimestral también exige el inventario SEC del 1 de marzo al 14 de agosto, los informes de ambos cierres y las condiciones del depositario. El contrato establece 1 ADS = 5 acciones ordinarias; ambos informes muestran 1.062.690 miles de ADS y 5.313.451 miles de acciones subyacentes. Esos totales redondeados corroboran la ratio contractual y no se usan para calcularla. La cancelación de 154.454 acciones de remuneración, efectiva el 12 de mayo y reportada el 25 de junio, afecta acciones recuperadas de empleados; no genera un factor para los ADS existentes.

El PDF de 43 páginas conserva sus 4.368.300 bytes exactos. Se comprobaron visualmente las páginas 4, 6, 38 y 39. La extracción OCR se guarda como auxiliar; el PDF es la fuente. Su custodia se identifica como documento primario aportado por el usuario. El 6-K del 4 de junio corrobora la junta y su aprobación: no se presenta el PDF como archivo SEC ni como enlace contenido en ese 6-K. El certificado lo vincula por hash mediante la prueba suplementaria.

Chevron: el estado de patrimonio conserva 2.442.676.580 acciones emitidas. La línea de dividendos de acciones registra −11 millones de USD en resultados retenidos, sin efecto en las columnas de capital o tesorería. Las acciones en circulación se concilian como 1.991.597.732 − 16.255.113 + 428.655 = 1.975.771.274. Los 14.168.000 títulos del Benefit Plan Trust están incluidos en todos los saldos emitidos. Los términos de RSU y los dos 11-K de planes distinguen prestaciones, elecciones de reinversión y conversiones históricas de un reparto proporcional a todos los titulares. No se atribuyen los 11 millones a un plan concreto. El factor para las unidades common existentes es 1/1.

Reconstrucciones nuevas leídas directamente en las cuatro filas XML de Ariel:

| Valor | CUSIP / clase | Q1 | Q2 | Factor | Diferencia | Resultado |
|---|---|---:|---:|---|---:|---|
| TSMC | 874039100 / SPONSORED ADS | 16.092 | 17.838 | 1/1 | +1.746 | REPORTED_INCREASED |
| Chevron | 166764100 / COM | 41.499 | 34.626 | 1/1 | −6.873 | REPORTED_REDUCED |

Hay 73 comprobaciones manuales acumuladas con resultado evaluable, incluidas estas dos nuevas. Se observaron cero falsos positivos en esas comprobaciones; no es una estimación estadística de error cero. Las nuevas 19 resoluciones se reparten en 6 aumentos, 10 reducciones y 3 sin cambio de cantidad reportada.

Fuentes principales y trazabilidad:

- [TSMC: junta, 6-K del 4 de junio](https://www.sec.gov/Archives/edgar/data/1046179/000104617926000302/tsm-agmx20260604x6k.htm).
- [TSMC: condiciones de los ADS, Exhibit 2.1](https://www.sec.gov/Archives/edgar/data/1046179/000162828026025362/exhibit21.htm).
- [TSMC: Q1, Note 21](https://www.sec.gov/Archives/edgar/data/1046179/000104617926000278/a2026q1consolidatedreport-.htm) y [Q2, Note 21](https://www.sec.gov/Archives/edgar/data/1046179/000104617926000541/a2026q2consolidatedreport-.htm).
- [Chevron: 10-Q Q2, estado de patrimonio y notas](https://www.sec.gov/Archives/edgar/data/93410/000009341026000167/cvx-20260630.htm).
- [Chevron ESIP: 11-K, Note 1](https://www.sec.gov/Archives/edgar/data/93410/000009341026000158/cvx-20260624.htm) y [Hess savings plan: 11-K, Note 1](https://www.sec.gov/Archives/edgar/data/93410/000009341026000160/hes-20260624.htm).

La auditoría vuelve a construir ambos inventarios desde las respuestas SEC conservadas y verifica los cuerpos originales y los bloques de documentos. Preserva 2873 archivos previos por hash, el HEAD, el corpus de 8.137 comparaciones y el snapshot público. Dos repeticiones sin red producen el mismo resultado. Se descargaron únicamente dos 11-K adicionales para esta revisión; no se actualizaron posiciones 13F.

Detalle de los formularios relevantes revisados; la clasificación se refiere a su efecto sobre las unidades de los dos valores del piloto:

| Emisor | Fecha | Formulario / accession | Alcance revisado |
|---|---|---|---|
| TSMC | 2026-03-02 | 6-K / 0001046179-26-000027 | Cash dividend per-share adjustment from reclaimed RSAs; April 9 cash payment, no ADS unit allocation. |
| TSMC | 2026-03-10 | 6-K / 0001046179-26-000031 | February revenue, subsidiary loans/guarantees and FX derivatives; no common/ADS transformation. |
| TSMC | 2026-03-17 | 6-K / 0001046179-26-000076 | ADS-holder AGM proposal window March 31–April 7 under existing deposit agreement; no change to ratio. |
| TSMC | 2026-03-25 | 6-K / 0001046179-26-000126 | February month-end capital/insider report; cancellation none; asset investments and nonconvertible bonds. |
| TSMC | 2026-04-10 | 6-K / 0001046179-26-000136 | March revenue and subsidiary financing/FX disclosure; no holder-unit event. |
| TSMC | 2026-04-16 | 6-K / 0001046179-26-000199 | Q1 earnings and EX-99.1/99.2; cash dividend recap, EPS denominators and existing ADR reporting. |
| TSMC | 2026-04-16 | 6-K / 0001046179-26-000201 | Taiwan-IFRS versus IASB-IFRS differences relate to retained-earnings tax timing for 2025. |
| TSMC | 2026-04-16 | 20-F / 0001628280-26-025362 | 20-F registered ADS/CUSIP and common class; EX-2.1 depositary ratio/distributions/amendments; equity and linked charter/award/debt terms. |
| TSMC | 2026-04-17 | 6-K / 0001046179-26-000203 | April 17 added AGM articles agenda; operative amendment now resolved by retained June 4 minutes. |
| TSMC | 2026-04-24 | 6-K / 0001046179-26-000205 | March month-end insider, asset, bonds and capital report; no general share transformation. |
| TSMC | 2026-05-08 | 6-K / 0001046179-26-000213 | April revenue and subsidiary financing/FX report; no holder-unit event. |
| TSMC | 2026-05-08 | 6-K / 0001046179-26-000215 | Sony preliminary agreement for image-sensor JV; target operations, not TSM ADS restructuring. |
| TSMC | 2026-05-12 | 6-K / 0001046179-26-000274 | May board Q1 results; NT$7 cash dividend September record/October payment; capital appropriations. |
| TSMC | 2026-05-12 | 6-K / 0001046179-26-000275 | May 12 board approval cancels reclaimed employee RSAs; scope limited to award shares, not ADS holders. |
| TSMC | 2026-05-15 | 6-K / 0001046179-26-000278 | Q1 interim accounts, Note 21 common/ADS equity and Note 26 RSA terms; ADS ratio corroboration. |
| TSMC | 2026-05-15 | 6-K / 0001046179-26-000280 | Sale of 152 million VIS investee shares (8.1%); does not exchange existing TSM shares. |
| TSMC | 2026-05-26 | 6-K / 0001046179-26-000292 | April month-end insider/assets/capital/bonds/cancellation report; no all-holder quantity transformation. |
| TSMC | 2026-05-27 | 6-K / 0001046179-26-000294 | Cash dividend per-share adjustment due to reclaimed RSAs; July 9 cash payment, no new ADS allocation. |
| TSMC | 2026-06-04 | 6-K / 0001046179-26-000302 | SEC confirms June 4 AGM and approved articles amendment; exact operative scope supplied by issuer minutes. |
| TSMC | 2026-06-10 | 6-K / 0001046179-26-000367 | June 10 report covers May revenue, loans, guarantees and FX; no Q2 holder-unit transformation. |
| TSMC | 2026-06-25 | 6-K / 0001046179-26-000377 | June 25 report covers May: 154,454 reclaimed employee RSAs cancelled effective May 12; not pro-rata common/ADS event. |
| TSMC | 2026-07-02 | 6-K / 0001046179-26-000381 | July 1 Arizona subsidiary treasurer change, not a change in the security or depositary. |
| TSMC | 2026-07-13 | 6-K / 0001046179-26-000447 | July 13 report covers June revenue, loans, guarantees and FX; no Q2 holder-unit transformation. |
| TSMC | 2026-07-16 | 6-K / 0001046179-26-000451 | July 16 Q2 earnings and presentation; EPS/ADR units, cash dividend and VIS/JV recap, no Q2 ADS change. |
| TSMC | 2026-07-24 | 6-K / 0001046179-26-000459 | July 24 report covers June: no common-share cancellation; insider transfers and fixed-income investment only. |
| TSMC | 2026-08-10 | 6-K / 0001046179-26-000471 | August 10 July operating report; no retrospective Q2 security transformation. |
| TSMC | 2026-08-11 | 6-K / 0001046179-26-000536 | August 11 approves Q2 accounts and cash dividend December record/January 2027 payment; optional USD cash currency is not an ADS ratio change. |
| TSMC | 2026-08-11 | 6-K / 0001046179-26-000539 | August 11 Sony definitive JV: Sony asset company split and TSMC cash contribution; future third-party vehicle, not existing TSM ADSs. |
| TSMC | 2026-08-14 | 6-K / 0001046179-26-000541 | August 14 Q2 reviewed interim accounts: Note 21 ADS/common units, dividend policy, RSA cancellation, Note 26 awards and subsequent events. |
| Chevron | 2026-03-25 | 8-K / 0000093410-26-000103 | March 25 bylaws update about nonemployee director compensation/board governance; stock-transfer and record-date powers remain conditional. |
| Chevron | 2026-04-07 | DEF 14A / 0001193125-26-145617 | Annual proxy: six meeting matters, director/employee RSU and PSU dividend equivalents, vesting, benefit/deferred compensation and historical Hess context. |
| Chevron | 2026-04-07 | DEFA14A / 0001193125-26-145625 | Annual meeting voting notice and administrative materials; no operative security terms. |
| Chevron | 2026-04-07 | DEFA14A / 0001193125-26-145629 | Electronic voting materials, sample control number and CUSIP trademark; no CUSIP change. |
| Chevron | 2026-04-07 | DEFA14A / 0001193125-26-145641 | Employee proxy-voting instructions for common/plan shares; no share-denomination event. |
| Chevron | 2026-04-09 | 8-K / 0000093410-26-000108 | April 9 preliminary Q1: repurchases offset by employee option exercises; operational guidance, not a split. |
| Chevron | 2026-05-01 | 8-K / 0000093410-26-000110 | May 1 earnings EX-99.1; $1.78 cash dividend payable June 10, record May 19. |
| Chevron | 2026-05-07 | 10-Q / 0000093410-26-000113 | March 31 10-Q: common capital, equity quantity reconciliation, award/treasury cash flows and historical Hess Note 18. |
| Chevron | 2026-05-29 | 8-K / 0000093410-26-000123 | Pate future resignation December 31 and 2027 retirement; employment change only. |
| Chevron | 2026-05-29 | 8-K / 0000093410-26-000125 | May 27 final annual votes: directors, auditor, pay and three shareholder proposals; no approved quantity or class amendment. |
| Chevron | 2026-06-24 | 11-K / 0000093410-26-000158 | Chevron ESIP 2025 accounts filed June 24: participant choice of taxable cash dividends or reinvestment; savings-plan contribution/distribution rules. Note 8 evaluates subsequent events through June 24. No pro-rata event for common holders. |
| Chevron | 2026-06-24 | 11-K / 0000093410-26-000160 | Hess savings-plan 2025 accounts filed June 24: Hess-share conversion July 18, 2025 and savings-plan merger December 31, 2025; both historical, neither transforms existing CVX common in Q2 2026. |
| Chevron | 2026-07-31 | 8-K / 0000093410-26-000162 | July 31 earnings EX-99.1; Q2 results/repurchases and next cash dividend September 10, outside Q2. |
| Chevron | 2026-08-06 | 10-Q / 0000093410-26-000167 | June 30 10-Q: full Q2/H1 equity, quantity and trust footnotes, treasury repurchases/reissuances, Note 18 historic acquisition, compensation/benefit scope. |

El inventario completo también contabiliza formularios de insiders y titulares, informes de minerales de conflicto, reportes de posiciones/votos y material anual fuera de la selección de formularios corporativos. Los dos 11-K se incorporaron por su relevancia al alcance de planes; no alteran la selección del piloto.

Reproducción local: `python3 -B scripts/movement_pilot_wave1d/closure.py`; auditoría: `python3 -B scripts/movement_pilot_wave1d/audit.py`. Las atestaciones manuales no se vuelven a generar durante la repetición. Todos los artefactos de Wave 1D están en este directorio y el código está en `scripts/movement_pilot_wave1d` del worktree aislado. No se ha realizado commit, push ni deploy.

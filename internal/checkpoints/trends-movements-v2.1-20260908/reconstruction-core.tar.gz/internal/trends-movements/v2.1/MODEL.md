# Movement qualification v2.1 — internal only

This module consumes the frozen corpus; it never replaces the public snapshot, imports into application code, or changes publication readiness. Python's standard library provides independent XML reconstruction and exact rational arithmetic. It has no network fetch path and no model/LLM decision in the resolver. Primary evidence is the already retained SEC archive. The two existing reviewed movements are excluded from the 8,137-case corpus.

## Reproduction

Run from the repository root with Python 3.9 or later:

```sh
python3 scripts/movement_qualification/freeze.py --check
python3 scripts/movement_qualification/census.py
python3 scripts/movement_qualification/build_registries.py
python3 scripts/movement_qualification/select_pilot.py
python3 -m unittest discover -s scripts/movement_qualification -p 'test_*.py'
python3 scripts/movement_qualification/run.py pilot
python3 scripts/movement_qualification/run.py expand
python3 scripts/report-movement-qualification.py
```

`freeze.py` without `--check` writes only when no frozen corpus exists; otherwise it checks equivalence. `select_pilot.py` also refuses drift. The corpus hash covers canonical UTF-8 JSONL before gzip, sorted by `comparison_id`. Gzip has mtime zero; the uncompressed hash is the portable identity. A null quantity is unknown, not zero. Multiple accessions are retained as arrays; the singular accession is null when ambiguous.

`pilot-manual-review.json` is a separately recorded primary-source review of the 55 cases. It is not generated from resolver outputs. A new dossier requires a new explicit review. Expansion validates the pilot against hashes of the corpus, all registries, source archives and Python qualification code/tests. Failed tests, any false positive, any mismatch or stale evidence/code stops expansion. The pilot was reviewed by Codex case by case, not by an independent external human reviewer. Its five positive cases belong to one security; it does not estimate global precision. Positive NEW/EXIT and transformed-security paths currently have synthetic tests only.

## Tiers and the four-way partition

| Tier | Required evidence | Permitted result |
|---|---|---|
| TIER_A_AUTO_SAFE | Same manager perimeter; usable authoritative, complete, explicitly non-confidential quarters; resolved amendment composition; issue/instrument/class continuity; complete interval-specific corporate-action clearance | Exact quantity comparison: INCREASED, REDUCED, UNCHANGED |
| TIER_B_PRESENCE_TRANSITION | All applicable Tier A filing/perimeter controls plus an explicit absence certificate excluding all twelve presence risks, full security search and no transformation | NEW or EXITED |
| TIER_C_ACTION_NORMALIZED | Verified one-to-one issue relationship and one exactly documented split, reverse split or class/CUSIP conversion; rational factor; no fractional entitlement/cash-in-lieu ambiguity | Exact comparison after normalization |
| UNQUALIFIED | Any missing, contradictory, stale or unsupported prerequisite | INDETERMINATE |

`AUTO_RESOLVABLE` identifies resolved Tier A cases; `AUTO_RESOLVED` is their count. `EVIDENCE_RESOLVABLE` identifies still-indeterminate cases needing scoped security/action/presence evidence. `HUMAN_REVIEW_REQUIRED` covers confidentiality, unproven manager scope, class and evidence ambiguities. `STRUCTURALLY_BLOCKED` takes priority for changed perimeters, unusable or ambiguous filings, notices, duplicate groups and unsupported options/principal. A future resolved Tier B/C case is counted as `EVIDENCE_RESOLVED`, not as a pending evidence case. Structural > human > evidence is a workflow priority, not a claim that the other blockers disappear.

Confidence is `PROVEN` or `INSUFFICIENT`, not a probability. PROVEN means the supplied primary-evidence claims satisfy the explicit gates. A retained hash authenticates bytes and binds an attestation to the exact holdings, periods and filings; it does not prove the economic truth of an analyst's attestation. Reviewing and trusting those attestations remains a separate responsibility.

## Manager perimeter

`manager-perimeter-registry.json` includes all 46 universe entries, including 44 expected filers and two notices. Each record names the economic group, Q1/Q2 CIK, included and reporting manager identifiers, report type, accessions, YES/NO/INDETERMINATE, reason and primary source references. CIK and 13F file numbers identify included managers; a name without either is unproven. Identical combination reports remain unproven rather than automatically equivalent. Pershing remains NO. BAMCO remains YES after trimming XML whitespace from an included-manager CIK; that formatting difference is not an economic perimeter change. This is a conservative reported-perimeter model; it does not assert that matching names prove an unchanged economic mandate.

## Amendments

The vocabulary is NONE, RESTATEMENT, ADDITIVE_CONFIRMED, NON_HOLDINGS_AMENDMENT and AMBIGUOUS. NONE selects one original; RESTATEMENT substitutes the latest restatement and never sums it with its original. ADDITIVE_CONFIRMED requires an explicit primary-evidence composition attestation and a unique selected accession set. A NEW HOLDINGS label alone never creates that attestation. NON_HOLDINGS_AMENDMENT is recognized as a potential review disposition but cannot feed this phase's resolver. The current corpus contains NONE, RESTATEMENT and AMBIGUOUS; no ADDITIVE_CONFIRMED or NON_HOLDINGS_AMENDMENT was invented to improve coverage. First Eagle Q2 remains AMBIGUOUS, selected holdings withheld, for all 425 comparisons.

## Corporate actions and continuity

`corporate-action-registry.json` normalizes issuer, security/CUSIP, effective date, action type, rational numerator/denominator, predecessor/successor, SEC accession/URL, verification status, retained hash and existing-unit effect. Types are SPLIT, REVERSE_SPLIT, MERGER, SPINOFF, CONVERSION, CUSIP_CHANGE, SHARE_CLASS_CHANGE, TICKER_CHANGE, REORGANIZATION and OTHER. Event coverage is separate: an empty registry is never evidence of no action.

The only populated clearance is Alphabet Class C (02079K107, long SH), Q1→Q2 2026. It adopts the class-specific corporate-action scope already documented in the two retained reviews, with issuer Note 11 and June issuance terms inspected again. It does not inherit those managers' quantity or perimeter approvals. Two June issuance events are recorded once and reused for every affected candidate. New common issuance and separate preferred instruments do not multiply existing Class C units. This clearance cannot be applied to Class A, another issuer, another interval, or an absent row.

`security-identity-graph.json` supports SAME_SECURITY, SUCCESSOR_OF, PREDECESSOR_OF, CLASS_CONVERSION, ISSUER_SAME_SECURITY_DIFFERENT_TICKER and UNKNOWN_RELATION. Identical issue keys/class metadata can support issue continuity, but cannot waive the separate action check. Name matches produce UNKNOWN_RELATION research hints only; even identical issuer IDs never union securities for movement arithmetic. Current graph edges do not assert any unverified conversion.

Merger, spinoff, reorganization, multiple transforming events or fractional/cash-in-lieu entitlement remain blocked. Ticker-only verified changes preserve the security unit. Positive transformation support is bounded to synthetic fixtures until a separate real primary-evidence pilot covers those event types.

## Presence transitions

An absent row does not certify absence of an economic position. Tier B requires explicit CLEAR evidence for CUSIP change, share-class change, merger, spinoff, conversion, ticker change, issuer rename, amendment, confidentiality, filing completeness, reporting perimeter and permitted omission. The proof is bound to a manager, quarters, accession set and exact remaining holding. No Tier B certificates were created in this run.

## Review tasks and bias

`review-tasks.json` groups repeated requirements by manager/group blocker or issuer/security/interval. A task can cover many comparisons and a comparison can depend on several tasks. Task-count reduction is not a measured reduction in analyst hours. Shared issuer research never clears manager-specific confidentiality or absence checks automatically.

`readiness-and-bias.json` reports any-resolved and fully-resolved coverage separately, manager and large-portfolio strata, original presence strata, corporate-action candidates and primary SEC SIC categories. Unknown sectors remain unknown. Materiality screens the union of the top ten holdings or >=1% of reported 13F value in either usable quarter; this is not AUM. Unavailable-quarter materiality is recorded separately.

Resolution is not random: all nine results concern one Class C issue, all NEW/EXIT candidates remain unresolved, and large portfolios have lower resolution rates. Bias is FAIL. Internal qualification success is independent of publication readiness, which remains NOT_READY.

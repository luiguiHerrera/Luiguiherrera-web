# Wave 1B: identidad oficial y cobertura de eventos

Trabajo interno sobre el commit `3efd28f11080de3c44ff4cd636503fd98cd2cdbe`, sin modificar el corpus ni el snapshot público. Reutiliza el piloto prospectivo de 501 comparaciones / 66 títulos y conserva los umbrales anteriores: al menos 500 comparaciones calificadas, 10 gestores, 20 títulos y 5 grupos SIC conocidos, sin falsos positivos ni familias calificadas sin revisión. Diez resoluciones concentradas en un título no satisfacen ese requisito.

## Autoridad de identidad

Los TXT SEC Q1 y Q2 se conservan byte por byte. El parser exige 80 caracteres ASCII por registro, posiciones oficiales, indicador `*`/espacio y estados `*A*`/`*D*`/vacío. Guarda líneas, terminadores, offsets, números de línea, trimestre, URL, hora y SHA-256. Los duplicados idénticos conservan todas sus procedencias; registros contradictorios nunca se eligen silenciosamente. La clave del master es CUSIP de nueve caracteres más indicador de opciones.

El asterisco significa que existen opciones cotizadas sobre ese título, según la hoja de instrucciones SEC Q2, página 2. No significa que la posición sea una opción. La FAQ 44 exige reportar el CUSIP del subyacente para PUT/CALL. La posición conserva su clave CUSIP + PUT/CALL/LONG + SH/PRN: nunca se mezcla con otra posición. Un enlace de opción acredita únicamente el subyacente; no acredita sus términos contractuales ni comparabilidad.

El enlace se hace por CUSIP exacto y candidato único, nunca por similitud de emisor. Los nombres y clases oficiales se preservan. Diferencias explícitas de letra de clase, conflicto de instrumento, cambio de descripción oficial o duplicados contradictorios impiden una identidad de periodo cerrada. Variantes textuales de etiquetas 13F se registran sin afirmar equivalencia entre ellas. La continuidad de comparaciones conserva además los controles de clase de v2.1.

`EXACT_Q1`/`EXACT_Q2` son estados por trimestre; `EXACT_BOTH`, `Q1_ONLY`, `Q2_ONLY`, `AMBIGUOUS`, `OPTION_MISMATCH` y `CLASS_CONFLICT` son estados del par. Si falta en ambos, el estado principal es `NOT_FOUND_Q1` y los detalles conservan también `NOT_FOUND_Q2`. Un registro marcado D está presente como registro oficial y conserva D: no se interpreta como ausencia de holdings ni como venta.

La métrica principal usa los mismos 2.543 títulos sin emisor de Wave 1. Solo cierra un caso si hay enlace exacto ambos trimestres, clase oficial compatible y el mismo nombre oficial. Las identidades de un solo trimestre, nombres cambiados y conflictos quedan fuera del numerador. Es identidad en la lista SEC, no identificación jurídica por CIK ni autorización de movimiento.

## Expedientes y CIK

El corpus completo contiene 3.055 claves de posición. Los expedientes de investigación se construyen sobre los 2.555 títulos de las 5.314 comparaciones EVIDENCE_RESOLVABLE. Agrupan etiquetas oficiales exactamente iguales conservando cada CUSIP, clase, estado trimestral, comparación, gestor y fila original. El expediente no afirma consolidación de entidades jurídicas. Casos con cambio de nombre o identidad incompleta permanecen separados por título.

El directorio oficial SEC de nombres/CIK genera candidatos con normalización exclusivamente ortográfica: mayúsculas, espacios, puntos y comas. No expande abreviaturas, reordena palabras ni utiliza tickers. Más de un CIK candidato implica MULTIPLE_CANDIDATES. Para EXACT_VERIFIED se exige además nombre igual en submissions y filings de emisor del periodo; se rechaza un CIK histórico sin reporting actual. Se conserva separadamente la autoridad de los enlaces CUSIP/clase/CIK previamente revisados. No se extiende un enlace histórico a títulos hermanos. Los candidatos del piloto se comprueban primero; candidatos fuera del piloto pendientes de confirmación siguen INDETERMINATE. NO_MATCH significa que este procedimiento no halló coincidencia exacta, no que no exista un CIK.

## Inventario, detector y eventos

Ventana económica: 1 de abril a 30 de junio de 2026. Ventana de disclosures: 1 de marzo a 14 de agosto de 2026. Los términos incorporados por referencia pueden ser anteriores: la fecha de recuperación o publicación nunca sustituye a la fecha efectiva.

Primero se inventarían formularios y particiones del índice SEC por sus fechas, incluyendo S-4/S-4/A/424B3/425 y las familias de registro, proxy, reorganización y ofertas, además de reporting periódico y 8-K/6-K. La ausencia de una partición requerida impide declarar el índice completo. Inventario completo no implica documentos completos ni revisión completa.

El plan fijo recupera 527 submissions completos de los emisores verificados del piloto, salvo Bank of America: su inventario de 4.677 accesiones exige una revisión por título de emisiones y prospectos, y permanece UNKNOWN. No se usa el volumen para emitir un certificado favorable. Cada submission conserva todos los documentos y anexos, y se comprueba la accesión del encabezado y la integridad de los bloques DOCUMENT. Se registran enlaces y archivos binarios. Los datos XBRL generados no se sustituyen por la narrativa primaria: el HTML inline XBRL sí se busca. Un anexo legal PDF/imagen sin revisión sigue pendiente. Los gráficos decorativos de portada pueden excluirse con una razón y localización explícitas; no constituyen evidencia económica.

Cada coincidencia del detector es una ocurrencia candidata, no un evento distinto. Se preservan accession, archivo, offset y contexto. Incluye las expresiones solicitadas y variantes como reverse split, split, stock/share dividend y reorganización. Cero coincidencias no constituye prueba negativa. Los eventos usados requieren verificación primaria de emisor, título/clase anterior y posterior, fecha efectiva y términos. Eventos Visa de clases B/C no se aplican al CUSIP de clase A.

## Certificado operativo

`VERIFIED_CLEAR_FOR_COMPARABILITY` exige simultáneamente:

1. Bindings Q1/Q2 exactos y con hashes válidos; mismo CUSIP/indicador, nombre y clase oficial; sin anomalías A/D pendientes.
2. CIK verificado con fuentes SEC ligadas al catálogo de hashes y posición LONG/SH.
3. Inventario completo de la ventana, todas las familias mínimas y documentos completos de todas las accesiones relevantes, con hashes verificados.
4. Detector ejecutado sobre la versión exacta del inventario y sus textos/anexos; términos previos incorporados pertinentes revisados.
5. Revisión primaria explícita de términos de clase inicial/final, estado de patrimonio, eventos que cambian unidades y anexos pertinentes. Se revisan todos los contextos candidatos, además de estas secciones: no se certifica por ausencia de palabras.
6. Cada candidato tiene una decisión justificada y, cuando corresponde, referencia a un evento verificado. Ningún conflicto, transformación o anexo pertinente queda sin resolver.
7. La revisión está ligada al título, a la versión exacta de la evidencia y a un reloj de evidencia fijo. Cambios de código/evidencia invalidan el gate del piloto.

Este es un procedimiento de cobertura de comparabilidad, no una prueba absoluta de inexistencia de cualquier acontecimiento. El mismo CUSIP no descarta un split. Los certificados son por título/periodo y no sustituyen la validación del filing, confidencialidad, perímetro, enmiendas o presencia de cada gestor.

Split/reverse split requieren razón racional explícita en fuente primaria, fecha y clase exactas, términos de fracciones verificados y cantidades resultantes exactas. No se infiere un factor de holdings, del valor de mercado, de cifras redondeadas de un emisor ni de una razón correspondiente a otra clase. Se conservan cantidad anterior cruda, factor, anterior normalizada y actual. Transformaciones no soportadas y ajustes múltiples se abstienen.

La salida es REPORTED_INCREASED / REPORTED_REDUCED / REPORTED_UNCHANGED. No afirma BOUGHT/SOLD. NEW/EXIT, casos estructurales y revisión humana mantienen sus controles previos. El piloto puede producir resultados internos revisables; solo un PASS permite aplicarlos a las 5.314 comparaciones. Si no hay PASS, los totales globales conservan las nueve calificaciones anteriores. No hay cambios públicos, commit, push ni deploy.

## Fuentes y reproducción

- SEC lista y especificación: https://www.sec.gov/rules-regulations/staff-guidance/official-list-section-13f-securities
- Q1 TXT: https://www.sec.gov/files/investment/13flist2026q1.txt
- Q2 TXT: https://www.sec.gov/files/investment/13flist2026q2-txt.txt
- Instrucciones Q2: https://www.sec.gov/files/investment/13flist2026q2.pdf
- FAQ 44: https://www.sec.gov/rules-regulations/staff-guidance/division-investment-management-frequently-asked-questions/frequently-asked-questions-about-form-13f
- Nombres/CIK: https://www.sec.gov/Archives/edgar/cik-lookup-data.txt

Los TXT trimestrales mantienen sus bytes directamente. Los submissions y el directorio se comprimen sin pérdidas para almacenamiento; source-manifest.json registra la codificación y el SHA-256 de los bytes originales. Cada lectura descomprime y valida ese hash. No se redistribuyen en la web ni se incorporan al runtime público.

Comandos desde el worktree, sin red para reproducir: `python3 -B scripts/movement_security_wave1b/identity.py pilot`, `identity.py full`, `issuers.py packets`, `inventory.py`, `detection.py`, `pilot.py`, `report.py`. Las revisiones manuales son entradas preservadas, no se generan automáticamente a partir de palabras clave. La comprobación de replay compara bytes de los resultados derivados. La identidad se aplicó al corpus solamente después de revisar 16 títulos estratificados del piloto original, ambas listas y las filas 13F correspondientes, con cero falsos positivos observados; esto no es un límite estadístico de error poblacional ni firma humana independiente.

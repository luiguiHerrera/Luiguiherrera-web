# Fixed pilot model

The scope remains the original 66 securities, 501 BOTH_PRESENT comparisons and 19 managers. Its selection fingerprint is `93c6596bf8fcc5c9c26b0dcbb56c47a8743c62336d095f479ffb6f80fa647145`. The 8,137-row movement corpus remains immutable. The comparison engine refuses IDs outside the selected set. No global resolution or publication state is rewritten.

Issuer identity combines SEC quarterly official-list CUSIP/class, current SEC legal entity evidence and registered class on primary reports. Candidate CIKs and tickers cannot verify identity. The three FPIs use their 6-K/20-F regime; unsupported/fund classifications do not become domestic coverage. SIC comes from SEC submissions and is reported as the SEC two-digit SIC family, not a guessed sector.

Owned inventory traverses the SEC current submissions plus every historical file whose declared dates intersect March 1–August 14. None of the final verified issuers requires an overlapping historical file for this window; traversal is covered by adversarial tests. Holder filings and a 425 explicitly naming a different filing person are kept separate. The current index supplies observed applicable forms; a form that was never filed is not fabricated as missing.

Complete inherited submissions and targeted new primary bodies/exhibits preserve source URLs and exact hashes. A document hash identifies either raw fetched bytes or an explicitly defined SGML DOCUMENT block. The parser excludes hidden Inline XBRL resources from narratives. The final audit rehashes every document against its retained source and checks Berkshire's primary narrative against the raw document.

Keyword groups organize review by issuer, accession, family, mentioned class and candidate period. Mentioned years do not establish an effective date. Groups may still over-separate one economic event; their count is operational compression, not an economic-event census. Manual class/equity/current-report/linked-term conclusions go beyond keyword matches. Absence of hits cannot clear coverage.

Positive other-product scope is a distinct use of the 691 bounded pricing covers. Their exact bytes, rendered text, positive product classification and excerpts are checked and included in the bank inventory fingerprint. They cannot become event or negative-coverage authority. Every owned accession must have a retained primary document or bound positive other-class proof. A change in source, inventory, candidate group, class, supplemental document or product-scope record invalidates the attestation.

The class coverage certificate requires both official quarter bindings, verified CIK, known regime, complete inventory, inspected applicable forms/links, explicit class/narrative review, and no unresolved list, event, conflict or amendment issue. Per-manager provenance, amendment, reporting continuity and perimeter dependencies remain mandatory in the existing engine. NEW/EXIT retain their separate strict transition gate.

Only primary evidence with event type, affected class, effective date and terms can be a VERIFIED_EVENT. FedEx has a verified unsupported spin-off and remains blocked. Berkshire A has positive cumulative observations of elected conversions: 14,223 minus 9,851 = 4,372 during Q2. That establishes a nonuniform class transformation, not an exact effective day or a factor for every holder. Class B is reviewed independently. Chevron and TSMC remain UNKNOWN for the precise retained-evidence gaps in `remaining-pilot-packets.json`.

Exact reported quantities are reconstructed from each manager's SEC information tables. Applicable split factors use integer numerators/denominators and exact Fraction arithmetic, reject invalid/nonintegral transformations and enforce the economic window April 1–June 30. No split factor is newly applied here. A reported quantity change never proves a purchase, sale or economic transaction.

The manual attestation command is intentionally excluded from automatic replay. One primary comparison per new security evidence family and every evidence node unlocking at least ten comparisons must be reviewed. The reviewer is the Codex primary agent, not an independent human signatory. Zero observed errors among selected manual checks does not establish a statistical zero-error rate.

From the isolated worktree, offline evaluation is:

```sh
python3 -B scripts/movement_pilot_wave1c/pilot_engine.py
python3 -B scripts/movement_pilot_wave1c/final_audit.py
python3 -B -m unittest discover -s scripts/movement_pilot_wave1c -p 'test_*.py'
```

The recorded offline replay disables `urllib.request.urlopen` and compares hashes of all four engine output files. `review_records.py --attest-reviewed-current-scopes` must only be run after the changed primary scopes have actually been reviewed. The Swift helper documents the OCR method used for the Diageo PDF; OCR is an aid and the raw PDF remains the source authority.

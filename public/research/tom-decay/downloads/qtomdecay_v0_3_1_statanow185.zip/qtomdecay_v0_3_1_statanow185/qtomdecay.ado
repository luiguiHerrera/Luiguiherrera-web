*! qtomdecay 0.3.1 18aug2026
program define qtomdecay, rclass
    version 18.5

    syntax anything(name=symbol id="symbol") [, ///
        SOURCE(string) ///
        FROM(string) ///
        TO(string) ///
        HACLAGS(integer -1) ///
        ROLLINGYEARS(integer 10) ///
        BREAKMINYEARS(integer 10) ///
        SAVE(string) ///
        DATA(string) ///
        REPLACE ]

    if "`source'" == "" {
        local source "yahoo"
    }
    if "`from'" == "" {
        if lower("`source'") == "french" {
            local from "1926-07-01"
        }
        else {
            local from "1950-01-01"
        }
    }
    if "`save'" == "" {
        local save "qtomdecay_`symbol'"
    }

    local source = lower("`source'")

    if !inlist("`source'", "yahoo", "french", "file") {
        di as error "source() must be yahoo, french, or file"
        exit 198
    }
    if "`source'" == "file" & "`data'" == "" {
        di as error "source(file) requires data(path)"
        exit 198
    }
    if `haclags' < -1 {
        di as error "haclags() must be -1 or >= 0"
        exit 198
    }
    if `rollingyears' < 5 {
        di as error "rollingyears() must be >= 5"
        exit 198
    }
    if `breakminyears' < 5 {
        di as error "breakminyears() must be >= 5"
        exit 198
    }

    quietly findfile qtomdecay_core.py
    local pyfile "`r(fn)'"

    di as txt "TOM Anomaly Decay Map v0.3.1"
    di as txt "  symbol:          " as res "`symbol'"
    di as txt "  source:          " as res "`source'"
    di as txt "  from:            " as res "`from'"
    di as txt "  rolling years:   " as res "`rollingyears'"
    di as txt "  break min years: " as res "`breakminyears'"
    di as txt "  output:          " as res "`save'"

    python script "`pyfile'", args( ///
        "`symbol'" ///
        "`source'" ///
        "`from'" ///
        "`to'" ///
        "`haclags'" ///
        "`rollingyears'" ///
        "`breakminyears'" ///
        "`save'" ///
        "`data'" ///
    )

    return local symbol "`symbol'"
    return local source "`source'"
    return local bundle "`save'"

    di as result "qtomdecay completed"
end

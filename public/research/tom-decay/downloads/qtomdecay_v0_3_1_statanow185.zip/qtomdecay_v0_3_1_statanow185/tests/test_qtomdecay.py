import unittest, tempfile, sys
from pathlib import Path
import numpy as np, pandas as pd
HERE=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(HERE))
from qtomdecay_core import *
from qtomdecay_core import _normalize

def synth(start="1980-01-01",periods=12000,seed=1):
    d=pd.bdate_range(start,periods=periods)
    r=np.random.default_rng(seed).normal(0,.008,len(d))
    c=100*np.cumprod(1+r)
    return pd.DataFrame({"date":d,"close":c,"adj_close":c})

class Tests(unittest.TestCase):
    def test_event_time_zero_is_last_trading_day(self):
        df=_normalize(synth("2010-01-01",1500))
        ev=build_event_map(df)
        one=ev[ev.event_month==ev.event_month.iloc[0]]
        trow=one[one.relative_day==0].iloc[0]
        self.assertEqual(pd.Timestamp(trow.date),pd.Timestamp(trow.event_month_end))
        self.assertEqual(sorted(ev.relative_day.unique()),list(range(-10,11)))

    def test_canonical_days_are_0_to_3(self):
        df=_normalize(synth("2010-01-01",1500))
        ev=build_event_map(df)
        self.assertEqual(set(ev.loc[ev.tom_day==1,"relative_day"]),{0,1,2,3})

    def test_daily_baseline_contains_all_days(self):
        df=_normalize(synth("2010-01-01",1500))
        ev=build_event_map(df)
        daily=build_daily_labels(df,ev)
        self.assertEqual(len(daily),len(df))
        self.assertGreater((daily.tom_day==0).sum(),(daily.tom_day==1).sum())

    def test_exact_pressure_windows(self):
        df=_normalize(synth("2010-01-01",1500))
        ev=build_event_map(df)
        months=event_months(ev)
        self.assertIn("selling_pressure_t8_t4",months.columns)
        self.assertIn("positive_reversal_t3_t1",months.columns)
        self.assertIn("buying_pressure_t_p3",months.columns)

    def test_adjacent_decay_detection(self):
        # Construct full daily data with strong TOM in group A and none in B.
        rng=np.random.default_rng(2); n=2000
        daily=pd.DataFrame({
            "date":pd.bdate_range("1990-01-01",periods=n),
            "return":rng.normal(0,.005,n),
            "tom_day":0,
            "regime":["A"]*(n//2)+["B"]*(n-n//2)
        })
        daily.loc[daily.index%5==0,"tom_day"]=1
        daily.loc[(daily.regime=="A")&(daily.tom_day==1),"return"]+=.002
        out=adjacent_regime_tests(daily,"regime",["A","B"],5)
        self.assertLess(float(out.iloc[0].change_b_minus_a),0)

    def test_e2e(self):
        with tempfile.TemporaryDirectory() as td:
            r=run(Config(symbol="S",source="file",start="1980-01-01",output=str(Path(td)/"o")),market_data=synth())
            for n in [
                "publication_regime_summary.csv","settlement_regime_summary.csv",
                "publication_adjacent_tests.csv","settlement_adjacent_tests.csv",
                "relative_day_map.csv","event_months.csv","break_tests.csv",
                "pressure_reversal_by_settlement.csv","settlement_timing_summary.csv",
                "calendar_concentration.csv","research_report.json","manifest.json"
            ]:
                self.assertTrue((r["output"]/n).exists())

if __name__=="__main__": unittest.main()

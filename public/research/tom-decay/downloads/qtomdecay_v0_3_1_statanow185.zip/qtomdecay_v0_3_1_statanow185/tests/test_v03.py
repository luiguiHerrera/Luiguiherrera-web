
import unittest, tempfile, io, zipfile, sys
from pathlib import Path
import numpy as np, pandas as pd

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))

from qtomdecay_core import (
    Config, parse_french_daily_bytes, rolling_premium,
    pairwise_calendar_tests, exploratory_breakpoint,
    _normalize, build_event_map, build_daily_labels, event_months, run
)

def synth(start="1950-01-01",periods=20000,seed=42):
    d=pd.bdate_range(start,periods=periods)
    rng=np.random.default_rng(seed)
    r=rng.normal(.0002,.009,len(d))
    c=100*np.cumprod(1+r)
    return pd.DataFrame({"date":d,"close":c,"adj_close":c})

class V03Tests(unittest.TestCase):
    def test_parse_french_zip_and_market_return(self):
        txt="""This file was created using CRSP
,Mkt-RF,SMB,HML,RF
19260701,0.10,0.20,0.30,0.01
19260702,-0.20,0.10,0.00,0.01
Copyright
"""
        bio=io.BytesIO()
        with zipfile.ZipFile(bio,"w",zipfile.ZIP_DEFLATED) as z:
            z.writestr("F-F_Research_Data_Factors_daily.csv",txt)
        df,prov=parse_french_daily_bytes(bio.getvalue())
        self.assertAlmostEqual(df.iloc[0]["return"],.0011,places=12)
        self.assertAlmostEqual(df.iloc[1]["return"],-.0019,places=12)
        self.assertEqual(prov["provider"],"Kenneth French Data Library")
        self.assertEqual(len(prov["download_sha256"]),64)

    def test_rolling_has_ci(self):
        df=_normalize(synth(periods=12000))
        ev=build_event_map(df)
        daily=build_daily_labels(df,ev)
        out=rolling_premium(daily,10,5)
        self.assertGreater(len(out),10)
        self.assertTrue({"ci95_lo","ci95_hi","tom_premium_daily"}.issubset(out.columns))

    def test_calendar_pairwise_tests_exist(self):
        df=_normalize(synth(periods=8000))
        months=event_months(build_event_map(df))
        out=pairwise_calendar_tests(months,5)
        self.assertEqual(len(out),3)
        self.assertTrue((out["difference_hac_p"]>=0).all())

    def test_exploratory_break_is_labeled(self):
        df=_normalize(synth(periods=12000))
        daily=build_daily_labels(df,build_event_map(df))
        summary,grid=exploratory_breakpoint(daily,10,5)
        self.assertEqual(summary["status"],"EXPLORATORY_NOT_CONFIRMATORY")
        self.assertGreater(len(grid),5)
        self.assertIn("warning",summary)

    def test_end_to_end_outputs_new_tables(self):
        with tempfile.TemporaryDirectory() as td:
            r=run(
                Config(symbol="S",source="file",start="1950-01-01",
                       rolling_years=10,breakpoint_min_years=10,
                       output=str(Path(td)/"out")),
                market_data=synth()
            )
            for n in [
                "rolling_premium.csv",
                "calendar_pairwise_tests.csv",
                "exploratory_breakpoint_grid.csv",
                "research_report.json",
                "manifest.json",
            ]:
                self.assertTrue((r["output"]/n).exists())

if __name__=="__main__":
    unittest.main()

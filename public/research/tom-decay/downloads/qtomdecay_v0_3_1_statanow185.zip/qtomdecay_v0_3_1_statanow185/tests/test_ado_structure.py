
import unittest
from pathlib import Path

class AdoStructureTests(unittest.TestCase):
    def test_no_inline_control_braces(self):
        ado = (Path(__file__).resolve().parents[1] / "qtomdecay.ado").read_text()
        for line in ado.splitlines():
            stripped = line.strip()
            if stripped.startswith("if ") and "{" in stripped:
                self.assertTrue(stripped.endswith("{"),
                                f"Opening brace must end the line: {stripped}")
            if stripped == "}":
                self.assertEqual(stripped, "}")

    def test_program_has_matching_multiline_braces(self):
        ado = (Path(__file__).resolve().parents[1] / "qtomdecay.ado").read_text()
        opens = sum(1 for line in ado.splitlines() if line.strip().endswith("{"))
        closes = sum(1 for line in ado.splitlines() if line.strip() == "}")
        self.assertEqual(opens, closes)

if __name__ == "__main__":
    unittest.main()

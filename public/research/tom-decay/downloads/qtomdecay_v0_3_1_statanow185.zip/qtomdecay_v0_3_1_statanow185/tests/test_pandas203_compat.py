
import unittest
from pathlib import Path
import sys
import pandas as pd

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

from qtomdecay_core import rolling_premium

class Pandas203CompatibilityTests(unittest.TestCase):
    def test_core_does_not_use_ye_string_alias(self):
        core = (HERE / "qtomdecay_core.py").read_text()
        self.assertNotIn('freq="YE"', core)
        self.assertIn("pd.offsets.YearEnd()", core)

    def test_yearend_date_range_accepts_offset_object(self):
        idx = pd.date_range(
            start=pd.Timestamp("2000-12-31"),
            end=pd.Timestamp("2003-12-31"),
            freq=pd.offsets.YearEnd(),
        )
        self.assertEqual(len(idx), 4)
        self.assertEqual(idx[0], pd.Timestamp("2000-12-31"))
        self.assertEqual(idx[-1], pd.Timestamp("2003-12-31"))

if __name__ == "__main__":
    unittest.main()

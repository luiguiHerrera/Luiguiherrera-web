# qtomdecay v0.3

Final validation-oriented research module before narrative freeze.

Adds:
- independent Kenneth French Data Library replication (`source(french)`);
- reconstructed broad U.S. market return = `(Mkt-RF + RF)/100`;
- source provenance + download SHA-256 in the output report/manifest;
- fixed 10-year rolling TOM premium with HAC 95% confidence interval;
- direct calendar-group pairwise tests;
- exploratory structural-break search with a minimum sample on each side.

The automatic breakpoint is **exploratory**, and its p-value is explicitly
unadjusted for the date search. Externally fixed historical cutoffs remain
the main confirmatory/descriptive comparisons.

No TOM-window optimization is performed.

## v0.3.1 compatibility fix

The rolling-year endpoint generator now passes `pd.offsets.YearEnd()` directly
to `pandas.date_range()` instead of using the newer `YE` string alias.
This keeps the package compatible with the pinned pandas 2.0.3 environment
used by StataNow on the validation machine.

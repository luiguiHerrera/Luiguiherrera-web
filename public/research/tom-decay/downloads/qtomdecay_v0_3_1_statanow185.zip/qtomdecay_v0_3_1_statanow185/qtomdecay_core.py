from __future__ import annotations
import sys, json, math, hashlib, io, zipfile, urllib.request
from dataclasses import dataclass
from pathlib import Path
from statistics import NormalDist
from datetime import datetime, timezone
import numpy as np
import pandas as pd

VERSION="0.3.1"
ND=NormalDist()

PUBLICATION_CUTOFF=pd.Timestamp("1987-01-01")
T3_CUTOFF=pd.Timestamp("1995-06-07")
DECIMAL_CUTOFF=pd.Timestamp("2001-04-09")
T2_CUTOFF=pd.Timestamp("2017-09-05")
T1_CUTOFF=pd.Timestamp("2024-05-28")

PUBLICATION_ORDER=[
    "PRE_PUBLICATION",
    "PUBLISHED_PRE_DECIMAL",
    "POST_DECIMAL_PRE_T2",
    "T2",
    "T1",
]
SETTLEMENT_ORDER=["T5","T3","T2","T1"]

class QTOMDecayError(Exception): pass

@dataclass
class Config:
    symbol:str="^GSPC"
    source:str="yahoo"
    start:str="1950-01-01"
    end:str=""
    hac_lags:int=-1
    rolling_years:int=10
    breakpoint_min_years:int=10
    output:str="qtomdecay_output"
    data_file:str=""

def _sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()

def _normalize(df):
    out=df.copy()
    if isinstance(out.columns,pd.MultiIndex):
        out.columns=[c[0] if isinstance(c,tuple) else c for c in out.columns]
    ren={}
    for c in out.columns:
        k=str(c).strip().lower().replace(" ","_")
        if k in {"date","datetime"}: ren[c]="date"
        elif k=="close": ren[c]="close"
        elif k in {"adj_close","adjclose","adjusted_close"}: ren[c]="adj_close"
    out=out.rename(columns=ren)
    if "date" not in out.columns and (isinstance(out.index,pd.DatetimeIndex) or out.index.name is not None):
        out=out.reset_index()
        out=out.rename(columns={out.columns[0]:"date"})
    if "date" not in out.columns or "close" not in out.columns:
        raise QTOMDecayError("Data requires date and close columns")
    out["date"]=pd.to_datetime(out["date"],errors="coerce")
    try:
        if out["date"].dt.tz is not None: out["date"]=out["date"].dt.tz_localize(None)
    except Exception: pass
    out["close"]=pd.to_numeric(out["close"],errors="coerce")
    if "adj_close" not in out.columns: out["adj_close"]=out["close"]
    out["adj_close"]=pd.to_numeric(out["adj_close"],errors="coerce")
    out=out.dropna(subset=["date","close"]).sort_values("date").drop_duplicates("date",keep="last").reset_index(drop=True)
    out["return"]=out["adj_close"].pct_change()
    return out

def fetch_yahoo(cfg):
    import yfinance as yf
    df=yf.Ticker(cfg.symbol).history(
        start=cfg.start or None,end=cfg.end or None,interval="1d",
        auto_adjust=False,actions=True,repair=False
    )
    if df is None or len(df)==0: raise QTOMDecayError(f"No Yahoo data for {cfg.symbol}")
    return _normalize(df)


FRENCH_DAILY_URL="https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/F-F_Research_Data_Factors_daily_CSV.zip"

def parse_french_daily_bytes(raw_bytes):
    """
    Parse official Fama/French daily factor ZIP.
    Reconstruct total market return as (Mkt-RF + RF) / 100.
    """
    source_sha256=hashlib.sha256(raw_bytes).hexdigest()
    with zipfile.ZipFile(io.BytesIO(raw_bytes)) as z:
        names=[n for n in z.namelist() if n.lower().endswith(".csv")]
        if not names:
            raise QTOMDecayError("French ZIP contains no CSV file")
        text=z.read(names[0]).decode("utf-8-sig",errors="replace")

    rows=[]
    for line in text.splitlines():
        parts=[p.strip() for p in line.split(",")]
        if len(parts)<5:
            continue
        date_token=parts[0]
        if len(date_token)!=8 or not date_token.isdigit():
            continue
        try:
            mktrf=float(parts[1])
            rf=float(parts[4])
        except ValueError:
            continue
        rows.append({
            "date":pd.to_datetime(date_token,format="%Y%m%d"),
            "mkt_rf_pct":mktrf,
            "rf_pct":rf,
            "return":(mktrf+rf)/100.0,
        })

    if len(rows)<2:
        raise QTOMDecayError("Unable to parse French daily observations")

    df=pd.DataFrame(rows).sort_values("date").drop_duplicates("date",keep="last").reset_index(drop=True)
    # Synthesize a wealth index only because the shared event-map code expects
    # close/adj_close. Returns remain the source of truth.
    wealth=100.0*np.cumprod(1.0+df["return"].fillna(0.0))
    df["close"]=wealth
    df["adj_close"]=wealth
    return df, {
        "provider":"Kenneth French Data Library",
        "dataset":"Fama/French 3 Factors [Daily]",
        "market_return_definition":"(Mkt-RF + RF) / 100",
        "download_url":FRENCH_DAILY_URL,
        "download_sha256":source_sha256,
    }

def fetch_french(cfg):
    try:
        with urllib.request.urlopen(FRENCH_DAILY_URL,timeout=60) as r:
            raw=r.read()
    except Exception as e:
        raise QTOMDecayError(f"French download failed: {e}") from e
    df,provenance=parse_french_daily_bytes(raw)
    if len(df)<100:
        raise QTOMDecayError("French daily dataset returned fewer than 100 observations")
    return df,provenance
def fetch_file(cfg):
    p=Path(cfg.data_file).expanduser()
    if not p.exists(): raise QTOMDecayError(f"File not found: {p}")
    df=pd.read_stata(p) if p.suffix.lower()==".dta" else pd.read_csv(p)
    return _normalize(df)

def get_data(cfg):
    source=cfg.source.lower()
    if source=="yahoo":
        df=fetch_yahoo(cfg)
        provenance={
            "provider":"Yahoo Finance via yfinance",
            "symbol":cfg.symbol,
            "return_definition":"provider adjusted-close percentage change",
        }
    elif source=="french":
        df,provenance=fetch_french(cfg)
    elif source=="file":
        df=fetch_file(cfg)
        provenance={
            "provider":"user file",
            "path":str(Path(cfg.data_file).expanduser()),
            "return_definition":"adjusted-close percentage change",
        }
    else:
        raise QTOMDecayError("source() must be yahoo, french, or file")

    if cfg.start: df=df[df["date"]>=pd.Timestamp(cfg.start)]
    if cfg.end: df=df[df["date"]<=pd.Timestamp(cfg.end)]
    df=df.reset_index(drop=True)
    if len(df)<100: raise QTOMDecayError("At least 100 observations required")
    return df,provenance

def publication_regime(d):
    d=pd.Timestamp(d)
    if d<PUBLICATION_CUTOFF: return "PRE_PUBLICATION"
    if d<DECIMAL_CUTOFF: return "PUBLISHED_PRE_DECIMAL"
    if d<T2_CUTOFF: return "POST_DECIMAL_PRE_T2"
    if d<T1_CUTOFF: return "T2"
    return "T1"

def settlement_regime(d):
    d=pd.Timestamp(d)
    if d<T3_CUTOFF: return "T5"
    if d<T2_CUTOFF: return "T3"
    if d<T1_CUTOFF: return "T2"
    return "T1"

def build_event_map(df):
    """
    Literature-aligned event time:
      T = 0 = last trading day of month
      T-k = negative integers
      T+k = positive integers in next month

    Map covers T-10 ... T ... T+10.
    """
    x=df.copy()
    x["month"]=x["date"].dt.to_period("M")
    months=sorted(x["month"].unique())
    rows=[]
    for m in months[:-1]:
        cur=x[x["month"]==m]
        nxt=x[x["month"]==(m+1)]
        if len(cur)<11 or len(nxt)<10: continue
        me=cur["date"].iloc[-1]

        pre=cur.iloc[-11:].copy()
        pre["relative_day"]=range(-10,1)       # ...,-1,0 where 0 is T
        post=nxt.iloc[:10].copy()
        post["relative_day"]=range(1,11)

        z=pd.concat([pre,post],ignore_index=True)
        for _,r in z.iterrows():
            rows.append({
                "event_month":str(m),
                "event_month_end":me,
                "date":r["date"],
                "relative_day":int(r["relative_day"]),
                "return":float(r["return"]) if pd.notna(r["return"]) else np.nan,
                "publication_regime":publication_regime(me),
                "settlement_regime":settlement_regime(me),
                "quarter_end":int(m.month in {3,6,9,12}),
                "semi_year_end":int(m.month in {6,12}),
            })

    out=pd.DataFrame(rows)
    if out.empty: raise QTOMDecayError("Unable to build event map")
    out["tom_day"]=out["relative_day"].isin([0,1,2,3]).astype(int)
    return out

def build_daily_labels(df, events):
    """
    Full daily sample. TOM is canonical T,T+1,T+2,T+3.
    All other trading days are the comparison group.
    """
    canonical_dates=set(
        pd.to_datetime(events.loc[events["relative_day"].isin([0,1,2,3]),"date"])
    )
    out=df[["date","return"]].copy()
    out["tom_day"]=out["date"].isin(canonical_dates).astype(int)
    out["publication_regime"]=out["date"].map(publication_regime)
    out["settlement_regime"]=out["date"].map(settlement_regime)
    return out

def automatic_hac_lags(n):
    return int(math.floor(4*(n/100)**(2/9))) if n>0 else 0

def ols_hac(y,X,nlags=-1):
    y=np.asarray(y,float); X=np.asarray(X,float)
    ok=np.isfinite(y)&np.all(np.isfinite(X),axis=1)
    y=y[ok]; X=X[ok]
    n,k=X.shape
    if n<=k+5: raise QTOMDecayError("Insufficient observations for HAC regression")
    if nlags<0: nlags=automatic_hac_lags(n)
    nlags=min(int(nlags),n-1)
    inv=np.linalg.inv(X.T@X)
    b=inv@(X.T@y)
    u=y-X@b
    xu=X*u[:,None]
    S=xu.T@xu
    for lag in range(1,nlags+1):
        w=1-lag/(nlags+1)
        g=xu[lag:].T@xu[:-lag]
        S+=w*(g+g.T)
    cov=inv@S@inv*n/(n-k)
    se=np.sqrt(np.maximum(np.diag(cov),0))
    return b,se,nlags

def pval(z):
    return 2*(1-ND.cdf(abs(float(z))))

def premium_summary(daily,col,hac_lags=-1):
    rows=[]
    for reg,z in daily.groupby(col,sort=False):
        z=z.dropna(subset=["return"]).copy()
        if len(z)<50: continue
        y=z["return"].to_numpy(float)
        tom=z["tom_day"].to_numpy(float)
        b,se,L=ols_hac(y,np.column_stack([np.ones(len(z)),tom]),hac_lags)
        zz=b[1]/se[1] if se[1]>0 else np.nan
        tr=z.loc[z.tom_day==1,"return"]
        nr=z.loc[z.tom_day==0,"return"]
        rows.append({
            "regime_type":col,"regime":reg,"observations":len(z),
            "tom_days":int(z.tom_day.sum()),
            "tom_daily_mean":float(tr.mean()),
            "all_other_days_mean":float(nr.mean()),
            "tom_minus_all_other_daily":float(b[1]),
            "hac_se":float(se[1]),"hac_z":float(zz),
            "hac_p":float(pval(zz)) if np.isfinite(zz) else np.nan,
            "hac_lags":int(L),
            "tom_win_rate":float((tr>0).mean()),
            "other_win_rate":float((nr>0).mean()),
        })
    return pd.DataFrame(rows)

def adjacent_regime_tests(daily,col,order,hac_lags=-1):
    rows=[]
    for a,bname in zip(order[:-1],order[1:]):
        z=daily[daily[col].isin([a,bname])].dropna(subset=["return"]).copy()
        if z[col].nunique()<2: continue
        z["group_b"]=(z[col]==bname).astype(float)
        z["interaction"]=z["tom_day"]*z["group_b"]
        X=np.column_stack([np.ones(len(z)),z.tom_day,z.group_b,z.interaction])
        beta,se,L=ols_hac(z["return"],X,hac_lags)
        zz=beta[3]/se[3] if se[3]>0 else np.nan
        rows.append({
            "regime_type":col,"regime_a":a,"regime_b":bname,
            "observations":len(z),
            "tom_premium_a":float(beta[1]),
            "tom_premium_b":float(beta[1]+beta[3]),
            "change_b_minus_a":float(beta[3]),
            "change_hac_se":float(se[3]),
            "change_hac_z":float(zz),
            "change_hac_p":float(pval(zz)) if np.isfinite(zz) else np.nan,
            "hac_lags":int(L),
        })
    return pd.DataFrame(rows)

def cutoff_break_test(daily,cutoff,label,hac_lags=-1):
    z=daily.dropna(subset=["return"]).copy()
    z["post"]=(z.date>=cutoff).astype(float)
    z["interaction"]=z.tom_day*z.post
    if z.post.nunique()<2: return None
    X=np.column_stack([np.ones(len(z)),z.tom_day,z.post,z.interaction])
    b,se,L=ols_hac(z["return"],X,hac_lags)
    zz=b[3]/se[3] if se[3]>0 else np.nan
    return {
        "break_name":label,"cutoff":cutoff,"observations":len(z),
        "tom_premium_pre":float(b[1]),
        "tom_premium_post":float(b[1]+b[3]),
        "change_post_minus_pre":float(b[3]),
        "change_hac_se":float(se[3]),
        "change_hac_z":float(zz),
        "change_hac_p":float(pval(zz)) if np.isfinite(zz) else np.nan,
        "hac_lags":int(L),
    }

def break_tests(daily,hac_lags=-1):
    specs=[
        ("PUBLICATION_ERA_1987",PUBLICATION_CUTOFF),
        ("SETTLEMENT_T5_TO_T3_1995",T3_CUTOFF),
        ("DECIMALIZATION_2001",DECIMAL_CUTOFF),
        ("SETTLEMENT_T3_TO_T2_2017",T2_CUTOFF),
        ("SETTLEMENT_T2_TO_T1_2024",T1_CUTOFF),
    ]
    return pd.DataFrame([
        r for label,cutoff in specs
        if (r:=cutoff_break_test(daily,cutoff,label,hac_lags)) is not None
    ])

def relative_day_map(events):
    rows=[]
    for col in ["publication_regime","settlement_regime"]:
        for (reg,rel),z in events.groupby([col,"relative_day"],sort=False):
            r=z["return"].dropna()
            rows.append({
                "regime_type":col,"regime":reg,"relative_day":int(rel),
                "observations":len(r),"mean_return":float(r.mean()),
                "median_return":float(r.median()),
                "positive_pct":float((r>0).mean()),
                "std_return":float(r.std(ddof=1)) if len(r)>1 else np.nan,
            })
    return pd.DataFrame(rows)

def _compound(daymap,days):
    vals=[daymap.get(d,np.nan) for d in days]
    if not all(np.isfinite(vals)): return np.nan
    return float(np.prod([1+v for v in vals])-1)

def event_months(events):
    rows=[]
    for em,z in events.groupby("event_month",sort=False):
        m=dict(zip(z.relative_day,z["return"]))
        b=z.iloc[0]
        rows.append({
            "event_month":em,"event_month_end":b.event_month_end,
            "publication_regime":b.publication_regime,
            "settlement_regime":b.settlement_regime,
            "quarter_end":int(b.quarter_end),
            "semi_year_end":int(b.semi_year_end),
            # Exact Rinne/Suominen/Vaittinen windows where T=0.
            "selling_pressure_t8_t4":_compound(m,[-8,-7,-6,-5,-4]),
            "positive_reversal_t3_t1":_compound(m,[-3,-2,-1]),
            "buying_pressure_t_p3":_compound(m,[0,1,2,3]),
            "canonical_tom_t_p3":_compound(m,[0,1,2,3]),
            # Broader seven-day rebound around the turn.
            "broad_rebound_t3_p3":_compound(m,[-3,-2,-1,0,1,2,3]),
        })
    return pd.DataFrame(rows)

def pressure_reversal(months,hac_lags=-1):
    z=months.dropna(subset=["selling_pressure_t8_t4","positive_reversal_t3_t1"]).copy()
    if len(z)<20: return {},pd.DataFrame()

    corr=float(z[["selling_pressure_t8_t4","positive_reversal_t3_t1"]].corr().iloc[0,1])
    z["negative_pressure"]=(z.selling_pressure_t8_t4<0).astype(float)

    # Monthly HAC regression: reversal = a + b*I(prior pressure < 0)
    X=np.column_stack([np.ones(len(z)),z.negative_pressure])
    b,se,L=ols_hac(z.positive_reversal_t3_t1,X,hac_lags)
    zz=b[1]/se[1] if se[1]>0 else np.nan

    neg=z[z.negative_pressure==1].positive_reversal_t3_t1
    pos=z[z.negative_pressure==0].positive_reversal_t3_t1

    summary={
        "months":int(len(z)),
        "pressure_reversal_corr":corr,
        "reversal_after_negative_pressure_mean":float(neg.mean()),
        "reversal_after_nonnegative_pressure_mean":float(pos.mean()),
        "difference_negative_minus_nonnegative":float(b[1]),
        "difference_hac_se":float(se[1]),
        "difference_hac_z":float(zz),
        "difference_hac_p":float(pval(zz)) if np.isfinite(zz) else np.nan,
        "hac_lags":int(L),
        "negative_pressure_months":int(len(neg)),
        "nonnegative_pressure_months":int(len(pos)),
    }

    by_reg=[]
    for reg,g in z.groupby("settlement_regime",sort=False):
        by_reg.append({
            "settlement_regime":reg,"months":len(g),
            "pressure_reversal_corr":float(g[["selling_pressure_t8_t4","positive_reversal_t3_t1"]].corr().iloc[0,1]),
            "selling_pressure_mean":float(g.selling_pressure_t8_t4.mean()),
            "positive_reversal_mean":float(g.positive_reversal_t3_t1.mean()),
            "buying_pressure_mean":float(g.buying_pressure_t_p3.mean()),
        })
    return summary,pd.DataFrame(by_reg)

def settlement_timing_summary(events):
    rows=[]
    for reg,z in events.groupby("settlement_regime",sort=False):
        means=z.groupby("relative_day")["return"].mean()
        pre=means.loc[[d for d in range(-8,0) if d in means.index]]
        rebound=means.loc[[d for d in range(-3,4) if d in means.index]]
        rows.append({
            "settlement_regime":reg,
            "event_months":z.event_month.nunique(),
            "pressure_trough_day":int(pre.idxmin()) if len(pre) else np.nan,
            "pressure_trough_mean_return":float(pre.min()) if len(pre) else np.nan,
            "rebound_peak_day":int(rebound.idxmax()) if len(rebound) else np.nan,
            "rebound_peak_mean_return":float(rebound.max()) if len(rebound) else np.nan,
        })
    return pd.DataFrame(rows)

def calendar_concentration(months,hac_lags=-1):
    z=months.dropna(subset=["canonical_tom_t_p3"]).copy()
    z["calendar_group"]="REGULAR"
    z.loc[z.quarter_end==1,"calendar_group"]="QUARTER_END"
    z.loc[z.semi_year_end==1,"calendar_group"]="SEMI_YEAR_END"
    rows=[]
    for grp,g in z.groupby("calendar_group",sort=False):
        y=g.canonical_tom_t_p3.to_numpy(float)
        b,se,L=ols_hac(y,np.ones((len(y),1)),hac_lags) if len(y)>10 else ([np.nan],[np.nan],0)
        zz=b[0]/se[0] if np.isfinite(se[0]) and se[0]>0 else np.nan
        rows.append({
            "calendar_group":grp,"months":len(g),
            "mean_canonical_tom_return":float(g.canonical_tom_t_p3.mean()),
            "median_canonical_tom_return":float(g.canonical_tom_t_p3.median()),
            "positive_pct":float((g.canonical_tom_t_p3>0).mean()),
            "mean_hac_se":float(se[0]) if np.isfinite(se[0]) else np.nan,
            "mean_hac_z":float(zz) if np.isfinite(zz) else np.nan,
            "mean_hac_p":float(pval(zz)) if np.isfinite(zz) else np.nan,
            "hac_lags":int(L),
        })
    return pd.DataFrame(rows)


def rolling_premium(daily,years=10,hac_lags=-1):
    """
    Annual endpoints with an exact trailing N-year calendar window.
    This is descriptive time variation, not an optimization.
    """
    z=daily.dropna(subset=["return"]).copy()
    first=z.date.min()
    last=z.date.max()
    endpoints=pd.date_range(
        start=pd.Timestamp(first.year+years,12,31),
        end=pd.Timestamp(last.year,12,31),
        freq=pd.offsets.YearEnd()
    )
    rows=[]
    for endpoint in endpoints:
        start=endpoint-pd.DateOffset(years=years)
        w=z[(z.date>start)&(z.date<=endpoint)]
        if len(w)<years*200:
            continue
        y=w["return"].to_numpy(float)
        tom=w["tom_day"].to_numpy(float)
        b,se,L=ols_hac(y,np.column_stack([np.ones(len(w)),tom]),hac_lags)
        zz=b[1]/se[1] if se[1]>0 else np.nan
        crit=ND.inv_cdf(.975)
        rows.append({
            "window_end":endpoint,
            "window_start":start,
            "years":int(years),
            "observations":len(w),
            "tom_days":int(w.tom_day.sum()),
            "tom_premium_daily":float(b[1]),
            "hac_se":float(se[1]),
            "ci95_lo":float(b[1]-crit*se[1]),
            "ci95_hi":float(b[1]+crit*se[1]),
            "hac_z":float(zz),
            "hac_p":float(pval(zz)) if np.isfinite(zz) else np.nan,
            "hac_lags":int(L),
        })
    return pd.DataFrame(rows)

def pairwise_calendar_tests(months,hac_lags=-1):
    z=months.dropna(subset=["canonical_tom_t_p3"]).copy()
    z["calendar_group"]="REGULAR"
    z.loc[z.quarter_end==1,"calendar_group"]="QUARTER_ONLY"
    z.loc[z.semi_year_end==1,"calendar_group"]="SEMI_YEAR"

    pairs=[("REGULAR","QUARTER_ONLY"),("REGULAR","SEMI_YEAR"),("QUARTER_ONLY","SEMI_YEAR")]
    rows=[]
    for a,bname in pairs:
        w=z[z.calendar_group.isin([a,bname])].copy()
        if w.calendar_group.nunique()<2:
            continue
        w["group_b"]=(w.calendar_group==bname).astype(float)
        X=np.column_stack([np.ones(len(w)),w.group_b])
        b,se,L=ols_hac(w.canonical_tom_t_p3,X,hac_lags)
        zz=b[1]/se[1] if se[1]>0 else np.nan
        rows.append({
            "group_a":a,"group_b":bname,"months":len(w),
            "mean_a":float(w.loc[w.calendar_group==a,"canonical_tom_t_p3"].mean()),
            "mean_b":float(w.loc[w.calendar_group==bname,"canonical_tom_t_p3"].mean()),
            "difference_b_minus_a":float(b[1]),
            "difference_hac_se":float(se[1]),
            "difference_hac_z":float(zz),
            "difference_hac_p":float(pval(zz)) if np.isfinite(zz) else np.nan,
            "hac_lags":int(L),
        })
    return pd.DataFrame(rows)

def exploratory_breakpoint(daily,min_years=10,hac_lags=-1):
    """
    Search year-end cutoffs for the largest absolute standardized change in
    TOM premium. This is exploratory by construction.

    No multiplicity-adjusted p-value is claimed. We report the naive HAC p
    only as a diagnostic and label it unadjusted.
    """
    z=daily.dropna(subset=["return"]).copy()
    start_year=int(z.date.dt.year.min())
    end_year=int(z.date.dt.year.max())
    candidates=range(start_year+min_years,end_year-min_years+1)
    rows=[]
    for year in candidates:
        cutoff=pd.Timestamp(f"{year}-01-01")
        w=z.copy()
        w["post"]=(w.date>=cutoff).astype(float)
        w["interaction"]=w.tom_day*w.post
        if w.post.nunique()<2:
            continue
        X=np.column_stack([np.ones(len(w)),w.tom_day,w.post,w.interaction])
        b,se,L=ols_hac(w["return"],X,hac_lags)
        if se[3]<=0 or not np.isfinite(se[3]):
            continue
        zz=b[3]/se[3]
        rows.append({
            "candidate_year":int(year),
            "cutoff":cutoff,
            "tom_premium_pre":float(b[1]),
            "tom_premium_post":float(b[1]+b[3]),
            "change_post_minus_pre":float(b[3]),
            "change_hac_se":float(se[3]),
            "change_hac_z":float(zz),
            "naive_hac_p_unadjusted":float(pval(zz)),
            "hac_lags":int(L),
        })
    grid=pd.DataFrame(rows)
    if grid.empty:
        return {},grid
    best=grid.iloc[grid.change_hac_z.abs().argmax()]
    summary={
        "status":"EXPLORATORY_NOT_CONFIRMATORY",
        "criterion":"maximum absolute HAC z for TOM interaction change",
        "minimum_years_each_side":int(min_years),
        "selected_year":int(best.candidate_year),
        "selected_cutoff":best.cutoff,
        "tom_premium_pre":float(best.tom_premium_pre),
        "tom_premium_post":float(best.tom_premium_post),
        "change_post_minus_pre":float(best.change_post_minus_pre),
        "change_hac_z":float(best.change_hac_z),
        "naive_hac_p_unadjusted":float(best.naive_hac_p_unadjusted),
        "warning":"p-value is not multiplicity-adjusted and must not be read as a confirmatory test",
    }
    return summary,grid
def _safe(df):
    out=df.copy().replace([np.inf,-np.inf],np.nan)
    for c in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[c]):
            out[c]=pd.to_datetime(out[c]).dt.tz_localize(None)
        elif out[c].dtype==object:
            out[c]=out[c].astype(str)
    return out

def _write(df,base):
    df.to_csv(base.with_suffix(".csv"),index=False)
    _safe(df).to_stata(base.with_suffix(".dta"),write_index=False,version=118)

def run(cfg,market_data=None):
    if market_data is not None:
        df=_normalize(market_data)
        provenance={"provider":"synthetic/injected test data"}
    else:
        df,provenance=get_data(cfg)

    events=build_event_map(df)
    daily=build_daily_labels(df,events)

    pub=premium_summary(daily,"publication_regime",cfg.hac_lags)
    sett=premium_summary(daily,"settlement_regime",cfg.hac_lags)
    pub_adj=adjacent_regime_tests(daily,"publication_regime",PUBLICATION_ORDER,cfg.hac_lags)
    sett_adj=adjacent_regime_tests(daily,"settlement_regime",SETTLEMENT_ORDER,cfg.hac_lags)
    br=break_tests(daily,cfg.hac_lags)
    rel=relative_day_map(events)
    months=event_months(events)
    pressure,pressure_reg=pressure_reversal(months,cfg.hac_lags)
    timing=settlement_timing_summary(events)
    calendar=calendar_concentration(months,cfg.hac_lags)
    calendar_tests=pairwise_calendar_tests(months,cfg.hac_lags)
    rolling=rolling_premium(daily,cfg.rolling_years,cfg.hac_lags)
    exploratory,exploratory_grid=exploratory_breakpoint(
        daily,cfg.breakpoint_min_years,cfg.hac_lags
    )

    out=Path(cfg.output).expanduser().resolve()
    out.mkdir(parents=True,exist_ok=True)

    tables={
        "publication_regime_summary":pub,
        "settlement_regime_summary":sett,
        "publication_adjacent_tests":pub_adj,
        "settlement_adjacent_tests":sett_adj,
        "break_tests":br,
        "relative_day_map":rel,
        "event_months":months,
        "pressure_reversal_by_settlement":pressure_reg,
        "settlement_timing_summary":timing,
        "calendar_concentration":calendar,
        "calendar_pairwise_tests":calendar_tests,
        "rolling_premium":rolling,
        "exploratory_breakpoint_grid":exploratory_grid,
    }
    for name,tab in tables.items():
        _write(tab,out/name)

    report={
        "schema":"qtomdecay-v0.3","version":VERSION,
        "symbol":cfg.symbol,"source":cfg.source,
        "source_provenance":provenance,
        "start":str(df.date.min().date()),"end":str(df.date.max().date()),
        "canonical_tom_days":[0,1,2,3],
        "event_time_definition":"T=0 is the last trading day of each month",
        "rolling_years":int(cfg.rolling_years),
        "pressure_windows":{
            "selling_pressure":"T-8..T-4",
            "positive_reversal":"T-3..T-1",
            "buying_pressure":"T..T+3",
        },
        "cutoffs":{
            "publication_era":"1987-01-01",
            "T5_to_T3":"1995-06-07",
            "decimalization_complete":"2001-04-09",
            "T3_to_T2":"2017-09-05",
            "T2_to_T1":"2024-05-28",
        },
        "pressure_reversal":pressure,
        "exploratory_breakpoint":exploratory,
        "methodology_notes":[
            "TOM premium is measured against all other trading days.",
            "Externally fixed cutoff tests are confirmatory/descriptive relative to the research plan.",
            "The automatic breakpoint search is explicitly exploratory and its naive p-value is not multiplicity-adjusted.",
            "Rolling windows are descriptive and use a fixed trailing calendar length.",
            "No TOM window optimization is performed.",
        ],
        "warnings":[
            "1987 is a publication-era boundary, not an exact market-awareness date.",
            "Structural cutoffs correlate with broader market evolution; they are not standalone causal identification.",
            "T+1 history is short and exploratory.",
            "Yahoo and Kenneth French/CRSP-market-proxy differ in both provider and market-universe definition.",
            "For ^GSPC, Yahoo represents the provider's index series; for French, market return is Mkt-RF + RF.",
        ],
    }
    (out/"research_report.json").write_text(json.dumps(report,indent=2,default=str))

    man={
        "schema":"qtomdecay-manifest-v0.3","version":VERSION,
        "created_at_utc":datetime.now(timezone.utc).isoformat(),
        "source_provenance":provenance,
        "files":{}
    }
    for p in sorted(out.iterdir()):
        if p.is_file() and p.name!="manifest.json":
            man["files"][p.name]={"bytes":p.stat().st_size,"sha256":_sha256(p)}
    (out/"manifest.json").write_text(json.dumps(man,indent=2,default=str))

    return {
        "publication_summary":pub,
        "settlement_summary":sett,
        "publication_adjacent_tests":pub_adj,
        "settlement_adjacent_tests":sett_adj,
        "break_tests":br,
        "relative_day_map":rel,
        "event_months":months,
        "pressure_reversal":pressure,
        "pressure_reversal_by_settlement":pressure_reg,
        "settlement_timing_summary":timing,
        "calendar_concentration":calendar,
        "calendar_pairwise_tests":calendar_tests,
        "rolling_premium":rolling,
        "exploratory_breakpoint":exploratory,
        "exploratory_breakpoint_grid":exploratory_grid,
        "provenance":provenance,
        "output":out,
    }

def main(argv=None):
    argv=argv or sys.argv
    cfg=Config(
        symbol=argv[1],
        source=argv[2] or "yahoo",
        start=argv[3] or "1950-01-01",
        end=argv[4],
        hac_lags=int(argv[5]),
        rolling_years=int(argv[6]),
        breakpoint_min_years=int(argv[7]),
        output=argv[8],
        data_file=argv[9] if len(argv)>9 else ""
    )
    r=run(cfg)
    print(f"QTOMDECAY_OK|{r['output']}")
    print("\nSOURCE PROVENANCE")
    print(json.dumps(r["provenance"],indent=2,default=str))
    print("\nALL-DAY PUBLICATION / MICROSTRUCTURE REGIMES")
    print(r["publication_summary"].to_string(index=False))
    print("\nALL-DAY SETTLEMENT REGIMES")
    print(r["settlement_summary"].to_string(index=False))
    print("\nADJACENT PUBLICATION REGIME TESTS")
    print(r["publication_adjacent_tests"].to_string(index=False))
    print("\nADJACENT SETTLEMENT REGIME TESTS")
    print(r["settlement_adjacent_tests"].to_string(index=False))
    print("\nCUMULATIVE CUTOFF BREAK TESTS")
    print(r["break_tests"].to_string(index=False))
    print("\nPRESSURE / REVERSAL")
    print(json.dumps(r["pressure_reversal"],indent=2))
    print("\nCALENDAR PAIRWISE TESTS")
    print(r["calendar_pairwise_tests"].to_string(index=False))
    print("\nROLLING PREMIUM — LAST 12 WINDOWS")
    print(r["rolling_premium"].tail(12).to_string(index=False))
    print("\nEXPLORATORY BREAKPOINT")
    print(json.dumps(r["exploratory_breakpoint"],indent=2,default=str))

if __name__=="__main__": main()

{smcl}
{title:qtomdecay v0.3.1 — TOM anomaly decay research map}

{p 4 4 2}
Fixed canonical TOM days T,T+1,T+2,T+3. No TOM-window optimization.

{p 4 4 2}
Sources:
{cmd:source(yahoo)} uses the selected Yahoo symbol.
{cmd:source(french)} downloads the official Fama/French 3 Factors Daily file
and reconstructs the broad U.S. market return as Mkt-RF + RF.
{cmd:source(file)} uses a local CSV/DTA.

{p 4 4 2}
v0.3 adds a trailing rolling premium with HAC 95% CI, direct regular/quarter/
semi-year tests, and a clearly labeled exploratory breakpoint search.

{phang2}
{cmd:. qtomdecay ^GSPC, source(yahoo) from("1950-01-01") save("/tmp/gspc_decay") replace}

{phang2}
{cmd:. qtomdecay USMKT, source(french) from("1926-07-01") save("/tmp/french_decay") replace}

import { PRICE_BASIS } from "./contract.ts";
import { bytesHash, finite, positive } from "./math.ts";
import { validDate, weakest } from "./temporal.ts";
import type { ContractIdentity, Packet, Row, Temporal, VxPacket } from "./types.ts";
const record = (x: unknown): Record<string, unknown> => x !== null && typeof x === "object" && !Array.isArray(x) ? x as Record<string, unknown> : {};
const array = (x: unknown): unknown[] => Array.isArray(x) ? x : [];
const text = (x: unknown): string => typeof x === "string" ? x : "";
export function parseNumericCell(value: unknown): number | null {
  if (finite(value)) return value;
  if (typeof value !== "string") return null;
  let s = value.trim().replaceAll(",", "");
  if (/^\([\d.]+\)$/.test(s)) s = "-" + s.slice(1, -1);
  return /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(s) && finite(Number(s)) ? Number(s) : null;
}
function dated(date: string): Row {
  return { observationDate: date, observationEndAt: date + "T23:59:59.999999Z", observationEndCertainty: "CONSERVATIVE_BOUND", sourcePublishedAt: null };
}
function parseJson(bytes: string): unknown { try { return JSON.parse(bytes); } catch { return null; } }
function csvRows(csv: string): Record<string, string>[] {
  const rows: string[][] = []; let row: string[] = [], cell = "", quoted = false;
  for (let i = 0; i < csv.length; i++) {
    const c = csv[i];
    if (c === '"') { if (quoted && csv[i + 1] === '"') { cell += '"'; i++; } else quoted = !quoted; }
    else if (!quoted && (c === "," || c === "\n")) { row.push(cell.replace(/\r$/, "")); cell = ""; if (c === "\n") { rows.push(row); row = []; } }
    else cell += c;
  }
  if (cell || row.length) { row.push(cell.replace(/\r$/, "")); rows.push(row); }
  if (quoted || !rows.length) return [];
  const headers = rows.shift()!.map(s => s.replace(/^\uFEFF/, "").trim());
  return rows.filter(r => r.length === headers.length).map(r => Object.fromEntries(headers.map((h, i) => [h, r[i]])));
}
export function normalizeYahoo(bytes: string, metadata: Temporal, expectedTicker: string): Packet {
  const payload = record(parseJson(bytes)), chart = record(payload.chart), result = record(array(chart.result)[0]);
  const meta = record(result.meta), indicators = record(result.indicators), adjusted = array(record(array(indicators.adjclose)[0]).adjclose);
  const zone = text(meta.exchangeTimezoneName);
  let validZone = true; try { if (!zone) throw Error(); new Intl.DateTimeFormat("en", { timeZone: zone }); } catch { validZone = false; }
  const packet: Packet = { ...metadata, vintageHash: bytesHash(bytes), sourceId: "EQUITY_ADJUSTED", sourceField: "chart.result[0].indicators.adjclose[0].adjclose", seriesType: "ETF_ADJUSTED_PRICE", priceBasis: PRICE_BASIS, currency: text(meta.currency), rows: [], status: metadata.status ?? "AVAILABLE" };
  if (chart.error || !validZone || meta.symbol !== expectedTicker || meta.currency !== "USD") return { ...packet, status: "INVALID" };
  for (const [index, timestamp] of array(result.timestamp).entries()) {
    if (!finite(timestamp)) continue;
    const instant = new Date(timestamp * 1000);
    if (!finite(instant.valueOf())) continue;
    const parts = new Intl.DateTimeFormat("en", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(instant);
    const value = (kind: string) => parts.find(p => p.type === kind)?.value;
    const date = `${value("year")}-${value("month")}-${value("day")}`;
    // No quote.close read exists on this path. Missing adjclose remains missing.
    packet.rows.push({ ...dated(date), adjusted_close: positive(adjusted[index]) ? adjusted[index] : null });
  }
  packet.declaredStart = packet.rows.map(r => r.observationDate!).sort()[0];
  return packet;
}
export function normalizeVixCsv(bytes: string, metadata: Temporal): Packet {
  const rows = csvRows(bytes).map(row => {
    const parts = /^([0-9]{1,2})\/([0-9]{1,2})\/(\d{4})$/.exec(row.DATE ?? "");
    const date = parts ? `${parts[3]}-${parts[1].padStart(2, "0")}-${parts[2].padStart(2, "0")}` : "";
    const value = parseNumericCell(row.CLOSE);
    return { ...dated(date), value: positive(value) ? value : null };
  }).filter(r => validDate(r.observationDate));
  return { ...metadata, sourceId: "VIX_OFFICIAL", sourceField: "DATE,CLOSE", vintageHash: bytesHash(bytes), seriesType: "OFFICIAL_VIX_INDEX", rows, declaredStart: rows.map(r => r.observationDate!).sort()[0], status: metadata.status ?? "AVAILABLE" };
}
export type MonthlyHistory = { identity: ContractIdentity; metadata: Temporal; rows: Row[] };
export function normalizeVxHistory(bytes: string, identity: ContractIdentity, metadata: Temporal): MonthlyHistory {
  const rows = csvRows(bytes).map(row => ({ ...dated(row["Trade Date"]), settlement: parseNumericCell(row.Settle) })).filter(row => validDate(row.observationDate));
  return { identity, metadata: { ...metadata, sourceId: "VX_OFFICIAL", vintageHash: bytesHash(bytes) }, rows };
}
export function normalizeMonthlyCatalog(payload: unknown): ContractIdentity[] {
  const entries = Array.isArray(payload) ? payload : Object.values(record(payload)).flatMap(array);
  return entries.map(record).filter(row => row.duration_type === "M" && row.futures_root === "VX" && validDate(row.expire_date)).map(row => ({ symbol: "VX/" + text(row.product_display).split("/").at(-1), expirationDate: text(row.expire_date) })).filter(row => /^VX\/[FGHJKMNQUVXZ]\d$/.test(row.symbol)).sort((a, b) => a.expirationDate.localeCompare(b.expirationDate));
}
export function assembleVx(date: string, catalog: ContractIdentity[], catalogMetadata: Temporal, histories: MonthlyHistory[]): VxPacket {
  const expected = catalog.filter(r => r.expirationDate > date).slice(0, 9);
  const contributing = expected.slice(0, 2).map(identity => histories.find(h => h.identity.expirationDate === identity.expirationDate && h.identity.symbol === identity.symbol));
  const ancestry = [catalogMetadata, ...contributing.map(h => h?.metadata ?? {})];
  const known = ancestry.every(m => m.availableAt && ["EXACT", "CONSERVATIVE_BOUND"].includes(m.availabilityCertainty ?? "UNKNOWN"));
  const contracts = expected.map(identity => {
    const history = histories.find(h => h.identity.symbol === identity.symbol && h.identity.expirationDate === identity.expirationDate);
    const rows = history?.rows.filter(r => r.observationDate === date) ?? [];
    const value = rows.length === 1 ? rows[0].settlement : null;
    return { ...identity, settlement: positive(value) ? value : null };
  });
  return { ...dated(date), sourceId: "VX_OFFICIAL", sourceVersion: catalogMetadata.sourceVersion, vintageHash: bytesHash(JSON.stringify(ancestry.map(m => m.vintageHash))),
    capturedAt: known ? ancestry.map(m => m.capturedAt).filter((v): v is string => !!v).sort().at(-1) : null,
    availableAt: known ? ancestry.map(m => m.availableAt!).sort().at(-1) : null, availabilityCertainty: known ? "CONSERVATIVE_BOUND" : "UNKNOWN",
    replayClass: weakest(ancestry.map(m => m.replayClass)), availabilityEvidence: ancestry.every(m => !!m.availabilityEvidence) ? ancestry.map(m => m.availabilityEvidence).join(";") : undefined,
    status: new Set(expected.map(r => r.expirationDate)).size !== expected.length || ancestry.some(m => m.status && m.status !== "AVAILABLE") ? "INVALID" : "AVAILABLE",
    seriesType: "OFFICIAL_MONTHLY_VX_SETTLEMENT", expectedContracts: expected, contracts };
}
function flowDate(value: unknown): string {
  if (validDate(value)) return value;
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const match = /^(\d{1,2}) ([A-Z][a-z]{2}) (\d{4})$/.exec(text(value));
  if (!match || !months.includes(match[2])) return "";
  return `${match[3]}-${String(months.indexOf(match[2]) + 1).padStart(2, "0")}-${match[1].padStart(2, "0")}`;
}
export function normalizeBtcTable(payload: unknown, metadata: Temporal): Packet {
  const p = record(payload), columns = array(p.columns).map(text), expectedFunds = columns.filter(c => c !== "Date" && c !== "Total");
  const rows = array(p.rows).map(array).map(cells => {
    const date = flowDate(cells[columns.indexOf("Date")]);
    const funds = Object.fromEntries(expectedFunds.map(fund => [fund, parseNumericCell(cells[columns.indexOf(fund)])]));
    const reported = parseNumericCell(cells[columns.indexOf("Total")]);
    const allObserved = expectedFunds.length > 0 && Object.values(funds).every(finite);
    const sum = allObserved ? Object.values(funds).reduce<number>((s, v) => s + v!, 0) : null;
    return { ...dated(date), total: reported ?? sum, reportedTotal: reported, totalDerived: reported === null && sum !== null, reconciliationDifference: reported !== null && sum !== null ? reported - sum : null, funds, coverage: allObserved ? "COMPLETE" : "PARTIAL" };
  }).filter(r => validDate(r.observationDate));
  return { ...metadata, sourceId: "BTC_NATIVE", sourceField: "columns,rows", vintageHash: bytesHash(JSON.stringify(payload)), seriesType: "REPORTED_ETF_NET_FLOW", currency: "USD_MILLIONS", expectedFunds, rows, status: !columns.includes("Date") || !columns.includes("Total") || new Set(columns).size !== columns.length ? "INVALID" : metadata.status ?? "AVAILABLE" };
}
export function normalizeGldRows(payload: unknown, metadata: Temporal, unitEventDates: string[] = []): Packet {
  // Accept dated parsed native fund rows only, never oneDay/twentyDay presentation scalars.
  const rows = array(payload).map(record).map(row => ({ ...dated(text(row.date)), shares: parseNumericCell(row["shares outstanding"] ?? row.sharesOutstanding), nav: parseNumericCell(row.nav), aum: parseNumericCell(row["total net assets"] ?? row.totalNetAssets) })).filter(r => validDate(r.observationDate));
  return { ...metadata, sourceId: "GLD_NATIVE", sourceField: "date,nav,shares outstanding,total net assets", vintageHash: bytesHash(JSON.stringify(payload)), seriesType: "FUND_SHARES_NAV_AUM", rows, unitEventDates, status: Array.isArray(payload) ? metadata.status ?? "AVAILABLE" : "INVALID" };
}
